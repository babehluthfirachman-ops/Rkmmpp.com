// RKM MPP DIGITAL Service Worker - Offline Support & High Speed Caching
const CACHE_NAME = 'rkm-mpp-cache-v2.1';
const STATIC_ASSETS = [
  '/',
  '/index.html',
  '/manifest.json'
];

// External assets to precache / cache on runtime
const PRECACHE_ORIGINS = [
  'fonts.googleapis.com',
  'fonts.gstatic.com',
  'lh3.googleusercontent.com'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(async (cache) => {
      try {
        await cache.addAll(STATIC_ASSETS);
      } catch (err) {
        console.warn('[SW] Cache addAll non-fatal warning:', err);
      }
    })
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) => {
      return Promise.all(
        keys.map((key) => {
          if (key !== CACHE_NAME) {
            console.log('[SW] Deleting legacy cache:', key);
            return caches.delete(key);
          }
        })
      );
    }).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  // Only handle GET requests
  if (event.request.method !== 'GET') return;

  const url = new URL(event.request.url);

  // Skip dev server endpoints, modules, webhook calls, dynamic POST APIs, and script sync endpoints
  if (
    url.pathname.includes('/api/') || 
    url.pathname.includes('/@vite/') || 
    url.pathname.includes('/@fs/') || 
    url.pathname.includes('/node_modules/') || 
    url.pathname.includes('/src/') ||
    url.hostname.includes('script.google.com') || 
    url.hostname.includes('script.googleusercontent.com')
  ) {
    return;
  }

  // Handle Google Fonts and static CDN assets with Cache-First strategy
  if (PRECACHE_ORIGINS.some(origin => url.hostname.includes(origin))) {
    event.respondWith(
      caches.match(event.request).then((cached) => {
        if (cached) return cached;
        return fetch(event.request).then((networkResponse) => {
          if (networkResponse && networkResponse.status === 200) {
            const responseClone = networkResponse.clone();
            caches.open(CACHE_NAME).then((cache) => {
              cache.put(event.request, responseClone);
            });
          }
          return networkResponse;
        }).catch(() => cached);
      })
    );
    return;
  }

  // For app assets (scripts, styles, images) use Stale-While-Revalidate
  event.respondWith(
    caches.match(event.request).then((cachedResponse) => {
      const fetchPromise = fetch(event.request).then((networkResponse) => {
        if (networkResponse && networkResponse.status === 200 && (networkResponse.type === 'basic' || networkResponse.type === 'cors')) {
          const responseToCache = networkResponse.clone();
          caches.open(CACHE_NAME).then((cache) => {
            cache.put(event.request, responseToCache);
          });
        }
        return networkResponse;
      }).catch(() => {
        // If offline and request is HTML navigation, serve index.html
        if (event.request.mode === 'navigate' || event.request.headers.get('accept')?.includes('text/html')) {
          return caches.match('/index.html');
        }
        return cachedResponse;
      });

      return cachedResponse || fetchPromise;
    })
  );
});
