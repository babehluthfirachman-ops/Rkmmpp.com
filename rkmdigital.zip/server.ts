import express, { Request, Response, NextFunction } from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';

// ES Module dirname resolution
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = 3000;
const DATA_DIR = path.join(process.cwd(), 'data');
const SETTINGS_FILE = path.join(DATA_DIR, 'system_settings.json');
const LOGS_FILE = path.join(DATA_DIR, 'audit_logs.json');

// Ensure data directory exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// Default Superadmin Configuration
const DEFAULT_SETTINGS = {
  appName: 'RKM MPP DIGITAL',
  logoUrl: 'https://images.unsplash.com/photo-1577495508048-b635879837f1?w=150&auto=format&fit=crop&q=80',
  faviconUrl: '/favicon.ico',
  footerText: '© 2024–2027 Rukun Kematian Metro Parung Panjang (RKM MPP). Berlandaskan AD/ART Musyawarah Warga.',
  smtp: {
    host: 'smtp.gmail.com',
    port: 587,
    secure: false,
    username: 'rkmmpp@gmail.com',
    password: '',
    senderEmail: 'rkmmpp@gmail.com',
    senderName: 'RKM Metro Parung Panjang Notifikasi'
  },
  ocrApiKey: '',
  ocrEndpoint: 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent',
  googleWorkspaceApiKey: '',
  googleWorkspaceEndpoint: 'https://script.google.com/macros/s/AKfycbwRKM_MPP_Webhook_Trigger/exec',
  autoScanCameraOcr: true,
  maxUploadFileSizeMb: 10,
  maintenanceMode: false,
  sessionTimeoutMinutes: 120,
  maxLoginAttempts: 5,
  passwordMinLength: 8,
  passwordRequireSpecialChar: true,
  passwordRequireNumber: true,
  lastBackupDate: new Date().toISOString(),
  updatedAt: new Date().toISOString(),
  updatedBy: 'Babeh (Super Admin)'
};

// Helper: Read Settings
function getSavedSettings() {
  try {
    if (fs.existsSync(SETTINGS_FILE)) {
      const data = fs.readFileSync(SETTINGS_FILE, 'utf-8');
      return { ...DEFAULT_SETTINGS, ...JSON.parse(data) };
    }
  } catch (err) {
    console.error('Error reading settings file:', err);
  }
  return { ...DEFAULT_SETTINGS };
}

// Helper: Save Settings
function saveSettings(settings: any) {
  fs.writeFileSync(SETTINGS_FILE, JSON.stringify(settings, null, 2), 'utf-8');
}

// Helper: Append Audit Log
function appendAuditLog(entry: {
  userName: string;
  userRole: string;
  action: string;
  details: string;
  ipAddress: string;
  status: 'Success' | 'Warning' | 'Failed';
}) {
  try {
    let logs = [];
    if (fs.existsSync(LOGS_FILE)) {
      const data = fs.readFileSync(LOGS_FILE, 'utf-8');
      logs = JSON.parse(data);
    }
    const newLog = {
      id: `log-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
      ...entry
    };
    logs.unshift(newLog);
    // Keep max 500 logs
    if (logs.length > 500) logs = logs.slice(0, 500);
    fs.writeFileSync(LOGS_FILE, JSON.stringify(logs, null, 2), 'utf-8');
    return newLog;
  } catch (err) {
    console.error('Error writing audit log:', err);
    return null;
  }
}

// Middleware: Superadmin Role Validation
function requireSuperAdmin(req: Request, res: Response, next: NextFunction) {
  const userRole = (req.headers['x-user-role'] as string) || '';
  const userName = (req.headers['x-user-name'] as string) || '';
  const authHeader = (req.headers['authorization'] as string) || '';

  // Allowed if role is superadmin or admin user token provided
  if (
    userRole.toLowerCase() === 'superadmin' ||
    userName.toLowerCase() === 'admin' ||
    userName.toLowerCase() === 'babeh' ||
    authHeader.includes('superadmin') ||
    authHeader.includes('admin')
  ) {
    return next();
  }

  // Unauthorized response
  return res.status(403).json({
    success: false,
    error: 'Akses Ditolak: Fitur Pengaturan Sistem hanya boleh diakses oleh Super Admin.',
    requiredRole: 'superadmin',
    providedRole: userRole || 'anonymous'
  });
}

async function startServer() {
  const app = express();

  // Parse JSON payloads with appropriate limit
  app.use(express.json({ limit: '25mb' }));
  app.use(express.urlencoded({ extended: true, limit: '25mb' }));

  // ==========================================
  // BACKEND API ROUTES
  // ==========================================

  // 1. Public Health & System Status Check (Includes Maintenance Mode Flag)
  app.get('/api/system/status', (req: Request, res: Response) => {
    const settings = getSavedSettings();
    res.json({
      success: true,
      appName: settings.appName,
      maintenanceMode: Boolean(settings.maintenanceMode),
      logoUrl: settings.logoUrl,
      footerText: settings.footerText,
      version: '2024–2027 v2.4',
      serverTime: new Date().toISOString()
    });
  });

  // 2. GET Superadmin Settings (Protected)
  app.get('/api/superadmin/settings', requireSuperAdmin, (req: Request, res: Response) => {
    try {
      const settings = getSavedSettings();
      res.json({
        success: true,
        settings,
        meta: {
          lastUpdated: settings.updatedAt,
          updatedBy: settings.updatedBy
        }
      });
    } catch (err: any) {
      res.status(500).json({
        success: false,
        error: 'Gagal mengambil pengaturan sistem: ' + (err?.message || 'Internal error')
      });
    }
  });

  // 3. POST / PUT Superadmin Settings (Update with Validation & Audit Log)
  const handleUpdateSettings = (req: Request, res: Response) => {
    try {
      const current = getSavedSettings();
      const updates = req.body || {};

      // Basic validations
      if (updates.appName !== undefined && typeof updates.appName === 'string' && updates.appName.trim() === '') {
        return res.status(400).json({ success: false, error: 'Nama aplikasi tidak boleh kosong' });
      }

      if (updates.sessionTimeoutMinutes !== undefined) {
        const timeout = Number(updates.sessionTimeoutMinutes);
        if (isNaN(timeout) || timeout < 5 || timeout > 1440) {
          return res.status(400).json({ success: false, error: 'Durasi sesi harus antara 5 hingga 1440 menit (24 jam)' });
        }
      }

      if (updates.maxUploadFileSizeMb !== undefined) {
        const maxSize = Number(updates.maxUploadFileSizeMb);
        if (isNaN(maxSize) || maxSize < 1 || maxSize > 100) {
          return res.status(400).json({ success: false, error: 'Batas ukuran berkas harus antara 1 MB hingga 100 MB' });
        }
      }

      if (updates.passwordMinLength !== undefined) {
        const minLen = Number(updates.passwordMinLength);
        if (isNaN(minLen) || minLen < 4 || minLen > 32) {
          return res.status(400).json({ success: false, error: 'Minimal panjang password harus antara 4 hingga 32 karakter' });
        }
      }

      const clientIp = (req.headers['x-forwarded-for'] as string) || req.socket.remoteAddress || '127.0.0.1';
      const actorName = (req.headers['x-user-name'] as string) || updates.updatedBy || 'Super Admin';

      const mergedSettings = {
        ...current,
        ...updates,
        smtp: {
          ...current.smtp,
          ...(updates.smtp || {})
        },
        updatedAt: new Date().toISOString().replace('T', ' ').substring(0, 19) + ' WIB',
        updatedBy: actorName
      };

      saveSettings(mergedSettings);

      // Audit Log for Superadmin Change
      appendAuditLog({
        userName: actorName,
        userRole: 'superadmin',
        action: 'SUPERADMIN_SETTINGS_UPDATED',
        details: `Pembaruan Pengaturan Sistem Superadmin (Maintenance: ${mergedSettings.maintenanceMode ? 'Aktif' : 'Non-Aktif'}, OCR Camera: ${mergedSettings.autoScanCameraOcr ? 'Aktif' : 'Non-Aktif'}, Upload Max: ${mergedSettings.maxUploadFileSizeMb}MB)`,
        ipAddress: clientIp,
        status: 'Success'
      });

      return res.json({
        success: true,
        message: 'Pengaturan sistem Superadmin berhasil disimpan dan disinkronisasi.',
        settings: mergedSettings
      });
    } catch (err: any) {
      console.error('Error updating settings:', err);
      return res.status(500).json({
        success: false,
        error: 'Terjadi kesalahan server saat menyimpan pengaturan: ' + (err?.message || 'Internal error')
      });
    }
  };

  app.post('/api/superadmin/settings', requireSuperAdmin, handleUpdateSettings);
  app.put('/api/superadmin/settings', requireSuperAdmin, handleUpdateSettings);

  // 4. Trigger Manual Backup Endpoint (Protected)
  app.post('/api/superadmin/backup', requireSuperAdmin, (req: Request, res: Response) => {
    try {
      const clientIp = (req.headers['x-forwarded-for'] as string) || req.socket.remoteAddress || '127.0.0.1';
      const actorName = (req.headers['x-user-name'] as string) || 'Super Admin';
      const timestamp = new Date().toISOString();
      const settings = getSavedSettings();

      // Read current audit logs to include in backup
      let auditLogs = [];
      if (fs.existsSync(LOGS_FILE)) {
        try {
          auditLogs = JSON.parse(fs.readFileSync(LOGS_FILE, 'utf-8'));
        } catch {
          auditLogs = [];
        }
      }

      // Update last backup date in settings
      settings.lastBackupDate = new Date().toISOString().replace('T', ' ').substring(0, 19) + ' WIB';
      saveSettings(settings);

      // Append audit log for backup
      appendAuditLog({
        userName: actorName,
        userRole: 'superadmin',
        action: 'DATABASE_BACKUP_MANUAL',
        details: 'Ekspor dan backup manual database sistem dieksekusi',
        ipAddress: clientIp,
        status: 'Success'
      });

      res.json({
        success: true,
        message: 'Backup database sistem berhasil dibuat.',
        timestamp,
        stats: {
          generatedAt: timestamp,
          settingsSnapshot: true,
          auditLogsCount: auditLogs.length
        },
        downloadPayload: {
          exportDate: timestamp,
          source: 'RKM MPP Superadmin API',
          systemSettings: settings,
          auditLogs
        }
      });
    } catch (err: any) {
      res.status(500).json({
        success: false,
        error: 'Gagal membuat backup database: ' + (err?.message || 'Error')
      });
    }
  });

  // 5. GET Audit Logs (Protected)
  app.get('/api/superadmin/logs', requireSuperAdmin, (req: Request, res: Response) => {
    try {
      let logs = [];
      if (fs.existsSync(LOGS_FILE)) {
        try {
          logs = JSON.parse(fs.readFileSync(LOGS_FILE, 'utf-8'));
        } catch {
          logs = [];
        }
      }

      const format = req.query.format as string;
      if (format === 'csv') {
        res.setHeader('Content-Type', 'text/csv');
        res.setHeader('Content-Disposition', 'attachment; filename="system_audit_logs.csv"');
        let csv = 'ID,Waktu,Pengguna,Role,Aksi,Detail,IP Address,Status\n';
        logs.forEach((l: any) => {
          csv += `"${l.id}","${l.timestamp}","${l.userName}","${l.userRole}","${l.action}","${(l.details || '').replace(/"/g, '""')}","${l.ipAddress}","${l.status}"\n`;
        });
        return res.send(csv);
      }

      res.json({
        success: true,
        count: logs.length,
        logs
      });
    } catch (err: any) {
      res.status(500).json({
        success: false,
        error: 'Gagal memuat log audit: ' + (err?.message || 'Error')
      });
    }
  });

  // ==========================================
  // VITE DEV MIDDLEWARE / STATIC ASSETS
  // ==========================================
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`RKM MPP Digital Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
