import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { Transaction, OrganizationSettings, Officer, Citizen } from '../types';
import { formatRupiah, formatDateIndo, calculateCitizenMonthlyDues } from './formatters';

/**
 * Generate and download official Cashbook PDF
 */
export function exportCashbookPdf(
  transactions: Transaction[],
  settings: OrganizationSettings,
  filterMonth: string,
  summaryOrInitialBalance?: {
    totalIn: number;
    totalOut: number;
    endingBalance: number;
    initialBalance?: number;
  } | number
) {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4'
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const monthTitle = filterMonth === 'all' 
    ? 'SEMUA PERIODE PEMBUKUAN' 
    : `PERIODE BULAN ${filterMonth}`;

  // Derive summary metrics safely
  let initialBalance = 0;
  let totalIn = 0;
  let totalOut = 0;
  let endingBalance = 0;

  if (typeof summaryOrInitialBalance === 'number') {
    initialBalance = summaryOrInitialBalance;
    totalIn = transactions.filter(t => t.type === 'in').reduce((sum, t) => sum + t.amount, 0);
    totalOut = transactions.filter(t => t.type === 'out').reduce((sum, t) => sum + t.amount, 0);
    endingBalance = initialBalance + totalIn - totalOut;
  } else if (summaryOrInitialBalance) {
    initialBalance = summaryOrInitialBalance.initialBalance || 0;
    totalIn = summaryOrInitialBalance.totalIn;
    totalOut = summaryOrInitialBalance.totalOut;
    endingBalance = summaryOrInitialBalance.endingBalance;
  } else {
    totalIn = transactions.filter(t => t.type === 'in').reduce((sum, t) => sum + t.amount, 0);
    totalOut = transactions.filter(t => t.type === 'out').reduce((sum, t) => sum + t.amount, 0);
    endingBalance = totalIn - totalOut;
  }

  // 1. KOP SURAT
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(14);
  doc.setTextColor(15, 23, 42); // slate-900
  doc.text(settings.orgName || 'RUKUN KEMATIAN MUSLIM (RKM)', pageWidth / 2, 16, { align: 'center' });

  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(51, 65, 85); // slate-700
  doc.text(settings.village || 'Perumahan Metro Parung Panjang, Parungpanjang, Bogor', pageWidth / 2, 21, { align: 'center' });
  doc.text(`Kontak Posko: ${settings.contactCenter || '0812-3456-7890'} | Email: ${settings.email || 'info@rkm-mpp.org'}`, pageWidth / 2, 26, { align: 'center' });

  // Divider Line
  doc.setDrawColor(16, 185, 129); // emerald-500
  doc.setLineWidth(0.8);
  doc.line(14, 29, pageWidth - 14, 29);
  doc.setDrawColor(100, 116, 139);
  doc.setLineWidth(0.2);
  doc.line(14, 30, pageWidth - 14, 30);

  // 2. DOCUMENT TITLE
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(12);
  doc.setTextColor(15, 23, 42);
  doc.text('LAPORAN BUKU KAS KEUANGAN RKM', pageWidth / 2, 38, { align: 'center' });

  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(100, 116, 139);
  doc.text(`${monthTitle} • Dicetak pada: ${formatDateIndo(new Date().toISOString().split('T')[0])}`, pageWidth / 2, 43, { align: 'center' });

  // 3. FINANCIAL SUMMARY BOX
  doc.setFillColor(248, 250, 252);
  doc.roundedRect(14, 48, pageWidth - 28, 22, 2, 2, 'F');
  doc.setDrawColor(226, 232, 240);
  doc.roundedRect(14, 48, pageWidth - 28, 22, 2, 2, 'S');

  doc.setFontSize(8);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(100, 116, 139);
  doc.text('TOTAL PENERIMAAN (MASUK)', 22, 54);
  doc.text('TOTAL PENGELUARAN (KELUAR)', pageWidth / 2, 54, { align: 'center' });
  doc.text('SALDO AKHIR KAS', pageWidth - 22, 54, { align: 'right' });

  doc.setFontSize(11);
  doc.setTextColor(5, 150, 105); // emerald-600
  doc.text(formatRupiah(totalIn), 22, 63);

  doc.setTextColor(225, 29, 72); // rose-600
  doc.text(formatRupiah(totalOut), pageWidth / 2, 63, { align: 'center' });

  doc.setTextColor(15, 23, 42); // slate-900
  doc.text(formatRupiah(endingBalance), pageWidth - 22, 63, { align: 'right' });

  // 4. TRANSACTION TABLE
  // Sort chronological for ledger
  const sorted = [...transactions].sort((a, b) => a.date.localeCompare(b.date));
  let running = initialBalance;

  const tableData = sorted.map((t, idx) => {
    if (t.type === 'in') running += t.amount;
    else running -= t.amount;

    return [
      idx + 1,
      t.date,
      t.receiptNo || '-',
      `${t.description}\n(${t.recipientOrPayer})`,
      t.category,
      t.type === 'in' ? formatRupiah(t.amount) : '-',
      t.type === 'out' ? formatRupiah(t.amount) : '-',
      formatRupiah(running)
    ];
  });

  autoTable(doc, {
    startY: 75,
    head: [['No', 'Tanggal', 'No. Bukti', 'Uraian / Pihak Terkait', 'Kategori', 'Masuk (Rp)', 'Keluar (Rp)', 'Saldo (Rp)']],
    body: tableData,
    theme: 'grid',
    headStyles: {
      fillColor: [16, 185, 129], // emerald-500
      textColor: [255, 255, 255],
      fontSize: 8,
      fontStyle: 'bold',
      halign: 'center'
    },
    bodyStyles: {
      fontSize: 7.5,
      textColor: [30, 41, 59]
    },
    columnStyles: {
      0: { halign: 'center', cellWidth: 8 },
      1: { halign: 'center', cellWidth: 18 },
      2: { halign: 'center', cellWidth: 22 },
      3: { cellWidth: 'auto' },
      4: { halign: 'center', cellWidth: 24 },
      5: { halign: 'right', cellWidth: 24, textColor: [5, 150, 105] },
      6: { halign: 'right', cellWidth: 24, textColor: [225, 29, 72] },
      7: { halign: 'right', cellWidth: 24, fontStyle: 'bold' }
    },
    margin: { left: 14, right: 14, bottom: 40 },
    didDrawPage: (data) => {
      // Footer page number
      doc.setFontSize(7.5);
      doc.setTextColor(148, 163, 184);
      doc.text(
        `Halaman ${data.pageNumber} - RKM Digital Official Report`,
        pageWidth / 2,
        doc.internal.pageSize.getHeight() - 8,
        { align: 'center' }
      );
    }
  });

  // 5. SIGNATURE BLOCK (At the bottom of last page)
  const finalY = (doc as any).lastAutoTable.finalY + 12;
  const pageHeight = doc.internal.pageSize.getHeight();
  
  // If not enough room on current page, add new page
  if (finalY + 35 > pageHeight - 15) {
    doc.addPage();
  }

  const sigY = (finalY + 35 > pageHeight - 15) ? 25 : finalY;

  doc.setFontSize(8.5);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(51, 65, 85);

  const sigCol1 = 25;
  const sigCol2 = pageWidth / 2;
  const sigCol3 = pageWidth - 25;

  doc.text('Mengetahui / Menyetujui,', sigCol1, sigY, { align: 'center' });
  doc.text('Ketua Paguyuban RKM,', sigCol1, sigY + 4, { align: 'center' });

  doc.text('Diperiksa Oleh,', sigCol2, sigY, { align: 'center' });
  doc.text('Sekretaris RKM,', sigCol2, sigY + 4, { align: 'center' });

  doc.text('Dibuat & Dipertanggungjawabkan,', sigCol3, sigY, { align: 'center' });
  doc.text('Bendahara Kas RKM,', sigCol3, sigY + 4, { align: 'center' });

  // Signature lines
  const nameY = sigY + 22;
  doc.setFont('helvetica', 'bold');
  doc.text(`( ${settings.chairmanName || 'Ketua RKM'} )`, sigCol1, nameY, { align: 'center' });
  doc.text(`( ${settings.secretaryName || 'Sekretaris RKM'} )`, sigCol2, nameY, { align: 'center' });
  doc.text(`( ${settings.treasurerName || 'Bendahara RKM'} )`, sigCol3, nameY, { align: 'center' });

  // Save PDF
  const filename = `Laporan_Kas_RKM_${filterMonth === 'all' ? 'Semua' : filterMonth}_${new Date().toISOString().split('T')[0]}.pdf`;
  doc.save(filename);
}

/**
 * Generate and download official Citizen Directory PDF (Buku Induk Warga)
 */
export function exportCitizensPdf(
  citizensList: Citizen[],
  settings: OrganizationSettings,
  filterDescription: string = 'Seluruh Warga Terdaftar'
) {
  const doc = new jsPDF({
    orientation: 'landscape',
    unit: 'mm',
    format: 'a4'
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const baseRate = settings.baseDuesAmount || settings.duesAmount || 5000;
  const extraRate = settings.extraMemberDuesAmount || 3000;

  // 1. KOP SURAT
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(14);
  doc.setTextColor(15, 23, 42);
  doc.text(settings.orgName || 'RUKUN KEMATIAN MUSLIM (RKM)', pageWidth / 2, 14, { align: 'center' });

  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(51, 65, 85);
  doc.text(`${settings.village || 'Perumahan Metro Parung Panjang'} | AD/ART Periode 2024–2027 | Hotline: ${settings.contactCenter || '0812-3456-7890'}`, pageWidth / 2, 19, { align: 'center' });

  // Divider
  doc.setDrawColor(16, 185, 129);
  doc.setLineWidth(0.7);
  doc.line(14, 23, pageWidth - 14, 23);

  // Title
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(15, 23, 42);
  doc.text('BUKU INDUK DATA MASTER WARGA & KELUARGA (KK)', pageWidth / 2, 29, { align: 'center' });

  doc.setFontSize(8);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(100, 116, 139);
  doc.text(`Filter: ${filterDescription} • Total: ${citizensList.length} Kepala Keluarga (${citizensList.reduce((acc, c) => acc + c.members.length, 0)} Jiwa) • Dicetak: ${formatDateIndo(new Date().toISOString().split('T')[0])}`, pageWidth / 2, 34, { align: 'center' });

  // Table Data
  const tableData = citizensList.map((c, idx) => {
    const dues = calculateCitizenMonthlyDues(c, baseRate, extraRate);
    const aliveMembers = c.members.filter(m => m.status === 'Hidup').length;
    const addressStr = `${c.block} ${c.houseNumber}, RT ${c.rt}/RW ${c.rw}`;
    
    return [
      idx + 1,
      c.noKK,
      c.nik,
      c.headOfFamily,
      addressStr,
      c.phone || '-',
      `${aliveMembers} Jiwa\n(${dues.coreMembersCount} Inti, ${dues.extraMembersCount} Tambahan)`,
      formatRupiah(dues.totalMonthlyDues),
      c.status
    ];
  });

  autoTable(doc, {
    startY: 38,
    head: [['No', 'Nomor KK', 'NIK Kepala KK', 'Nama Kepala Keluarga', 'Alamat / RT-RW', 'No. HP/WA', 'Jiwa Tertanggung', 'Iuran / Bln', 'Status']],
    body: tableData,
    theme: 'grid',
    headStyles: {
      fillColor: [16, 185, 129],
      textColor: [255, 255, 255],
      fontSize: 8,
      fontStyle: 'bold',
      halign: 'center'
    },
    bodyStyles: {
      fontSize: 7.5,
      textColor: [30, 41, 59]
    },
    columnStyles: {
      0: { halign: 'center', cellWidth: 8 },
      1: { halign: 'center', cellWidth: 32, fontStyle: 'bold' },
      2: { halign: 'center', cellWidth: 32 },
      3: { cellWidth: 'auto', fontStyle: 'bold' },
      4: { cellWidth: 45 },
      5: { halign: 'center', cellWidth: 26 },
      6: { halign: 'center', cellWidth: 30 },
      7: { halign: 'right', cellWidth: 24, fontStyle: 'bold', textColor: [5, 150, 105] },
      8: { halign: 'center', cellWidth: 20 }
    },
    margin: { left: 14, right: 14, bottom: 25 },
    didDrawPage: (data) => {
      doc.setFontSize(7);
      doc.setTextColor(148, 163, 184);
      doc.text(
        `Buku Induk Warga RKM MPP • Halaman ${data.pageNumber}`,
        pageWidth / 2,
        doc.internal.pageSize.getHeight() - 6,
        { align: 'center' }
      );
    }
  });

  // Save PDF
  const filename = `Buku_Induk_Warga_RKM_${new Date().toISOString().split('T')[0]}.pdf`;
  doc.save(filename);
}

/**
 * Generate and download official single KK Family Document PDF
 */
export function exportSingleCitizenFamilyPdf(
  citizen: Citizen,
  settings: OrganizationSettings
) {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4'
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const baseRate = settings.baseDuesAmount || settings.duesAmount || 5000;
  const extraRate = settings.extraMemberDuesAmount || 3000;
  const dues = calculateCitizenMonthlyDues(citizen, baseRate, extraRate);

  // 1. KOP SURAT
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(13);
  doc.setTextColor(15, 23, 42);
  doc.text(settings.orgName || 'RUKUN KEMATIAN MUSLIM (RKM)', pageWidth / 2, 16, { align: 'center' });

  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(51, 65, 85);
  doc.text(settings.village || 'Perumahan Metro Parung Panjang, Parungpanjang, Bogor', pageWidth / 2, 21, { align: 'center' });
  doc.text(`Legalitas AD/ART 2024–2027 | Hotline Layanan: ${settings.contactCenter || '0812-3456-7890'}`, pageWidth / 2, 26, { align: 'center' });

  // Divider Line
  doc.setDrawColor(16, 185, 129);
  doc.setLineWidth(0.8);
  doc.line(14, 29, pageWidth - 14, 29);

  // 2. DOCUMENT TITLE
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(12);
  doc.setTextColor(15, 23, 42);
  doc.text('KARTU KELUARGA & BUKTI KEANGGOTAAN RKM', pageWidth / 2, 37, { align: 'center' });

  doc.setFontSize(8.5);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(100, 116, 139);
  doc.text(`Nomor KK: ${citizen.noKK} • Status: ${citizen.status}`, pageWidth / 2, 42, { align: 'center' });

  // 3. CITIZEN HEAD INFO BOX
  doc.setFillColor(248, 250, 252);
  doc.roundedRect(14, 47, pageWidth - 28, 28, 2, 2, 'F');
  doc.setDrawColor(226, 232, 240);
  doc.roundedRect(14, 47, pageWidth - 28, 28, 2, 2, 'S');

  doc.setFontSize(8.5);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(71, 85, 105);
  doc.text('Nama Kepala Keluarga', 20, 54);
  doc.text('NIK Kepala Keluarga', 20, 61);
  doc.text('Alamat Lengkap', 20, 68);

  doc.setFont('helvetica', 'normal');
  doc.setTextColor(15, 23, 42);
  doc.text(`:  ${citizen.headOfFamily}`, 60, 54);
  doc.text(`:  ${citizen.nik}`, 60, 61);
  doc.text(`:  ${citizen.block || 'Blok'} ${citizen.houseNumber || ''}, RT ${citizen.rt} / RW ${citizen.rw} (${citizen.address || citizen.paguyubanName || '-'})`, 60, 68);

  doc.setFont('helvetica', 'bold');
  doc.setTextColor(71, 85, 105);
  doc.text('No. Handphone / WA', 125, 54);
  doc.text('Total Iuran Bulanan', 125, 61);
  doc.text('Status Hak Fardhu Kifayah', 125, 68);

  doc.setFont('helvetica', 'normal');
  doc.setTextColor(15, 23, 42);
  doc.text(`:  ${citizen.phone || '-'}`, 165, 54);
  doc.text(`:  ${formatRupiah(dues.totalMonthlyDues)} / bln`, 165, 61);
  doc.text(`:  ${citizen.status === 'Aktif' ? 'BERHAK PENUH' : 'DITANGGUHKAN'}`, 165, 68);

  // 4. FAMILY MEMBERS TABLE
  const memberData = citizen.members.map((m, idx) => [
    idx + 1,
    m.name,
    m.nik,
    m.relation,
    m.category,
    m.gender,
    m.birthDate || '-',
    m.status
  ]);

  autoTable(doc, {
    startY: 80,
    head: [['No', 'Nama Lengkap Jiwa', 'NIK', 'Hubungan', 'Kategori', 'Gender', 'Tanggal Lahir', 'Status Jiwa']],
    body: memberData,
    theme: 'grid',
    headStyles: {
      fillColor: [16, 185, 129],
      textColor: [255, 255, 255],
      fontSize: 8,
      fontStyle: 'bold',
      halign: 'center'
    },
    bodyStyles: {
      fontSize: 8,
      textColor: [30, 41, 59]
    },
    columnStyles: {
      0: { halign: 'center', cellWidth: 8 },
      1: { fontStyle: 'bold', cellWidth: 40 },
      2: { halign: 'center', cellWidth: 32 },
      3: { halign: 'center', cellWidth: 22 },
      4: { halign: 'center', cellWidth: 20 },
      5: { halign: 'center', cellWidth: 20 },
      6: { halign: 'center', cellWidth: 22 },
      7: { halign: 'center', cellWidth: 18 }
    },
    margin: { left: 14, right: 14 }
  });

  // 5. SIGNATURE BLOCK
  const finalY = (doc as any).lastAutoTable.finalY + 14;
  const sigCol1 = 40;
  const sigCol2 = pageWidth - 40;

  doc.setFontSize(8.5);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(51, 65, 85);

  doc.text('Kepala Keluarga / Warga,', sigCol1, finalY, { align: 'center' });
  doc.text('Pengurus RKM MPP,', sigCol2, finalY, { align: 'center' });

  const nameY = finalY + 22;
  doc.setFont('helvetica', 'bold');
  doc.text(`( ${citizen.headOfFamily} )`, sigCol1, nameY, { align: 'center' });
  doc.text(`( ${settings.chairmanName || 'Ketua RKM'} )`, sigCol2, nameY, { align: 'center' });

  const filename = `Data_KK_${citizen.noKK}_${citizen.headOfFamily.replace(/\s+/g, '_')}.pdf`;
  doc.save(filename);
}

/**
 * Generate and download official 4-Month Report PDF
 */
export function exportFourMonthReportPdf(
  periodLabel: string,
  year: number,
  settings: OrganizationSettings,
  summary: {
    startBalance: number;
    totalIn: number;
    totalOut: number;
    endBalance: number;
  },
  incomeDetails: { category: string; count: number; amount: number }[],
  expenseDetails: { category: string; count: number; amount: number }[],
  activeDeathsCount: number
) {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4'
  });

  const pageWidth = doc.internal.pageSize.getWidth();

  // KOP
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(14);
  doc.setTextColor(15, 23, 42);
  doc.text(settings.orgName || 'RUKUN KEMATIAN MUSLIM (RKM)', pageWidth / 2, 16, { align: 'center' });

  doc.setFontSize(9.5);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(51, 65, 85);
  doc.text(settings.village || 'Perumahan Metro Parung Panjang, Parungpanjang, Bogor', pageWidth / 2, 21, { align: 'center' });
  doc.text(`Ketetapan AD/ART Periode 2024–2027 | Hotline: ${settings.contactCenter}`, pageWidth / 2, 26, { align: 'center' });

  doc.setDrawColor(16, 185, 129);
  doc.setLineWidth(0.8);
  doc.line(14, 29, pageWidth - 14, 29);

  // Title
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(12);
  doc.setTextColor(15, 23, 42);
  doc.text('LAPORAN PERTANGGUNGJAWABAN REALISASI KAS 4-BULANAN', pageWidth / 2, 38, { align: 'center' });

  doc.setFontSize(9.5);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(100, 116, 139);
  doc.text(`Periode: ${periodLabel} ${year} • Status: Disahkan Musyawarah Pengurus & Warga`, pageWidth / 2, 43, { align: 'center' });

  // Summary box
  doc.setFillColor(241, 245, 249);
  doc.roundedRect(14, 48, pageWidth - 28, 26, 2, 2, 'F');
  doc.setDrawColor(203, 213, 225);
  doc.roundedRect(14, 48, pageWidth - 28, 26, 2, 2, 'S');

  doc.setFontSize(8);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(71, 85, 105);
  doc.text('SALDO AWAL PERIODE', 20, 54);
  doc.text('TOTAL PENERIMAAN (+)', 65, 54);
  doc.text('TOTAL PENGELUARAN (-)', 115, 54);
  doc.text('SALDO AKHIR KAS (=)', pageWidth - 20, 54, { align: 'right' });

  doc.setFontSize(10.5);
  doc.setTextColor(30, 41, 59);
  doc.text(formatRupiah(summary.startBalance), 20, 64);

  doc.setTextColor(5, 150, 105);
  doc.text(formatRupiah(summary.totalIn), 65, 64);

  doc.setTextColor(225, 29, 72);
  doc.text(formatRupiah(summary.totalOut), 115, 64);

  doc.setTextColor(15, 23, 42);
  doc.text(formatRupiah(summary.endBalance), pageWidth - 20, 64, { align: 'right' });

  // Table 1: Penerimaan
  const inTableData = incomeDetails.map((item, i) => [
    i + 1,
    item.category,
    `${item.count} Transaksi`,
    formatRupiah(item.amount)
  ]);
  inTableData.push(['', 'TOTAL PENERIMAAN KAS', '', formatRupiah(summary.totalIn)]);

  autoTable(doc, {
    startY: 79,
    head: [['No', 'Pos Penerimaan (Pemasukan)', 'Frekuensi', 'Jumlah Realisasi (Rp)']],
    body: inTableData,
    theme: 'grid',
    headStyles: { fillColor: [5, 150, 105], textColor: [255, 255, 255], fontSize: 8 },
    bodyStyles: { fontSize: 8 },
    columnStyles: {
      0: { halign: 'center', cellWidth: 10 },
      2: { halign: 'center', cellWidth: 35 },
      3: { halign: 'right', fontStyle: 'bold' }
    },
    margin: { left: 14, right: 14 }
  });

  // Table 2: Pengeluaran
  const finalY1 = (doc as any).lastAutoTable.finalY + 8;
  const outTableData = expenseDetails.map((item, i) => [
    i + 1,
    item.category,
    `${item.count} Kegiatan`,
    formatRupiah(item.amount)
  ]);
  outTableData.push(['', 'TOTAL PENGELUARAN KAS', '', formatRupiah(summary.totalOut)]);

  autoTable(doc, {
    startY: finalY1,
    head: [['No', 'Pos Alokasi Pengeluaran Fardhu Kifayah & Operasional', 'Frekuensi', 'Jumlah Realisasi (Rp)']],
    body: outTableData,
    theme: 'grid',
    headStyles: { fillColor: [225, 29, 72], textColor: [255, 255, 255], fontSize: 8 },
    bodyStyles: { fontSize: 8 },
    columnStyles: {
      0: { halign: 'center', cellWidth: 10 },
      2: { halign: 'center', cellWidth: 35 },
      3: { halign: 'right', fontStyle: 'bold' }
    },
    margin: { left: 14, right: 14 }
  });

  // Signatures
  const finalY2 = (doc as any).lastAutoTable.finalY + 12;
  const pageHeight = doc.internal.pageSize.getHeight();
  if (finalY2 + 35 > pageHeight - 15) {
    doc.addPage();
  }

  const sigY = (finalY2 + 35 > pageHeight - 15) ? 25 : finalY2;

  doc.setFontSize(8.5);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(51, 65, 85);

  const sigCol1 = 25;
  const sigCol2 = pageWidth / 2;
  const sigCol3 = pageWidth - 25;

  doc.text('Mengetahui / Mengesahkan,', sigCol1, sigY, { align: 'center' });
  doc.text('Ketua Paguyuban RKM,', sigCol1, sigY + 4, { align: 'center' });

  doc.text('Verifikasi Organisasi,', sigCol2, sigY, { align: 'center' });
  doc.text('Sekretaris RKM,', sigCol2, sigY + 4, { align: 'center' });

  doc.text('Dibuat & Disusun Oleh,', sigCol3, sigY, { align: 'center' });
  doc.text('Bendahara Kas RKM,', sigCol3, sigY + 4, { align: 'center' });

  const nameY = sigY + 22;
  doc.setFont('helvetica', 'bold');
  doc.text(`( ${settings.chairmanName || 'Drs. H. Bambang Sutrisno, M.Pd.'} )`, sigCol1, nameY, { align: 'center' });
  doc.text(`( ${settings.secretaryName || 'Sekretaris RKM'} )`, sigCol2, nameY, { align: 'center' });
  doc.text(`( ${settings.treasurerName || 'H. Agus Supriyadi, S.E.'} )`, sigCol3, nameY, { align: 'center' });

  const filename = `Laporan_4_Bulanan_RKM_${periodLabel.replace(/\s+/g, '_')}_${year}.pdf`;
  doc.save(filename);
}
