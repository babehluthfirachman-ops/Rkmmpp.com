import { Citizen, Transaction, OrganizationSettings } from '../types';
import { formatRupiah, calculateCitizenMonthlyDues } from './formatters';

/**
 * Escapes fields for CSV format
 */
function escapeCsv(val: any): string {
  if (val === null || val === undefined) return '""';
  const str = String(val).replace(/"/g, '""');
  return `"${str}"`;
}

/**
 * Trigger file download in browser
 */
function downloadBlob(content: string, filename: string, mimeType: string) {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

/**
 * Export Citizens Directory to CSV (Excel compatible with UTF-8 BOM)
 */
export function exportCitizensCsv(citizens: Citizen[], settings?: OrganizationSettings) {
  const headers = [
    'No',
    'No KTA',
    'No KK',
    'NIK Kepala Keluarga',
    'Nama Kepala Keluarga',
    'Status Anggota',
    'Status Pengurus',
    'Jabatan Pengurus',
    'Kategori Khusus Sosial',
    'No Telepon/WA',
    'Blok Rumah',
    'Nomor Rumah',
    'RT',
    'RW',
    'Alamat Lengkap',
    'Tanggal Bergabung',
    'Jumlah Jiwa Tertanggung',
    'Rincian Anggota Keluarga',
    'Estimasi Iuran Bulanan'
  ];

  const rows = citizens.map((c, index) => {
    const activeMembers = c.members.filter(m => m.status === 'Hidup');
    const membersDetail = c.members.map(m => 
      `${m.name} (${m.relation}${m.socialCategory && m.socialCategory !== 'Umum' ? ` - ${m.socialCategory}` : ''}, ${m.gender}, Status: ${m.status})`
    ).join('; ');

    const specialSocialCategories = Array.from(new Set(
      c.members
        .map(m => m.socialCategory)
        .filter(cat => cat && cat !== 'Umum')
    )).join(', ') || (c.socialCategories?.join(', ') || '-');

    const duesCalc = calculateCitizenMonthlyDues(
      c, 
      settings?.baseDuesAmount || settings?.duesAmount || 5000, 
      settings?.extraMemberDuesAmount || 3000
    );

    return [
      index + 1,
      c.ktaNumber || `KTA-RKM-${c.noKK}`,
      c.noKK,
      c.nik,
      c.headOfFamily,
      c.status,
      c.isOfficer ? 'PENGURUS TERPILIH' : 'Anggota Biasa',
      c.officerRole || '-',
      specialSocialCategories,
      c.phone || '-',
      c.block || '-',
      c.houseNumber || '-',
      c.rt || '-',
      c.rw || '-',
      c.address || '-',
      c.joinDate,
      activeMembers.length,
      membersDetail,
      duesCalc.totalMonthlyDues
    ].map(escapeCsv).join(',');
  });

  // \uFEFF ensures Excel opens UTF-8 Indonesian text without encoding errors
  const csvContent = '\uFEFF' + [headers.map(escapeCsv).join(','), ...rows].join('\r\n');
  const filename = `Daftar_Warga_RKM_${new Date().toISOString().slice(0, 10)}.csv`;
  downloadBlob(csvContent, filename, 'text/csv;charset=utf-8;');
}

/**
 * Export Financial Transactions / Cashbook to CSV (Excel compatible)
 */
export function exportCashbookCsv(
  transactions: Transaction[], 
  settings?: OrganizationSettings,
  periodName: string = 'Semua Periode'
) {
  const headers = [
    'No',
    'ID Transaksi',
    'Tanggal',
    'Jenis Kas',
    'Arus',
    'Kategori',
    'Nominal (Rp)',
    'Keterangan',
    'Penerima / Pembayar',
    'Blok / No KK',
    'Metode Pembayaran',
    'Petugas Kasir'
  ];

  const rows = transactions.map((t, index) => {
    return [
      index + 1,
      t.id,
      t.date,
      t.type === 'in' ? 'Kas Masuk (Pemasukan)' : 'Kas Keluar (Pengeluaran)',
      t.type === 'in' ? 'Pemasukan' : 'Pengeluaran',
      t.category,
      t.amount,
      t.description,
      t.recipientOrPayer || '-',
      t.noKK || '-',
      t.paymentMethod || 'Tunai',
      t.verifiedBy || 'Petugas RKM'
    ].map(escapeCsv).join(',');
  });

  const totalIn = transactions.filter(t => t.type === 'in').reduce((s, t) => s + t.amount, 0);
  const totalOut = transactions.filter(t => t.type === 'out').reduce((s, t) => s + t.amount, 0);
  const netBalance = totalIn - totalOut;

  const summaryRows = [
    '',
    ['', '', '', '', '', 'TOTAL PEMASUKAN', totalIn, '', '', '', '', ''].map(escapeCsv).join(','),
    ['', '', '', '', '', 'TOTAL PENGELUARAN', totalOut, '', '', '', '', ''].map(escapeCsv).join(','),
    ['', '', '', '', '', 'SALDO AKHIR PERIODE', netBalance, '', '', '', '', ''].map(escapeCsv).join(',')
  ];

  const csvContent = '\uFEFF' + [
    escapeCsv(`LAPORAN ARSIP KEUANGAN BUKU KAS - ${settings?.orgName || 'RKM METRO PARUNG PANJANG'}`),
    escapeCsv(`Periode: ${periodName} | Tanggal Unduh: ${new Date().toLocaleString('id-ID')}`),
    '',
    headers.map(escapeCsv).join(','),
    ...rows,
    ...summaryRows
  ].join('\r\n');

  const filename = `Laporan_Kas_RKM_${periodName.replace(/\s+/g, '_')}_${new Date().toISOString().slice(0, 10)}.csv`;
  downloadBlob(csvContent, filename, 'text/csv;charset=utf-8;');
}

/**
 * Export Citizens Dues Status / Payment Report to CSV (Excel compatible)
 */
export function exportDuesReportCsv(
  citizens: Citizen[],
  monthKey: string = '2026-08',
  settings?: OrganizationSettings
) {
  const baseRate = settings?.baseDuesAmount || settings?.duesAmount || 5000;
  const extraRate = settings?.extraMemberDuesAmount || 3000;

  const headers = [
    'No',
    'No KTA',
    'No KK',
    'Nama Kepala Keluarga',
    'RT',
    'RW',
    'Blok Rumah',
    'No Rumah',
    'No Telepon/WA',
    'Jumlah Jiwa Tertanggung',
    'Tarif Iuran Bulanan (Rp)',
    `Status Iuran (${monthKey})`,
    'Tanggal Bayar',
    'Metode Pembayaran',
    'Petugas Kasir / Kolektor',
    'Bulan Menunggak (2026)',
    'Total Tunggakan (Rp)'
  ];

  const rows = citizens.map((c, index) => {
    const duesCalc = calculateCitizenMonthlyDues(c, baseRate, extraRate);
    const dueRecord = c.monthlyDues?.[monthKey];
    const isPaid = Boolean(dueRecord?.paid);

    const unpaidMonths = Object.entries(c.monthlyDues || {})
      .filter(([k, v]) => !(v as any)?.paid && k.startsWith('2026'))
      .map(([k]) => k);

    const totalArrears = unpaidMonths.length * duesCalc.totalMonthlyDues;

    return [
      index + 1,
      c.ktaNumber || `KTA-RKM-${c.noKK}`,
      c.noKK,
      c.headOfFamily,
      c.rt,
      c.rw,
      c.block || '-',
      c.houseNumber || '-',
      c.phone || '-',
      c.members.length,
      duesCalc.totalMonthlyDues,
      isPaid ? 'LUNAS' : 'BELUM LUNAS / MENUNGGAK',
      isPaid ? (dueRecord?.paidAt || '-') : '-',
      isPaid ? (dueRecord?.paymentMethod || 'Tunai') : '-',
      isPaid ? (dueRecord?.collector || '-') : '-',
      unpaidMonths.length > 0 ? unpaidMonths.join('; ') : 'Tidak Ada',
      totalArrears
    ].map(escapeCsv).join(',');
  });

  const totalCitizens = citizens.length;
  const totalPaid = citizens.filter(c => c.monthlyDues?.[monthKey]?.paid).length;
  const totalUnpaid = totalCitizens - totalPaid;

  const summaryRows = [
    '',
    ['', '', '', '', '', '', '', '', '', 'TOTAL WARGA (KK)', totalCitizens].map(escapeCsv).join(','),
    ['', '', '', '', '', '', '', '', '', 'SUDAH LUNAS (KK)', totalPaid].map(escapeCsv).join(','),
    ['', '', '', '', '', '', '', '', '', 'BELUM LUNAS (KK)', totalUnpaid].map(escapeCsv).join(',')
  ];

  const csvContent = '\uFEFF' + [
    escapeCsv(`REKAPITULASI IURAN KAS PAGUYUBAN RKM - ${settings?.orgName || 'RKM METRO PARUNG PANJANG'}`),
    escapeCsv(`Bulan Acuan: ${monthKey} | Tanggal Unduh: ${new Date().toLocaleString('id-ID')}`),
    '',
    headers.map(escapeCsv).join(','),
    ...rows,
    ...summaryRows
  ].join('\r\n');

  const filename = `Rekap_Iuran_RKM_${monthKey}_${new Date().toISOString().slice(0, 10)}.csv`;
  downloadBlob(csvContent, filename, 'text/csv;charset=utf-8;');
}
