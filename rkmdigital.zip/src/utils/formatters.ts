export const formatRupiah = (amount: number): string => {
  return new Intl.NumberFormat('id-ID', {
    style: 'currency',
    currency: 'IDR',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  }).format(amount);
};

export const formatDateIndo = (dateStr: string, withDay: boolean = true): string => {
  try {
    const date = new Date(dateStr);
    if (isNaN(date.getTime())) return dateStr;
    
    return new Intl.DateTimeFormat('id-ID', {
      weekday: withDay ? 'long' : undefined,
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    }).format(date);
  } catch {
    return dateStr;
  }
};

export const formatDateTimeIndo = (dateStr: string): string => {
  try {
    const date = new Date(dateStr);
    if (isNaN(date.getTime())) return dateStr;
    
    return new Intl.DateTimeFormat('id-ID', {
      weekday: 'long',
      day: 'numeric',
      month: 'long',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date) + ' WIB';
  } catch {
    return dateStr;
  }
};

const ANGKA = ['', 'Satu', 'Dua', 'Tiga', 'Empat', 'Lima', 'Enam', 'Tujuh', 'Delapan', 'Sembilan', 'Sepuluh', 'Sebelas'];

export const terbilangRupiah = (nominal: number): string => {
  if (nominal === 0) return 'Nol Rupiah';

  const sebut = (n: number): string => {
    if (n < 12) {
      return ANGKA[n];
    } else if (n < 20) {
      return sebut(n - 10) + ' Belas';
    } else if (n < 100) {
      return sebut(Math.floor(n / 10)) + ' Puluh ' + sebut(n % 10);
    } else if (n < 200) {
      return 'Seratus ' + sebut(n - 100);
    } else if (n < 1000) {
      return sebut(Math.floor(n / 100)) + ' Ratus ' + sebut(n % 100);
    } else if (n < 2000) {
      return 'Seribu ' + sebut(n - 1000);
    } else if (n < 1000000) {
      return sebut(Math.floor(n / 1000)) + ' Ribu ' + sebut(n % 1000);
    } else if (n < 1000000000) {
      return sebut(Math.floor(n / 1000000)) + ' Juta ' + sebut(n % 1000000);
    } else if (n < 1000000000000) {
      return sebut(Math.floor(n / 1000000000)) + ' Miliar ' + sebut(n % 1000000000);
    }
    return '';
  };

  const hasil = sebut(Math.abs(nominal)).replace(/\s+/g, ' ').trim();
  return `${hasil} Rupiah`;
};

export const MONTH_NAMES = [
  { key: '01', name: 'Januari', short: 'Jan' },
  { key: '02', name: 'Februari', short: 'Feb' },
  { key: '03', name: 'Maret', short: 'Mar' },
  { key: '04', name: 'April', short: 'Apr' },
  { key: '05', name: 'Mei', short: 'Mei' },
  { key: '06', name: 'Juni', short: 'Jun' },
  { key: '07', name: 'Juli', short: 'Jul' },
  { key: '08', name: 'Agustus', short: 'Agu' },
  { key: '09', name: 'September', short: 'Sep' },
  { key: '10', name: 'Oktober', short: 'Okt' },
  { key: '11', name: 'November', short: 'Nov' },
  { key: '12', name: 'Desember', short: 'Des' }
];

export const getMonthNameFromKey = (yearMonthKey: string): string => {
  const [year, month] = yearMonthKey.split('-');
  const monthObj = MONTH_NAMES.find(m => m.key === month);
  return monthObj ? `${monthObj.name} ${year}` : yearMonthKey;
};

// WhatsApp Link Generator
export const createWhatsAppUrl = (phone: string, text: string): string => {
  let cleanPhone = phone.replace(/\D/g, '');
  if (cleanPhone.startsWith('0')) {
    cleanPhone = '62' + cleanPhone.slice(1);
  }
  return `https://api.whatsapp.com/send?phone=${cleanPhone}&text=${encodeURIComponent(text)}`;
};

/**
 * Normalizes image URLs, converting Google Drive sharing links to direct CDN view links
 */
export const getDirectImageUrl = (url?: string): string => {
  if (!url) return '';
  const trimmed = url.trim();

  // If it's already a direct Googleusercontent link or data URI or direct image
  if (trimmed.includes('lh3.googleusercontent.com') || trimmed.startsWith('data:')) {
    return trimmed;
  }

  // Check for Google Drive file ID patterns
  // Pattern 1: https://drive.google.com/file/d/FILE_ID/view...
  const fileDMatch = trimmed.match(/\/file\/d\/([a-zA-Z0-9_-]+)/);
  if (fileDMatch && fileDMatch[1]) {
    return `https://lh3.googleusercontent.com/d/${fileDMatch[1]}`;
  }

  // Pattern 2: id=FILE_ID
  const idMatch = trimmed.match(/[?&]id=([a-zA-Z0-9_-]+)/);
  if (idMatch && idMatch[1]) {
    return `https://lh3.googleusercontent.com/d/${idMatch[1]}`;
  }

  // Pattern 3: open?id=FILE_ID
  const openMatch = trimmed.match(/\/open\?id=([a-zA-Z0-9_-]+)/);
  if (openMatch && openMatch[1]) {
    return `https://lh3.googleusercontent.com/d/${openMatch[1]}`;
  }

  return trimmed;
};

/**
 * Checks if a user is Super Admin
 */
export const isSuperAdmin = (user?: { username?: string; id?: string; title?: string; role?: string } | null): boolean => {
  if (!user) return false;
  const username = user.username?.toLowerCase() || '';
  const title = user.title?.toLowerCase() || '';
  const role = user.role?.toLowerCase() || '';
  const id = user.id || '';
  return role === 'superadmin' || username === 'admin' || id === 'usr-1' || title.includes('super admin');
};

/**
 * List of blocks from Blok A to Blok Z
 */
export const BLOCK_OPTIONS = Array.from({ length: 26 }, (_, i) => `Blok ${String.fromCharCode(65 + i)}`);

/**
 * List of RTs from RT 001 to RT 011
 */
export const RT_OPTIONS = [
  '001', '002', '003', '004', '005', '006', '007', '008', '009', '010', '011'
];

export const RT_LABELS: Record<string, string> = {
  '001': 'RT 001',
  '002': 'RT 002',
  '003': 'RT 003',
  '004': 'RT 004',
  '005': 'RT 005',
  '006': 'RT 006',
  '007': 'RT 007',
  '008': 'RT 008',
  '009': 'RT 009',
  '010': 'RT 010',
  '011': 'RT 011',
  // Backward compatibility with 2 digits
  '01': 'RT 001',
  '02': 'RT 002',
  '03': 'RT 003',
  '04': 'RT 004',
  '05': 'RT 005',
  '06': 'RT 006',
  '07': 'RT 007',
  '08': 'RT 008',
  '09': 'RT 009',
  '10': 'RT 010',
  '11': 'RT 011'
};

export const DEFAULT_DEATH_BUDGET_BREAKDOWN = {
  shroud: 150000,       // 1. Kain Kafan 1 Set Lengkap
  bathing: 100000,      // 2. Tim Memandikan Jenazah (2 orang x @ Rp 50.000)
  prayer: 450000,       // 3. Shalat Jenazah + Amplop Imam & Jamaah
  transport: 200000,    // 4. Mobil Jenazah / Operasional Transportasi
  gravedigger: 800000,  // 5. Gali Kubur & Papan Penutup TPU Desa Gerowong
  adminDistrict: 150000,// 6. Pengurusan Administrasi Makam Kecamatan
  tactical: 50000       // 7. Biaya Taktis Operasional Satgas
};

export interface AdArtStatusResult {
  status: 'Aktif' | 'Masa Tenggang' | 'Menunggak' | 'Gugur / Non-Aktif' | 'Non-Aktif' | 'Pindah';
  statusBadgeColor: string;
  statusBadgeText: string;
  isEligibleFullBenefit: boolean;
  isEligibleServiceOnly: boolean;
  unpaidMonthsCount: number;
  unpaidMonthsList: string[];
  membershipMonths: number;
  requiresReRegistration: boolean;
  reRegistrationFee: number;
  notes: string;
}

/**
 * Smart Auto-Calculated Status Engine (Aturan Bisnis AD/ART RKM MPP 2024–2027):
 * - Status "AKTIF": Terdaftar >= 3 Bulan DAN Iuran Lunas -> Berhak Santunan Penuh Rp 1.900.000
 * - Status "MASA TENGGANG": Terdaftar < 3 Bulan -> Berhak Pelayanan Jenazah, TANPA Santunan Tunai
 * - Status "MENUNGGAK": Tunggakan 1-3 bulan
 * - Status "GUGUR / NON-AKTIF": Tunggakan > 3 Bulan (Tanpa Konfirmasi) ATAU Pindah Domisili. Pendaftaran ulang wajib Rp 50.000.
 */
export const getAdArtCitizenStatus = (
  citizen?: { 
    status?: string; 
    joinDate?: string; 
    monthlyDues?: Record<string, { paid?: boolean }>; 
    address?: string; 
  } | null,
  currentYear: string = '2026',
  currentMonthIndex: number = 8 // August (1-based: 8)
): AdArtStatusResult => {
  if (!citizen) {
    return {
      status: 'Non-Aktif',
      statusBadgeColor: 'bg-slate-100 text-slate-700 border-slate-300',
      statusBadgeText: 'Non-Aktif',
      isEligibleFullBenefit: false,
      isEligibleServiceOnly: false,
      unpaidMonthsCount: 0,
      unpaidMonthsList: [],
      membershipMonths: 0,
      requiresReRegistration: false,
      reRegistrationFee: 50000,
      notes: 'Data warga tidak ditemukan'
    };
  }

  if (citizen.status === 'Pindah') {
    return {
      status: 'Pindah',
      statusBadgeColor: 'bg-zinc-100 text-zinc-700 border-zinc-300',
      statusBadgeText: 'Pindah Domisili',
      isEligibleFullBenefit: false,
      isEligibleServiceOnly: false,
      unpaidMonthsCount: 0,
      unpaidMonthsList: [],
      membershipMonths: 0,
      requiresReRegistration: true,
      reRegistrationFee: 50000,
      notes: 'Warga telah pindah domisili dari MPP'
    };
  }

  // Calculate membership age in months
  let membershipMonths = 12;
  if (citizen.joinDate) {
    try {
      const join = new Date(citizen.joinDate);
      const now = new Date();
      membershipMonths = (now.getFullYear() - join.getFullYear()) * 12 + (now.getMonth() - join.getMonth());
      if (membershipMonths < 0) membershipMonths = 0;
    } catch {
      membershipMonths = 12;
    }
  }

  // Calculate unpaid months up to current month (e.g. up to 2026-08)
  const unpaidMonthsList: string[] = [];
  for (let m = 1; m <= currentMonthIndex; m++) {
    const monthKey = `${currentYear}-${m.toString().padStart(2, '0')}`;
    const payment = citizen.monthlyDues?.[monthKey];
    if (!payment?.paid) {
      unpaidMonthsList.push(monthKey);
    }
  }

  const unpaidCount = unpaidMonthsList.length;

  // Evaluation Rules
  if (membershipMonths < 3) {
    return {
      status: 'Masa Tenggang',
      statusBadgeColor: 'bg-amber-100 text-amber-800 border-amber-300',
      statusBadgeText: 'Masa Tenggang (< 3 Bulan)',
      isEligibleFullBenefit: false,
      isEligibleServiceOnly: true,
      unpaidMonthsCount: unpaidCount,
      unpaidMonthsList,
      membershipMonths,
      requiresReRegistration: false,
      reRegistrationFee: 0,
      notes: 'Terdaftar < 3 Bulan: Berhak Pelayanan Jenazah & Ambulance, TANPA Santunan Tunai'
    };
  }

  if (unpaidCount > 3) {
    return {
      status: 'Gugur / Non-Aktif',
      statusBadgeColor: 'bg-rose-100 text-rose-800 border-rose-300',
      statusBadgeText: 'Gugur (Tunggakan > 3 Bulan)',
      isEligibleFullBenefit: false,
      isEligibleServiceOnly: false,
      unpaidMonthsCount: unpaidCount,
      unpaidMonthsList,
      membershipMonths,
      requiresReRegistration: true,
      reRegistrationFee: 50000,
      notes: 'Tunggakan melebihi 3 bulan: Hak santunan gugur. Jika mendaftar kembali wajib biaya registrasi Rp 50.000'
    };
  }

  if (unpaidCount > 0 && unpaidCount <= 3) {
    return {
      status: 'Menunggak',
      statusBadgeColor: 'bg-orange-100 text-orange-800 border-orange-300',
      statusBadgeText: `Menunggak (${unpaidCount} Bulan)`,
      isEligibleFullBenefit: false, // Must settle arrears before disbursement
      isEligibleServiceOnly: true,
      unpaidMonthsCount: unpaidCount,
      unpaidMonthsList,
      membershipMonths,
      requiresReRegistration: false,
      reRegistrationFee: 0,
      notes: `Menunggak ${unpaidCount} bulan. Pelayanan jenazah tetap diberikan; santunan tunai dicairkan setelah tunggakan diselesaikan`
    };
  }

  // All paid and >= 3 months
  return {
    status: 'Aktif',
    statusBadgeColor: 'bg-emerald-100 text-emerald-800 border-emerald-300',
    statusBadgeText: 'Aktif (Hak Penuh Rp 1.9jt)',
    isEligibleFullBenefit: true,
    isEligibleServiceOnly: true,
    unpaidMonthsCount: 0,
    unpaidMonthsList: [],
    membershipMonths,
    requiresReRegistration: false,
    reRegistrationFee: 0,
    notes: 'Anggota Aktif lunas iuran: Berhak Pelayanan Fardhu Kifayah & Santunan Penuh Rp 1.900.000'
  };
};
export const CORE_RELATIONS = [
  'Kepala Keluarga',
  'Istri',
  'Suami',
  'Anak',
  'Orang Tua',
  'Mertua'
];

export const EXTRA_RELATIONS = [
  'Adik',
  'Kakak',
  'Saudara',
  'Famili Lain'
];

/**
 * Determine whether a relationship is classified as Anggota Inti Jiwa
 */
export const isCoreFamilyRelation = (relation: string): boolean => {
  const rel = relation?.trim().toLowerCase() || '';
  return (
    rel.includes('kepala') ||
    rel.includes('istri') ||
    rel.includes('suami') ||
    rel.includes('anak') ||
    rel.includes('orang tua') ||
    rel.includes('ayah') ||
    rel.includes('ibu') ||
    rel.includes('mertua')
  );
};

/**
 * Categorize a relation as 'Inti' or 'Tambahan'
 */
export const getMemberCategory = (relation: string): 'Inti' | 'Tambahan' => {
  return isCoreFamilyRelation(relation) ? 'Inti' : 'Tambahan';
};

export interface CitizenDuesCalculation {
  baseFee: number;
  extraFeePerMember: number;
  coreMembersCount: number;
  extraMembersCount: number;
  totalMembersCount: number;
  totalExtraDues: number;
  totalMonthlyDues: number;
}

/**
 * Calculates monthly dues for a family / citizen:
 * - Base dues (KK & Anggota Inti): Rp 5.000 / month
 * - Extra member (Adik, Kakak, Saudara): + Rp 3.000 / member / month
 */
export const calculateCitizenMonthlyDues = (
  citizen?: { members?: Array<{ relation: string; status?: string }> } | null,
  baseFee: number = 5000,
  extraFeePerMember: number = 3000
): CitizenDuesCalculation => {
  if (!citizen || !citizen.members || citizen.members.length === 0) {
    return {
      baseFee,
      extraFeePerMember,
      coreMembersCount: 1,
      extraMembersCount: 0,
      totalMembersCount: 1,
      totalExtraDues: 0,
      totalMonthlyDues: baseFee
    };
  }

  // Count living members
  const liveMembers = citizen.members.filter(m => m.status !== 'Meninggal');
  let coreCount = 0;
  let extraCount = 0;

  liveMembers.forEach(m => {
    if (isCoreFamilyRelation(m.relation)) {
      coreCount++;
    } else {
      extraCount++;
    }
  });

  const totalExtraDues = extraCount * extraFeePerMember;
  const totalMonthlyDues = baseFee + totalExtraDues;

  return {
    baseFee,
    extraFeePerMember,
    coreMembersCount: coreCount,
    extraMembersCount: extraCount,
    totalMembersCount: liveMembers.length,
    totalExtraDues,
    totalMonthlyDues
  };
};

/**
 * Generate high quality standard avatar URL based on name and role
 */
export const getAvatarUrl = (name: string, role?: string, customAvatar?: string): string => {
  if (customAvatar && customAvatar.trim() !== '') {
    return getDirectImageUrl(customAvatar);
  }

  // Generate color palette based on role
  let bg = '047857'; // emerald for general
  let color = 'ffffff';

  if (role === 'superadmin') bg = '581c87'; // purple
  else if (role === 'bendahara') bg = 'b45309'; // amber
  else if (role === 'ketua') bg = '1d4ed8'; // blue
  else if (role === 'tim_jenazah' || role === 'petugas') bg = '0f766e'; // teal
  else if (role === 'koordinator') bg = '0369a1'; // sky
  else if (role === 'warga') bg = '059669'; // emerald

  const cleanName = encodeURIComponent(name || 'User');
  return `https://ui-avatars.com/api/?name=${cleanName}&background=${bg}&color=${color}&bold=true&size=128&rounded=true`;
};

