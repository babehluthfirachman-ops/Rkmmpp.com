import React, { createContext, useContext, useState, useEffect, useRef } from 'react';
import confetti from 'canvas-confetti';
import { 
  UserRole, 
  UserProfile, 
  Citizen, 
  Transaction, 
  DeathNotice, 
  Asset, 
  AssetLoan, 
  OrganizationSettings, 
  FeedbackMessage, 
  Officer,
  FamilyMember,
  MonthPayment,
  SystemPermission,
  SecurityPolicy,
  AccessAuditLog,
  AppNotification,
  ThemeMode,
  DutySchedule,
  SuperadminSystemSettings
} from '../types';
import { 
  INITIAL_USERS,
  INITIAL_SETTINGS, 
  INITIAL_CITIZENS, 
  INITIAL_TRANSACTIONS, 
  INITIAL_DEATH_NOTICES, 
  INITIAL_ASSETS, 
  INITIAL_ASSET_LOANS, 
  INITIAL_FEEDBACKS, 
  INITIAL_OFFICERS,
  DEFAULT_PERMISSIONS,
  DEFAULT_SECURITY_POLICY,
  INITIAL_SUPERADMIN_SETTINGS,
  INITIAL_AUDIT_LOGS,
  INITIAL_NOTIFICATIONS,
  INITIAL_DUTY_SCHEDULES
} from '../data/initialData';
import { calculateCitizenMonthlyDues } from '../utils/formatters';
import { syncDatabaseToGoogleSheet, FullSyncPayload } from '../utils/googleSheetsSync';

export interface ActiveReceiptData {
  receiptNo: string;
  citizen: Citizen;
  monthsPaid: string[];
  duesAmount: number;
  infaqAmount: number;
  totalAmount: number;
  date: string;
  paymentMethod: string;
  collector: string;
}

interface RkmContextType {
  currentUser: UserProfile | null;
  currentRole: UserRole;
  users: UserProfile[];
  citizens: Citizen[];
  transactions: Transaction[];
  deathNotices: DeathNotice[];
  assets: Asset[];
  assetLoans: AssetLoan[];
  settings: OrganizationSettings;
  superadminSettings: SuperadminSystemSettings;
  officers: Officer[];
  dutySchedules: DutySchedule[];
  feedbacks: FeedbackMessage[];
  permissions: SystemPermission[];
  rolePermissions: Record<string, UserRole[]>;
  securityPolicy: SecurityPolicy;
  auditLogs: AccessAuditLog[];
  notifications: AppNotification[];
  unreadNotificationsCount: number;
  theme: ThemeMode;
  activeReceipt: ActiveReceiptData | null;
  selectedKtaCitizen: Citizen | null;
  selectedLelayu: DeathNotice | null;
  selectedProfileCitizen: Citizen | null;
  isProfileModalOpen: boolean;
  
  // Theme & Notifications
  toggleTheme: () => void;
  setTheme: (mode: ThemeMode) => void;
  addNotification: (notif: Omit<AppNotification, 'id' | 'createdAt' | 'read'>) => void;
  markNotificationAsRead: (id: string) => void;
  markAllNotificationsAsRead: () => void;
  deleteNotification: (id: string) => void;
  
  // Modals
  openReceiptModal: (data: ActiveReceiptData) => void;
  closeReceiptModal: () => void;
  openKtaModal: (citizen: Citizen) => void;
  closeKtaModal: () => void;
  openLelayuModal: (lelayu: DeathNotice) => void;
  closeLelayuModal: () => void;
  openProfileModal: (citizen?: Citizen) => void;
  closeProfileModal: () => void;

  // Actions
  login: (username: string, role?: UserRole, password?: string) => boolean;
  quickSwitchRole: (role: UserRole) => void;
  logout: () => void;
  processPayment: (params: {
    noKK: string;
    months: string[];
    infaqAmount?: number;
    paymentMethod: 'Tunai' | 'Transfer Bank' | 'QRIS' | 'Kolektif';
    collector?: string;
  }) => string | null;
  
  // Account & Access Actions
  addUser: (user: Omit<UserProfile, 'id'>) => void;
  updateUser: (id: string, user: Partial<UserProfile>) => void;
  deleteUser: (id: string) => void;
  toggleUserStatus: (id: string) => void;
  resetUserPassword: (id: string, newPin: string) => void;
  updateRolePermission: (permissionId: string, roles: UserRole[]) => void;
  resetRolePermissions: () => void;
  updateSecurityPolicy: (policy: Partial<SecurityPolicy>) => void;
  addAuditLog: (log: Omit<AccessAuditLog, 'id' | 'timestamp'>) => void;
  clearAuditLogs: () => void;

  addTransaction: (tx: Omit<Transaction, 'id'>) => void;
  deleteTransaction: (id: string) => void;
  
  addCitizen: (c: Omit<Citizen, 'id'>) => void;
  updateCitizen: (id: string, c: Partial<Citizen>) => void;
  deleteCitizen: (id: string) => void;
  
  addFamilyMember: (citizenId: string, member: Omit<FamilyMember, 'id'>) => void;
  updateFamilyMember: (citizenId: string, memberId: string, member: Partial<FamilyMember>) => void;
  deleteFamilyMember: (citizenId: string, memberId: string) => void;
  
  addDeathNotice: (dn: Omit<DeathNotice, 'id' | 'createdAt'>, createAssistanceTx?: boolean) => void;
  updateDeathNotice: (id: string, dn: Partial<DeathNotice>) => void;
  
  addAsset: (asset: Omit<Asset, 'id'>) => void;
  updateAsset: (id: string, asset: Partial<Asset>) => void;
  addAssetLoan: (loan: Omit<AssetLoan, 'id'>) => void;
  returnAssetLoan: (loanId: string) => void;
  
  updateSettings: (newSettings: Partial<OrganizationSettings>) => void;
  updateSuperadminSettings: (newSettings: Partial<SuperadminSystemSettings>) => Promise<boolean>;
  addOfficer: (officer: Omit<Officer, 'id'>) => void;
  updateOfficer: (id: string, officer: Partial<Officer>) => void;
  deleteOfficer: (id: string) => void;
  addDutySchedule: (duty: Omit<DutySchedule, 'id'>) => void;
  updateDutySchedule: (id: string, duty: Partial<DutySchedule>) => void;
  deleteDutySchedule: (id: string) => void;
  addFeedback: (fb: Omit<FeedbackMessage, 'id' | 'createdAt' | 'status'>) => void;
  replyFeedback: (id: string, reply: string) => void;
  
  syncGoogleSheets: () => Promise<boolean>;
  importFullData: (data: any) => boolean;
  resetToDefaultData: () => void;
  resetToDemo: () => void;
  runAutoAging: (forceManual?: boolean) => { updatedCount: number; message: string };
}

const RkmContext = createContext<RkmContextType | undefined>(undefined);

const STORAGE_KEYS = {
  CURRENT_USER: 'rkm_mpp_current_user_v3',
  USERS: 'rkm_mpp_users_v3',
  CITIZENS: 'rkm_mpp_citizens_v3',
  TRANSACTIONS: 'rkm_mpp_transactions_v3',
  DEATH_NOTICES: 'rkm_mpp_death_notices_v3',
  ASSETS: 'rkm_mpp_assets_v3',
  ASSET_LOANS: 'rkm_mpp_asset_loans_v3',
  SETTINGS: 'rkm_mpp_settings_v3',
  SUPERADMIN_SETTINGS: 'rkm_mpp_superadmin_settings_v3',
  FEEDBACKS: 'rkm_mpp_feedbacks_v3',
  OFFICERS: 'rkm_mpp_officers_v3',
  DUTY_SCHEDULES: 'rkm_mpp_duty_schedules_v3',
  SECURITY_POLICY: 'rkm_mpp_security_policy_v3',
  ROLE_PERMISSIONS: 'rkm_mpp_role_permissions_v3',
  AUDIT_LOGS: 'rkm_mpp_audit_logs_v3',
  NOTIFICATIONS: 'rkm_mpp_notifications_v3'
};

// Immediate clean slate: purge all legacy mock database keys so the app boots completely empty
try {
  if (typeof window !== 'undefined' && !localStorage.getItem('rkm_empty_db_clean_slate_v3')) {
    for (let i = localStorage.length - 1; i >= 0; i--) {
      const key = localStorage.key(i);
      if (key && (key.startsWith('rkm_mpp_') || key.startsWith('rkm_'))) {
        localStorage.removeItem(key);
      }
    }
    localStorage.setItem('rkm_empty_db_clean_slate_v3', 'true');
  }
} catch {}

export const RkmProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Theme state (Dark Mode / Light Mode)
  const [theme, setThemeState] = useState<ThemeMode>(() => {
    const saved = localStorage.getItem('rkm_theme') as ThemeMode | null;
    if (saved && (saved === 'dark' || saved === 'light')) return saved;
    return 'light';
  });

  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    localStorage.setItem('rkm_theme', theme);
  }, [theme]);

  const toggleTheme = () => {
    setThemeState(prev => (prev === 'dark' ? 'light' : 'dark'));
  };

  const setTheme = (mode: ThemeMode) => {
    setThemeState(mode);
  };

  // In-app Notifications
  const [notifications, setNotifications] = useState<AppNotification[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.NOTIFICATIONS);
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return INITIAL_NOTIFICATIONS;
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(notifications));
  }, [notifications]);

  const unreadNotificationsCount = notifications.filter(n => !n.read).length;

  const addNotification = (notifData: Omit<AppNotification, 'id' | 'createdAt' | 'read'>) => {
    const newNotif: AppNotification = {
      ...notifData,
      id: `notif-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      createdAt: new Date().toISOString().replace('T', ' ').slice(0, 16),
      read: false
    };
    setNotifications(prev => [newNotif, ...prev]);
  };

  const markNotificationAsRead = (id: string) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
  };

  const markAllNotificationsAsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  };

  const deleteNotification = (id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  };

  // Registered System Users
  const [users, setUsers] = useState<UserProfile[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.USERS);
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return INITIAL_USERS;
  });

  // Current user / role (Default to null so user opens directly to public portal without premature auth)
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(() => {
    // Clear any persistent auto-login so opening the web always starts unauthenticated on Beranda
    try {
      localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
    } catch {}
    return null;
  });

  // Role Permissions Matrix
  const [rolePermissions, setRolePermissions] = useState<Record<string, UserRole[]>>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.ROLE_PERMISSIONS);
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    const initialMap: Record<string, UserRole[]> = {};
    DEFAULT_PERMISSIONS.forEach(p => {
      initialMap[p.id] = p.defaultRoles;
    });
    return initialMap;
  });

  // Security Policy
  const [securityPolicy, setSecurityPolicy] = useState<SecurityPolicy>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.SECURITY_POLICY);
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return DEFAULT_SECURITY_POLICY;
  });

  // Audit Logs
  const [auditLogs, setAuditLogs] = useState<AccessAuditLog[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.AUDIT_LOGS);
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return INITIAL_AUDIT_LOGS;
  });

  const [citizens, setCitizens] = useState<Citizen[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.CITIZENS);
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return INITIAL_CITIZENS;
  });

  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.TRANSACTIONS);
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return INITIAL_TRANSACTIONS;
  });

  const [deathNotices, setDeathNotices] = useState<DeathNotice[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.DEATH_NOTICES);
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return INITIAL_DEATH_NOTICES;
  });

  const [assets, setAssets] = useState<Asset[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.ASSETS);
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return INITIAL_ASSETS;
  });

  const [assetLoans, setAssetLoans] = useState<AssetLoan[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.ASSET_LOANS);
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return INITIAL_ASSET_LOANS;
  });

  const [settings, setSettings] = useState<OrganizationSettings>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.SETTINGS);
    if (saved) {
      try { 
        const parsed = JSON.parse(saved);
        return {
          ...INITIAL_SETTINGS,
          ...parsed,
          logoUrl: parsed.logoUrl || INITIAL_SETTINGS.logoUrl
        };
      } catch {}
    }
    return INITIAL_SETTINGS;
  });

  const [superadminSettings, setSuperadminSettings] = useState<SuperadminSystemSettings>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.SUPERADMIN_SETTINGS);
    if (saved) {
      try { 
        const parsed = JSON.parse(saved);
        return {
          ...INITIAL_SUPERADMIN_SETTINGS,
          ...parsed
        };
      } catch {}
    }
    return INITIAL_SUPERADMIN_SETTINGS;
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.SUPERADMIN_SETTINGS, JSON.stringify(superadminSettings));
  }, [superadminSettings]);

  // Sync superadmin settings from backend API
  useEffect(() => {
    fetch('/api/superadmin/settings', {
      headers: {
        'x-user-role': currentUser?.role || 'superadmin',
        'x-user-name': currentUser?.name || 'admin'
      }
    })
      .then(res => res.ok ? res.json() : null)
      .then(data => {
        if (data && data.settings) {
          setSuperadminSettings(prev => ({
            ...prev,
            ...data.settings
          }));
        }
      })
      .catch(() => {
        // Fallback to localStorage
      });
  }, [currentUser?.role, currentUser?.name]);

  const updateSuperadminSettings = async (newSettings: Partial<SuperadminSystemSettings>): Promise<boolean> => {
    setSuperadminSettings(prev => ({
      ...prev,
      ...newSettings
    }));

    try {
      await fetch('/api/superadmin/settings', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-user-role': currentUser?.role || 'superadmin',
          'x-user-name': currentUser?.name || 'admin'
        },
        body: JSON.stringify(newSettings)
      });
    } catch {}

    addAuditLog({
      userName: currentUser?.name || 'Super Admin',
      userRole: currentUser?.role || 'superadmin',
      action: 'SUPERADMIN_SETTINGS_UPDATED',
      details: `Pengaturan sistem superadmin diperbarui oleh ${currentUser?.name || 'Super Admin'}`,
      ipAddress: '182.253.14.88 (System Settings)',
      status: 'Success'
    });

    return true;
  };

  const [feedbacks, setFeedbacks] = useState<FeedbackMessage[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.FEEDBACKS);
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return INITIAL_FEEDBACKS;
  });

  const [officers, setOfficers] = useState<Officer[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.OFFICERS);
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return INITIAL_OFFICERS;
  });

  const [dutySchedules, setDutySchedules] = useState<DutySchedule[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.DUTY_SCHEDULES);
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return INITIAL_DUTY_SCHEDULES;
  });

  // Modal states
  const [activeReceipt, setActiveReceipt] = useState<ActiveReceiptData | null>(null);
  const [selectedKtaCitizen, setSelectedKtaCitizen] = useState<Citizen | null>(null);
  const [selectedLelayu, setSelectedLelayu] = useState<DeathNotice | null>(null);
  const [selectedProfileCitizen, setSelectedProfileCitizen] = useState<Citizen | null>(null);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState<boolean>(false);

  const openProfileModal = (citizen?: Citizen) => {
    if (citizen) {
      setSelectedProfileCitizen(citizen);
    } else {
      const match = citizens.find(c => c.noKK === currentUser?.noKK) || citizens[0];
      setSelectedProfileCitizen(match || null);
    }
    setIsProfileModalOpen(true);
  };

  const closeProfileModal = () => {
    setIsProfileModalOpen(false);
    setSelectedProfileCitizen(null);
  };

  // Sync to local storage
  useEffect(() => {
    if (currentUser) {
      localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(currentUser));
    } else {
      localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
    }
  }, [currentUser]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
  }, [users]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.ROLE_PERMISSIONS, JSON.stringify(rolePermissions));
  }, [rolePermissions]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.SECURITY_POLICY, JSON.stringify(securityPolicy));
  }, [securityPolicy]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.AUDIT_LOGS, JSON.stringify(auditLogs));
  }, [auditLogs]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CITIZENS, JSON.stringify(citizens));
  }, [citizens]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.TRANSACTIONS, JSON.stringify(transactions));
  }, [transactions]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.DEATH_NOTICES, JSON.stringify(deathNotices));
  }, [deathNotices]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.ASSETS, JSON.stringify(assets));
  }, [assets]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.ASSET_LOANS, JSON.stringify(assetLoans));
  }, [assetLoans]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
  }, [settings]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.FEEDBACKS, JSON.stringify(feedbacks));
  }, [feedbacks]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.OFFICERS, JSON.stringify(officers));
  }, [officers]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.DUTY_SCHEDULES, JSON.stringify(dutySchedules));
  }, [dutySchedules]);

  const addAuditLog = (log: Omit<AccessAuditLog, 'id' | 'timestamp'>) => {
    const newLog: AccessAuditLog = {
      ...log,
      id: `log-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      timestamp: new Date().toLocaleString('id-ID', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
      }).replace(/\./g, ':')
    };
    setAuditLogs(prev => [newLog, ...prev.slice(0, 49)]); // Keep last 50 logs
  };

  const clearAuditLogs = () => {
    setAuditLogs([]);
  };

  // User Account Management
  const addUser = (userData: Omit<UserProfile, 'id'>) => {
    const newUser: UserProfile = {
      ...userData,
      id: `usr-${Date.now()}`,
      status: userData.status || 'Aktif',
      createdAt: new Date().toISOString().split('T')[0]
    };
    setUsers(prev => [newUser, ...prev]);
    addAuditLog({
      userName: currentUser?.name || 'Sistem',
      userRole: currentUser?.role || 'bendahara',
      action: 'USER_CREATED',
      details: `Akun baru dibuat: ${newUser.name} (@${newUser.username}) role: ${newUser.role}`,
      ipAddress: '182.253.14.88 (Dashboard Admin)',
      status: 'Success'
    });
  };

  const updateUser = (id: string, updatedData: Partial<UserProfile>) => {
    setUsers(prev => prev.map(u => u.id === id ? { ...u, ...updatedData } : u));
    if (currentUser?.id === id) {
      setCurrentUser(prev => prev ? { ...prev, ...updatedData } : null);
    }
    addAuditLog({
      userName: currentUser?.name || 'Sistem',
      userRole: currentUser?.role || 'bendahara',
      action: 'USER_UPDATED',
      details: `Profil akun ${id} diperbarui`,
      ipAddress: '182.253.14.88 (Dashboard Admin)',
      status: 'Success'
    });
  };

  const deleteUser = (id: string) => {
    const target = users.find(u => u.id === id);
    setUsers(prev => prev.filter(u => u.id !== id));
    addAuditLog({
      userName: currentUser?.name || 'Sistem',
      userRole: currentUser?.role || 'bendahara',
      action: 'USER_DELETED',
      details: `Akun dihapus: ${target?.name || id} (@${target?.username || ''})`,
      ipAddress: '182.253.14.88 (Dashboard Admin)',
      status: 'Warning'
    });
  };

  const toggleUserStatus = (id: string) => {
    setUsers(prev => prev.map(u => {
      if (u.id === id) {
        const nextStatus = u.status === 'Terkunci' ? 'Aktif' : 'Terkunci';
        return { ...u, status: nextStatus };
      }
      return u;
    }));
  };

  const resetUserPassword = (id: string, newPin: string) => {
    setUsers(prev => prev.map(u => {
      if (u.id === id) {
        return { ...u, password: newPin, status: 'Aktif' };
      }
      return u;
    }));
    const target = users.find(u => u.id === id);
    addAuditLog({
      userName: currentUser?.name || 'Sistem',
      userRole: currentUser?.role || 'bendahara',
      action: 'PASSWORD_RESET',
      details: `PIN/Password akun ${target?.name || id} direset`,
      ipAddress: '182.253.14.88 (Dashboard Admin)',
      status: 'Success'
    });
  };

  const updateRolePermission = (permissionId: string, roles: UserRole[]) => {
    setRolePermissions(prev => ({
      ...prev,
      [permissionId]: roles
    }));
  };

  const resetRolePermissions = () => {
    const initialMap: Record<string, UserRole[]> = {};
    DEFAULT_PERMISSIONS.forEach(p => {
      initialMap[p.id] = p.defaultRoles;
    });
    setRolePermissions(initialMap);
  };

  const updateSecurityPolicy = (policy: Partial<SecurityPolicy>) => {
    setSecurityPolicy(prev => ({ ...prev, ...policy }));
  };

  // Login handler
  const login = (username: string, role?: UserRole, password?: string): boolean => {
    const cleanUser = username.trim().toLowerCase();
    
    // Check in registered users list
    let found = users.find(u => u.username.toLowerCase() === cleanUser || u.phone.replace(/\D/g, '') === cleanUser.replace(/\D/g, ''));
    
    // Also check by No KK or NIK for citizen
    if (!found) {
      const citizenMatch = citizens.find(c => c.noKK === cleanUser || c.nik === cleanUser || c.phone.replace(/\D/g, '') === cleanUser.replace(/\D/g, ''));
      if (citizenMatch) {
        found = {
          id: `usr-${citizenMatch.id}`,
          username: citizenMatch.noKK,
          name: citizenMatch.headOfFamily,
          role: 'warga',
          phone: citizenMatch.phone,
          noKK: citizenMatch.noKK,
          rt: citizenMatch.rt,
          rw: citizenMatch.rw,
          status: 'Aktif',
          title: `Warga RT ${citizenMatch.rt}/RW ${citizenMatch.rw}`,
          avatar: ''
        };
      }
    }

    if (found) {
      if (found.status === 'Terkunci') {
        addAuditLog({
          userName: found.name,
          userRole: found.role,
          action: 'LOGIN_BLOCKED',
          details: `Percobaan login akun terkunci (@${found.username})`,
          ipAddress: '182.253.14.88 (Web Portal)',
          status: 'Failed'
        });
        return false;
      }

      const nowFormatted = new Date().toLocaleString('id-ID', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      }) + ' WIB';

      const updatedUser = { ...found, lastLogin: nowFormatted };
      setCurrentUser(updatedUser);
      setUsers(prev => prev.map(u => u.id === found!.id ? updatedUser : u));

      addAuditLog({
        userName: found.name,
        userRole: found.role,
        action: 'LOGIN_SUCCESS',
        details: `Login berhasil sebagai ${found.role.toUpperCase()} (@${found.username})`,
        ipAddress: '182.253.14.88 (Web Portal)',
        status: 'Success'
      });
      return true;
    }

    // Fallback if role is explicitly chosen
    if (role) {
      const roleUser = users.find(u => u.role === role) || INITIAL_USERS.find(u => u.role === role);
      if (roleUser) {
        setCurrentUser(roleUser);
        addAuditLog({
          userName: roleUser.name,
          userRole: roleUser.role,
          action: 'LOGIN_QUICK_ROLE',
          details: `Login cepat peran: ${role.toUpperCase()}`,
          ipAddress: '182.253.14.88 (Portal Web)',
          status: 'Success'
        });
        return true;
      }
    }

    addAuditLog({
      userName: username,
      userRole: role || 'guest',
      action: 'LOGIN_FAILED',
      details: `Kredensial tidak ditemukan untuk input: "${username}"`,
      ipAddress: '182.253.14.88 (Web Portal)',
      status: 'Failed'
    });

    return false;
  };

  const quickSwitchRole = (role: UserRole) => {
    const targetUser = users.find(u => u.role === role) || INITIAL_USERS.find(u => u.role === role);
    if (targetUser) {
      setCurrentUser(targetUser);
    }
  };

  const logout = () => {
    if (currentUser) {
      addAuditLog({
        userName: currentUser.name,
        userRole: currentUser.role,
        action: 'LOGOUT',
        details: `Pengguna keluar dari sesi aplikasi`,
        ipAddress: '182.253.14.88 (Web Portal)',
        status: 'Success'
      });
    }
    setCurrentUser(null);
  };

  // Process Dues Payment
  const processPayment = ({
    noKK,
    months,
    infaqAmount = 0,
    paymentMethod,
    collector = 'Petugas Kas'
  }: {
    noKK: string;
    months: string[];
    infaqAmount?: number;
    paymentMethod: 'Tunai' | 'Transfer Bank' | 'QRIS' | 'Kolektif';
    collector?: string;
  }): string | null => {
    const citizen = citizens.find(c => c.noKK === noKK);
    if (!citizen) return null;

    const timestamp = new Date();
    const dateStr = timestamp.toISOString().split('T')[0];
    const receiptNo = `RKM-${timestamp.getFullYear()}${(timestamp.getMonth() + 1).toString().padStart(2, '0')}-${Math.floor(1000 + Math.random() * 9000)}`;
    
    // Dynamic dues calculation based on core vs extra members
    const baseFee = settings.baseDuesAmount || settings.duesAmount || 5000;
    const extraFee = settings.extraMemberDuesAmount || 3000;
    const duesCalc = calculateCitizenMonthlyDues(citizen, baseFee, extraFee);
    const monthlyRate = duesCalc.totalMonthlyDues;
    const duesTotal = months.length * monthlyRate;
    const grandTotal = duesTotal + infaqAmount;

    // Update citizen dues map
    const updatedMonthlyDues = { ...citizen.monthlyDues };
    months.forEach(mKey => {
      updatedMonthlyDues[mKey] = {
        paid: true,
        paidAt: dateStr,
        receiptNo,
        amount: monthlyRate,
        paymentMethod,
        collector
      };
    });

    setCitizens(prev => prev.map(c => c.noKK === noKK ? { ...c, monthlyDues: updatedMonthlyDues } : c));

    // Create Transaction Record
    const monthText = months.join(', ');
    const newTx: Transaction = {
      id: `tx-${Date.now()}`,
      type: 'in',
      category: 'Iuran Wajib',
      amount: grandTotal,
      date: dateStr,
      description: `Pembayaran Iuran Kas (${monthText}) an. ${citizen.headOfFamily} (No. KK: ${citizen.noKK}, RT ${citizen.rt})${infaqAmount > 0 ? ` + Infaq Rp ${infaqAmount.toLocaleString('id-ID')}` : ''}`,
      recipientOrPayer: citizen.headOfFamily,
      noKK: citizen.noKK,
      receiptNo,
      paymentMethod,
      verifiedBy: currentUser?.name || collector
    };

    setTransactions(prev => [newTx, ...prev]);

    // Add Audit Log for Payment Processing
    addAuditLog({
      userName: currentUser?.name || collector,
      userRole: currentUser?.role || 'bendahara',
      action: 'PAYMENT_PROCESSED',
      details: `Pemrosesan Iuran Kas KK ${citizen.headOfFamily} (${months.join(', ')}) Total Rp ${grandTotal.toLocaleString('id-ID')} [No. Kwitansi: ${receiptNo}, Metode: ${paymentMethod}]`,
      ipAddress: '182.253.14.88 (Kasir Iuran)',
      status: 'Success'
    });

    // Add In-App Notification for Payment
    addNotification({
      title: `Pembayaran Iuran Kas Diterima (${receiptNo})`,
      message: `Setoran kas iuran (${months.join(', ')}) senilai ${grandTotal.toLocaleString('id-ID')} atas nama KK ${citizen.headOfFamily} telah sukses dibukukan.`,
      category: 'iuran',
      type: 'success',
      targetNoKK: citizen.noKK,
      linkTab: 'iuran'
    });

    // Active receipt for modal
    const receiptData: ActiveReceiptData = {
      receiptNo,
      citizen,
      monthsPaid: months,
      duesAmount: duesTotal,
      infaqAmount,
      totalAmount: grandTotal,
      date: dateStr,
      paymentMethod,
      collector
    };

    setActiveReceipt(receiptData);

    // Trigger celebration confetti
    try {
      confetti({
        particleCount: 80,
        spread: 60,
        origin: { y: 0.6 }
      });
    } catch {}

    return receiptNo;
  };

  const addTransaction = (tx: Omit<Transaction, 'id'>) => {
    const newTx: Transaction = {
      ...tx,
      id: `tx-${Date.now()}`
    };
    setTransactions(prev => [newTx, ...prev]);
    addAuditLog({
      userName: currentUser?.name || 'Bendahara',
      userRole: currentUser?.role || 'bendahara',
      action: tx.type === 'in' ? 'KAS_MASUK' : 'KAS_KELUAR',
      details: `Catat ${tx.type === 'in' ? 'Pemasukan' : 'Pengeluaran'} [${tx.category}]: Rp ${tx.amount.toLocaleString('id-ID')} (${tx.description})`,
      ipAddress: '182.253.14.88 (Buku Kas)',
      status: 'Success'
    });
  };

  const deleteTransaction = (id: string) => {
    const target = transactions.find(t => t.id === id);
    setTransactions(prev => prev.filter(t => t.id !== id));
    addAuditLog({
      userName: currentUser?.name || 'Bendahara',
      userRole: currentUser?.role || 'bendahara',
      action: 'KAS_DIHAPUS',
      details: `Hapus transaksi ${target?.type === 'in' ? 'Pemasukan' : 'Pengeluaran'} [${target?.category || ''}]: Rp ${(target?.amount || 0).toLocaleString('id-ID')} (${target?.description || id})`,
      ipAddress: '182.253.14.88 (Buku Kas)',
      status: 'Warning'
    });
  };

  // Auto-Aging Status Iuran Otomatis
  const runAutoAging = (forceManual: boolean = false): { updatedCount: number; message: string } => {
    const now = new Date();
    const currentYear = now.getFullYear();
    const currentMonth = now.getMonth() + 1; // 1 to 12
    const currentDay = now.getDate();
    const dueDay = settings.autoAgingDueDay || 10;
    const graceMonths = settings.autoAgingGraceMonths || settings.gracePeriodMonths || 3;

    if (!settings.autoAgingEnabled && !forceManual) {
      return { updatedCount: 0, message: 'Auto-Aging dinonaktifkan di pengaturan sistem.' };
    }

    let updatedCount = 0;
    const newCitizens = citizens.map(cit => {
      if (cit.status === 'Pindah' || cit.status === 'Non-Aktif') {
        return cit;
      }

      // Check last 6 months up to current month (or previous month if before dueDay)
      const monthsToCheck: string[] = [];
      const endMonth = currentDay > dueDay ? currentMonth : currentMonth - 1;

      for (let i = 0; i < 6; i++) {
        let m = endMonth - i;
        let y = currentYear;
        if (m <= 0) {
          m += 12;
          y -= 1;
        }
        monthsToCheck.push(`${y}-${m.toString().padStart(2, '0')}`);
      }

      let unpaidCount = 0;
      for (const mKey of monthsToCheck) {
        if (!cit.monthlyDues[mKey]?.paid) {
          unpaidCount++;
        }
      }

      let newStatus = cit.status;
      if (unpaidCount >= graceMonths) {
        newStatus = 'Menunggak';
      } else if (unpaidCount > 0) {
        newStatus = 'Masa Tenggang';
      } else {
        newStatus = 'Aktif';
      }

      if (newStatus !== cit.status) {
        updatedCount++;
        return { ...cit, status: newStatus };
      }
      return cit;
    });

    if (updatedCount > 0) {
      setCitizens(newCitizens);
      const timestamp = new Date().toLocaleString('id-ID');
      setSettings(prev => ({ ...prev, lastAutoAgingRun: timestamp }));
      addAuditLog({
        userName: currentUser?.name || 'Sistem Otomatis',
        userRole: currentUser?.role || 'superadmin',
        action: 'AUTO_AGING_RUN',
        details: `Auto-Aging Status Iuran berhasil dijalankan: ${updatedCount} KK disesuaikan statusnya (Batas Tgl: ${dueDay}, Toleransi: ${graceMonths} Bln)`,
        ipAddress: '182.253.14.88 (Scheduler Sistem)',
        status: 'Success'
      });
    }

    return {
      updatedCount,
      message: `Auto-Aging selesai: ${updatedCount} data warga diselaraskan status iurannya.`
    };
  };

  const addCitizen = (c: Omit<Citizen, 'id'>) => {
    const newCit: Citizen = {
      ...c,
      id: `cit-${Date.now()}`
    };
    setCitizens(prev => [newCit, ...prev]);
    addAuditLog({
      userName: currentUser?.name || 'Super Admin',
      userRole: currentUser?.role || 'bendahara',
      action: 'CITIZEN_CREATED',
      details: `Pendaftaran KK baru: ${newCit.headOfFamily} (No. KK: ${newCit.noKK})`,
      ipAddress: '182.253.14.88 (Dashboard)',
      status: 'Success'
    });
  };

  const updateCitizen = (id: string, c: Partial<Citizen>) => {
    const target = citizens.find(item => item.id === id);
    setCitizens(prev => prev.map(item => item.id === id ? { ...item, ...c } : item));
    
    // Sinkronisasi dua arah ke Pengurus jika warga ini adalah pengurus terpilih
    setOfficers(prev => prev.map(off => {
      if (off.citizenId === id || (target && off.noKK === target.noKK) || (off.name === target?.headOfFamily)) {
        return {
          ...off,
          citizenId: id,
          name: c.headOfFamily || off.name,
          phone: c.phone || off.phone,
          photo: c.avatar || off.photo,
          ktaNumber: c.ktaNumber || off.ktaNumber,
          address: c.address || off.address,
          block: c.block || off.block,
          houseNumber: c.houseNumber || off.houseNumber,
          rt: c.rt || off.rt,
          rw: c.rw || off.rw,
          role: c.officerRole || off.role,
          dutyStatus: c.officerDutyStatus || off.dutyStatus,
          division: c.officerDivision || off.division
        };
      }
      return off;
    }));

    addAuditLog({
      userName: currentUser?.name || 'Super Admin',
      userRole: currentUser?.role || 'bendahara',
      action: 'CITIZEN_UPDATED',
      details: `Data KK/Warga diperbarui: ${c.headOfFamily || target?.headOfFamily || id} (No. KK: ${c.noKK || target?.noKK || ''})`,
      ipAddress: '182.253.14.88 (Dashboard)',
      status: 'Success'
    });
  };

  const deleteCitizen = (id: string) => {
    const target = citizens.find(item => item.id === id);
    setCitizens(prev => prev.filter(item => item.id !== id));
    // Jika warga yang dihapus berstatus pengurus, lepaskan dari data pengurus
    setOfficers(prev => prev.filter(o => o.citizenId !== id && (!target || o.noKK !== target.noKK)));
    addAuditLog({
      userName: currentUser?.name || 'Super Admin',
      userRole: currentUser?.role || 'bendahara',
      action: 'CITIZEN_DELETED',
      details: `Data KK/Warga dihapus: ${target?.headOfFamily || id} (No. KK: ${target?.noKK || ''})`,
      ipAddress: '182.253.14.88 (Dashboard)',
      status: 'Warning'
    });
  };

  const addFamilyMember = (citizenId: string, member: Omit<FamilyMember, 'id'>) => {
    const newMember: FamilyMember = {
      ...member,
      id: `m-${Date.now()}`
    };
    const target = citizens.find(c => c.id === citizenId);
    setCitizens(prev => prev.map(c => {
      if (c.id === citizenId) {
        return {
          ...c,
          members: [...c.members, newMember]
        };
      }
      return c;
    }));
    addAuditLog({
      userName: currentUser?.name || 'Super Admin',
      userRole: currentUser?.role || 'bendahara',
      action: 'MEMBER_ADDED',
      details: `Penambahan jiwa baru: ${newMember.name} (${newMember.relation}) ke KK ${target?.headOfFamily || citizenId}`,
      ipAddress: '182.253.14.88 (Dashboard)',
      status: 'Success'
    });
  };

  const updateFamilyMember = (citizenId: string, memberId: string, member: Partial<FamilyMember>) => {
    const target = citizens.find(c => c.id === citizenId);
    const prevMember = target?.members.find(m => m.id === memberId);
    setCitizens(prev => prev.map(c => {
      if (c.id === citizenId) {
        const updatedMembers = c.members.map(m => m.id === memberId ? { ...m, ...member } : m);
        // If this member was the head of family or relation changed to Kepala Keluarga, keep headOfFamily synced
        const isHead = member.relation === 'Kepala Keluarga' || prevMember?.relation === 'Kepala Keluarga';
        return {
          ...c,
          headOfFamily: (isHead && member.name) ? member.name : c.headOfFamily,
          nik: (isHead && member.nik) ? member.nik : c.nik,
          members: updatedMembers
        };
      }
      return c;
    }));
    addAuditLog({
      userName: currentUser?.name || 'Super Admin',
      userRole: currentUser?.role || 'bendahara',
      action: 'MEMBER_UPDATED',
      details: `Perubahan data jiwa: ${member.name || prevMember?.name || memberId} pada KK ${target?.headOfFamily || citizenId}`,
      ipAddress: '182.253.14.88 (Dashboard)',
      status: 'Success'
    });
  };

  const deleteFamilyMember = (citizenId: string, memberId: string) => {
    const target = citizens.find(c => c.id === citizenId);
    const targetMember = target?.members.find(m => m.id === memberId);
    setCitizens(prev => prev.map(c => {
      if (c.id === citizenId) {
        return {
          ...c,
          members: c.members.filter(m => m.id !== memberId)
        };
      }
      return c;
    }));
    addAuditLog({
      userName: currentUser?.name || 'Super Admin',
      userRole: currentUser?.role || 'bendahara',
      action: 'MEMBER_DELETED',
      details: `Pengurangan jiwa: ${targetMember?.name || memberId} dihapus dari KK ${target?.headOfFamily || citizenId}`,
      ipAddress: '182.253.14.88 (Dashboard)',
      status: 'Warning'
    });
  };

  const addDeathNotice = (dn: Omit<DeathNotice, 'id' | 'createdAt'>, createAssistanceTx: boolean = true) => {
    const now = new Date();
    const dateStr = now.toISOString().split('T')[0];
    const newNotice: DeathNotice = {
      ...dn,
      id: `dn-${Date.now()}`,
      createdAt: dateStr
    };

    setDeathNotices(prev => [newNotice, ...prev]);

    // Automatically create Cash Outflow transaction for Santunan Kematian if requested
    if (createAssistanceTx && dn.rkmAssistanceAmount > 0) {
      const assistanceTx: Transaction = {
        id: `tx-${Date.now()}`,
        type: 'out',
        category: 'Santunan Kematian',
        amount: dn.rkmAssistanceAmount,
        date: dateStr,
        description: `Penyaluran Santunan Uang Duka wafatnya Alm/Almh. ${dn.deceasedName} bin/binti ${dn.binBinti} (Keluarga ${dn.contactPerson}, RT ${dn.rt})`,
        recipientOrPayer: dn.contactPerson,
        noKK: dn.noKK,
        receiptNo: `RKM-OUT-${now.getFullYear()}${(now.getMonth() + 1).toString().padStart(2, '0')}-${Math.floor(1000 + Math.random() * 9000)}`,
        paymentMethod: 'Tunai',
        verifiedBy: currentUser?.name || 'Ketua / Bendahara RKM'
      };
      setTransactions(prev => [assistanceTx, ...prev]);
    }

    // Add In-App Notification for Death Notice
    addNotification({
      title: `Siaga Musibah Duka Cita: Alm/Almh. ${dn.deceasedName}`,
      message: `Inna lillahi wa inna ilaihi raji'un. Telah berpulang ke Rahmatullah Alm/Almh. ${dn.deceasedName} (${dn.binBinti}) di RT ${dn.rt}/RW ${dn.rw}. Satgas Siaga 24 Jam siap memberikan pendampingan.`,
      category: 'layanan',
      type: 'urgent',
      linkTab: 'layanan-duka'
    });

    // Track critical death service report in Audit Log
    addAuditLog({
      userName: currentUser?.name || 'Petugas Satgas Duka',
      userRole: currentUser?.role || 'petugas',
      action: 'LAPORAN_DUKA_CREATED',
      details: `Laporan duka Alm/Almh. ${dn.deceasedName} bin/binti ${dn.binBinti} (RT ${dn.rt}/RW ${dn.rw}) diterbitkan. Santunan santunan: Rp ${(dn.rkmAssistanceAmount || 0).toLocaleString('id-ID')}`,
      ipAddress: '182.253.14.88 (Layanan Duka)',
      status: 'Warning'
    });
  };

  const updateDeathNotice = (id: string, dn: Partial<DeathNotice>) => {
    const target = deathNotices.find(item => item.id === id);
    const isStatusUpdate = dn.status && target && dn.status !== target.status;
    
    setDeathNotices(prev => prev.map(item => item.id === id ? { ...item, ...dn } : item));
    
    addAuditLog({
      userName: currentUser?.name || 'Petugas Satgas Duka',
      userRole: currentUser?.role || 'petugas',
      action: isStatusUpdate ? 'STATUS_DUKA_UPDATED' : 'LAPORAN_DUKA_UPDATED',
      details: isStatusUpdate 
        ? `Pembaruan status laporan duka Alm/Almh. ${target?.deceasedName || dn.deceasedName || id}: status diubah dari [${target?.status}] menjadi [${dn.status}]`
        : `Pembaruan data laporan layanan duka: Alm/Almh. ${dn.deceasedName || target?.deceasedName || id}`,
      ipAddress: '182.253.14.88 (Layanan Duka)',
      status: 'Success'
    });
  };

  const addAsset = (asset: Omit<Asset, 'id'>) => {
    const newAsset: Asset = {
      ...asset,
      id: `ast-${Date.now()}`
    };
    setAssets(prev => [...prev, newAsset]);
  };

  const updateAsset = (id: string, asset: Partial<Asset>) => {
    setAssets(prev => prev.map(item => item.id === id ? { ...item, ...asset } : item));
  };

  const addAssetLoan = (loan: Omit<AssetLoan, 'id'>) => {
    const newLoan: AssetLoan = {
      ...loan,
      id: `ln-${Date.now()}`
    };

    setAssetLoans(prev => [newLoan, ...prev]);

    // Deduct available quantity from asset
    setAssets(prev => prev.map(a => {
      if (a.id === loan.assetId) {
        const remaining = Math.max(0, a.availableQty - loan.quantity);
        return { ...a, availableQty: remaining };
      }
      return a;
    }));
  };

  const returnAssetLoan = (loanId: string) => {
    const loan = assetLoans.find(l => l.id === loanId);
    if (!loan) return;

    const dateStr = new Date().toISOString().split('T')[0];
    setAssetLoans(prev => prev.map(l => l.id === loanId ? { ...l, status: 'Dikembalikan', returnDateActual: dateStr } : l));

    // Restore available quantity to asset
    setAssets(prev => prev.map(a => {
      if (a.id === loan.assetId) {
        return { ...a, availableQty: Math.min(a.quantity, a.availableQty + loan.quantity) };
      }
      return a;
    }));
  };

  const updateSettings = (newSettings: Partial<OrganizationSettings>) => {
    setSettings(prev => ({ ...prev, ...newSettings }));
  };

  const addOfficer = (officerData: Omit<Officer, 'id'>) => {
    // Pengurus adalah seorang anggota yg terpilih: Cek apakah warga sudah terdaftar
    const existingCitizen = citizens.find(c => 
      (officerData.citizenId && c.id === officerData.citizenId) ||
      (officerData.noKK && c.noKK === officerData.noKK) ||
      (c.headOfFamily.toLowerCase() === officerData.name.toLowerCase())
    );

    const generatedKta = officerData.ktaNumber || existingCitizen?.ktaNumber || `KTA-RKM-P${Math.floor(10 + Math.random() * 89)}-2024`;
    let linkedCitizenId = existingCitizen?.id;

    if (existingCitizen) {
      // Update warga menjadi berstatus pengurus terpilih
      setCitizens(prev => prev.map(c => c.id === existingCitizen.id ? {
        ...c,
        isOfficer: true,
        officerRole: officerData.role,
        officerDutyStatus: officerData.dutyStatus,
        officerDivision: officerData.division || 'Pengurus Terpilih',
        ktaNumber: generatedKta,
        phone: officerData.phone || c.phone,
        avatar: officerData.photo || c.avatar
      } : c));
    } else {
      // Jika warga belum ada di sistem, daftarkan otomatis sebagai warga/anggota RKM
      linkedCitizenId = `cit-${Date.now()}`;
      const newCit: Citizen = {
        id: linkedCitizenId,
        noKK: officerData.noKK || `320108${Date.now().toString().slice(-10)}`,
        headOfFamily: officerData.name,
        nik: officerData.nik || `320108${Date.now().toString().slice(-10)}`,
        phone: officerData.phone,
        address: officerData.address || `Perumahan Metro Parung Panjang RT ${officerData.rtAssigned[0]?.replace('RT ', '') || '01'}/RW 08`,
        block: officerData.block || 'Blok A',
        houseNumber: officerData.houseNumber || 'No. 01',
        rt: officerData.rt || (officerData.rtAssigned[0]?.replace('RT ', '') || '01'),
        rw: officerData.rw || '08',
        joinDate: new Date().toISOString().split('T')[0],
        status: 'Aktif',
        isOfficer: true,
        officerRole: officerData.role,
        officerDutyStatus: officerData.dutyStatus,
        officerDivision: officerData.division || 'Pengurus Terpilih',
        ktaNumber: generatedKta,
        avatar: officerData.photo,
        monthlyDues: {},
        members: [
          {
            id: `m-${Date.now()}`,
            name: officerData.name,
            nik: officerData.nik || `320108${Date.now().toString().slice(-10)}`,
            relation: 'Kepala Keluarga',
            category: 'Inti',
            gender: 'Laki-laki',
            status: 'Hidup',
            socialCategory: 'Umum'
          }
        ]
      };
      setCitizens(prev => [newCit, ...prev]);
    }

    const newOfficer: Officer = {
      ...officerData,
      id: `ofc-${Date.now()}`,
      citizenId: linkedCitizenId,
      ktaNumber: generatedKta,
      noKK: existingCitizen?.noKK || officerData.noKK,
      nik: existingCitizen?.nik || officerData.nik,
      block: existingCitizen?.block || officerData.block,
      houseNumber: existingCitizen?.houseNumber || officerData.houseNumber,
      rt: existingCitizen?.rt || officerData.rt,
      rw: existingCitizen?.rw || officerData.rw,
      address: existingCitizen?.address || officerData.address,
      termPeriod: officerData.termPeriod || '2024–2027'
    };

    setOfficers(prev => [...prev, newOfficer]);

    addAuditLog({
      userName: currentUser?.name || 'Super Admin',
      userRole: currentUser?.role || 'superadmin',
      action: 'OFFICER_ADDED',
      details: `Pengurus terpilih baru ditambahkan & disinkronkan dengan keanggotaan: ${newOfficer.name} (${newOfficer.role}, No KTA: ${generatedKta})`,
      ipAddress: '182.253.14.88 (Pengaturan)',
      status: 'Success'
    });
  };

  const updateOfficer = (id: string, officerData: Partial<Officer>) => {
    const target = officers.find(o => o.id === id);
    setOfficers(prev => prev.map(o => o.id === id ? { ...o, ...officerData } : o));

    // Sinkronisasi pembaruan pengurus ke data warga/KTA terkait
    const linkedCitId = officerData.citizenId || target?.citizenId;
    const targetNoKK = officerData.noKK || target?.noKK;

    if (linkedCitId || targetNoKK || target?.name) {
      setCitizens(prev => prev.map(c => {
        const isMatch = (linkedCitId && c.id === linkedCitId) ||
                        (targetNoKK && c.noKK === targetNoKK) ||
                        (target && c.headOfFamily.toLowerCase() === target.name.toLowerCase());
        if (isMatch) {
          return {
            ...c,
            headOfFamily: officerData.name || c.headOfFamily,
            phone: officerData.phone || c.phone,
            avatar: officerData.photo || c.avatar,
            ktaNumber: officerData.ktaNumber || c.ktaNumber,
            isOfficer: true,
            officerRole: officerData.role || c.officerRole,
            officerDutyStatus: officerData.dutyStatus || c.officerDutyStatus,
            officerDivision: officerData.division || c.officerDivision
          };
        }
        return c;
      }));
    }

    addAuditLog({
      userName: currentUser?.name || 'Super Admin',
      userRole: currentUser?.role || 'superadmin',
      action: 'OFFICER_UPDATED',
      details: `Data pengurus diperbarui: ${officerData.name || target?.name || id} (${officerData.role || target?.role || ''})`,
      ipAddress: '182.253.14.88 (Pengaturan)',
      status: 'Success'
    });
  };

  const deleteOfficer = (id: string) => {
    const target = officers.find(o => o.id === id);
    setOfficers(prev => prev.filter(o => o.id !== id));

    // Lepaskan status pengurus pada warga tanpa menghapus data keanggotaannya
    if (target) {
      setCitizens(prev => prev.map(c => {
        const isMatch = (target.citizenId && c.id === target.citizenId) ||
                        (target.noKK && c.noKK === target.noKK) ||
                        (c.headOfFamily.toLowerCase() === target.name.toLowerCase());
        if (isMatch) {
          return {
            ...c,
            isOfficer: false,
            officerRole: undefined,
            officerDutyStatus: undefined,
            officerDivision: undefined
          };
        }
        return c;
      }));
    }

    addAuditLog({
      userName: currentUser?.name || 'Super Admin',
      userRole: currentUser?.role || 'superadmin',
      action: 'OFFICER_DELETED',
      details: `Pengurus dihapus dari kepengurusan: ${target?.name || id} (${target?.role || ''})`,
      ipAddress: '182.253.14.88 (Pengaturan)',
      status: 'Warning'
    });
  };

  const addDutySchedule = (dutyData: Omit<DutySchedule, 'id'>) => {
    const newDuty: DutySchedule = {
      ...dutyData,
      id: `duty-${Date.now()}`
    };
    setDutySchedules(prev => [newDuty, ...prev]);
    addNotification({
      title: 'Jadwal Piket Satgas Dibuat',
      message: `Piket ${newDuty.shiftType} untuk ${newDuty.dayName}, ${newDuty.date} (${newDuty.coordinatorName}) berhasil dijadwalkan.`,
      category: 'layanan',
      type: 'info',
      linkTab: 'layanan-duka'
    });
  };

  const updateDutySchedule = (id: string, dutyData: Partial<DutySchedule>) => {
    setDutySchedules(prev => prev.map(d => d.id === id ? { ...d, ...dutyData } : d));
  };

  const deleteDutySchedule = (id: string) => {
    setDutySchedules(prev => prev.filter(d => d.id !== id));
  };

  const addFeedback = (fb: Omit<FeedbackMessage, 'id' | 'createdAt' | 'status'>) => {
    const now = new Date();
    const timeStr = `${now.toISOString().split('T')[0]} ${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
    const newFeedback: FeedbackMessage = {
      ...fb,
      id: `fb-${Date.now()}`,
      createdAt: timeStr,
      status: 'Baru'
    };
    setFeedbacks(prev => [newFeedback, ...prev]);
  };

  const replyFeedback = (id: string, reply: string) => {
    setFeedbacks(prev => prev.map(f => f.id === id ? { ...f, status: 'Dibalas', reply } : f));
  };

  const syncGoogleSheets = async (): Promise<boolean> => {
    try {
      const now = new Date();
      const dateStr = `${now.getDate()} ${['Jan','Feb','Mar','Apr','Mei','Jun','Jul','Agu','Sep','Okt','Nov','Des'][now.getMonth()]} ${now.getFullYear()}, ${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')} WIB`;
      
      const payload: FullSyncPayload = {
        syncTimestamp: new Date().toISOString(),
        version: '2026.1',
        source: 'RKM MPP Digital PWA',
        citizens,
        transactions,
        deathNotices,
        assets,
        settings,
        usersCount: users.length
      };

      if (settings.webhookUrl && settings.webhookUrl.startsWith('http')) {
        await syncDatabaseToGoogleSheet(settings.webhookUrl, payload);
      }

      setSettings(prev => ({
        ...prev,
        googleSheetConnected: true,
        lastSheetSync: dateStr,
        lastSheetSyncStatus: 'Success'
      }));

      addAuditLog({
        userName: currentUser?.name || 'Sistem',
        userRole: currentUser?.role || 'superadmin',
        action: 'GOOGLE_SHEETS_SYNC',
        details: `Sinkronisasi database ke Google Spreadsheet berhasil (${citizens.length} KK, ${transactions.length} Transaksi, ${deathNotices.length} Layanan Duka, ${assets.length} Aset)`,
        ipAddress: '182.253.14.88 (Google Cloud API)',
        status: 'Success'
      });

      return true;
    } catch (error) {
      console.error('Google Sheets sync error:', error);
      const now = new Date();
      const dateStr = `${now.getDate()} ${['Jan','Feb','Mar','Apr','Mei','Jun','Jul','Agu','Sep','Okt','Nov','Des'][now.getMonth()]} ${now.getFullYear()}, ${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')} WIB`;
      setSettings(prev => ({
        ...prev,
        lastSheetSync: dateStr,
        lastSheetSyncStatus: 'Failed'
      }));
      return false;
    }
  };

  // Automatic CRUD Sync to Google Sheets whenever data mutations occur
  const isInitialMount = useRef(true);
  const syncTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    if (isInitialMount.current) {
      isInitialMount.current = false;
      return;
    }

    if (!settings.webhookUrl || !settings.webhookUrl.startsWith('http')) {
      return;
    }

    // Debounce auto-sync by 2000ms to batch fast operations
    if (syncTimeoutRef.current) {
      clearTimeout(syncTimeoutRef.current);
    }

    syncTimeoutRef.current = setTimeout(() => {
      syncGoogleSheets().catch(err => {
        console.log('[RKM Auto-Sync] CRUD sync note:', err);
      });
    }, 2000);

    return () => {
      if (syncTimeoutRef.current) {
        clearTimeout(syncTimeoutRef.current);
      }
    };
  }, [citizens, transactions, deathNotices, assets, assetLoans, officers, feedbacks, settings.duesAmount, settings.extraMemberDuesAmount]);

  // Background Auto-Sync Timer when autoSheetSyncEnabled is true
  useEffect(() => {
    if (!settings.autoSheetSyncEnabled || !settings.webhookUrl) return;

    const intervalMinutes = settings.autoSheetSyncIntervalMinutes || 15;
    const intervalMs = Math.max(intervalMinutes, 1) * 60 * 1000;

    const timer = setInterval(() => {
      syncGoogleSheets().catch(err => console.warn('Background auto-sync skipped:', err));
    }, intervalMs);

    return () => clearInterval(timer);
  }, [settings.autoSheetSyncEnabled, settings.webhookUrl, settings.autoSheetSyncIntervalMinutes, citizens, transactions, deathNotices, assets, settings, users.length]);

  const importFullData = (data: any): boolean => {
    try {
      if (data.settings) setSettings(data.settings);
      if (Array.isArray(data.users)) setUsers(data.users);
      if (Array.isArray(data.citizens)) setCitizens(data.citizens);
      if (Array.isArray(data.transactions)) setTransactions(data.transactions);
      if (Array.isArray(data.deathNotices)) setDeathNotices(data.deathNotices);
      if (Array.isArray(data.assets)) setAssets(data.assets);
      if (Array.isArray(data.assetLoans)) setAssetLoans(data.assetLoans);
      if (Array.isArray(data.officers)) setOfficers(data.officers);
      if (Array.isArray(data.dutySchedules)) setDutySchedules(data.dutySchedules);
      if (Array.isArray(data.feedbacks)) setFeedbacks(data.feedbacks);
      if (Array.isArray(data.auditLogs)) setAuditLogs(data.auditLogs);
      if (data.securityPolicy) setSecurityPolicy(data.securityPolicy);
      if (data.rolePermissions) setRolePermissions(data.rolePermissions);
      return true;
    } catch {
      return false;
    }
  };

  const resetToDemo = () => {
    localStorage.clear();
    try {
      localStorage.setItem('rkm_empty_db_clean_slate_v3', 'true');
    } catch {}
    setUsers(INITIAL_USERS);
    setCurrentUser(null);
    setCitizens([]);
    setTransactions([]);
    setDeathNotices([]);
    setAssets([]);
    setAssetLoans([]);
    setSettings(INITIAL_SETTINGS);
    setOfficers([]);
    setDutySchedules([]);
    setFeedbacks([]);
    setNotifications([]);
    setSecurityPolicy(DEFAULT_SECURITY_POLICY);
    setAuditLogs([]);
    const initialMap: Record<string, UserRole[]> = {};
    DEFAULT_PERMISSIONS.forEach(p => {
      initialMap[p.id] = p.defaultRoles;
    });
    setRolePermissions(initialMap);
  };

  const currentRole = currentUser?.role || 'warga';

  return (
    <RkmContext.Provider value={{
      currentUser,
      currentRole,
      users,
      citizens,
      transactions,
      deathNotices,
      assets,
      assetLoans,
      settings,
      officers,
      dutySchedules,
      feedbacks,
      permissions: DEFAULT_PERMISSIONS,
      rolePermissions,
      securityPolicy,
      auditLogs,
      notifications,
      unreadNotificationsCount,
      theme,
      activeReceipt,
      selectedKtaCitizen,
      selectedLelayu,
      selectedProfileCitizen,
      isProfileModalOpen,
      toggleTheme,
      setTheme,
      addNotification,
      markNotificationAsRead,
      markAllNotificationsAsRead,
      deleteNotification,
      openReceiptModal: (data) => setActiveReceipt(data),
      closeReceiptModal: () => setActiveReceipt(null),
      openKtaModal: (citizen) => setSelectedKtaCitizen(citizen),
      closeKtaModal: () => setSelectedKtaCitizen(null),
      openLelayuModal: (lelayu) => setSelectedLelayu(lelayu),
      closeLelayuModal: () => setSelectedLelayu(null),
      openProfileModal,
      closeProfileModal,
      login,
      quickSwitchRole,
      logout,
      processPayment,
      addUser,
      updateUser,
      deleteUser,
      toggleUserStatus,
      resetUserPassword,
      updateRolePermission,
      resetRolePermissions,
      updateSecurityPolicy,
      addAuditLog,
      clearAuditLogs,
      addTransaction,
      deleteTransaction,
      addCitizen,
      updateCitizen,
      deleteCitizen,
      addFamilyMember,
      updateFamilyMember,
      deleteFamilyMember,
      addDeathNotice,
      updateDeathNotice,
      addAsset,
      updateAsset,
      addAssetLoan,
      returnAssetLoan,
      updateSettings,
      superadminSettings,
      updateSuperadminSettings,
      addOfficer,
      updateOfficer,
      deleteOfficer,
      addDutySchedule,
      updateDutySchedule,
      deleteDutySchedule,
      addFeedback,
      replyFeedback,
      syncGoogleSheets,
      importFullData,
      resetToDefaultData: resetToDemo,
      resetToDemo,
      runAutoAging
    }}>
      {children}
    </RkmContext.Provider>
  );
};

export const useRkm = () => {
  const context = useContext(RkmContext);
  if (!context) {
    throw new Error('useRkm must be used within an RkmProvider');
  }
  return context;
};
