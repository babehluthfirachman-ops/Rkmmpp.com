import { 
  UserProfile, 
  Citizen, 
  Transaction, 
  DeathNotice, 
  Asset, 
  AssetLoan, 
  OrganizationSettings, 
  FeedbackMessage, 
  Officer,
  SystemPermission,
  SecurityPolicy,
  SuperadminSystemSettings,
  AccessAuditLog,
  AppNotification,
  DutySchedule
} from '../types';

export const INITIAL_USERS: UserProfile[] = [
  {
    id: 'usr-1',
    username: 'admin',
    name: 'Babeh',
    role: 'superadmin',
    phone: '081234567890',
    email: 'babeh@rkm-mpp.org',
    password: 'admin',
    status: 'Aktif',
    title: 'Babeh (Super Admin - Akses Penuh Sistem & Pengaturan)',
    avatar: '',
    rt: '02',
    rw: '08',
    lastLogin: '05 Sep 2026, 12:00 WIB',
    createdAt: '2024-01-10'
  }
];

export const DEFAULT_USERS = INITIAL_USERS;

export const DEFAULT_PERMISSIONS: SystemPermission[] = [
  // Kas & Keuangan
  {
    id: 'view_cashbook',
    category: 'Kas & Keuangan',
    label: 'Melihat Buku Kas & Saldo Real-Time',
    description: 'Akses transparansi mutasi kas masuk, kas keluar, dan saldo bank & tunai.',
    defaultRoles: ['superadmin', 'bendahara', 'ketua', 'petugas', 'warga']
  },
  {
    id: 'create_transaction',
    category: 'Kas & Keuangan',
    label: 'Mencatat Pemasukan & Pengeluaran Kas',
    description: 'Menambahkan mutasi iuran warga, santunan duka, infaq, atau belanja operasional.',
    defaultRoles: ['superadmin', 'bendahara', 'petugas']
  },
  {
    id: 'delete_transaction',
    category: 'Kas & Keuangan',
    label: 'Menghapus / Membatalkan Transaksi Kas',
    description: 'Menghapus mutasi kas dengan audit trail dan validasi nominal.',
    defaultRoles: ['superadmin', 'bendahara']
  },
  {
    id: 'generate_receipt_wa',
    category: 'Kas & Keuangan',
    label: 'Menerbitkan Kuitansi Digital & WhatsApp',
    description: 'Membuat nomor kuitansi sah ber-QR Code dan mengirimkan notifikasi WA ke warga.',
    defaultRoles: ['superadmin', 'bendahara', 'petugas']
  },
  // Data Warga
  {
    id: 'view_citizens',
    category: 'Data Warga',
    label: 'Melihat Direktori & Data Warga',
    description: 'Melihat daftar KK, anggota keluarga, alamat, dan nomor kontak.',
    defaultRoles: ['superadmin', 'bendahara', 'ketua', 'petugas']
  },
  {
    id: 'manage_citizens',
    category: 'Data Warga',
    label: 'Tambah, Edit & Hapus Data Kepala Keluarga & Anggota',
    description: 'Mendaftarkan KK baru, mutasi anggota jiwa, atau merubah status warga.',
    defaultRoles: ['superadmin', 'bendahara', 'ketua']
  },
  {
    id: 'print_kta',
    category: 'Data Warga',
    label: 'Menerbitkan & Cetak KTA Digital Warga',
    description: 'Mengunduh dan mencetak Kartu Tanda Anggota RKM resmi ber-QR Code.',
    defaultRoles: ['superadmin', 'bendahara', 'ketua', 'petugas', 'warga']
  },
  // Layanan Duka
  {
    id: 'create_death_notice',
    category: 'Layanan Duka & Santunan',
    label: 'Menerbitkan Berita Duka & Poster Lelayu Digital',
    description: 'Mempublikasikan info wafat, waktu pemakaman, masjid, dan poster takziah.',
    defaultRoles: ['superadmin', 'bendahara', 'ketua', 'petugas']
  },
  {
    id: 'disburse_death_benefit',
    category: 'Layanan Duka & Santunan',
    label: 'Mencairkan Santunan Duka (Rp 3.000.000,-)',
    description: 'Otorisasi pencairan dana kerohiman tunai kepada ahli waris sah.',
    defaultRoles: ['superadmin', 'bendahara', 'ketua']
  },
  {
    id: 'dispatch_ambulance_shrouds',
    category: 'Layanan Duka & Santunan',
    label: 'Mobilisasi Armada Ambulan & Kain Kafan',
    description: 'Pengeluaran paket kain kafan suci dan penugasan sopir mobil jenazah 24 jam.',
    defaultRoles: ['superadmin', 'bendahara', 'petugas']
  },
  // Logistik & Aset
  {
    id: 'manage_assets',
    category: 'Logistik & Aset',
    label: 'Kelola Inventaris Tenda, Kursi & Sound',
    description: 'Menambah atau memperbarui kondisi aset fisik paguyuban.',
    defaultRoles: ['superadmin', 'bendahara', 'petugas']
  },
  {
    id: 'process_asset_loans',
    category: 'Logistik & Aset',
    label: 'Pencatatan Peminjaman & Pengembalian Aset',
    description: 'Mencatat peminjaman tenda/kursi untuk takziah warga atau hajatan sosial.',
    defaultRoles: ['superadmin', 'bendahara', 'petugas']
  },
  // Pengaturan & Keamanan
  {
    id: 'manage_system_settings',
    category: 'Pengaturan & Keamanan',
    label: 'Ubah Identitas, Tarif Kas & AD/ART',
    description: 'Mengubah besaran iuran, nominal santunan duka, bank, dan klausul AD/ART.',
    defaultRoles: ['superadmin', 'bendahara']
  },
  {
    id: 'manage_user_accounts',
    category: 'Pengaturan & Keamanan',
    label: 'Kelola Akun Pengguna & Hak Akses (RBAC)',
    description: 'Membuat akun pengurus/satgas baru, reset password, dan mengatur izin akses.',
    defaultRoles: ['superadmin', 'bendahara']
  },
  {
    id: 'backup_restore_data',
    category: 'Pengaturan & Keamanan',
    label: 'Backup, Restore & Sinkronisasi Cloud',
    description: 'Ekspor database JSON, CSV Excel, dan sinkronisasi ke Google Spreadsheet.',
    defaultRoles: ['superadmin', 'bendahara', 'ketua']
  }
];

export const DEFAULT_SECURITY_POLICY: SecurityPolicy = {
  sessionTimeoutHours: 24,
  allowCitizenNoKkLogin: true,
  requireTwoFactorForAdmin: false,
  pinLength: 6,
  autoLockFailedAttempts: 5,
  enforceStrongPassword: true,
  enableAuditLogging: true
};

export const INITIAL_SUPERADMIN_SETTINGS: SuperadminSystemSettings = {
  // 1. Manajamen Identitas & Brand Aplikasi
  appName: 'RKM MPP DIGITAL',
  logoUrl: 'https://images.unsplash.com/photo-1577495508048-b635879837f1?w=150&auto=format&fit=crop&q=80',
  faviconUrl: '/favicon.ico',
  footerText: '© 2024–2027 Rukun Kematian Metro Parung Panjang (RKM MPP). Berlandaskan AD/ART Musyawarah Warga.',
  smtp: {
    host: 'smtp.gmail.com',
    port: 587,
    secure: false,
    username: 'rkmmpp@gmail.com',
    password: '',
    senderEmail: 'rkmmpp@gmail.com',
    senderName: 'RKM Metro Parung Panjang Notifikasi'
  },

  // 2. Konfigurasi Sistem OCR & Integrasi
  ocrApiKey: '',
  ocrEndpoint: 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent',
  googleWorkspaceApiKey: '',
  googleWorkspaceEndpoint: 'https://script.google.com/macros/s/AKfycbwRKM_MPP_Webhook_Trigger/exec',
  autoScanCameraOcr: true,
  maxUploadFileSizeMb: 10,

  // 3. Keamanan & Akses (Security & Access Control)
  maintenanceMode: false,
  sessionTimeoutMinutes: 120,
  maxLoginAttempts: 5,
  passwordMinLength: 8,
  passwordRequireSpecialChar: true,
  passwordRequireNumber: true,

  // 4. Fitur Backup & Metadata
  lastBackupDate: '2026-08-28 12:00 WIB',
  updatedAt: '2026-08-28 12:00 WIB',
  updatedBy: 'Babeh (Super Admin)'
};

export const INITIAL_AUDIT_LOGS: AccessAuditLog[] = [];

export const INITIAL_SETTINGS: OrganizationSettings = {
  orgName: 'PERUMAHAN METRO PARUNG PANJANG',
  shortName: 'RKM METRO PARUNG PANJANG',
  slogan: 'Bersama Mengabdi, Menolong Sesama dalam Duka & Kebajikan',
  legalNumber: 'SK DKM Al-Muhajirin / 012/RKM-MPP/2024',
  foundedYear: '2018',
  adArtPeriod: '2024–2027',
  logoUrl: 'https://lh3.googleusercontent.com/d/1ZLdrjSjY8eudTvhUhwPkl2dNBl407HYV',
  stampUrl: 'https://images.unsplash.com/photo-1579783902614-a3fb3927b675?w=200&auto=format&fit=crop&q=80',
  rtRw: 'Perumahan Metro Parung Panjang',
  village: 'Desa Parung Panjang',
  district: 'Kecamatan Parungpanjang',
  regency: 'Kabupaten Bogor',
  province: 'Jawa Barat',
  postalCode: '16360',
  contactCenter: '0812-3456-7890 (Siaga 24 Jam)',
  waAdmin: '6281234567890',
  email: 'rkmmpp@gmail.com',
  websiteUrl: 'https://portal.rkm-mpp.id',
  duesAmount: 5000, // Iuran Pokok 1 Keluarga / Anggota Inti: Rp 5.000 / bulan
  baseDuesAmount: 5000,
  extraMemberDuesAmount: 3000, // Iuran Tambahan per Jiwa (Adik, Kakak, Saudara): Rp 3.000 / bulan
  deathBenefitAmount: 3000000,
  registrationFee: 50000, // Biaya Pendaftaran Anggota Baru: Rp 50.000
  gracePeriodMonths: 3,
  maxArrearsMonths: 3,
  
  // Auto-Aging Status Iuran Otomatis
  autoAgingEnabled: true,
  autoAgingDueDay: 10,
  autoAgingGraceMonths: 3,
  lastAutoAgingRun: '2026-08-30 00:00',

  // Rincian Alokasi Paket Fardhu Kifayah
  deathPackageItems: [
    { id: 'shroud', name: 'Kain Kafan & Perlengkapan', amount: 150000 },
    { id: 'bathing', name: 'Tim Pemulasaraan / Memandikan Jenazah', amount: 100000 },
    { id: 'prayer', name: 'Imam Salat Jenazah & Doa', amount: 450000 },
    { id: 'transport', name: 'BBM & Operasional Driver Ambulans', amount: 200000 },
    { id: 'gravedigger', name: 'Penggalian Liang Lahat (TPU)', amount: 800000 },
    { id: 'adminDistrict', name: 'Administrasi & Retribusi TPU', amount: 150000 },
    { id: 'tactical', name: 'Dana Taktis / Darurat Lapangan', amount: 50000 }
  ],
  deathPackageShroud: 150000,
  deathPackageBathing: 100000,
  deathPackagePrayer: 450000,
  deathPackageTransport: 200000,
  deathPackageGravedigger: 800000,
  deathPackageAdminDistrict: 150000,
  deathPackageTactical: 50000,

  // Penandatangan Dokumen Resmi
  treasurerName: 'H. Agus Supriyadi, S.E.',
  treasurerPhone: '0812-8899-7766',
  chairmanName: 'Drs. H. Bambang Sutrisno, M.Pd.',
  chairmanPhone: '0813-9876-5432',
  secretaryName: 'M. Ridwan Prasetyo, S.Kom.',
  secretaryPhone: '0857-1234-9988',
  advisorName: 'K.H. Ahmad Syahid, Lc. (Ketua DKM)',
  mortuaryCoordinatorName: 'Ust. Abdul Somad Al-Banjari',
  mortuaryCoordinatorPhone: '0813-7788-9900',

  // Format Penomoran
  receiptPrefix: 'KW-RKM',
  ktaPrefix: 'KTA-MPP',
  lelayuPrefix: 'BD-MPP',

  // Operasional Ambulans & Pemakaman
  ambulancePlate: 'F 1982 MPP',
  ambulanceDriver1: 'Bpk. Herman Suherman (0812-8822-1100)',
  ambulanceDriver2: 'Bpk. Ruslan Effendi (0813-7711-2233)',
  cemeteryName: 'TPU Desa Gerowong / TPU Giri Mulya Parung Panjang',
  cemeteryLocation: 'Jl. Raya Salimah, Gerowong, Parungpanjang, Bogor',

  // Master Wilayah
  rwList: ['RW 01', 'RW 02', 'RW 03', 'RW 05', 'RW 08', 'RW 12'],
  rtList: ['RT 01', 'RT 02', 'RT 03', 'RT 04', 'RT 05', 'RT 06', 'RT 07', 'RT 08', 'RT 09', 'RT 10', 'RT 11'],
  paguyubanList: ['Paguyuban Graha Asri', 'Paguyuban Warga Muslim', 'Paguyuban Griya Parung', 'Paguyuban Sejahtera Mandiri'],
  blockList: ['Blok A', 'Blok B', 'Blok C', 'Blok D', 'Blok E', 'Blok F', 'Blok G', 'Blok H', 'Blok I', 'Blok J', 'Blok K', 'Blok L', 'Blok M', 'Blok N'],

  // Template Notifikasi WhatsApp
  waTemplateReceipt: 'Assalamu\'alaikum Wr. Wb. Terima kasih Bpk/Ibu *{nama}* (No. KK: {no_kk}). Pembayaran Iuran RKM MPP bulan *{bulan}* sebesar *{nominal}* telah kami terima dengan No. Kuitansi: *{no_kuitansi}*. Semoga berkah dan menjadi ladang amal jariyah. Wassalamu\'alaikum.',
  waTemplateLelayu: 'INNA LILLAHI WA INNA ILAIHI RAJI\'UN\n\nTelah berpulang ke Rahmatullah:\n*Almarhum/Almarhumah: {nama}*\nUsia: {usia} Tahun\nAlamat Duka: {alamat}\n\nWaktu Pemakaman: {waktu_pemakaman}\nLokasi TPU: {tpu}\n\nMohon dimaafkan segala khilaf almarhum/ah. Info Satgas RKM: {hotline}',
  waTemplateReminder: 'Assalamu\'alaikum Wr. Wb. Bpk/Ibu *{nama}* (KK: {no_kk}), kami menginformasikan tagihan iuran RKM MPP yang belum tercatat untuk periode *{bulan}* sejumlah *{nominal}*. Pembayaran dapat dilakukan via transfer Bank BSI / QRIS atau tunai kepada koordinator RT *{rt}*. Terima kasih.',
  waTemplateWelcome: 'Selamat datang di Paguyuban Rukun Kematian (RKM) Perumahan Metro Parung Panjang. No. KTA Digital Anda: *{kta_no}*. Akses status iuran mandiri kapan saja di portal: https://portal.rkm-mpp.id',

  googleSheetConnected: true,
  autoSheetSyncEnabled: true,
  autoSheetSyncIntervalMinutes: 15,
  lastSheetSync: '28 Agu 2026, 10:45 WIB',
  lastSheetSyncStatus: 'Success',
  sheetUrl: 'https://docs.google.com/spreadsheets/d/1BxiMVs0XRA5nFMdKvBdBZj_RKM_MPP_Spreadsheet_Sync/edit',
  webhookUrl: 'https://script.google.com/macros/s/AKfycbwRKM_MPP_Webhook_Trigger/exec',
  qrisMerchantId: 'ID1020038472911',
  qrisCodeUrl: 'https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=00020101021126580014ID.GO.QRIS.WWW01189360091400012345670215ID10200384729115204581253033605802ID5922RKM+MPP+PARUNG+PANJANG6005BOGOR61051691162070703A01630454D1',
  bankAccounts: [
    {
      bank: 'Bank Syariah Indonesia (BSI)',
      accountNumber: '7192837465',
      accountHolder: 'RKM MASJID METRO PARUNG PANJANG',
      isPrimary: true
    },
    {
      bank: 'Bank Central Asia (BCA)',
      accountNumber: '8400192837',
      accountHolder: 'RKM METRO PARUNG PANJANG',
      isPrimary: false
    },
    {
      bank: 'Bank Mandiri',
      accountNumber: '1330019283746',
      accountHolder: 'RKM MASJID METRO PARUNG PANJANG',
      isPrimary: false
    }
  ],
  systemSettings: {
    maintenanceMode: false,
    publicPortalEnabled: true,
    citizenSelfRegistration: true,
    strictNikValidation: true,
    sessionTimeoutMinutes: 120,
    maxLoginAttempts: 5,
    masterPin: '198200',
    criticalCashThreshold: 5000000,
    annualPaymentDiscount: 10000,
    monthlyLateFee: 0,
    waGatewayProvider: 'fonnte',
    waGatewayApiKey: '',
    waGatewayEndpoint: 'https://api.fonnte.com/send',
    autoSendReceiptWa: true,
    autoBroadcastDeathNotice: true,
    autoSendMonthlyReminder: true,
    auditLogRetentionDays: 365,
    requireTwoFactorAuth: false,
    autoBackupDaily: true
  }
};

export const INITIAL_OFFICERS: Officer[] = [];
export const INITIAL_CITIZENS: Citizen[] = [];
export const INITIAL_TRANSACTIONS: Transaction[] = [];
export const INITIAL_DEATH_NOTICES: DeathNotice[] = [];
export const INITIAL_ASSETS: Asset[] = [];
export const INITIAL_ASSET_LOANS: AssetLoan[] = [];
export const INITIAL_FEEDBACKS: FeedbackMessage[] = [];
export const INITIAL_NOTIFICATIONS: AppNotification[] = [];
export const INITIAL_DUTY_SCHEDULES: DutySchedule[] = [];
