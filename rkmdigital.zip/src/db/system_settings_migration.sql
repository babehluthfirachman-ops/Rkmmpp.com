-- ==============================================================================
-- DATABASE SCHEMA MIGRATION: system_settings
-- Sistem Informasi Paguyuban Rukun Kematian Metro Parung Panjang (RKM MPP)
-- Fitur: Pengaturan Sistem Superadmin (Superadmin System Settings)
-- ==============================================================================

-- 1. Tabel Utama: system_settings (Kolom Terstruktur & Key-Value Flexibel)
CREATE TABLE IF NOT EXISTS system_settings (
    id VARCHAR(50) PRIMARY KEY DEFAULT 'default',
    
    -- Identitas & Brand Aplikasi
    app_name VARCHAR(255) NOT NULL DEFAULT 'RKM MPP DIGITAL',
    logo_url TEXT DEFAULT NULL,
    favicon_url TEXT DEFAULT NULL,
    footer_text TEXT DEFAULT '© 2024–2027 Rukun Kematian Metro Parung Panjang. Hak Cipta Dilindungi.',
    
    -- Konfigurasi Email & SMTP
    smtp_host VARCHAR(255) DEFAULT 'smtp.gmail.com',
    smtp_port INT DEFAULT 587,
    smtp_secure BOOLEAN DEFAULT FALSE,
    smtp_user VARCHAR(255) DEFAULT 'rkmmpp@gmail.com',
    smtp_password VARCHAR(255) DEFAULT NULL,
    smtp_sender_email VARCHAR(255) DEFAULT 'rkmmpp@gmail.com',
    smtp_sender_name VARCHAR(255) DEFAULT 'RKM MPP Notifikasi Sistem',
    
    -- Sistem OCR & Integrasi
    ocr_api_key TEXT DEFAULT NULL,
    ocr_endpoint TEXT DEFAULT 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent',
    google_workspace_api_key TEXT DEFAULT NULL,
    google_workspace_endpoint TEXT DEFAULT NULL,
    auto_scan_camera_ocr BOOLEAN DEFAULT TRUE,
    max_upload_file_size_mb INT DEFAULT 10,
    
    -- Keamanan & Kontrol Akses (Security & Access Control)
    maintenance_mode BOOLEAN DEFAULT FALSE,
    session_timeout_minutes INT DEFAULT 120,
    max_login_attempts INT DEFAULT 5,
    password_min_length INT DEFAULT 8,
    password_require_special_char BOOLEAN DEFAULT TRUE,
    password_require_number BOOLEAN DEFAULT TRUE,
    
    -- Penyimpanan Key-Value Tambahan (Extensible Configuration)
    extra_configs JSON DEFAULT NULL,
    
    -- Audit Timestamps
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_by VARCHAR(100) DEFAULT 'superadmin'
);

-- 2. Indexing untuk optimasi query cepat
CREATE INDEX IF NOT EXISTS idx_system_settings_maintenance ON system_settings(maintenance_mode);

-- 3. Tabel Key-Value Pelengkap: system_config_kv (Opsional untuk modularitas granular)
CREATE TABLE IF NOT EXISTS system_config_kv (
    config_key VARCHAR(100) PRIMARY KEY,
    config_value TEXT NOT NULL,
    group_name VARCHAR(50) NOT NULL DEFAULT 'general', -- 'general', 'ocr', 'security', 'smtp'
    is_secret BOOLEAN DEFAULT FALSE,
    description TEXT,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 4. Seed / Initial Data Default
INSERT INTO system_settings (
    id,
    app_name,
    logo_url,
    favicon_url,
    footer_text,
    smtp_host,
    smtp_port,
    smtp_secure,
    smtp_user,
    smtp_sender_email,
    smtp_sender_name,
    ocr_endpoint,
    auto_scan_camera_ocr,
    max_upload_file_size_mb,
    maintenance_mode,
    session_timeout_minutes,
    max_login_attempts,
    password_min_length,
    password_require_special_char,
    password_require_number,
    updated_by
) VALUES (
    'default',
    'RKM MPP DIGITAL',
    'https://images.unsplash.com/photo-1577495508048-b635879837f1?w=150&auto=format&fit=crop&q=80',
    '/favicon.ico',
    '© 2024–2027 Rukun Kematian Metro Parung Panjang (RKM MPP). Berlandaskan AD/ART Musyawarah Warga.',
    'smtp.gmail.com',
    587,
    FALSE,
    'rkmmpp@gmail.com',
    'rkmmpp@gmail.com',
    'RKM Metro Parung Panjang Notifikasi',
    'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent',
    TRUE,
    10,
    FALSE,
    120,
    5,
    8,
    TRUE,
    TRUE,
    'Babeh (Super Admin)'
) ON CONFLICT (id) DO NOTHING;

-- Seed key-value pair dasar
INSERT INTO system_config_kv (config_key, config_value, group_name, is_secret, description)
VALUES 
    ('app_name', 'RKM MPP DIGITAL', 'general', FALSE, 'Nama resmi aplikasi paguyuban'),
    ('maintenance_mode', 'false', 'security', FALSE, 'Status mode pemeliharaan sistem'),
    ('auto_scan_camera_ocr', 'true', 'ocr', FALSE, 'Deteksi otomatis kamera OCR KTP/KK'),
    ('max_upload_file_size_mb', '10', 'ocr', FALSE, 'Batas ukuran unggah berkas (MB)'),
    ('session_timeout_minutes', '120', 'security', FALSE, 'Masa kedaluwarsa sesi login (menit)'),
    ('smtp_host', 'smtp.gmail.com', 'smtp', FALSE, 'Server SMTP email keluar')
ON CONFLICT (config_key) DO NOTHING;
