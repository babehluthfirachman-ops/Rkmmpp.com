import React, { useState } from 'react';
import { 
  User, 
  Search, 
  CreditCard, 
  CheckCircle2, 
  AlertCircle, 
  QrCode, 
  Printer, 
  Share2, 
  Users, 
  ShieldCheck, 
  HeartHandshake, 
  Send, 
  MessageSquare, 
  Sparkles,
  Wallet,
  Calendar,
  Building,
  HelpCircle,
  Camera
} from 'lucide-react';
import { useRkm } from '../context/RkmContext';
import { formatRupiah, formatDateIndo, MONTH_NAMES, getMonthNameFromKey, calculateCitizenMonthlyDues, getAvatarUrl } from '../utils/formatters';
import { Citizen } from '../types';

export const CitizenPortalView: React.FC = () => {
  const { 
    currentUser, 
    citizens, 
    settings, 
    transactions, 
    processPayment, 
    openReceiptModal, 
    openKtaModal, 
    openProfileModal,
    addFeedback, 
    feedbacks 
  } = useRkm();

  // Selected citizen for portal (defaults to current user's citizen record or first citizen)
  const defaultCitizen = citizens.find(c => c.noKK === currentUser?.noKK) || citizens[0];
  const [selectedCitizenId, setSelectedCitizenId] = useState<string>(defaultCitizen?.id || '');
  const [searchQuery, setSearchQuery] = useState('');

  // Payment form states
  const [selectedMonths, setSelectedMonths] = useState<string[]>([]);
  const [infaqAmount, setInfaqAmount] = useState<number>(0);
  const [paymentMethod, setPaymentMethod] = useState<'QRIS' | 'Transfer Bank' | 'Tunai'>('QRIS');
  const [isProcessing, setIsProcessing] = useState(false);
  const [showQrisModal, setShowQrisModal] = useState(false);

  // Feedback form state
  const [feedbackCategory, setFeedbackCategory] = useState<'Saran' | 'Pertanyaan' | 'Keluhan'>('Saran');
  const [feedbackMessage, setFeedbackMessage] = useState('');
  const [feedbackSubmitted, setFeedbackSubmitted] = useState(false);

  const activeCitizen = citizens.find(c => c.id === selectedCitizenId) || defaultCitizen;

  // Filter citizens for lookup
  const filteredCitizens = searchQuery
    ? citizens.filter(c => 
        c.headOfFamily.toLowerCase().includes(searchQuery.toLowerCase()) ||
        c.noKK.includes(searchQuery) ||
        c.nik.includes(searchQuery) ||
        c.address.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : citizens;

  // Toggle month selection for payment
  const handleToggleMonth = (monthKey: string) => {
    setSelectedMonths(prev => 
      prev.includes(monthKey) 
        ? prev.filter(m => m !== monthKey) 
        : [...prev, monthKey].sort()
    );
  };

  const handleSelectAllUnpaid = () => {
    if (!activeCitizen) return;
    const unpaid = Object.entries(activeCitizen.monthlyDues)
      .filter(([k, v]) => !(v as any).paid && k.startsWith('2026'))
      .map(([k]) => k);
    setSelectedMonths(unpaid);
  };

  const baseRate = settings.baseDuesAmount || settings.duesAmount || 5000;
  const extraRate = settings.extraMemberDuesAmount || 3000;
  const activeCitizenRate = activeCitizen ? calculateCitizenMonthlyDues(activeCitizen, baseRate, extraRate).totalMonthlyDues : baseRate;

  const duesTotal = selectedMonths.length * activeCitizenRate;
  const grandTotal = duesTotal + (Number(infaqAmount) || 0);

  // Handle Pay Action
  const handlePay = () => {
    if (!activeCitizen || selectedMonths.length === 0) return;

    if (paymentMethod === 'QRIS') {
      setShowQrisModal(true);
      return;
    }

    executePayment();
  };

  const executePayment = () => {
    setIsProcessing(true);
    setTimeout(() => {
      processPayment({
        noKK: activeCitizen.noKK,
        months: selectedMonths,
        infaqAmount: Number(infaqAmount) || 0,
        paymentMethod: paymentMethod === 'QRIS' ? 'QRIS' : paymentMethod === 'Transfer Bank' ? 'Transfer Bank' : 'Tunai',
        collector: paymentMethod === 'QRIS' ? 'Online QRIS Merchant' : paymentMethod === 'Transfer Bank' ? 'Transfer BSI / Kas RKM' : 'Petugas Lapangan'
      });
      setSelectedMonths([]);
      setInfaqAmount(0);
      setIsProcessing(false);
      setShowQrisModal(false);
    }, 600);
  };

  // Submit Feedback
  const handleSubmitFeedback = (e: React.FormEvent) => {
    e.preventDefault();
    if (!feedbackMessage.trim() || !activeCitizen) return;

    addFeedback({
      citizenName: activeCitizen.headOfFamily,
      noKK: activeCitizen.noKK,
      phone: activeCitizen.phone,
      category: feedbackCategory,
      message: feedbackMessage
    });

    setFeedbackMessage('');
    setFeedbackSubmitted(true);
    setTimeout(() => setFeedbackSubmitted(false), 4000);
  };

  // Calculation of active citizen's stats
  const totalMonthsPaid = activeCitizen ? Object.values(activeCitizen.monthlyDues).filter(m => (m as any).paid).length : 0;
  const unpaidMonthsList = activeCitizen 
    ? Object.entries(activeCitizen.monthlyDues).filter(([k, v]) => !(v as any).paid && k.startsWith('2026')).map(([k]) => k)
    : [];

  return (
    <div className="space-y-6 pb-12 animate-fade-in">
      
      {/* Header & Quick Family Switcher */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 bg-emerald-100 text-emerald-700 rounded-xl">
              <User className="w-5 h-5" />
            </span>
            <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900">Portal Warga Mandiri</h1>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Cek riwayat iuran keluarga, bayar iuran, cetak KTA, dan pantau santunan rukun kematian.
          </p>
        </div>

        {/* Citizen Search / Switcher Box */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
          <div className="relative min-w-[240px]">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Cari Nama / No. KK / RT..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none"
            />
          </div>

          <select
            value={activeCitizen?.id || ''}
            onChange={(e) => {
              setSelectedCitizenId(e.target.value);
              setSelectedMonths([]);
            }}
            className="py-2 px-3 text-xs bg-emerald-50 border border-emerald-300 font-bold text-emerald-950 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none"
          >
            {filteredCitizens.map(c => (
              <option key={c.id} value={c.id}>
                {c.headOfFamily} (RT {c.rt} - KK: {c.noKK})
              </option>
            ))}
          </select>
        </div>
      </div>

      {activeCitizen && (
        <>
          {/* Family Summary Profile Card */}
          <div className="bg-gradient-to-r from-emerald-800 to-teal-950 text-white rounded-3xl p-6 sm:p-8 shadow-xl relative overflow-hidden border border-emerald-600/30">
            <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
              
              <div className="flex items-start gap-4">
                <div className="relative group shrink-0">
                  <img 
                    src={getAvatarUrl(activeCitizen.headOfFamily, 'warga', activeCitizen.avatar)} 
                    alt={activeCitizen.headOfFamily}
                    referrerPolicy="no-referrer"
                    className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl object-cover bg-emerald-600/50 border-2 border-emerald-400/40 shadow-md"
                  />
                  <button
                    onClick={() => openProfileModal(activeCitizen)}
                    className="absolute -bottom-1.5 -right-1.5 p-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 rounded-xl shadow-md border-2 border-emerald-900 transition-all cursor-pointer"
                    title="Unggah / Ubah Foto Avatar"
                  >
                    <Camera className="w-3.5 h-3.5" />
                  </button>
                </div>
                <div>
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-xs px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 font-bold">
                      RT {activeCitizen.rt} / RW {activeCitizen.rw}
                    </span>
                    <span className="text-xs px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-400/30 font-bold">
                      Status: {activeCitizen.status}
                    </span>
                    {activeCitizen.block && (
                      <span className="text-xs px-2.5 py-0.5 rounded-full bg-blue-500/20 text-blue-300 border border-blue-400/30 font-bold">
                        Blok {activeCitizen.block}
                      </span>
                    )}
                  </div>
                  <h2 className="text-xl sm:text-2xl font-black text-white mt-1">
                    {activeCitizen.headOfFamily}
                  </h2>
                  <p className="text-xs text-slate-300 font-mono mt-0.5">
                    No. KK: <strong>{activeCitizen.noKK}</strong> • NIK: {activeCitizen.nik}
                  </p>
                  <p className="text-xs text-slate-300 mt-1">
                    Alamat: {activeCitizen.address} • No. HP: {activeCitizen.phone}
                  </p>
                </div>
              </div>

              {/* Action buttons on profile */}
              <div className="flex flex-wrap gap-2.5 shrink-0">
                <button
                  onClick={() => openProfileModal(activeCitizen)}
                  className="flex items-center gap-2 px-4 py-2.5 bg-white/15 hover:bg-white/25 active:scale-98 text-white font-bold text-xs sm:text-sm rounded-xl border border-white/25 shadow-sm transition-all cursor-pointer"
                >
                  <Camera className="w-4 h-4 text-emerald-300" />
                  <span>Profil & Avatar</span>
                </button>

                <button
                  onClick={() => openKtaModal(activeCitizen)}
                  className="flex items-center gap-2 px-4 py-2.5 bg-emerald-500 hover:bg-emerald-600 active:scale-98 text-slate-950 font-bold text-xs sm:text-sm rounded-xl shadow-lg transition-all cursor-pointer"
                >
                  <QrCode className="w-4 h-4" />
                  <span>Lihat KTA Digital</span>
                </button>

                <a
                  href={`https://wa.me/${settings.waAdmin}?text=Assalamu'alaikum%20Admin%20RKM,%20saya%20warga%20${encodeURIComponent(activeCitizen.headOfFamily)}%20(KK:%20${activeCitizen.noKK})`}
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-center gap-2 px-4 py-2.5 bg-white/10 hover:bg-white/20 active:scale-98 text-white font-semibold text-xs sm:text-sm rounded-xl border border-white/20 transition-all"
                >
                  <MessageSquare className="w-4 h-4 text-emerald-400" />
                  <span>WhatsApp Admin</span>
                </a>
              </div>

            </div>

            {/* Quick Metrics Bar */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6 pt-6 border-t border-emerald-700/60 text-xs">
              <div className="bg-emerald-950/40 p-3 rounded-xl border border-emerald-700/40">
                <span className="text-emerald-300 block text-[10px] uppercase font-bold">Jiwa Tertanggung</span>
                <span className="text-lg font-black text-white">{activeCitizen.members.length} Anggota Keluarga</span>
              </div>
              <div className="bg-emerald-950/40 p-3 rounded-xl border border-emerald-700/40">
                <span className="text-emerald-300 block text-[10px] uppercase font-bold">Tarif Iuran</span>
                <span className="text-lg font-black text-white">{formatRupiah(settings.duesAmount)} / bln</span>
              </div>
              <div className="bg-emerald-950/40 p-3 rounded-xl border border-emerald-700/40">
                <span className="text-emerald-300 block text-[10px] uppercase font-bold">Iuran Lunas 2026</span>
                <span className="text-lg font-black text-emerald-400">{totalMonthsPaid} Bulan</span>
              </div>
              <div className="bg-emerald-950/40 p-3 rounded-xl border border-emerald-700/40">
                <span className="text-emerald-300 block text-[10px] uppercase font-bold">Tunggakan 2026</span>
                <span className={`text-lg font-black ${unpaidMonthsList.length > 0 ? 'text-amber-400' : 'text-emerald-400'}`}>
                  {unpaidMonthsList.length > 0 ? `${unpaidMonthsList.length} Bulan` : 'Lunas Semua ✨'}
                </span>
              </div>
            </div>
          </div>

          {/* 2-Columns: Payment Matrix & Family Members List */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            {/* Left 2 Cols: Monthly Dues Matrix & Self-Pay Module */}
            <div className="lg:col-span-2 space-y-6">
              
              {/* Month-by-month status card */}
              <div className="bg-white rounded-2xl border border-slate-200/80 p-5 sm:p-6 shadow-sm">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-100 gap-3">
                  <div>
                    <h3 className="font-bold text-base text-slate-900">Status Iuran Kas Tahun 2026</h3>
                    <p className="text-xs text-slate-500">Pilih bulan yang ingin dibayar lalu klik proses pembayaran</p>
                  </div>

                  {unpaidMonthsList.length > 0 && (
                    <button
                      onClick={handleSelectAllUnpaid}
                      className="px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 text-xs font-bold rounded-lg border border-emerald-200 transition-colors"
                    >
                      Pilih Semua Bulan Belum Bayar ({unpaidMonthsList.length})
                    </button>
                  )}
                </div>

                {/* Grid 12 Months */}
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 mt-4">
                  {MONTH_NAMES.map((m) => {
                    const monthKey = `2026-${m.key}`;
                    const payment = activeCitizen.monthlyDues[monthKey];
                    const isPaid = payment?.paid;
                    const isSelected = selectedMonths.includes(monthKey);

                    return (
                      <div
                        key={m.key}
                        onClick={() => !isPaid && handleToggleMonth(monthKey)}
                        className={`p-3.5 rounded-xl border transition-all ${
                          isPaid
                            ? 'bg-emerald-50/60 border-emerald-200'
                            : isSelected
                            ? 'bg-emerald-600 text-white border-emerald-700 shadow-md ring-2 ring-emerald-500/40 cursor-pointer'
                            : 'bg-slate-50 border-slate-200 hover:border-slate-300 cursor-pointer hover:bg-slate-100'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className={`font-bold text-xs ${isSelected ? 'text-white' : 'text-slate-800'}`}>
                            {m.name}
                          </span>
                          {isPaid ? (
                            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                          ) : (
                            <div className={`w-4 h-4 rounded border flex items-center justify-center ${
                              isSelected ? 'bg-white text-emerald-600 border-white' : 'border-slate-300'
                            }`}>
                              {isSelected && <span className="text-[10px] font-black">✓</span>}
                            </div>
                          )}
                        </div>

                        <div className="mt-2 text-[11px]">
                          {isPaid ? (
                            <div>
                              <span className="font-bold text-emerald-800">Lunas</span>
                              <div className="text-[10px] text-slate-500 font-mono mt-0.5 truncate">
                                {payment.receiptNo}
                              </div>
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  openReceiptModal({
                                    receiptNo: payment.receiptNo || 'RKM-2026',
                                    citizen: activeCitizen,
                                    monthsPaid: [monthKey],
                                    duesAmount: payment.amount,
                                    infaqAmount: 0,
                                    totalAmount: payment.amount,
                                    date: payment.paidAt || '2026-08-01',
                                    paymentMethod: payment.paymentMethod || 'QRIS',
                                    collector: payment.collector || 'Petugas'
                                  });
                                }}
                                className="mt-1 text-[10px] text-emerald-700 font-bold hover:underline block"
                              >
                                Lihat Kuitansi &rarr;
                              </button>
                            </div>
                          ) : (
                            <div>
                              <span className={`font-bold ${isSelected ? 'text-emerald-100' : 'text-rose-600'}`}>
                                Belum Bayar
                              </span>
                              <div className={`text-[10px] ${isSelected ? 'text-emerald-200' : 'text-slate-500'}`}>
                                {formatRupiah(activeCitizenRate)}
                              </div>
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Payment Checkout Box if months selected */}
                {selectedMonths.length > 0 && (
                  <div className="mt-6 p-5 bg-gradient-to-br from-emerald-50 to-teal-50 rounded-2xl border border-emerald-200 animate-fade-in">
                    <h4 className="font-extrabold text-sm text-emerald-950 flex items-center gap-2">
                      <CreditCard className="w-4 h-4 text-emerald-700" />
                      Konfirmasi Pembayaran ({selectedMonths.length} Bulan Dipilih)
                    </h4>

                    <div className="mt-3 grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                      <div>
                        <span className="text-slate-500 block">Bulan yang dibayar:</span>
                        <span className="font-bold text-slate-800">
                          {selectedMonths.map(m => getMonthNameFromKey(m)).join(', ')}
                        </span>
                        
                        <div className="mt-3">
                          <label className="text-slate-600 block font-semibold mb-1">
                            Infaq / Donasi Kas Kematian (Sukarela):
                          </label>
                          <div className="flex gap-2">
                            {[0, 10000, 20000, 50000].map(amt => (
                              <button
                                key={amt}
                                type="button"
                                onClick={() => setInfaqAmount(amt)}
                                className={`px-2.5 py-1 rounded-lg text-xs font-semibold ${
                                  infaqAmount === amt 
                                    ? 'bg-emerald-600 text-white' 
                                    : 'bg-white text-slate-700 border border-slate-200'
                                }`}
                              >
                                {amt === 0 ? 'Nol' : formatRupiah(amt)}
                              </button>
                            ))}
                          </div>
                        </div>
                      </div>

                      <div className="space-y-3">
                        <div>
                          <label className="text-slate-600 block font-semibold mb-1">Metode Pembayaran:</label>
                          <div className="grid grid-cols-3 gap-2">
                            {(['QRIS', 'Transfer Bank', 'Tunai'] as const).map(met => (
                              <button
                                key={met}
                                type="button"
                                onClick={() => setPaymentMethod(met)}
                                className={`py-1.5 px-2 rounded-lg text-xs font-bold text-center border ${
                                  paymentMethod === met
                                    ? 'bg-emerald-700 text-white border-emerald-800'
                                    : 'bg-white text-slate-700 border-slate-300'
                                }`}
                              >
                                {met}
                              </button>
                            ))}
                          </div>
                        </div>

                        <div className="bg-white p-3 rounded-xl border border-emerald-200 flex justify-between items-center">
                          <div>
                            <span className="text-[10px] uppercase font-bold text-slate-400">Total Pembayaran</span>
                            <div className="text-lg font-black text-emerald-900 font-mono">{formatRupiah(grandTotal)}</div>
                          </div>
                          
                          <button
                            onClick={handlePay}
                            disabled={isProcessing}
                            className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow-md transition-all active:scale-95"
                          >
                            {isProcessing ? 'Memproses...' : 'Bayar Sekarang &rarr;'}
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

              </div>

              {/* Feedback / Kotak Saran Warga */}
              <div className="bg-white rounded-2xl border border-slate-200/80 p-5 sm:p-6 shadow-sm">
                <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
                  <MessageSquare className="w-5 h-5 text-emerald-600" />
                  <div>
                    <h3 className="font-bold text-sm text-slate-900">Kotak Aspirasi & Layanan Warga</h3>
                    <p className="text-xs text-slate-500">Kirim pertanyaan, masukan, atau usulan langsung ke pengurus RKM</p>
                  </div>
                </div>

                {feedbackSubmitted && (
                  <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs font-semibold mt-3">
                    ✓ Pesan Anda telah tersampaikan ke Pengurus RKM. Terima kasih atas partisipasi Anda!
                  </div>
                )}

                <form onSubmit={handleSubmitFeedback} className="mt-4 space-y-3">
                  <div className="flex gap-2">
                    {(['Saran', 'Pertanyaan', 'Keluhan'] as const).map(cat => (
                      <button
                        key={cat}
                        type="button"
                        onClick={() => setFeedbackCategory(cat)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-semibold ${
                          feedbackCategory === cat 
                            ? 'bg-slate-900 text-white' 
                            : 'bg-slate-100 text-slate-600'
                        }`}
                      >
                        {cat}
                      </button>
                    ))}
                  </div>

                  <textarea
                    rows={3}
                    placeholder="Tulis pesan atau pertanyaan Anda di sini..."
                    value={feedbackMessage}
                    onChange={(e) => setFeedbackMessage(e.target.value)}
                    className="w-full p-3 text-xs bg-slate-50 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                    required
                  />

                  <div className="flex justify-end">
                    <button
                      type="submit"
                      className="flex items-center gap-1.5 px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-xl transition-all"
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>Kirim Pesan</span>
                    </button>
                  </div>
                </form>

                {/* Previous replies */}
                <div className="mt-4 pt-3 border-t border-slate-100 space-y-2">
                  <h4 className="text-xs font-bold text-slate-700">Tanggapan Pengurus:</h4>
                  {feedbacks.filter(f => f.noKK === activeCitizen.noKK).map(fb => (
                    <div key={fb.id} className="p-3 bg-slate-50 rounded-xl text-xs space-y-1">
                      <div className="flex justify-between text-[11px] text-slate-500">
                        <span className="font-semibold text-slate-800">[{fb.category}] {fb.createdAt}</span>
                        <span className="text-emerald-700 font-bold">{fb.status}</span>
                      </div>
                      <p className="text-slate-700 italic">"{fb.message}"</p>
                      {fb.reply && (
                        <div className="mt-1 p-2 bg-emerald-50 border border-emerald-100 rounded-lg text-emerald-950 font-medium">
                          <strong>Admin:</strong> {fb.reply}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>

            </div>

            {/* Right 1 Col: Registered Family Members & Benefits */}
            <div className="space-y-6">
              
              {/* Family Members Covered */}
              <div className="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-sm">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                  <div className="flex items-center gap-2">
                    <Users className="w-4 h-4 text-emerald-600" />
                    <h3 className="font-bold text-sm text-slate-900">Anggota Keluarga Tertanggung</h3>
                  </div>
                  <span className="text-xs bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded-full">
                    {activeCitizen.members.length} Jiwa
                  </span>
                </div>

                <div className="mt-3 divide-y divide-slate-100">
                  {activeCitizen.members.map((m, idx) => (
                    <div key={m.id} className="py-2.5 flex items-center justify-between text-xs">
                      <div>
                        <div className="font-bold text-slate-900">{idx + 1}. {m.name}</div>
                        <div className="text-[10px] text-slate-500 font-mono">NIK: {m.nik}</div>
                      </div>
                      <div className="text-right">
                        <span className="text-[10px] px-2 py-0.5 bg-slate-100 text-slate-700 font-semibold rounded">
                          {m.relation}
                        </span>
                        <div className={`text-[10px] font-semibold mt-0.5 ${m.status === 'Hidup' ? 'text-emerald-600' : 'text-rose-600'}`}>
                          {m.status}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="mt-4 pt-3 border-t border-slate-100 text-center">
                  <button
                    onClick={() => openKtaModal(activeCitizen)}
                    className="w-full py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold rounded-xl transition-all"
                  >
                    Buka & Cetak KTA Lengkap
                  </button>
                </div>
              </div>

              {/* RKM Benefits Info */}
              <div className="bg-slate-900 text-white rounded-2xl p-5 shadow-sm border border-slate-800 space-y-3">
                <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                  <h4 className="font-bold text-xs text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
                    <HeartHandshake className="w-4 h-4" />
                    Hak Layanan Sesuai AD/ART
                  </h4>
                  <span className="text-[10px] bg-emerald-500/20 text-emerald-300 font-bold px-2 py-0.5 rounded-full border border-emerald-500/30">
                    2024–2027
                  </span>
                </div>
                
                <ul className="space-y-2 text-xs text-slate-300">
                  <li className="flex items-start gap-2">
                    <span className="text-emerald-400 font-bold">✓</span>
                    <span><strong>Uang Santunan Duka:</strong> {formatRupiah(settings.deathBenefitAmount)} tunai (Pasal 3 ART)</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-emerald-400 font-bold">✓</span>
                    <span><strong>Perlengkapan Jenazah Syar'i:</strong> Kain kafan, kapas, wewangian, sabun bidara, kapur barus</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-emerald-400 font-bold">✓</span>
                    <span><strong>Tim Pemulasaraan:</strong> Memandikan & mengkafani oleh tim ikhwan / akhwat terlatih</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-emerald-400 font-bold">✓</span>
                    <span><strong>Fasilitas Duka:</strong> Keranda, tenda duka (1-2 plong), kursi 50-100 unit, sound & lampu</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-emerald-400 font-bold">✓</span>
                    <span><strong>Transportasi & TPU:</strong> Mobil ambulance 24 jam & liang lahat makam TPU Parung Panjang</span>
                  </li>
                </ul>

                <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-[11px] text-slate-400">
                  <span>Berlaku bagi seluruh jiwa di KK aktif</span>
                  <a
                    href="https://drive.google.com/file/d/1itGAXcxzcn0Wg9uqoHnc1fniJzUJKX83/view?usp=sharing"
                    target="_blank"
                    rel="noreferrer"
                    className="text-emerald-400 font-semibold hover:underline"
                  >
                    Baca AD/ART PDF &rarr;
                  </a>
                </div>
              </div>

            </div>

          </div>
        </>
      )}

      {/* QRIS Payment Dynamic Popup */}
      {showQrisModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-sm animate-fade-in">
          <div className="bg-white rounded-2xl p-6 max-w-sm w-full shadow-2xl border border-slate-200 text-center">
            <h3 className="font-extrabold text-base text-slate-900 uppercase tracking-tight">
              Scan QRIS Pembayaran
            </h3>
            <p className="text-xs text-slate-500 mt-1">
              {settings.orgName}
            </p>

            <div className="my-4 p-3 bg-white border-2 border-emerald-600 rounded-xl inline-block shadow-md">
              <img
                src={settings.qrisCodeUrl}
                alt="QRIS Code"
                className="w-48 h-48 mx-auto"
              />
              <div className="text-[11px] font-bold text-slate-700 mt-2 font-mono">
                NMID: ID1020038472911
              </div>
            </div>

            <div className="bg-emerald-50 p-3 rounded-xl border border-emerald-200 text-xs">
              <div className="font-semibold text-slate-600">Total yang harus dibayar:</div>
              <div className="text-xl font-black text-emerald-900 font-mono mt-0.5">{formatRupiah(grandTotal)}</div>
              <div className="text-[10px] text-slate-500 mt-1">Bisa scan pakai GoPay, OVO, Dana, BCA, BSI, ShopeePay, dll.</div>
            </div>

            <div className="mt-4 flex gap-2">
              <button
                onClick={() => setShowQrisModal(false)}
                className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl"
              >
                Batal
              </button>
              <button
                onClick={executePayment}
                className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow transition-all"
              >
                Konfirmasi Sudah Bayar
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
