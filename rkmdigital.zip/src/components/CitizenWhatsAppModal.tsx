import React, { useState, useEffect } from 'react';
import { 
  X, 
  Send, 
  Copy, 
  Check, 
  MessageSquare, 
  Phone, 
  AlertCircle, 
  Heart, 
  QrCode, 
  CreditCard, 
  DollarSign, 
  Building, 
  Calendar, 
  FileText,
  Sparkles,
  ExternalLink
} from 'lucide-react';
import { Citizen, DeathNotice, OrganizationSettings } from '../types';
import { 
  formatRupiah, 
  formatDateIndo, 
  calculateCitizenMonthlyDues, 
  createWhatsAppUrl, 
  getMonthNameFromKey 
} from '../utils/formatters';

interface CitizenWhatsAppModalProps {
  citizen: Citizen;
  settings: OrganizationSettings;
  deathNotices: DeathNotice[];
  initialTab?: 'reminder' | 'lelayu' | 'membership' | 'custom';
  onClose: () => void;
  onToast: (msg: string) => void;
}

export const CitizenWhatsAppModal: React.FC<CitizenWhatsAppModalProps> = ({
  citizen,
  settings,
  deathNotices,
  initialTab = 'reminder',
  onClose,
  onToast
}) => {
  const [activeTab, setActiveTab] = useState<'reminder' | 'lelayu' | 'membership' | 'custom'>(initialTab);
  const [targetPhone, setTargetPhone] = useState(citizen.phone || '');
  const [selectedDeathId, setSelectedDeathId] = useState<string>(deathNotices[0]?.id || '');
  const [customMessage, setCustomMessage] = useState<string>('');
  const [copied, setCopied] = useState(false);

  const baseRate = settings.baseDuesAmount || settings.duesAmount || 5000;
  const extraRate = settings.extraMemberDuesAmount || 3000;
  const duesCalc = calculateCitizenMonthlyDues(citizen, baseRate, extraRate);

  // Calculate unpaid months for 2026 up to August/September
  const unpaidMonths = Object.entries(citizen.monthlyDues)
    .filter(([k, v]) => !(v as any)?.paid && k.startsWith('2026'))
    .map(([k]) => k)
    .sort();

  const totalTagihan = unpaidMonths.length * duesCalc.totalMonthlyDues;
  const primaryBank = settings.bankAccounts?.find(b => b.isPrimary) || settings.bankAccounts?.[0] || {
    bank: settings.bankName || 'BSI (Bank Syariah Indonesia)',
    accountNumber: settings.bankAccount || '7123-4567-8901',
    accountHolder: settings.bankHolder || 'RKM MPP Kas Sosial'
  };

  // Generate Message Template based on Active Tab
  useEffect(() => {
    if (activeTab === 'reminder') {
      const unpaidMonthNames = unpaidMonths.map(m => getMonthNameFromKey(m));
      const message = 
`*PEMBERITAHUAN IURAN KAS SOSIAL RKM MPP*
_${settings.orgName || 'RUKUN KEMATIAN MUSLIM METRO PARUNG PANJANG'}_
────────────────────────────
Assalamu'alaikum Warahmatullahi Wabarakatuh.

Yth. Bapak/Ibu *${citizen.headOfFamily}*
Alamat: ${citizen.block ? `${citizen.block} ${citizen.houseNumber || ''}` : citizen.address}, RT ${citizen.rt} / RW ${citizen.rw}

Semoga Bapak/Ibu sekeluarga senantiasa dalam lindungan dan rahmat Allah SWT.

Melalui pesan ini, kami pengurus RKM MPP menyampaikan rekapitulasi kewajiban iuran fardhu kifayah kematian:

📋 *RINCIAN KELUARGA & IURAN:*
• *No. Kartu Keluarga (KK):* ${citizen.noKK}
• *Jumlah Tertanggung:* ${citizen.members.length} Jiwa (${duesCalc.coreMembersCount} Inti${duesCalc.extraMembersCount > 0 ? `, +${duesCalc.extraMembersCount} Tambahan` : ''})
• *Tarif Iuran Bulanan:* ${formatRupiah(duesCalc.totalMonthlyDues)} / Bulan
• *Bulan Belum Terbayar:* 
  ${unpaidMonthNames.length > 0 ? unpaidMonthNames.join(', ') : 'Alhamdulillah Lunas Semua Bulan'}
• *Total Tagihan:* *${formatRupiah(totalTagihan)}* (${unpaidMonthNames.length} Bulan)

💳 *SALURAN PEMBAYARAN RESMI:*
1. *Transfer Bank:*
   • *Bank:* ${primaryBank.bank}
   • *No. Rekening:* \`${primaryBank.accountNumber}\`
   • *Atas Nama:* ${primaryBank.accountHolder}
2. *QRIS Kas RKM:* Tersedia pada aplikasi dan kuitansi digital pengurus.
3. *Petugas Tagih RT:* Dapat dititipkan melalui Koordinator RT ${citizen.rt}.

Setelah melakukan transfer/pembayaran, mohon konfirmasi ke nomor WhatsApp Pengurus: ${settings.waAdmin || '0812-3456-7890'}.

_Jazaakumullahu khairan katsiran atas kedisiplinan dan partisipasi Bapak/Ibu dalam menjaga keberlangsungan dana fardhu kifayah warga._

Wassalamu'alaikum Warahmatullahi Wabarakatuh.

*Pengurus RKM MPP 2024–2027*
Hotline: ${settings.contactCenter || settings.waAdmin || '-'}`;

      setCustomMessage(message);
    } else if (activeTab === 'lelayu') {
      const death = deathNotices.find(d => d.id === selectedDeathId) || deathNotices[0];
      if (death) {
        const message = 
`*BERITA DUKA CITA (MAKLUMAT LELAYU)*
_${settings.orgName || 'RUKUN KEMATIAN MUSLIM METRO PARUNG PANJANG'}_
────────────────────────────
*إِنَّا لِلَّٰهِ وَإِنَّا إِلَيْهِ رَاجِعُونَ*
_Inna lillahi wa inna ilaihi raji'un_

Telah berpulang ke Rahmatullah, warga/saudara kita tercinta:

👤 *Nama:* *${death.deceasedName}* ${death.binBinti ? `bin/binti ${death.binBinti}` : ''}
📅 *Usia:* ${death.age} Tahun
📍 *Alamat Duka:* ${death.address}, RT ${death.rt} / RW ${death.rw}
⏰ *Waktu Wafat:* ${death.passAwayTime}
🕌 *Lokasi Shalat Jenazah:* ${death.mosqueName || 'Masjid Jami Al-Muhajirin'}
⚰️ *Rencana Pemakaman:* ${death.cemeteryName || 'TPU Desa Gerowong / Makam RKM'} (${death.funeralTime})

Mari kita luangkan waktu untuk mendoakan almarhum/almarhumah, semoga diampuni segala dosa-dosanya, diterima seluruh amal ibadahnya, dan keluarga yang ditinggalkan diberikan keikhlasan dan ketabahan.

Bagi warga yang berkesempatan, dimohon kehadiran takziah dan mengiringi jenazah ke peristirahatan terakhir.

*Satgas Fardhu Kifayah & Pengurus RKM MPP*
Koordinator Jenazah: ${settings.mortuaryCoordinatorName || 'Ust. Tim Pemulasaraan'} (${settings.mortuaryCoordinatorPhone || settings.waAdmin})`;
        setCustomMessage(message);
      } else {
        setCustomMessage(
`*BERITA DUKA CITA (MAKLUMAT LELAYU)*
_${settings.orgName || 'RUKUN KEMATIAN MUSLIM METRO PARUNG PANJANG'}_
────────────────────────────
*إِنَّا لِلَّٰهِ وَإِنَّا إِلَيْهِ رَاجِعُونَ*
_Inna lillahi wa inna ilaihi raji'un_

Telah berpulang ke Rahmatullah warga perumahan kita. Informasi pelaksanaan fardhu kifayah dan pemakaman akan segera diumumkan oleh Satgas RKM MPP.

Mohon doa terbaik dari seluruh warga.`);
      }
    } else if (activeTab === 'membership') {
      const message = 
`*INFORMASI KEANGGOTAAN & KTA DIGITAL RKM MPP*
_${settings.orgName || 'RUKUN KEMATIAN MUSLIM METRO PARUNG PANJANG'}_
────────────────────────────
Assalamu'alaikum Wr. Wb.
Yth. Bapak/Ibu *${citizen.headOfFamily}*

Berikut adalah rincian data keanggotaan Anda yang tercatat resmi di database RKM MPP:

• *Kepala Keluarga:* ${citizen.headOfFamily}
• *No. KK:* ${citizen.noKK}
• *NIK:* ${citizen.nik}
• *Alamat:* ${citizen.block ? `${citizen.block} ${citizen.houseNumber || ''}` : citizen.address}, RT ${citizen.rt} / RW ${citizen.rw}
• *Status Keanggotaan:* ${citizen.status}
• *Jumlah Tertanggung:* ${citizen.members.length} Jiwa
• *Iuran Bulanan:* ${formatRupiah(duesCalc.totalMonthlyDues)} / bln
• *Tgl Terdaftar:* ${formatDateIndo(citizen.joinDate, false)}

Kartu Tanda Anggota (KTA Digital) dan riwayat pembayaran iuran dapat diakses melalui portal resmi RKM MPP Digital.

Terima kasih atas kebersamaan dan kepedulian Anda dalam paguyuban warga Muslim.

*Sekretariat RKM MPP*
WA Admin: ${settings.waAdmin || '-'}`;
      setCustomMessage(message);
    }
  }, [activeTab, selectedDeathId, citizen, settings, deathNotices]);

  const handleSendWhatsApp = () => {
    if (!targetPhone) {
      onToast('Silakan isi nomor WhatsApp penerima terlebih dahulu.');
      return;
    }
    const url = createWhatsAppUrl(targetPhone, customMessage);
    window.open(url, '_blank');
    onToast(`Membuka WhatsApp untuk mengirim pesan ke Bpk. ${citizen.headOfFamily}...`);
  };

  const handleCopyMessage = () => {
    navigator.clipboard.writeText(customMessage);
    setCopied(true);
    onToast('✓ Teks pesan berhasil disalin ke clipboard!');
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-xs animate-fade-in">
      <div className="bg-white rounded-3xl p-6 max-w-2xl w-full shadow-2xl border border-slate-200/80 max-h-[92vh] flex flex-col">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-100 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 bg-emerald-100 text-emerald-800 rounded-2xl">
              <MessageSquare className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-base text-slate-900 flex items-center gap-2">
                <span>Integrasi WhatsApp Gateway</span>
                <span className="text-[10px] bg-emerald-100 text-emerald-800 font-black px-2 py-0.5 rounded-full">
                  WhatsApp Direct
                </span>
              </h3>
              <p className="text-xs text-slate-500">
                Kirim pesan personal, tagihan iuran, atau maklumat duka kepada <strong>Bpk. {citizen.headOfFamily}</strong>
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 rounded-xl hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selection */}
        <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-2xl mt-4 shrink-0 overflow-x-auto text-xs font-bold">
          <button
            type="button"
            onClick={() => setActiveTab('reminder')}
            className={`flex items-center gap-1.5 py-2 px-3 rounded-xl transition-all whitespace-nowrap ${
              activeTab === 'reminder'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
            }`}
          >
            <CreditCard className="w-3.5 h-3.5" />
            <span>Pengingat Iuran</span>
            {unpaidMonths.length > 0 && (
              <span className={`text-[10px] px-1.5 py-0.2 rounded-full ${
                activeTab === 'reminder' ? 'bg-emerald-800 text-white' : 'bg-rose-100 text-rose-800'
              }`}>
                {unpaidMonths.length} Bln
              </span>
            )}
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('lelayu')}
            className={`flex items-center gap-1.5 py-2 px-3 rounded-xl transition-all whitespace-nowrap ${
              activeTab === 'lelayu'
                ? 'bg-rose-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
            }`}
          >
            <Heart className="w-3.5 h-3.5" />
            <span>Maklumat Duka</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('membership')}
            className={`flex items-center gap-1.5 py-2 px-3 rounded-xl transition-all whitespace-nowrap ${
              activeTab === 'membership'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
            }`}
          >
            <QrCode className="w-3.5 h-3.5" />
            <span>Info KTA Warga</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('custom')}
            className={`flex items-center gap-1.5 py-2 px-3 rounded-xl transition-all whitespace-nowrap ${
              activeTab === 'custom'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Pesan Kustom</span>
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="flex-1 overflow-y-auto mt-4 space-y-3.5 text-xs pr-1">
          
          {/* Target Phone Number */}
          <div className="p-3 bg-slate-50 border border-slate-200 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
            <div className="flex items-center gap-2">
              <Phone className="w-4 h-4 text-emerald-600 shrink-0" />
              <div>
                <span className="font-bold text-slate-800 block text-xs">Nomor WhatsApp Tujuan:</span>
                <span className="text-[11px] text-slate-500">Penerima: {citizen.headOfFamily}</span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <input
                type="text"
                placeholder="Contoh: 081234567890"
                value={targetPhone}
                onChange={(e) => setTargetPhone(e.target.value)}
                className="p-2 bg-white border border-slate-300 rounded-xl font-mono text-xs font-bold text-slate-900 focus:ring-2 focus:ring-emerald-500 w-44"
              />
            </div>
          </div>

          {/* If tab is Lelayu, select deceased */}
          {activeTab === 'lelayu' && deathNotices.length > 0 && (
            <div className="p-3 bg-rose-50/70 border border-rose-200 rounded-2xl space-y-1.5">
              <label className="font-bold text-rose-950 block text-xs">Pilih Berita Lelayu yang Ingin Diumumkan:</label>
              <select
                value={selectedDeathId}
                onChange={(e) => setSelectedDeathId(e.target.value)}
                className="w-full p-2 bg-white border border-rose-300 rounded-xl font-bold text-slate-900 text-xs"
              >
                {deathNotices.map(d => (
                  <option key={d.id} value={d.id}>
                    Alm(ah). {d.deceasedName} ({d.address}, RT {d.rt}) - {d.passAwayTime}
                  </option>
                ))}
              </select>
            </div>
          )}

          {/* Live Editable Text Area */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="font-bold text-slate-700 text-xs">Isi Teks Pesan WhatsApp (Dapat Diedit):</label>
              <span className="text-[11px] text-slate-400 font-mono">{customMessage.length} Karakter</span>
            </div>
            <textarea
              rows={8}
              value={customMessage}
              onChange={(e) => setCustomMessage(e.target.value)}
              className="w-full p-3 bg-slate-900 text-emerald-300 rounded-2xl font-mono text-[11px] leading-relaxed border border-slate-800 focus:ring-2 focus:ring-emerald-500 focus:outline-none resize-y"
            />
          </div>

          {/* WhatsApp Bubble Preview */}
          <div className="p-3.5 bg-emerald-950/5 border border-emerald-900/10 rounded-2xl space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-bold text-slate-700 text-[11px] flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                Pratinjau Tampilan Chat WhatsApp
              </span>
              <span className="text-[10px] text-slate-400 font-mono">Simulasi Bubble</span>
            </div>

            <div className="bg-[#dcf8c6] p-3 rounded-2xl shadow-xs text-slate-900 text-[11px] font-sans leading-relaxed whitespace-pre-wrap border border-emerald-300/40">
              {customMessage}
              <div className="text-[9px] text-slate-500 text-right mt-1 font-mono">
                {new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })} • ✓✓
              </div>
            </div>
          </div>

        </div>

        {/* Footer Actions */}
        <div className="pt-4 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              type="button"
              onClick={handleCopyMessage}
              className="flex-1 sm:flex-initial flex items-center justify-center gap-1.5 px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs transition-colors"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
              <span>{copied ? 'Tersalin!' : 'Salin Pesan'}</span>
            </button>

            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 bg-white hover:bg-slate-50 text-slate-500 font-semibold rounded-xl text-xs border border-slate-200"
            >
              Tutup
            </button>
          </div>

          <button
            type="button"
            onClick={handleSendWhatsApp}
            className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 active:scale-98 text-white font-black rounded-xl text-xs shadow-md transition-all cursor-pointer"
          >
            <Send className="w-4 h-4" />
            <span>Kirim via WhatsApp</span>
            <ExternalLink className="w-3.5 h-3.5 opacity-80" />
          </button>
        </div>

      </div>
    </div>
  );
};
