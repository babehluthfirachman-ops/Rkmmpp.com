import React, { useState } from 'react';
import { 
  FileText, 
  Download, 
  ExternalLink, 
  Search, 
  ShieldCheck, 
  Scale, 
  Users, 
  HeartHandshake, 
  BookOpen, 
  AlertCircle, 
  CheckCircle2, 
  Truck, 
  Clock, 
  Coins, 
  Calendar, 
  ChevronRight, 
  Sparkles, 
  Printer, 
  Share2,
  HelpCircle,
  Award,
  Building,
  Bookmark
} from 'lucide-react';
import { useRkm } from '../context/RkmContext';
import { formatRupiah, getDirectImageUrl } from '../utils/formatters';

interface ArticleItem {
  number: string;
  title: string;
  chapter: string;
  chapterTitle: string;
  type: 'AD' | 'ART';
  content: string[];
  keyPoints?: string[];
  tags: string[];
}

export const AdArtView: React.FC = () => {
  const { settings, currentRole } = useRkm();
  const [activeTab, setActiveTab] = useState<'ringkasan' | 'ad' | 'art' | 'sop' | 'struktur' | 'kalkulator' | 'pdf'>('ringkasan');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  // Interactive Calculator State for Citizen Benefits
  const [simMonthsActive, setSimMonthsActive] = useState<number>(12);
  const [simIsPaidUp, setSimIsPaidUp] = useState<boolean>(true);
  const [simFamilyStatus, setSimFamilyStatus] = useState<'Kepala Keluarga' | 'Istri' | 'Anak Kandung' | 'Orang Tua Serumah' | 'Warga Non-Anggota'>('Kepala Keluarga');

  const PDF_URL = 'https://drive.google.com/file/d/1itGAXcxzcn0Wg9uqoHnc1fniJzUJKX83/view?usp=sharing';
  const PDF_EMBED_URL = 'https://drive.google.com/file/d/1itGAXcxzcn0Wg9uqoHnc1fniJzUJKX83/preview';

  // Comprehensive Articles Database of AD/ART RKM MPP 2024-2027
  const ARTICLES_DATA: ArticleItem[] = [
    // ANGGARAN DASAR (AD)
    {
      number: 'Pasal 1',
      title: 'Nama, Waktu & Kedudukan',
      chapter: 'BAB I',
      chapterTitle: 'Nama, Waktu & Tempat Kedudukan',
      type: 'AD',
      content: [
        'Organisasi ini bernama Rukun Kematian Muslim Metro Parung Panjang, disingkat RKM MPP.',
        'RKM MPP didirikan untuk jangka waktu yang tidak ditentukan dan kepengurusan ini ditetapkan untuk Periode Bakti 2024 – 2027.',
        'RKM MPP berkedudukan di lingkungan Perumahan Metro Parung Panjang, Desa Parungpanjang, Kecamatan Parungpanjang, Kabupaten Bogor, Provinsi Jawa Barat.'
      ],
      keyPoints: ['Nama Resmi: RKM MPP', 'Periode Kepengurusan: 2024–2027', 'Wilayah: Perumahan Metro Parung Panjang'],
      tags: ['nama', 'periode', 'kedudukan', 'alamat', '2024-2027']
    },
    {
      number: 'Pasal 2',
      title: 'Azas dan Landasan',
      chapter: 'BAB II',
      chapterTitle: 'Azas, Landasan & Sifat',
      type: 'AD',
      content: [
        'RKM MPP berazaskan Islam berlandaskan Al-Qur\'an dan Sunnah Rasulullah SAW.',
        'Landasan operasional RKM MPP adalah musyawarah mufakat, ukhuwah Islamiyah, dan prinsip tolong-menolong dalam kebaikan dan ketaqwaan (Ta\'awun \'alal birri wat-taqwa).',
        'RKM MPP bersifat sosial keagamaan, independen, nirlaba, dan berasas kekeluargaan.'
      ],
      keyPoints: ['Azas Islam & Ta\'awun', 'Organisasi Sosial Keagamaan Nirlaba'],
      tags: ['azas', 'landasan', 'islam', 'ukhuwah']
    },
    {
      number: 'Pasal 3',
      title: 'Maksud dan Tujuan',
      chapter: 'BAB III',
      chapterTitle: 'Maksud & Tujuan',
      type: 'AD',
      content: [
        'Melaksanakan kewajiban Fardhu Kifayah terhadap jenazah warga Muslim di lingkungan Metro Parung Panjang secara syar\'i, tertib, dan bermartabat.',
        'Membantu meringankan beban moral, fisik, dan finansial keluarga yang tertimpa musibah kematian.',
        'Mempererat tali silaturahmi, persaudaraan, dan kepedulian sosial antar sesama warga Muslim Metro Parung Panjang.',
        'Menyediakan sarana, prasarana, perlengkapan pemulasaraan jenazah, dan armada mobil jenazah (ambulance) siaga 24 jam.'
      ],
      keyPoints: ['Pelayanan Fardhu Kifayah Lengkap', 'Santunan Finansial & Moral', 'Armada Ambulan & Logistik Siaga 24 Jam'],
      tags: ['tujuan', 'fardhu kifayah', 'layanan', 'bantuan']
    },
    {
      number: 'Pasal 4',
      title: 'Keanggotaan',
      chapter: 'BAB IV',
      chapterTitle: 'Keanggotaan',
      type: 'AD',
      content: [
        'Keanggotaan RKM MPP berbasis Kepala Keluarga (KK) yang beragama Islam dan berdomisili atau bertempat tinggal di lingkungan Metro Parung Panjang.',
        'Keanggotaan mencakup seluruh anggota keluarga yang tercantum dalam Kartu Keluarga (KK) yang didaftarkan secara sah.',
        'Ketentuan lebih lanjut mengenai syarat pendaftaran, hak, dan kewajiban anggota diatur dalam Anggaran Rumah Tangga (ART).'
      ],
      keyPoints: ['Berbasis Kartu Keluarga (KK)', 'Mencakup seluruh anggota keluarga dalam 1 KK'],
      tags: ['anggota', 'kartu keluarga', 'kk', 'domisili']
    },
    {
      number: 'Pasal 5',
      title: 'Hak dan Kewajiban Anggota',
      chapter: 'BAB IV',
      chapterTitle: 'Keanggotaan',
      type: 'AD',
      content: [
        'Setiap anggota berhak mendapatkan pelayanan pemulasaraan jenazah secara penuh, santunan kematian, serta fasilitas sarana prasarana duka secara cuma-cuma sesuai ketentuan.',
        'Setiap anggota berhak mengajukan usulan, saran, serta memilih dan dipilih menjadi pengurus RKM MPP.',
        'Setiap anggota berkewajiban membayar iuran wajib bulanan, mematuhi AD/ART, dan menjaga nama baik organisasi.'
      ],
      keyPoints: ['Hak: Layanan Penuh & Santunan', 'Kewajiban: Iuran Wajib Rutin'],
      tags: ['hak', 'kewajiban', 'iuran', 'pemilihan']
    },
    {
      number: 'Pasal 6',
      title: 'Keuangan dan Perbendaharaan',
      chapter: 'BAB V',
      chapterTitle: 'Keuangan & Harta Benda',
      type: 'AD',
      content: [
        'Sumber keuangan RKM MPP diperoleh dari: Iuran wajib anggota bulanan, Infaq/Sedekah sukarela warga, Donasi/Hibah tidak mengikat, dan Sumbangan dari pihak ketiga yang halal.',
        'Pengelolaan keuangan RKM MPP berprinsip transparan, akuntabel, dan dilaporkan secara berkala kepada seluruh anggota melalui sistem digital dan musyawarah.',
        'Dana kas RKM MPP hanya diperuntukkan bagi pelayanan fardhu kifayah, santunan kematian, pemeliharaan aset, dan operasional layanan duka.'
      ],
      keyPoints: ['Transparansi Digital & Akuntabel', 'Alokasi Khusus Sosial Duka'],
      tags: ['keuangan', 'kas', 'transparansi', 'infaq', 'laporan']
    },
    {
      number: 'Pasal 7',
      title: 'Struktur Organisasi & Musyawarah',
      chapter: 'BAB VI',
      chapterTitle: 'Organisasi & Pengambilan Keputusan',
      type: 'AD',
      content: [
        'Struktur organisasi terdiri dari: Dewan Pembina/Penasehat, Pengurus Harian (Ketua, Sekretaris, Bendahara), Bidang Pemulasaraan Fardhu Kifayah, Bidang Logistik & Armada, Bidang Humas & Komunikasi, serta Koordinator RT.',
        'Kekuasaan tertinggi organisasi berada pada Musyawarah Anggota.',
        'Kepengurusan RKM MPP dipilih dan disahkan untuk masa bakti 3 (tiga) tahun (Periode 2024–2027).'
      ],
      keyPoints: ['Masa Bakti: 3 Tahun (2024–2027)', 'Kekuasaan Tertinggi: Musyawarah Anggota'],
      tags: ['struktur', 'pengurus', 'musyawarah', 'tupoksi']
    },

    // ANGGARAN RUMAH TANGGA (ART)
    {
      number: 'Pasal 1 ART',
      title: 'Syarat & Prosedur Pendaftaran Anggota',
      chapter: 'BAB I ART',
      chapterTitle: 'Ketentuan Keanggotaan',
      type: 'ART',
      content: [
        'Warga Muslim yang berdomisili di Metro Parung Panjang berhak mendaftar sebagai anggota RKM MPP.',
        'Pendaftaran dilakukan dengan mengisi formulir pendaftaran digital/manual dan melampirkan fotokopi/foto Kartu Keluarga (KK) serta KTP Kepala Keluarga.',
        'Setiap anggota baru membayar biaya administrasi pendaftaran perdana sebesar Rp 50.000,- (lima puluh ribu rupiah) dan iuran bulan berjalan.'
      ],
      keyPoints: ['Pendaftaran via KK & KTP', 'Biaya Registrasi Perdana: Rp 50.000,-'],
      tags: ['pendaftaran', 'syarat anggota', 'biaya daftar', 'ktp', 'kk']
    },
    {
      number: 'Pasal 2 ART',
      title: 'Rincian Hak Pelayanan Pemulasaraan (Fardhu Kifayah)',
      chapter: 'BAB II ART',
      chapterTitle: 'Hak Pelayanan & Fasilitas',
      type: 'ART',
      content: [
        'Paket Kain Kafan Lengkap kualitas terbaik beserta perlengkapan (kapas, kamper, minyak wangi non-alkohol, sabun bidara, cendana, peniti, dll).',
        'Peralatan pemandian jenazah stainless steel, selang, gayung, dan petugas pemandi jenazah terlatih (Tim Ikhwan untuk pria, Tim Akhwat untuk wanita).',
        'Tenda Duka (1-2 plong), Kursi Lipat (50–100 unit), Lampu Penerangan Darurat, Keranda & Tutup Keranda Jenazah, serta Bendera Kuning Pengumuman.',
        'Layanan Mobil Ambulan Jenazah 24 Jam untuk pengantaran dari rumah duka/RS ke masjid dan menuju TPU Parung Panjang.',
        'Jasa Penggalian dan Perapihan Liang Lahat di TPU beserta papan lahad dan patok nisan sementara.'
      ],
      keyPoints: ['Kafan & Alat Mandi Lengkap', 'Tenda, Kursi & Sound Gratis', 'Ambulance 24 Jam', 'Gali Kubur & Papan Lahad'],
      tags: ['fardhu kifayah', 'kain kafan', 'ambulan', 'tenda', 'gali kubur', 'pemakaman']
    },
    {
      number: 'Pasal 3 ART',
      title: 'Santunan Uang Duka / Dana Kerohiman',
      chapter: 'BAB II ART',
      chapterTitle: 'Hak Pelayanan & Fasilitas',
      type: 'ART',
      content: [
        'Keluarga/ahli waris dari anggota aktif yang meninggal dunia berhak menerima Santunan Uang Duka sebesar Rp 3.000.000,- (Tiga Juta Rupiah) secara tunai/transfer sesaat setelah proses pemakaman.',
        'Santunan duka diberikan langsung oleh Bendahara/Ketua RKM kepada ahli waris utama disertai tanda terima penyerahan santunan resmi.',
        'Santunan duka berlaku bagi Kepala Keluarga, Istri, Anak Kandung, maupun Orang Tua/Mertua yang tercantum dalam Kartu Keluarga (KK) terdaftar.'
      ],
      keyPoints: ['Nominal Santunan Duka: Rp 3.000.000,-', 'Diserahkan langsung tunai/transfer ke ahli waris'],
      tags: ['santunan', 'uang duka', 'kerohiman', '3000000', 'ahli waris']
    },
    {
      number: 'Pasal 4 ART',
      title: 'Besaran dan Tata Cara Pembayaran Iuran',
      chapter: 'BAB III ART',
      chapterTitle: 'Iuran & Keuangan',
      type: 'ART',
      content: [
        'Besaran iuran wajib anggota adalah Rp 20.000,- (dua puluh ribu rupiah) per Kartu Keluarga (KK) setiap bulannya.',
        'Pembayaran iuran dapat dilakukan secara bulanan, triwulan, semesteran, atau tahunan di muka.',
        'Metode pembayaran resmi: (1) Tunai melalui Petugas Kolektor RT, (2) Transfer Rekening Bank Resmi RKM MPP (BSI / Bank Mandiri), (3) QRIS Dinamis Digital.',
        'Setiap pembayaran sah wajib mendapatkan Kuitansi Digital WhatsApp yang tercatat otomatis dalam Sistem Buku Kas RKM.'
      ],
      keyPoints: ['Iuran Wajib: Rp 20.000,- / KK / bulan', 'Kuitansi Digital WhatsApp Otomatis'],
      tags: ['iuran', '20000', 'rekening', 'qris', 'kuitansi whatsapp']
    },
    {
      number: 'Pasal 5 ART',
      title: 'Ketentuan Tunggakan & Status Keaktifan',
      chapter: 'BAB III ART',
      chapterTitle: 'Iuran & Keuangan',
      type: 'ART',
      content: [
        'Anggota dinyatakan Aktif apabila iuran terbayar lancar atau memiliki tunggakan maksimal 3 (tiga) bulan.',
        'Apabila anggota menunggak lebih dari 3 bulan hingga 6 bulan, pengurus akan menyampaikan surat pemberitahuan/notifikasi tagihan berkala.',
        'Jika terjadi musibah pada anggota yang menunggak 1-6 bulan, pelayanan Fardhu Kifayah (Kafan, Pemandian, Tenda, Ambulan) TETAP DIBERIKAN PENUH, sedangkan sisa tunggakan iuran akan dipotongkan secara musyawarah dari santunan duka.',
        'Anggota yang menunggak lebih dari 12 bulan berturut-turut tanpa konfirmasi dinyatakan non-aktif dan pelayanan diberikan berdasarkan kebijakan darurat kemanusiaan musyawarah pengurus.'
      ],
      keyPoints: ['Toleransi 1–3 Bulan', 'Fardhu Kifayah Tetap Diberikan Penuh', 'Pemotongan Tunggakan dari Santunan secara Musyawarah'],
      tags: ['tunggakan', 'toleransi', 'status aktif', 'dispensasi', 'potong santunan']
    },
    {
      number: 'Pasal 6 ART',
      title: 'Standar Operasional Prosedur (SOP) Pelayanan Kematian',
      chapter: 'BAB IV ART',
      chapterTitle: 'Standar Operasional Prosedur',
      type: 'ART',
      content: [
        'Langkah 1 (Pelaporan): Ahli waris / tetangga segera menghubungi Call Center / Satgas Siaga 24 Jam RKM MPP.',
        'Langkah 2 (Mobilisasi Logistik): Petugas Logistik mengantarkan keranda, kain kafan, dan memasang tenda duka serta kursi di rumah duka dalam waktu maksimal 60 menit.',
        'Langkah 3 (Pemandian & Pengafanan): Tim Fardhu Kifayah melaksanakan pemandian jenazah secara syar\'i, tertutup, menjaga aurat, dan mengafani.',
        'Langkah 4 (Broadcast Lelayu): Tim Humas merilis Pengumuman Lelayu Digital Resmi ke grup WhatsApp warga dan DKM Masjid.',
        'Langkah 5 (Sholat & Pemakaman): Pengantaran jenazah menggunakan mobil ambulance menuju Masjid untuk disholatkan dan dilanjutkan ke TPU Parung Panjang.',
        'Langkah 6 (Penyerahan Santunan): Penyerahan santunan uang duka kepada ahli waris beserta doa bersama.'
      ],
      keyPoints: ['Respon Cepat < 60 Menit', 'SOP Syar\'i Menjaga Aurat', 'Broadcast Lelayu Resmi'],
      tags: ['sop', 'alur kematian', 'respon 24 jam', 'lelayu', 'fardhu kifayah']
    },
    {
      number: 'Pasal 7 ART',
      title: 'Ketentuan Khusus: Jenazah Luar Kota & Warga Transit',
      chapter: 'BAB V ART',
      chapterTitle: 'Ketentuan Khusus',
      type: 'ART',
      content: [
        'Bagi anggota yang wafat dan pihak keluarga menghendaki pemakaman di luar kota/kampung halaman, RKM MPP tetap memfasilitasi pemandian, pengafanan, santunan duka penuh, dan subsidi biaya pengantaran armada ambulan sesuai jarak tempuh.',
        'Bagi warga Muslim di lingkungan Metro Parung Panjang yang belum terdaftar sebagai anggota resmi namun tertimpa musibah kematian, pengurus RKM MPP atas dasar kemanusiaan dan ukhuwah Islamiyah tetap membantu proses fardhu kifayah dengan biaya penggantian perlengkapan kafan & operasional ambulan secara musyawarah.'
      ],
      keyPoints: ['Fasilitasi Pemakaman Luar Kota', 'Bantuan Kemanusiaan Warga Non-Anggota'],
      tags: ['luar kota', 'kampung halaman', 'non anggota', 'warga transit', 'kemanusiaan']
    },
    {
      number: 'Pasal 8 ART',
      title: 'Peminjaman Inventaris & Sarana Duka',
      chapter: 'BAB VI ART',
      chapterTitle: 'Pengelolaan Aset',
      type: 'ART',
      content: [
        'Seluruh inventaris duka (tenda, kursi, sound system, keranda) diprioritaskan 100% untuk keperluan musibah kematian anggota tanpa dipungut biaya sewa sepeserpun.',
        'Peminjaman untuk keperluan kegiatan sosial lingkungan (pengajian, kerja bakti, rapat RT) diperbolehkan selama tidak bersamaan dengan peristiwa duka dan wajib mengajukan izin kepada Petugas Logistik.',
        'Peminjam bertanggung jawab menjaga kebersihan dan keutuhan barang yang dipinjam.'
      ],
      keyPoints: ['Prioritas Utama Kematian (Gratis)', 'Izin Resmi untuk Kegiatan Sosial'],
      tags: ['inventaris', 'pinjam tenda', 'kursi', 'sound system', 'aset']
    }
  ];

  const filteredArticles = ARTICLES_DATA.filter(item => {
    const matchesSearch = 
      item.number.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.content.some(c => c.toLowerCase().includes(searchQuery.toLowerCase())) ||
      item.tags.some(t => t.toLowerCase().includes(searchQuery.toLowerCase()));

    const matchesCategory = 
      selectedCategory === 'all' ? true :
      selectedCategory === 'AD' ? item.type === 'AD' :
      selectedCategory === 'ART' ? item.type === 'ART' :
      item.tags.includes(selectedCategory);

    return matchesSearch && matchesCategory;
  });

  // Calculate Benefit Simulation
  const getSimulationResult = () => {
    if (simFamilyStatus === 'Warga Non-Anggota') {
      return {
        eligible: false,
        badgeText: 'Bantuan Darurat Kemanusiaan',
        badgeColor: 'bg-amber-100 text-amber-800 border-amber-300',
        santunan: 0,
        kafan: 'Tersedia (Penggantian Biaya Bahan Syar\'i)',
        ambulan: 'Tersedia (Biaya BBM/Driver Swadaya)',
        tendaKursi: 'Tersedia (Prioritas setelah anggota)',
        pemakaman: 'Dibantu Koordinasi Penggalian Makam',
        notes: 'Sesuai Pasal 7 ART: Warga Muslim non-anggota tetap dibantu atas dasar ukhuwah & kemanusiaan.'
      };
    }

    if (!simIsPaidUp) {
      return {
        eligible: true,
        badgeText: 'Hak Penuh dengan Pemotongan Tunggakan',
        badgeColor: 'bg-teal-100 text-teal-800 border-teal-300',
        santunan: settings.deathBenefitAmount - (settings.duesAmount * 4),
        kafan: 'Gratis 100% (Paket Kain Kafan Lengkap & Tim Mandi)',
        ambulan: 'Gratis 100% (Ambulance Siaga 24 Jam)',
        tendaKursi: 'Gratis 100% (Tenda, Kursi, Sound System)',
        pemakaman: 'Gratis 100% (Gali Kubur, Papan Lahad & Nisan)',
        notes: 'Sesuai Pasal 5 ART: Layanan Fardhu Kifayah TIDAK BOLEH ditunda. Tunggakan iuran dipotong dari santunan duka.'
      };
    }

    return {
      eligible: true,
      badgeText: 'Hak Penuh Anggota Resmi (Fasilitas Utama)',
      badgeColor: 'bg-emerald-100 text-emerald-800 border-emerald-300',
      santunan: settings.deathBenefitAmount,
      kafan: 'Gratis 100% (Paket Kafan Lengkap Kualitas Terbaik)',
      ambulan: 'Gratis 100% (Ambulans Siaga 24 Jam ke TPU)',
      tendaKursi: 'Gratis 100% (Tenda 1-2 Plong, Kursi 50-100 unit)',
      pemakaman: 'Gratis 100% (Gali Kubur TPU + Papan Lahad)',
      notes: 'Sesuai Pasal 2 & 3 ART: Hak fardhu kifayah paripurna dan santunan uang duka tunai diserahkan langsung.'
    };
  };

  const simResult = getSimulationResult();

  return (
    <div className="space-y-6 pb-12 animate-fade-in">
      
      {/* Top Hero Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-emerald-950 to-slate-900 text-white rounded-3xl p-6 sm:p-8 shadow-xl relative overflow-hidden border border-emerald-700/40">
        <div className="absolute -right-12 -bottom-12 w-72 h-72 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-3 max-w-2xl">
            <div className="flex flex-wrap items-center gap-2">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-bold border border-emerald-500/30">
                <Scale className="w-3.5 h-3.5" />
                <span>Dokumen Regulasi Resmi Organisasi</span>
              </span>
              <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 text-xs font-extrabold border border-amber-500/30">
                <Calendar className="w-3.5 h-3.5" />
                <span>Periode Bakti 2024 – 2027</span>
              </span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white">
              AD / ART RKM METRO PARUNG PANJANG
            </h1>
            
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              Anggaran Dasar dan Anggaran Rumah Tangga (AD/ART) <strong>RKM MPP 2024–2027</strong> sebagai landasan hukum, 
              tata kelola fardhu kifayah, transparansi iuran kas, dan perlindungan sosial duka bagi seluruh warga Muslim Metro Parung Panjang.
            </p>

            <div className="flex flex-wrap items-center gap-3 pt-2 text-xs">
              <a
                href={PDF_URL}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold shadow-lg shadow-emerald-900/40 transition-all hover:scale-105"
              >
                <Download className="w-4 h-4" />
                <span>Buka / Unduh File PDF Asli</span>
                <ExternalLink className="w-3.5 h-3.5 ml-0.5" />
              </a>

              <button
                onClick={() => setActiveTab('pdf')}
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-emerald-300 font-semibold border border-slate-700 transition-all"
              >
                <BookOpen className="w-4 h-4" />
                <span>Pratinjau PDF di Aplikasi</span>
              </button>
            </div>
          </div>

          {/* Quick Stats / Summary Card */}
          <div className="bg-slate-800/80 backdrop-blur border border-slate-700/80 rounded-2xl p-5 text-xs space-y-3 shrink-0 lg:w-72">
            <div className="flex items-center justify-between border-b border-slate-700 pb-2">
              <span className="text-slate-400">Status Legalitas:</span>
              <span className="text-emerald-400 font-bold flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" /> Disahkan Musyawarah
              </span>
            </div>
            <div className="flex items-center justify-between border-b border-slate-700 pb-2">
              <span className="text-slate-400">Masa Berlaku:</span>
              <strong className="text-white">2024 – 2027 (3 Tahun)</strong>
            </div>
            <div className="flex items-center justify-between border-b border-slate-700 pb-2">
              <span className="text-slate-400">Iuran Wajib:</span>
              <strong className="text-emerald-300">{formatRupiah(settings.duesAmount)} / KK / Bln</strong>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-400">Santunan Kematian:</span>
              <strong className="text-amber-300">{formatRupiah(settings.deathBenefitAmount)}</strong>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none border-b border-slate-200">
        {[
          { id: 'ringkasan', label: 'Ringkasan & Poin Kunci', icon: Sparkles },
          { id: 'ad', label: 'Anggaran Dasar (AD)', icon: Scale },
          { id: 'art', label: 'Anggaran Rumah Tangga (ART)', icon: BookOpen },
          { id: 'sop', label: 'SOP Fardhu Kifayah 24 Jam', icon: HeartHandshake },
          { id: 'kalkulator', label: 'Kalkulator Hak & Santunan', icon: Coins },
          { id: 'struktur', label: 'Struktur Organisasi 2024-2027', icon: Users },
          { id: 'pdf', label: 'Dokumen PDF Asli', icon: FileText }
        ].map(tab => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs whitespace-nowrap transition-all ${
                isActive 
                  ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/20 ring-2 ring-emerald-500/20' 
                  : 'bg-white text-slate-600 hover:bg-slate-50 border border-slate-200'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* TAB 1: RINGKASAN & POIN KUNCI */}
      {activeTab === 'ringkasan' && (
        <div className="space-y-6">
          
          {/* 4 Pilar Utama AD/ART 2024-2027 */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm space-y-2">
              <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold">
                <HeartHandshake className="w-5 h-5" />
              </div>
              <h3 className="font-extrabold text-slate-900 text-sm">Fardhu Kifayah Paripurna</h3>
              <p className="text-xs text-slate-500 leading-relaxed">
                Pelayanan pengurusan jenazah 100% syar'i: kain kafan lengkap, tim pemandian ikhwan/akhwat, tenda, kursi, mobil ambulance, dan liang lahat.
              </p>
              <div className="text-[11px] text-emerald-700 font-semibold pt-1">
                Pasal 2 ART • Tanpa Biaya Tambahan
              </div>
            </div>

            <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm space-y-2">
              <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center font-bold">
                <Coins className="w-5 h-5" />
              </div>
              <h3 className="font-extrabold text-slate-900 text-sm">Santunan Uang Duka</h3>
              <p className="text-xs text-slate-500 leading-relaxed">
                Penyaluran dana kerohiman tunai sebesar <strong>{formatRupiah(settings.deathBenefitAmount)}</strong> langsung kepada ahli waris saat pemakaman.
              </p>
              <div className="text-[11px] text-amber-700 font-semibold pt-1">
                Pasal 3 ART • Pencairan Cepat
              </div>
            </div>

            <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm space-y-2">
              <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center font-bold">
                <Truck className="w-5 h-5" />
              </div>
              <h3 className="font-extrabold text-slate-900 text-sm">Armada Ambulance 24 Jam</h3>
              <p className="text-xs text-slate-500 leading-relaxed">
                Fasilitas mobil ambulance jenazah siaga penuh 24 jam untuk pengantaran rumah duka, masjid, dan TPU Parung Panjang.
              </p>
              <div className="text-[11px] text-blue-700 font-semibold pt-1">
                Pasal 2 & 7 ART • Driver Siaga
              </div>
            </div>

            <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm space-y-2">
              <div className="w-10 h-10 rounded-xl bg-purple-100 text-purple-700 flex items-center justify-center font-bold">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <h3 className="font-extrabold text-slate-900 text-sm">Transparansi Kas Digital</h3>
              <p className="text-xs text-slate-500 leading-relaxed">
                Iuran wajib <strong>{formatRupiah(settings.duesAmount)}/KK</strong> per bulan dicatat transparan, kuitansi otomatis via WhatsApp & laporan real-time.
              </p>
              <div className="text-[11px] text-purple-700 font-semibold pt-1">
                Pasal 4 ART • Audit Terbuka
              </div>
            </div>
          </div>

          {/* Tabel Hak dan Kewajiban Lengkap */}
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-4">
              <div>
                <h3 className="font-extrabold text-slate-900 text-base">Komparasi Hak & Kewajiban Warga (AD-ART 2024-2027)</h3>
                <p className="text-xs text-slate-500">Katalog hak layanan yang diperoleh warga terdaftar dan kewajiban anggota paguyuban.</p>
              </div>
              <span className="text-xs bg-emerald-100 text-emerald-800 font-bold px-3 py-1 rounded-full">
                Syar'i & Akuntabel
              </span>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              
              {/* Hak Anggota */}
              <div className="p-5 bg-emerald-50/50 rounded-2xl border border-emerald-100 space-y-3">
                <div className="flex items-center gap-2 text-emerald-800 font-extrabold text-sm">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>HAK ANGGOTA RKM MPP (Pasal 2 & 3 ART)</span>
                </div>
                <ul className="space-y-2.5 text-xs text-slate-700">
                  <li className="flex items-start gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-1.5 shrink-0" />
                    <span><strong>Pelayanan Pemulasaraan Penuh:</strong> Mandi jenazah syar'i, pengafanan, sholat jenazah, dan pemakaman di TPU.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-1.5 shrink-0" />
                    <span><strong>Kain Kafan & Obat-Obatan Duka:</strong> Kafan kualitas terbaik, sabun bidara, kapur barus, minyak wangi, kapas, cendana.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-1.5 shrink-0" />
                    <span><strong>Santunan Uang Duka:</strong> Bantuan tunai {formatRupiah(settings.deathBenefitAmount)} diserahkan kepada ahli waris.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-1.5 shrink-0" />
                    <span><strong>Armada Mobil Jenazah 24 Jam:</strong> Bebas biaya pengantaran dari rumah duka ke makam TPU Parung Panjang.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-1.5 shrink-0" />
                    <span><strong>Fasilitas Tenda & Kursi Takziah:</strong> Pemasangan tenda duka, kursi 50-100 unit, dan lampu darurat gratis.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-1.5 shrink-0" />
                    <span><strong>Pengumuman Berita Duka (Lelayu):</strong> Penerbitan selebaran dan broadcast digital WhatsApp ke seluruh grup warga.</span>
                  </li>
                </ul>
              </div>

              {/* Kewajiban Anggota */}
              <div className="p-5 bg-amber-50/50 rounded-2xl border border-amber-100 space-y-3">
                <div className="flex items-center gap-2 text-amber-900 font-extrabold text-sm">
                  <AlertCircle className="w-4 h-4 text-amber-600" />
                  <span>KEWAJIBAN ANGGOTA RKM MPP (Pasal 4 & 5 ART)</span>
                </div>
                <ul className="space-y-2.5 text-xs text-slate-700">
                  <li className="flex items-start gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-amber-500 mt-1.5 shrink-0" />
                    <span><strong>Membayar Iuran Wajib:</strong> {formatRupiah(settings.duesAmount)}/KK setiap bulan secara tertib melalui kolektor RT atau QRIS/Bank.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-amber-500 mt-1.5 shrink-0" />
                    <span><strong>Pembaruan Data Keluarga:</strong> Melaporkan perubahan anggota keluarga (kelahiran, kepindahan, penambahan anggota KK).</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-amber-500 mt-1.5 shrink-0" />
                    <span><strong>Menjaga Ukhuwah & Takziah:</strong> Berpartisipasi dalam takziah, sholat jenazah, dan mendoakan sesama warga yang wafat.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-amber-500 mt-1.5 shrink-0" />
                    <span><strong>Merawat Sarana Peminjaman:</strong> Menjaga kebersihan dan keutuhan barang inventaris yang dipinjam saat takziah.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-amber-500 mt-1.5 shrink-0" />
                    <span><strong>Mematuhi AD/ART:</strong> Menghormati keputusan musyawarah pengurus dan ketentuan syar'i pemulasaraan.</span>
                  </li>
                </ul>
              </div>

            </div>
          </div>

          {/* Quick FAQ / Kebijakan Khusus */}
          <div className="bg-slate-900 text-white rounded-3xl p-6 sm:p-8 space-y-4">
            <div className="flex items-center gap-2 text-emerald-400 font-extrabold text-sm">
              <Bookmark className="w-4 h-4" />
              <span>KETENTUAN KHUSUS & KEBIJAKAN DARURAT (ART BAB V)</span>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
              <div className="bg-slate-800/80 p-4 rounded-2xl border border-slate-700 space-y-1.5">
                <h4 className="font-bold text-emerald-300">Bagaimana Jika Menunggak Iuran?</h4>
                <p className="text-slate-300 text-[11px] leading-relaxed">
                  Sesuai Pasal 5 ART, pelayanan fardhu kifayah (kafan, ambulan, makam) <strong>TETAP DIBERIKAN 100%</strong>. 
                  Sisa tunggakan iuran akan dipotong dari santunan uang duka secara musyawarah tanpa memberatkan keluarga.
                </p>
              </div>

              <div className="bg-slate-800/80 p-4 rounded-2xl border border-slate-700 space-y-1.5">
                <h4 className="font-bold text-amber-300">Pemakaman Luar Kota / Kampung</h4>
                <p className="text-slate-300 text-[11px] leading-relaxed">
                  Sesuai Pasal 7 ART, jika jenazah dimakamkan di luar kota, RKM tetap memfasilitasi pemandian, pengafanan, 
                  santunan duka penuh, dan subsidi biaya pengantaran mobil ambulan.
                </p>
              </div>

              <div className="bg-slate-800/80 p-4 rounded-2xl border border-slate-700 space-y-1.5">
                <h4 className="font-bold text-blue-300">Warga Muslim Non-Anggota</h4>
                <p className="text-slate-300 text-[11px] leading-relaxed">
                  Atas dasar ukhuwah Islamiyah dan kemanusiaan, jenazah warga non-anggota tetap dibantu proses fardhu kifayahnya 
                  dengan penggantian biaya perlengkapan kain kafan & operasional ambulan secara musyawarah.
                </p>
              </div>
            </div>
          </div>

        </div>
      )}

      {/* TAB 2 & 3: PASAL-PASAL ANGGARAN DASAR (AD) & ANGGARAN RUMAH TANGGA (ART) */}
      {(activeTab === 'ad' || activeTab === 'art') && (
        <div className="space-y-6">
          
          {/* Search & Filter Bar */}
          <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="relative flex-1 w-full">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Cari pasal, topik (santunan, iuran, ambulan, fardhu kifayah, syarat anggota)..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs focus:ring-2 focus:ring-emerald-500 focus:bg-white"
              />
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="p-2 bg-slate-50 border border-slate-300 rounded-xl text-xs text-slate-700 font-semibold focus:ring-2 focus:ring-emerald-500"
              >
                <option value="all">Semua Kategori</option>
                <option value="AD">Hanya Anggaran Dasar (AD)</option>
                <option value="ART">Hanya Anggaran Rumah Tangga (ART)</option>
                <option value="santunan">Dana Santunan</option>
                <option value="iuran">Iuran & Keuangan</option>
                <option value="fardhu kifayah">Pemulasaraan & Makam</option>
                <option value="ambulan">Armada Ambulance</option>
                <option value="tunggakan">Ketentuan Tunggakan</option>
              </select>

              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="px-3 py-2 bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold hover:bg-slate-300"
                >
                  Reset
                </button>
              )}
            </div>
          </div>

          {/* List of Articles */}
          <div className="space-y-4">
            {filteredArticles
              .filter(item => activeTab === 'ad' ? item.type === 'AD' : item.type === 'ART')
              .map((article, idx) => (
                <div 
                  key={idx} 
                  className="bg-white rounded-2xl p-5 sm:p-6 border border-slate-200 shadow-sm space-y-3 hover:border-emerald-400 transition-all"
                >
                  <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 pb-3">
                    <div className="flex items-center gap-2">
                      <span className={`px-2.5 py-1 rounded-lg text-xs font-extrabold ${
                        article.type === 'AD' ? 'bg-indigo-100 text-indigo-800' : 'bg-emerald-100 text-emerald-800'
                      }`}>
                        {article.number}
                      </span>
                      <h3 className="font-extrabold text-slate-900 text-base">{article.title}</h3>
                    </div>
                    <span className="text-[11px] font-bold text-slate-400">
                      {article.chapterTitle}
                    </span>
                  </div>

                  {/* Content List */}
                  <div className="space-y-2 text-xs text-slate-700 leading-relaxed">
                    {article.content.map((point, pIdx) => (
                      <div key={pIdx} className="flex items-start gap-2.5">
                        <span className="font-bold text-emerald-700 shrink-0 mt-0.5">({pIdx + 1})</span>
                        <p>{point}</p>
                      </div>
                    ))}
                  </div>

                  {/* Highlights / Key Points */}
                  {article.keyPoints && (
                    <div className="bg-slate-50 rounded-xl p-3 border border-slate-200/80 flex flex-wrap items-center gap-2">
                      <span className="text-[10px] font-extrabold text-slate-500 uppercase tracking-wider">
                        Poin Kunci:
                      </span>
                      {article.keyPoints.map((kp, kpIdx) => (
                        <span 
                          key={kpIdx}
                          className="px-2 py-0.5 rounded-full bg-white text-emerald-800 border border-emerald-200 text-[11px] font-semibold"
                        >
                          {kp}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              ))}

            {filteredArticles.filter(item => activeTab === 'ad' ? item.type === 'AD' : item.type === 'ART').length === 0 && (
              <div className="text-center py-12 bg-white rounded-3xl border border-slate-200 p-6 space-y-3">
                <Search className="w-10 h-10 text-slate-300 mx-auto" />
                <h4 className="font-bold text-slate-700 text-sm">Tidak Ditemukan Pasal yang Sesuai</h4>
                <p className="text-xs text-slate-500">Coba gunakan kata kunci pencarian yang lain.</p>
              </div>
            )}
          </div>

        </div>
      )}

      {/* TAB 4: SOP FARDHU KIFAYAH 24 JAM */}
      {activeTab === 'sop' && (
        <div className="space-y-6">
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-6">
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-rose-100 text-rose-800 text-xs font-bold mb-2">
                <Clock className="w-3.5 h-3.5" />
                <span>Standar Operasional Prosedur 24 Jam</span>
              </div>
              <h2 className="text-xl font-extrabold text-slate-900">Alur Pelayanan Kematian Warga (SOP Fardhu Kifayah)</h2>
              <p className="text-xs text-slate-500 mt-1">
                Pedoman resmi satgas dan pengurus dalam merespon kabar duka hingga selesai prosesi pemakaman.
              </p>
            </div>

            {/* Stepper Visual */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              
              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2 relative">
                <div className="w-8 h-8 rounded-full bg-slate-900 text-white font-black text-xs flex items-center justify-center">
                  01
                </div>
                <h4 className="font-extrabold text-slate-900 text-sm">Laporan Berita Duka</h4>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Ahli waris atau tetangga melapor ke Satgas Siaga 24 Jam (<strong>{settings.contactCenter}</strong>) atau Ketua RT setempat.
                </p>
                <div className="text-[10px] text-emerald-700 font-bold">Respon: Seketika (0-15 Menit)</div>
              </div>

              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2 relative">
                <div className="w-8 h-8 rounded-full bg-slate-900 text-white font-black text-xs flex items-center justify-center">
                  02
                </div>
                <h4 className="font-extrabold text-slate-900 text-sm">Mobilisasi Logistik & Tenda</h4>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Tim Logistik mengantarkan keranda, kain kafan lengkap, memasang tenda duka (1-2 plong), kursi lipat, dan lampu penerangan.
                </p>
                <div className="text-[10px] text-emerald-700 font-bold">Target: &lt; 60 Menit di Lokasi</div>
              </div>

              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2 relative">
                <div className="w-8 h-8 rounded-full bg-slate-900 text-white font-black text-xs flex items-center justify-center">
                  03
                </div>
                <h4 className="font-extrabold text-slate-900 text-sm">Pemandian & Pengafanan</h4>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Tim Fardhu Kifayah (Ikhwan/Akhwat) memandikan jenazah secara syar'i, tertutup dari pandangan umum, dan mengafani dengan rapi.
                </p>
                <div className="text-[10px] text-emerald-700 font-bold">Syar'i & Menjaga Aib Jenazah</div>
              </div>

              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2 relative">
                <div className="w-8 h-8 rounded-full bg-slate-900 text-white font-black text-xs flex items-center justify-center">
                  04
                </div>
                <h4 className="font-extrabold text-slate-900 text-sm">Penerbitan Berita Lelayu</h4>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Tim Humas mempublikasikan poster lelayu digital ke seluruh grup warga WhatsApp dan pengumuman speaker Masjid DKM.
                </p>
                <div className="text-[10px] text-emerald-700 font-bold">Informasi Waktu & Lokasi Sholat</div>
              </div>

              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2 relative">
                <div className="w-8 h-8 rounded-full bg-slate-900 text-white font-black text-xs flex items-center justify-center">
                  05
                </div>
                <h4 className="font-extrabold text-slate-900 text-sm">Sholat Jenazah & Ambulan</h4>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Ambulan jenazah mengantar ke Masjid untuk disholatkan berjamaah, dilanjutkan pengantaran iring-iringan ke TPU Parung Panjang.
                </p>
                <div className="text-[10px] text-emerald-700 font-bold">Ambulans Siaga + Supir Resmi</div>
              </div>

              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2 relative">
                <div className="w-8 h-8 rounded-full bg-slate-900 text-white font-black text-xs flex items-center justify-center">
                  06
                </div>
                <h4 className="font-extrabold text-slate-900 text-sm">Pemakaman & Santunan Tunai</h4>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Penggalian liang lahat, pemakaman dengan papan lahad, dan penyerahan uang santunan duka {formatRupiah(settings.deathBenefitAmount)} ke ahli waris.
                </p>
                <div className="text-[10px] text-emerald-700 font-bold">Penyerahan Langsung Selesai Makam</div>
              </div>

            </div>
          </div>
        </div>
      )}

      {/* TAB 5: KALKULATOR HAK & SANTUNAN */}
      {activeTab === 'kalkulator' && (
        <div className="space-y-6">
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-6">
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 text-xs font-bold mb-2">
                <Scale className="w-3.5 h-3.5" />
                <span>Kalkulator Hak Sesuai AD/ART</span>
              </div>
              <h2 className="text-xl font-extrabold text-slate-900">Kalkulator Hak Fardhu Kifayah & Santunan Keluarga</h2>
              <p className="text-xs text-slate-500 mt-1">
                Periksa estimasi fasilitas dan nominal santunan duka yang berhak diterima berdasarkan status keaktifan keanggotaan.
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              
              {/* Input Form Controls */}
              <div className="space-y-4 bg-slate-50 p-5 rounded-2xl border border-slate-200">
                <h3 className="font-bold text-slate-800 text-sm border-b border-slate-200 pb-2">
                  Parameter Data Keluarga
                </h3>

                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Status Keanggotaan / Hubungan Keluarga:</label>
                  <select
                    value={simFamilyStatus}
                    onChange={(e) => setSimFamilyStatus(e.target.value as any)}
                    className="w-full p-2.5 bg-white border border-slate-300 rounded-xl text-xs font-semibold focus:ring-2 focus:ring-emerald-500"
                  >
                    <option value="Kepala Keluarga">Kepala Keluarga (Terdaftar dalam KK)</option>
                    <option value="Istri">Istri (Terdaftar dalam KK)</option>
                    <option value="Anak Kandung">Anak Kandung (Terdaftar dalam KK)</option>
                    <option value="Orang Tua Serumah">Orang Tua / Mertua (Tercantum dalam KK)</option>
                    <option value="Warga Non-Anggota">Warga Muslim Belum Terdaftar (Non-Anggota)</option>
                  </select>
                </div>

                {simFamilyStatus !== 'Warga Non-Anggota' && (
                  <>
                    <div>
                      <label className="text-xs font-bold text-slate-700 block mb-1">Status Iuran Bulanan:</label>
                      <div className="grid grid-cols-2 gap-2">
                        <button
                          type="button"
                          onClick={() => setSimIsPaidUp(true)}
                          className={`p-2.5 rounded-xl text-xs font-bold border transition-all ${
                            simIsPaidUp 
                              ? 'bg-emerald-600 text-white border-emerald-600 shadow-sm' 
                              : 'bg-white text-slate-600 border-slate-300'
                          }`}
                        >
                          Lunas / Tertib Rutin
                        </button>
                        <button
                          type="button"
                          onClick={() => setSimIsPaidUp(false)}
                          className={`p-2.5 rounded-xl text-xs font-bold border transition-all ${
                            !simIsPaidUp 
                              ? 'bg-amber-600 text-white border-amber-600 shadow-sm' 
                              : 'bg-white text-slate-600 border-slate-300'
                          }`}
                        >
                          Ada Tunggakan (1-4 Bln)
                        </button>
                      </div>
                    </div>

                    <div>
                      <label className="text-xs font-bold text-slate-700 block mb-1">
                        Lama Masa Keanggotaan: <strong>{simMonthsActive} Bulan</strong>
                      </label>
                      <input
                        type="range"
                        min="1"
                        max="36"
                        value={simMonthsActive}
                        onChange={(e) => setSimMonthsActive(Number(e.target.value))}
                        className="w-full accent-emerald-600"
                      />
                      <div className="flex justify-between text-[10px] text-slate-400 mt-1">
                        <span>1 Bulan</span>
                        <span>12 Bulan (1 Thn)</span>
                        <span>36 Bulan (3 Thn / 1 Periode)</span>
                      </div>
                    </div>
                  </>
                )}
              </div>

              {/* Simulation Result Output */}
              <div className="space-y-4 bg-white p-6 rounded-2xl border-2 border-emerald-600/30 shadow-md flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                    <span className="text-xs text-slate-500 font-semibold">Hasil Penilaian Hak AD/ART:</span>
                    <span className={`px-2.5 py-1 rounded-full text-xs font-extrabold border ${simResult.badgeColor}`}>
                      {simResult.badgeText}
                    </span>
                  </div>

                  <div className="my-4 p-4 bg-emerald-50 rounded-2xl border border-emerald-100 text-center">
                    <span className="text-xs text-slate-500 block">Estimasi Santunan Tunai Ahli Waris:</span>
                    <span className="text-2xl sm:text-3xl font-black text-emerald-900 tracking-tight">
                      {formatRupiah(simResult.santunan)}
                    </span>
                  </div>

                  <div className="space-y-2 text-xs">
                    <div className="flex items-center justify-between py-1 border-b border-slate-100">
                      <span className="text-slate-500">Perlengkapan Kain Kafan & Mandi:</span>
                      <strong className="text-slate-800">{simResult.kafan}</strong>
                    </div>
                    <div className="flex items-center justify-between py-1 border-b border-slate-100">
                      <span className="text-slate-500">Mobil Ambulans Jenazah 24 Jam:</span>
                      <strong className="text-slate-800">{simResult.ambulan}</strong>
                    </div>
                    <div className="flex items-center justify-between py-1 border-b border-slate-100">
                      <span className="text-slate-500">Tenda & Kursi Takziah Rumah:</span>
                      <strong className="text-slate-800">{simResult.tendaKursi}</strong>
                    </div>
                    <div className="flex items-center justify-between py-1">
                      <span className="text-slate-500">Liang Lahat & Papan Lahad TPU:</span>
                      <strong className="text-slate-800">{simResult.pemakaman}</strong>
                    </div>
                  </div>
                </div>

                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-[11px] text-slate-600">
                  <span className="font-bold text-slate-800">Catatan Regulasi:</span> {simResult.notes}
                </div>
              </div>

            </div>
          </div>
        </div>
      )}

      {/* TAB 6: STRUKTUR ORGANISASI 2024-2027 */}
      {activeTab === 'struktur' && (
        <div className="space-y-6">
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
              <div>
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-100 text-indigo-800 text-xs font-bold mb-2">
                  <Users className="w-3.5 h-3.5" />
                  <span>Susunan Pengurus Periode 2024 – 2027</span>
                </div>
                <h2 className="text-xl font-extrabold text-slate-900">Struktur Organisasi RKM Metro Parung Panjang</h2>
                <p className="text-xs text-slate-500">
                  Sesuai Surat Keputusan Musyawarah Anggota RKM MPP Masa Bakti 2024–2027.
                </p>
              </div>

              <div className="text-xs bg-slate-100 text-slate-700 font-bold px-3 py-1.5 rounded-xl border border-slate-200">
                Masa Bakti: 2024 – 2027
              </div>
            </div>

            {/* Hierarchical Structure Visual */}
            <div className="space-y-6">
              
              {/* Dewan Pembina / Penasehat */}
              <div className="text-center space-y-2">
                <span className="text-xs font-extrabold text-slate-500 uppercase tracking-wider">
                  DEWAN PEMBINA & PENASEHAT
                </span>
                <div className="max-w-md mx-auto bg-slate-900 text-white p-4 rounded-2xl shadow-md border border-slate-700">
                  <h4 className="font-extrabold text-sm text-emerald-400">Ketua DKM Masjid & Tokoh Masyarakat</h4>
                  <p className="text-xs text-slate-300">Pengawas Kebijakan & Pembina Fardhu Kifayah Syar'i</p>
                </div>
              </div>

              {/* Pengurus Harian */}
              <div className="space-y-2">
                <div className="text-center">
                  <span className="text-xs font-extrabold text-slate-500 uppercase tracking-wider">
                    PENGURUS HARIAN (PIMPINAN 2024–2027)
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="bg-emerald-50 border-2 border-emerald-500/40 rounded-2xl p-4 text-center space-y-1">
                    <span className="text-[10px] font-bold text-emerald-700 uppercase bg-emerald-100 px-2 py-0.5 rounded-full">
                      Ketua Paguyuban
                    </span>
                    <h4 className="font-extrabold text-slate-900 text-sm">{settings.chairmanName || 'Ustadz H. Ahmad Fauzi'}</h4>
                    <p className="text-xs text-slate-500">Penanggung Jawab Umum & Koordinator Fardhu Kifayah</p>
                  </div>

                  <div className="bg-blue-50 border-2 border-blue-500/40 rounded-2xl p-4 text-center space-y-1">
                    <span className="text-[10px] font-bold text-blue-700 uppercase bg-blue-100 px-2 py-0.5 rounded-full">
                      Sekretaris
                    </span>
                    <h4 className="font-extrabold text-slate-900 text-sm">{settings.secretaryName || 'M. Ridwan Syahputra'}</h4>
                    <p className="text-xs text-slate-500">Administrasi Warga, Kartu KK & Lelayu Digital</p>
                  </div>

                  <div className="bg-purple-50 border-2 border-purple-500/40 rounded-2xl p-4 text-center space-y-1">
                    <span className="text-[10px] font-bold text-purple-700 uppercase bg-purple-100 px-2 py-0.5 rounded-full">
                      Bendahara Kas
                    </span>
                    <h4 className="font-extrabold text-slate-900 text-sm">{settings.treasurerName || 'Hj. Siti Aminah'}</h4>
                    <p className="text-xs text-slate-500">Pengelolaan Kas, Iuran Bulanan & Santunan Duka</p>
                  </div>
                </div>
              </div>

              {/* Bidang-Bidang Teknis & Pelaksana Lapangan */}
              <div className="space-y-2">
                <div className="text-center">
                  <span className="text-xs font-extrabold text-slate-500 uppercase tracking-wider">
                    BIDANG PELAYANAN & SATGAS SIAGA
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-1 text-center">
                    <div className="w-8 h-8 rounded-lg bg-rose-100 text-rose-700 flex items-center justify-center mx-auto mb-1">
                      <HeartHandshake className="w-4 h-4" />
                    </div>
                    <h5 className="font-bold text-slate-900 text-xs">Bid. Pemulasaraan Jenazah</h5>
                    <p className="text-[11px] text-slate-500">Tim Pemandian Ikhwan & Akhwat, Pengafanan Syar'i</p>
                  </div>

                  <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-1 text-center">
                    <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center mx-auto mb-1">
                      <Truck className="w-4 h-4" />
                    </div>
                    <h5 className="font-bold text-slate-900 text-xs">Bid. Logistik & Armada</h5>
                    <p className="text-[11px] text-slate-500">Driver Ambulance 24 Jam, Tenda, Kursi & Sound</p>
                  </div>

                  <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-1 text-center">
                    <div className="w-8 h-8 rounded-lg bg-amber-100 text-amber-700 flex items-center justify-center mx-auto mb-1">
                      <Share2 className="w-4 h-4" />
                    </div>
                    <h5 className="font-bold text-slate-900 text-xs">Bid. Humas & Komunikasi</h5>
                    <p className="text-[11px] text-slate-500">Broadcast Lelayu, Takziah & Koordinasi DKM</p>
                  </div>

                  <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-1 text-center">
                    <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto mb-1">
                      <Users className="w-4 h-4" />
                    </div>
                    <h5 className="font-bold text-slate-900 text-xs">Koordinator Wilayah RT</h5>
                    <p className="text-[11px] text-slate-500">Kolektor Iuran RT 01-08 & Update Data Warga</p>
                  </div>
                </div>
              </div>

            </div>
          </div>
        </div>
      )}

      {/* TAB 7: DOKUMEN PDF ASLI (EMBED & LINK) */}
      {activeTab === 'pdf' && (
        <div className="space-y-6">
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h2 className="text-xl font-extrabold text-slate-900">Dokumen PDF Asli AD/ART RKM MPP 2024-2027</h2>
                <p className="text-xs text-slate-500">
                  File asli resmi: <code>AD-ART-RKM MPP New 2024-2027.pdf</code>
                </p>
              </div>

              <div className="flex items-center gap-2">
                <a
                  href={PDF_URL}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-sm transition-colors"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Buka di Google Drive Tab Baru</span>
                  <ExternalLink className="w-3 h-3 ml-1" />
                </a>
              </div>
            </div>

            {/* Embedded PDF iframe */}
            <div className="w-full h-[650px] rounded-2xl border border-slate-300 overflow-hidden bg-slate-100 shadow-inner">
              <iframe
                src={PDF_EMBED_URL}
                title="AD-ART-RKM MPP New 2024-2027 PDF"
                className="w-full h-full border-0"
                allow="autoplay"
              />
            </div>
            <p className="text-[11px] text-slate-400 text-center">
              Jika pratinjau di atas terhalang kebijakan browser pihak ketiga, silakan klik tombol hijau "Buka di Google Drive Tab Baru" di atas.
            </p>
          </div>
        </div>
      )}

    </div>
  );
};
