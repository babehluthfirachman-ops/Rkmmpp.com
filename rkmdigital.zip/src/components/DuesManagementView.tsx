import React, { useState } from 'react';
import { 
  CreditCard, 
  Search, 
  Filter, 
  CheckCircle2, 
  XCircle, 
  Printer, 
  Share2, 
  FileText, 
  Users, 
  Plus, 
  Calendar, 
  Download,
  Receipt,
  UserCheck,
  Check,
  ChevronRight,
  TrendingUp,
  Wallet,
  MessageSquare,
  Send,
  Phone,
  Copy,
  AlertCircle,
  FileSpreadsheet,
  BellRing,
  Sparkles,
  ShieldAlert,
  Clock,
  ExternalLink
} from 'lucide-react';
import { useRkm } from '../context/RkmContext';
import { formatRupiah, formatDateIndo, MONTH_NAMES, getMonthNameFromKey, calculateCitizenMonthlyDues, createWhatsAppUrl } from '../utils/formatters';
import { Citizen } from '../types';
import { exportDuesReportCsv } from '../utils/excelExport';

export const DuesManagementView: React.FC = () => {
  const { 
    citizens, 
    settings, 
    currentUser, 
    currentRole,
    processPayment, 
    openReceiptModal, 
    officers 
  } = useRkm();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedRt, setSelectedRt] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<'all' | 'unpaid' | 'paid'>('all');
  const [viewMode, setViewMode] = useState<'cashier' | 'matrix'>('cashier');

  // Selected citizen for cashier modal
  const [cashierCitizen, setCashierCitizen] = useState<Citizen | null>(null);
  const [selectedMonths, setSelectedMonths] = useState<string[]>([]);
  const [infaqAmount, setInfaqAmount] = useState<number>(0);
  const [paymentMethod, setPaymentMethod] = useState<'Tunai' | 'Transfer Bank' | 'QRIS'>('Tunai');
  const [collectorName, setCollectorName] = useState<string>(currentUser?.name || 'Petugas Lapangan');
  const [isProcessing, setIsProcessing] = useState(false);

  // WhatsApp Notification / Reminder Modal State
  const [waReminderCitizen, setWaReminderCitizen] = useState<Citizen | null>(null);
  const [waCustomMessage, setWaCustomMessage] = useState<string>('');
  const [waTargetPhone, setWaTargetPhone] = useState<string>('');
  const [copiedWa, setCopiedWa] = useState(false);
  const [notificationSentSuccess, setNotificationSentSuccess] = useState(false);

  // Automated Dues Reminder System State
  const [showAutoReminderModal, setShowAutoReminderModal] = useState(false);
  const [reminderTemplateType, setReminderTemplateType] = useState<'sopan' | 'jatuh_tempo' | 'kritis'>('sopan');
  const [reminderRtFilter, setReminderRtFilter] = useState<string>('all');
  const [reminderArrearsFilter, setReminderArrearsFilter] = useState<'all' | '1-month' | 'multiple-months' | 'critical'>('all');
  const [sentCitizenIds, setSentCitizenIds] = useState<Record<string, string>>({}); // citizenId -> timestamp
  const [copiedCitizenId, setCopiedCitizenId] = useState<string | null>(null);

  // Base list filtered by role isolation
  const visibleCitizens = citizens.filter(c => {
    // 1. Warga isolation: only see their own family
    if (currentRole === 'warga') {
      if (currentUser?.noKK && c.noKK === currentUser.noKK) return true;
      if (currentUser?.name && (c.headOfFamily.toLowerCase().includes(currentUser.name.toLowerCase()) || currentUser.name.toLowerCase().includes(c.headOfFamily.toLowerCase()))) return true;
      return false;
    }
    // 2. Koordinator isolation: only see members under their direct assignment or assigned blocks
    if (currentRole === 'koordinator') {
      const isAssignedDirectly = c.assignedCollectorId === currentUser?.id;
      const isAssignedBlock = Boolean(currentUser?.assignedBlocks && currentUser.assignedBlocks.length > 0 && currentUser.assignedBlocks.includes(c.block || ''));
      // Fallback: If no assigned blocks yet, allow matching RT
      const isAssignedRt = (!currentUser?.assignedBlocks || currentUser.assignedBlocks.length === 0) && (!c.assignedCollectorId) && c.rt === currentUser?.rt;
      return isAssignedDirectly || isAssignedBlock || isAssignedRt;
    }
    // 3. Superadmin, ketua, bendahara, petugas can view all
    return true;
  });

  // Filter citizens
  const filteredCitizens = visibleCitizens.filter(c => {
    const matchQuery = 
      c.headOfFamily.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.noKK.includes(searchQuery) ||
      c.nik.includes(searchQuery) ||
      c.address.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (c.block && c.block.toLowerCase().includes(searchQuery.toLowerCase()));
    
    const matchRt = selectedRt === 'all' || c.rt === selectedRt;
    
    // Check if paid current month (2026-08)
    const isPaidAug = c.monthlyDues['2026-08']?.paid;
    const matchStatus = 
      filterStatus === 'all' || 
      (filterStatus === 'paid' && isPaidAug) || 
      (filterStatus === 'unpaid' && !isPaidAug);

    return matchQuery && matchRt && matchStatus;
  });

  // Open cashier for a citizen
  const handleOpenCashier = (citizen: Citizen) => {
    setCashierCitizen(citizen);
    // Pre-select first unpaid month
    const firstUnpaid = Object.entries(citizen.monthlyDues)
      .find(([k, v]) => !v.paid && k.startsWith('2026'));
    if (firstUnpaid) {
      setSelectedMonths([firstUnpaid[0]]);
    } else {
      setSelectedMonths([]);
    }
    setInfaqAmount(0);
  };

  const handleToggleMonth = (mKey: string) => {
    setSelectedMonths(prev => 
      prev.includes(mKey) ? prev.filter(m => m !== mKey) : [...prev, mKey].sort()
    );
  };

  const handleQuickSelectMonths = (count: number) => {
    if (!cashierCitizen) return;
    const unpaidList = Object.entries(cashierCitizen.monthlyDues)
      .filter(([k, v]) => !(v as any).paid && k.startsWith('2026'))
      .map(([k]) => k);
    setSelectedMonths(unpaidList.slice(0, count));
  };

  const handleOpenWaReminder = (citizen: Citizen) => {
    setWaReminderCitizen(citizen);
    setWaTargetPhone(citizen.phone || '');
    setNotificationSentSuccess(false);

    const unpaid = Object.entries(citizen.monthlyDues)
      .filter(([k, v]) => !(v as any).paid && k.startsWith('2026'))
      .map(([k]) => getMonthNameFromKey(k));
    
    const duesPerMonth = calculateCitizenMonthlyDues(citizen, settings.baseDuesAmount || settings.duesAmount || 5000, settings.extraMemberDuesAmount || 3000).totalMonthlyDues;
    const totalTagihan = unpaid.length * duesPerMonth;

    const message = 
`*PEMBERITAHUAN IURAN RKM MPP*
_${settings.orgName} - ${settings.village}_
────────────────────────────
Assalamu'alaikum Wr. Wb.
Yth. Bapak/Ibu *${citizen.headOfFamily}* (RT ${citizen.rt} / RW ${citizen.rw})

Berikut kami sampaikan rekapitulasi iuran kematian Paguyuban RKM MPP untuk keluarga Anda:

• *No. KK:* ${citizen.noKK}
• *Jumlah Tertanggung:* ${citizen.members.length} Jiwa
• *Tarif Iuran:* ${formatRupiah(duesPerMonth)} / Bulan
• *Bulan Belum Terbayar (2026):*
  ${unpaid.length > 0 ? unpaid.join(', ') : 'Tidak ada (Lunas Semua Bulan)'}
• *Total Tagihan:* *${formatRupiah(totalTagihan)}* (${unpaid.length} Bulan)

*PILIHAN REKENING PEMBAYARAN RESMI:*
• *${settings.bankName}:* \`${settings.bankAccount}\` (a.n. ${settings.bankHolder})
• *QRIS Kas Paguyuban:* Tersedia di pos sekretariat & kuitansi digital.
• *Petugas Tagih RT:* Hubungi Bendahara RT atau Petugas Satgas RKM.

Setelah melakukan pembayaran, mohon konfirmasi bukti transfer via WhatsApp ke nomor pengurus: ${settings.waAdmin}

_Jazaakumullahu khairan katsiran atas partisipasi Anda dalam menjaga dana sosial fardhu kifayah kematian warga._`;

    setWaCustomMessage(message);
  };

  const handleSendWhatsAppNotification = () => {
    if (!waCustomMessage) return;
    const targetPhone = waTargetPhone || waReminderCitizen?.phone || settings.waAdmin;
    const url = createWhatsAppUrl(targetPhone, waCustomMessage);
    window.open(url, '_blank');
    setNotificationSentSuccess(true);
    setTimeout(() => {
      setNotificationSentSuccess(false);
    }, 4000);
  };

  const handleCopyWaMessage = () => {
    navigator.clipboard.writeText(waCustomMessage);
    setCopiedWa(true);
    setTimeout(() => setCopiedWa(false), 2500);
  };

  // Helper generator for automated reminders by template
  const generateReminderMessage = (c: Citizen, template: 'sopan' | 'jatuh_tempo' | 'kritis') => {
    const unpaid = Object.entries(c.monthlyDues)
      .filter(([k, v]) => !(v as any).paid && k.startsWith('2026'))
      .map(([k]) => getMonthNameFromKey(k));

    const bRate = settings.baseDuesAmount || settings.duesAmount || 5000;
    const eRate = settings.extraMemberDuesAmount || 3000;
    const { totalMonthlyDues } = calculateCitizenMonthlyDues(c, bRate, eRate);
    const totalTagihan = unpaid.length * totalMonthlyDues;

    if (template === 'kritis') {
      return `*PERINGATAN TUNGGAKAN IURAN KAS RKM MPP*
_${settings.orgName} - ${settings.village}_
────────────────────────────
Assalamu'alaikum Wr. Wb.
Yth. Bapak/Ibu *${c.headOfFamily}* (RT ${c.rt} / RW ${c.rw})
Alamat: ${c.address}

Kami menginformasikan bahwa kepesertaan rukun kematian keluarga Anda tercatat menunggak *${unpaid.length} bulan berturut-turut* pada tahun 2026:
• *Bulan Menunggak:* ${unpaid.join(', ')}
• *Jumlah Jiwa Tertanggung:* ${c.members.length} Jiwa
• *Total Kewajiban:* *${formatRupiah(totalTagihan)}*

⚠️ *Pemberitahuan Hak Santunan:*
Sesuai ketentuan AD/ART Paguyuban RKM MPP, warga dengan tunggakan lebih dari 3 bulan berstatus masa tenggang penangguhan santunan duka. Mohon segera menyelesaikan iuran agar kepesertaan keluarga Anda tetap aktif dan terlindungi.

*Rekening Pembayaran Resmi:*
• *${settings.bankName}:* \`${settings.bankAccount}\` (a.n. ${settings.bankHolder})
• *QRIS Kas / Tunai:* Melalui Pengurus RT / Bendahara RKM

Konfirmasi transfer via WA: ${settings.waAdmin}
Terima kasih atas perhatian dan kerjasamanya.`;
    }

    if (template === 'jatuh_tempo') {
      return `*PENGINGAT JATUH TEMPO IURAN RKM MPP*
_${settings.orgName}_
────────────────────────────
Assalamu'alaikum Wr. Wb.
Yth. Bapak/Ibu *${c.headOfFamily}* (RT ${c.rt} / RW ${c.rw})

Mengingatkan kembali bahwa iuran kas rukun kematian untuk bulan berjalan telah memasuki masa jatuh tempo:
• *Bulan Belum Lunas:* ${unpaid.join(', ')}
• *Tarif Iuran Bulanan:* ${formatRupiah(totalMonthlyDues)} / Bulan
• *Total Tagihan:* *${formatRupiah(totalTagihan)}* (${unpaid.length} Bulan)

*Pilihan Pembayaran:*
• *${settings.bankName}:* \`${settings.bankAccount}\` (a.n. ${settings.bankHolder})
• *QRIS Kas / Petugas RT:* Hubungi pengurus RT Anda.

Konfirmasi bukti setor ke: ${settings.waAdmin}
Semoga Allah SWT senantiasa memberikan keberkahan dan kesehatan bagi keluarga Anda. Aamiin.`;
    }

    // Default 'sopan'
    return `*PEMBERITAHUAN IURAN RKM MPP*
_${settings.orgName} - ${settings.village}_
────────────────────────────
Assalamu'alaikum Wr. Wb.
Yth. Bapak/Ibu *${c.headOfFamily}* (RT ${c.rt} / RW ${c.rw})

Berikut kami sampaikan ringkasan iuran kepesertaan Rukun Kematian (RKM MPP) untuk keluarga Anda:
• *No. KK:* ${c.noKK}
• *Jumlah Tertanggung:* ${c.members.length} Jiwa
• *Tarif Bulanan:* ${formatRupiah(totalMonthlyDues)} / Bulan
• *Bulan Belum Terbayar:* ${unpaid.length > 0 ? unpaid.join(', ') : 'Lunas'}
• *Total Tagihan:* *${formatRupiah(totalTagihan)}* (${unpaid.length} Bulan)

*PILIHAN REKENING PEMBAYARAN:*
• *${settings.bankName}:* \`${settings.bankAccount}\` (a.n. ${settings.bankHolder})
• *QRIS Kas Paguyuban / Kolektif RT:* Tersedia di pos sekretariat.

Konfirmasi bukti transfer ke nomor pengurus: ${settings.waAdmin}
_Jazaakumullahu khairan katsiran atas partisipasi Anda dalam menjaga dana sosial fardhu kifayah kematian warga._`;
  };

  const handleSendQuickReminder = (c: Citizen) => {
    const msg = generateReminderMessage(c, reminderTemplateType);
    const phone = c.phone || settings.waAdmin;
    const url = createWhatsAppUrl(phone, msg);
    window.open(url, '_blank');
    setSentCitizenIds(prev => ({
      ...prev,
      [c.id]: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })
    }));
  };

  const handleCopyCitizenReminder = (c: Citizen) => {
    const msg = generateReminderMessage(c, reminderTemplateType);
    navigator.clipboard.writeText(msg);
    setCopiedCitizenId(c.id);
    setTimeout(() => setCopiedCitizenId(null), 2500);
  };

  const baseRate = settings.baseDuesAmount || settings.duesAmount || 5000;
  const extraRate = settings.extraMemberDuesAmount || 3000;
  const cashierCitizenRate = cashierCitizen ? calculateCitizenMonthlyDues(cashierCitizen, baseRate, extraRate).totalMonthlyDues : baseRate;

  const duesTotal = selectedMonths.length * cashierCitizenRate;
  const grandTotal = duesTotal + (Number(infaqAmount) || 0);

  const handleProcessPayment = () => {
    if (!cashierCitizen || selectedMonths.length === 0) return;

    setIsProcessing(true);
    setTimeout(() => {
      processPayment({
        noKK: cashierCitizen.noKK,
        months: selectedMonths,
        infaqAmount: Number(infaqAmount) || 0,
        paymentMethod,
        collector: collectorName
      });
      setIsProcessing(false);
      setCashierCitizen(null);
    }, 500);
  };

  // Summary statistics
  const totalCollectedAugust = citizens.reduce((acc, c) => {
    const p = c.monthlyDues['2026-08'];
    return p?.paid ? acc + p.amount : acc;
  }, 0);

  const totalUnpaidAugust = citizens.filter(c => !c.monthlyDues['2026-08']?.paid).length;

  return (
    <div className="space-y-6 pb-12 animate-fade-in">
      
      {/* Header & Mode Switcher */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200/80 dark:border-slate-800 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400 rounded-xl">
              <CreditCard className="w-5 h-5" />
            </span>
            <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white">Kasir & Manajemen Iuran Warga</h1>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Penagihan iuran bulanan, verifikasi transfer/QRIS, kuitansi digital, dan matriks kepatuhan.
          </p>
        </div>

        {/* View mode toggle */}
        <div className="flex items-center bg-slate-100 dark:bg-slate-800 p-1.5 rounded-2xl border border-slate-200 dark:border-slate-700 self-start md:self-auto">
          <button
            onClick={() => setViewMode('cashier')}
            className={`px-4 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer ${
              viewMode === 'cashier' 
                ? 'bg-emerald-600 text-white shadow-md' 
                : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Kasir Cepat (POS)
          </button>
          <button
            onClick={() => setViewMode('matrix')}
            className={`px-4 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer ${
              viewMode === 'matrix' 
                ? 'bg-emerald-600 text-white shadow-md' 
                : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Matriks 12 Bulan (Jan-Des)
          </button>
        </div>
      </div>

      {/* Quick Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/60 p-4 sm:p-5 rounded-2xl shadow-xs">
          <span className="text-xs font-bold text-emerald-800 dark:text-emerald-300 uppercase tracking-wider">Terkumpul Bulan Ini (Agu)</span>
          <div className="text-xl sm:text-2xl font-black text-emerald-950 dark:text-emerald-100 font-mono mt-1">
            {formatRupiah(totalCollectedAugust)}
          </div>
          <p className="text-[11px] text-emerald-700 dark:text-emerald-400 mt-0.5">
            {citizens.filter(c => c.monthlyDues['2026-08']?.paid).length} dari {citizens.length} KK Lunas
          </p>
        </div>

        <div className="bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800/60 p-4 sm:p-5 rounded-2xl shadow-xs">
          <span className="text-xs font-bold text-rose-800 dark:text-rose-300 uppercase tracking-wider">Tunggakan Bulan Ini</span>
          <div className="text-xl sm:text-2xl font-black text-rose-950 dark:text-rose-100 font-mono mt-1">
            {totalUnpaidAugust} KK Belum Bayar
          </div>
          <p className="text-[11px] text-rose-700 dark:text-rose-400 mt-0.5">
            Potensi kas masuk: {formatRupiah(totalUnpaidAugust * settings.duesAmount)}
          </p>
        </div>

        <div className="bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-800/60 p-4 sm:p-5 rounded-2xl shadow-xs">
          <span className="text-xs font-bold text-indigo-800 dark:text-indigo-300 uppercase tracking-wider">Tarif Resmi Iuran</span>
          <div className="text-xl sm:text-2xl font-black text-indigo-950 dark:text-indigo-100 font-mono mt-1">
            {formatRupiah(settings.duesAmount)} / KK / Bulan
          </div>
          <p className="text-[11px] text-indigo-700 dark:text-indigo-400 mt-0.5">
            Hak santunan: {formatRupiah(settings.deathBenefitAmount)}
          </p>
        </div>
      </div>

      {/* Search & Filter Toolbar */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-sm flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-2 flex-1 min-w-[280px]">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Cari kepala keluarga / No. KK / NIK..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full h-10 pl-9 pr-3 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white placeholder:text-slate-400 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
            />
          </div>

          <select
            value={selectedRt}
            onChange={(e) => setSelectedRt(e.target.value)}
            className="h-10 px-3 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl font-semibold text-slate-700 dark:text-slate-200 cursor-pointer focus:outline-none focus:ring-2 focus:ring-emerald-500"
          >
            <option value="all">Semua RT (RT 01-06)</option>
            <option value="01">RT 01</option>
            <option value="02">RT 02</option>
            <option value="03">RT 03</option>
            <option value="04">RT 04</option>
            <option value="05">RT 05</option>
            <option value="06">RT 06</option>
          </select>

          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value as any)}
            className="h-10 px-3 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl font-semibold text-slate-700 dark:text-slate-200 cursor-pointer focus:outline-none focus:ring-2 focus:ring-emerald-500"
          >
            <option value="all">Semua Status Iuran</option>
            <option value="unpaid">Menunggak Bulan Ini (Agu)</option>
            <option value="paid">Sudah Lunas Bulan Ini</option>
          </select>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Automated WhatsApp Dues Reminder System Button */}
          {currentRole !== 'warga' && (
            <button
              onClick={() => setShowAutoReminderModal(true)}
              id="btn-open-auto-reminder-modal"
              className="h-10 flex items-center gap-2 px-3.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-sm transition-all active:scale-95 cursor-pointer"
              title="Sistem Pengingat Iuran Otomatis via WhatsApp untuk Warga Belum Bayar"
            >
              <BellRing className="w-4 h-4 text-emerald-200 animate-bounce" />
              <span>Pengingat Otomatis (WA)</span>
              {totalUnpaidAugust > 0 && (
                <span className="px-1.5 py-0.5 bg-emerald-800 text-emerald-100 text-[10px] rounded-full font-black">
                  {totalUnpaidAugust} KK
                </span>
              )}
            </button>
          )}

          {/* Unduh Laporan Iuran Excel / CSV */}
          <button
            onClick={() => {
              exportDuesReportCsv(citizens, '2026-08', settings);
            }}
            id="btn-export-excel-dues"
            className="h-10 flex items-center gap-1.5 px-3.5 bg-emerald-50 dark:bg-emerald-950/40 hover:bg-emerald-100 dark:hover:bg-emerald-900/60 text-emerald-900 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-700/60 rounded-xl text-xs font-bold transition-all active:scale-95 cursor-pointer shadow-xs"
            title="Unduh Rekap Laporan Iuran Warga dalam Format Excel / CSV"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-700 dark:text-emerald-400" />
            <span>Unduh Excel / CSV</span>
          </button>

          <button
            onClick={() => window.print()}
            className="h-10 flex items-center gap-1.5 px-3.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold transition-all active:scale-95 cursor-pointer"
          >
            <Printer className="w-4 h-4" />
            <span>Cetak Rekap</span>
          </button>
        </div>
      </div>

      {/* Main View Mode: CASHIER (POS) or MATRIX */}
      {viewMode === 'cashier' ? (
        /* Cashier Card List */
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredCitizens.map((citizen) => {
            const unpaid2026 = Object.entries(citizen.monthlyDues)
              .filter(([k, v]) => !(v as any).paid && k.startsWith('2026'))
              .map(([k]) => k);
            
            const isPaidAugust = (citizen.monthlyDues['2026-08'] as any)?.paid;

            return (
              <div 
                key={citizen.id}
                className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-5 shadow-sm hover:shadow-md transition-all flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <span className="text-[10px] font-bold px-2 py-0.5 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-full border border-slate-200/60 dark:border-slate-700/60">
                        RT {citizen.rt} / RW {citizen.rw}
                      </span>
                      <h3 className="font-extrabold text-sm sm:text-base text-slate-900 dark:text-white mt-1">
                        {citizen.headOfFamily}
                      </h3>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400 font-mono">
                        KK: {citizen.noKK}
                      </p>
                    </div>

                    <span className={`text-[11px] font-bold px-2.5 py-1 rounded-lg ${
                      isPaidAugust 
                        ? 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 border border-emerald-200/60 dark:border-emerald-800/60' 
                        : 'bg-rose-100 dark:bg-rose-950/60 text-rose-800 dark:text-rose-300 border border-rose-200/60 dark:border-rose-900/60'
                    }`}>
                      {isPaidAugust ? 'Agu Lunas' : 'Belum Bayar'}
                    </span>
                  </div>

                  <div className="mt-3 text-xs text-slate-600 dark:text-slate-300 space-y-1">
                    <p className="truncate">📍 {citizen.address}</p>
                    <p>👥 {citizen.members.length} Jiwa Tertanggung</p>
                  </div>

                  {/* Unpaid Badge summary */}
                  <div className="mt-3 pt-3 border-t border-slate-100 dark:border-slate-800">
                    <span className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider block mb-1">
                      Status Tunggakan 2026:
                    </span>
                    {unpaid2026.length === 0 ? (
                      <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        Lunas Sepanjang Tahun 2026
                      </span>
                    ) : (
                      <span className="text-xs font-semibold text-rose-600 dark:text-rose-400">
                        {unpaid2026.length} Bulan Belum Bayar ({unpaid2026.slice(0, 3).map(m => getMonthNameFromKey(m).split(' ')[0]).join(', ')}{unpaid2026.length > 3 ? '...' : ''})
                      </span>
                    )}
                  </div>
                </div>

                {/* Cashier Action */}
                <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex gap-2">
                  <button
                    onClick={() => handleOpenCashier(citizen)}
                    className="flex-1 py-2 bg-emerald-600 hover:bg-emerald-700 active:scale-98 text-white text-xs font-bold rounded-xl shadow-sm transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <CreditCard className="w-3.5 h-3.5" />
                    <span>Catat Bayar</span>
                  </button>

                  <button
                    onClick={() => handleOpenWaReminder(citizen)}
                    className="p-2 bg-emerald-50 dark:bg-emerald-950/40 hover:bg-emerald-100 dark:hover:bg-emerald-900/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800/60 rounded-xl text-xs font-semibold transition-all flex items-center gap-1 cursor-pointer"
                    title="Kirim Notifikasi / Tagihan WhatsApp"
                  >
                    <MessageSquare className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                    <span className="hidden sm:inline text-[11px] font-bold">WA</span>
                  </button>

                  <button
                    onClick={() => {
                      // find latest receipt
                      const paidMonths = Object.values(citizen.monthlyDues).filter(m => (m as any).paid) as any[];
                      const latest = paidMonths[paidMonths.length - 1];
                      if (latest) {
                        openReceiptModal({
                          receiptNo: latest.receiptNo || 'RKM-2026',
                          citizen,
                          monthsPaid: ['2026-08'],
                          duesAmount: latest.amount,
                          infaqAmount: 0,
                          totalAmount: latest.amount,
                          date: latest.paidAt || '2026-08-01',
                          paymentMethod: latest.paymentMethod || 'Tunai',
                          collector: latest.collector || 'Petugas'
                        });
                      } else {
                        alert('Warga ini belum memiliki riwayat pembayaran lunas.');
                      }
                    }}
                    className="p-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold transition-all cursor-pointer"
                    title="Lihat Kuitansi Terakhir"
                  >
                    <Receipt className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        /* Full 12-Month Matrix Table */
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-900 dark:bg-slate-950 text-white font-bold">
                  <th className="p-3 sticky left-0 bg-slate-900 dark:bg-slate-950 z-10">Kepala Keluarga / RT</th>
                  {MONTH_NAMES.map(m => (
                    <th key={m.key} className="p-2.5 text-center min-w-[65px] text-[11px] font-bold">
                      {m.short}
                    </th>
                  ))}
                  <th className="p-3 text-center">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {filteredCitizens.map((citizen) => (
                  <tr key={citizen.id} className="hover:bg-slate-50/70 dark:hover:bg-slate-800/60 transition-colors">
                    <td className="p-3 sticky left-0 bg-white dark:bg-slate-900 font-semibold text-slate-900 dark:text-white border-r border-slate-100 dark:border-slate-800 shadow-[2px_0_5px_-2px_rgba(0,0,0,0.05)]">
                      <div className="font-bold text-slate-900 dark:text-white">{citizen.headOfFamily}</div>
                      <div className="text-[10px] text-slate-500 dark:text-slate-400 font-mono">RT {citizen.rt} • KK: {citizen.noKK}</div>
                    </td>

                    {MONTH_NAMES.map(m => {
                      const monthKey = `2026-${m.key}`;
                      const payment = citizen.monthlyDues[monthKey];
                      const isPaid = payment?.paid;

                      return (
                        <td key={m.key} className="p-1.5 text-center">
                          {isPaid ? (
                            <button
                              onClick={() => {
                                openReceiptModal({
                                  receiptNo: payment.receiptNo || 'RKM-2026',
                                  citizen,
                                  monthsPaid: [monthKey],
                                  duesAmount: payment.amount,
                                  infaqAmount: 0,
                                  totalAmount: payment.amount,
                                  date: payment.paidAt || '2026-08-01',
                                  paymentMethod: payment.paymentMethod || 'Tunai',
                                  collector: payment.collector || 'Petugas'
                                });
                              }}
                              className="w-full py-1.5 px-1 bg-emerald-100 dark:bg-emerald-950/60 hover:bg-emerald-200 dark:hover:bg-emerald-900/80 text-emerald-800 dark:text-emerald-300 font-bold rounded-lg text-[10px] transition-colors cursor-pointer border border-emerald-200/60 dark:border-emerald-800/60"
                              title={`Lunas (${payment.receiptNo}) - Klik lihat kuitansi`}
                            >
                              ✓
                            </button>
                          ) : (
                            <button
                              onClick={() => {
                                setCashierCitizen(citizen);
                                setSelectedMonths([monthKey]);
                              }}
                              className="w-full py-1.5 px-1 bg-rose-50 dark:bg-rose-950/30 hover:bg-rose-100 dark:hover:bg-rose-900/50 text-rose-600 dark:text-rose-400 font-bold rounded-lg text-[10px] transition-colors cursor-pointer border border-rose-200/60 dark:border-rose-900/60"
                              title="Belum Bayar - Klik untuk bayar"
                            >
                              -
                            </button>
                          )}
                        </td>
                      );
                    })}

                    <td className="p-2.5 text-center">
                      <div className="flex items-center justify-center gap-1.5">
                        <button
                          onClick={() => handleOpenCashier(citizen)}
                          className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[10px] rounded-lg transition-all cursor-pointer"
                        >
                          Bayar
                        </button>
                        <button
                          onClick={() => handleOpenWaReminder(citizen)}
                          className="p-1 bg-emerald-50 dark:bg-emerald-950/40 hover:bg-emerald-100 dark:hover:bg-emerald-900/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800/60 rounded-lg transition-all cursor-pointer"
                          title="Kirim Notifikasi WhatsApp"
                        >
                          <MessageSquare className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* WhatsApp Reminder & Notification Modal */}
      {waReminderCitizen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-sm animate-fade-in">
          <div className="bg-white rounded-3xl p-6 max-w-lg w-full shadow-2xl border border-slate-100 max-h-[90vh] overflow-y-auto">
            
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-emerald-100 text-emerald-700 rounded-2xl">
                  <MessageSquare className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[10px] font-extrabold text-emerald-700 uppercase tracking-widest bg-emerald-50 px-2 py-0.5 rounded">
                    GATEWAY WHATSAPP RESMI
                  </span>
                  <h3 className="text-base font-extrabold text-slate-900 mt-0.5">
                    Kirim Notifikasi Iuran Warga
                  </h3>
                </div>
              </div>

              <button
                onClick={() => setWaReminderCitizen(null)}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100"
              >
                ✕
              </button>
            </div>

            {/* Target Citizen Info */}
            <div className="my-4 p-3.5 bg-slate-50 rounded-2xl border border-slate-200/80 text-xs space-y-1">
              <div className="flex items-center justify-between">
                <span className="text-slate-500 font-medium">Nama Kepala Keluarga:</span>
                <span className="font-bold text-slate-900">{waReminderCitizen.headOfFamily}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-500 font-medium">Wilayah:</span>
                <span className="font-semibold text-slate-800">RT {waReminderCitizen.rt} / RW {waReminderCitizen.rw}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-500 font-medium">Nomor WhatsApp Tujuan:</span>
                <div className="flex items-center gap-2">
                  <Phone className="w-3.5 h-3.5 text-emerald-600" />
                  <input
                    type="text"
                    value={waTargetPhone}
                    onChange={(e) => setWaTargetPhone(e.target.value)}
                    placeholder="Contoh: 08123456789"
                    className="p-1 px-2 border border-slate-300 rounded-lg text-xs font-mono font-bold text-slate-800 w-36"
                  />
                </div>
              </div>
            </div>

            {/* Custom Message Editor / Preview */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-slate-700">
                  Pratinjau Pesan WhatsApp:
                </label>
                <button
                  type="button"
                  onClick={handleCopyWaMessage}
                  className="text-[11px] font-bold text-emerald-700 hover:text-emerald-800 flex items-center gap-1"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>{copiedWa ? 'Tersalin!' : 'Salin Teks'}</span>
                </button>
              </div>

              <textarea
                rows={9}
                value={waCustomMessage}
                onChange={(e) => setWaCustomMessage(e.target.value)}
                className="w-full p-3 bg-slate-900 text-emerald-400 font-mono text-[11px] rounded-2xl border border-slate-800 focus:ring-2 focus:ring-emerald-500 leading-relaxed shadow-inner"
              />
            </div>

            {/* Feedback Alert */}
            {notificationSentSuccess && (
              <div className="mt-3 p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs flex items-center gap-2 font-medium animate-fade-in">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>WhatsApp berhasil dibuka! Pesan siap dikirimkan kepada warga.</span>
              </div>
            )}

            {/* Modal Actions */}
            <div className="mt-5 pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setWaReminderCitizen(null)}
                className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl"
              >
                Tutup
              </button>

              <button
                type="button"
                onClick={handleSendWhatsAppNotification}
                className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white font-extrabold text-xs rounded-xl shadow-md transition-all flex items-center gap-2"
              >
                <Send className="w-4 h-4" />
                <span>Kirim via WhatsApp</span>
              </button>
            </div>

          </div>
        </div>
      )}

      {/* Cashier Payment Modal Drawer */}
      {cashierCitizen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-sm animate-fade-in">
          <div className="bg-white rounded-3xl p-6 max-w-xl w-full shadow-2xl border border-slate-100 max-h-[90vh] overflow-y-auto">
            
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div>
                <span className="text-[10px] font-extrabold text-emerald-700 uppercase tracking-widest bg-emerald-50 px-2 py-0.5 rounded">
                  KASIR PENAGIHAN IURAN
                </span>
                <h3 className="text-lg font-extrabold text-slate-900 mt-1">
                  {cashierCitizen.headOfFamily}
                </h3>
                <p className="text-xs text-slate-500 font-mono">
                  No. KK: {cashierCitizen.noKK} • RT {cashierCitizen.rt} / RW {cashierCitizen.rw}
                </p>
              </div>

              <button
                onClick={() => setCashierCitizen(null)}
                className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg"
              >
                ✕
              </button>
            </div>

            {/* Select Months */}
            <div className="my-4">
              <div className="flex items-center justify-between mb-2">
                <label className="text-xs font-bold text-slate-800">
                  Pilih Bulan yang Ingin Dibayar (Tahun 2026):
                </label>
                <div className="flex gap-1.5">
                  <button
                    type="button"
                    onClick={() => handleQuickSelectMonths(1)}
                    className="text-[10px] px-2 py-0.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded font-semibold"
                  >
                    1 Bulan
                  </button>
                  <button
                    type="button"
                    onClick={() => handleQuickSelectMonths(3)}
                    className="text-[10px] px-2 py-0.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded font-semibold"
                  >
                    3 Bulan
                  </button>
                  <button
                    type="button"
                    onClick={() => handleQuickSelectMonths(12)}
                    className="text-[10px] px-2 py-0.5 bg-emerald-100 hover:bg-emerald-200 text-emerald-800 rounded font-bold"
                  >
                    1 Tahun Penuh
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
                {MONTH_NAMES.map(m => {
                  const mKey = `2026-${m.key}`;
                  const isPaid = cashierCitizen.monthlyDues[mKey]?.paid;
                  const isSelected = selectedMonths.includes(mKey);

                  return (
                    <button
                      key={m.key}
                      type="button"
                      disabled={isPaid}
                      onClick={() => handleToggleMonth(mKey)}
                      className={`p-2 rounded-xl text-xs font-semibold text-center border transition-all ${
                        isPaid
                          ? 'bg-slate-100 text-slate-400 border-slate-200 cursor-not-allowed'
                          : isSelected
                          ? 'bg-emerald-600 text-white border-emerald-700 shadow-sm font-bold'
                          : 'bg-white text-slate-700 border-slate-300 hover:border-slate-400'
                      }`}
                    >
                      <div>{m.name}</div>
                      <div className="text-[10px] mt-0.5 font-normal">
                        {isPaid ? '✓ Lunas' : formatRupiah(cashierCitizenRate)}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Infaq & Collector Options */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div>
                <label className="text-slate-700 font-bold block mb-1">
                  Infaq / Donasi Kas Kematian:
                </label>
                <input
                  type="number"
                  placeholder="Rp 0"
                  value={infaqAmount || ''}
                  onChange={(e) => setInfaqAmount(Number(e.target.value) || 0)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 font-mono font-bold"
                />
              </div>

              <div>
                <label className="text-slate-700 font-bold block mb-1">
                  Petugas Penerima:
                </label>
                <select
                  value={collectorName}
                  onChange={(e) => setCollectorName(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-semibold text-slate-800"
                >
                  {officers.map(of => (
                    <option key={of.id} value={of.name}>{of.name} ({of.role})</option>
                  ))}
                </select>
              </div>
            </div>

            {/* Payment Method Selector */}
            <div className="mt-3">
              <label className="text-slate-700 font-bold text-xs block mb-1">
                Metode Pembayaran:
              </label>
              <div className="grid grid-cols-3 gap-2">
                {(['Tunai', 'Transfer Bank', 'QRIS'] as const).map(met => (
                  <button
                    key={met}
                    type="button"
                    onClick={() => setPaymentMethod(met)}
                    className={`py-2 px-3 rounded-xl text-xs font-bold border transition-all ${
                      paymentMethod === met
                        ? 'bg-emerald-700 text-white border-emerald-800 shadow'
                        : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
                    }`}
                  >
                    {met}
                  </button>
                ))}
              </div>
            </div>

            {/* Checkout Grand Total & Submit */}
            <div className="mt-5 p-4 bg-emerald-50 rounded-2xl border border-emerald-200 flex flex-col sm:flex-row items-center justify-between gap-3">
              <div>
                <span className="text-[10px] uppercase font-bold text-emerald-800">
                  Total Bayar ({selectedMonths.length} Bulan + Infaq)
                </span>
                <div className="text-2xl font-black text-emerald-950 font-mono">
                  {formatRupiah(grandTotal)}
                </div>
              </div>

              <div className="flex gap-2 w-full sm:w-auto">
                <button
                  type="button"
                  onClick={() => setCashierCitizen(null)}
                  className="flex-1 sm:flex-none px-4 py-2.5 bg-white hover:bg-slate-100 text-slate-700 font-bold text-xs rounded-xl border border-slate-300 cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="button"
                  disabled={selectedMonths.length === 0 || isProcessing}
                  onClick={handleProcessPayment}
                  className="flex-1 sm:flex-none px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-extrabold text-xs rounded-xl shadow-md transition-all active:scale-95 cursor-pointer"
                >
                  {isProcessing ? 'Menyimpan...' : 'Cetak & Terbitkan Kuitansi &rarr;'}
                </button>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL: SISTEM PENGINGAT IURAN OTOMATIS & BROADCAST WHATSAPP */}
      {/* ========================================================================= */}
      {showAutoReminderModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/80 backdrop-blur-sm animate-fade-in">
          <div className="bg-white rounded-3xl max-w-4xl w-full shadow-2xl border border-slate-100 max-h-[92vh] flex flex-col overflow-hidden">
            
            {/* Modal Header */}
            <div className="p-5 sm:p-6 bg-gradient-to-r from-emerald-900 via-teal-900 to-slate-900 text-white flex items-start justify-between gap-4">
              <div className="flex items-start gap-3">
                <div className="p-2.5 bg-emerald-500/20 text-emerald-300 rounded-2xl border border-emerald-500/30 shrink-0">
                  <BellRing className="w-6 h-6 animate-pulse" />
                </div>
                <div>
                  <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-bold border border-emerald-500/30">
                    <Sparkles className="w-3 h-3" />
                    <span>SISTEM PENGINGAT OTOMATIS WHATSAPP</span>
                  </div>
                  <h3 className="text-lg sm:text-xl font-black mt-1">
                    Pengingat Iuran Warga Belum Bayar
                  </h3>
                  <p className="text-xs text-slate-300 mt-0.5">
                    Kirim pesan WhatsApp tagihan dengan rincian bulan tunggakan, nomor rekening, dan tarif fardhu kifayah secara terpersonalisasi.
                  </p>
                </div>
              </div>

              <button
                onClick={() => setShowAutoReminderModal(false)}
                className="p-2 text-slate-300 hover:text-white hover:bg-white/10 rounded-xl transition-all cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* Template Selector & Filters Toolbar */}
            <div className="p-4 bg-slate-50 border-b border-slate-200/80 space-y-3">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                <div className="flex-1 w-full sm:w-auto">
                  <label className="text-[11px] font-bold text-slate-700 uppercase tracking-wider block mb-1">
                    Pilih Template Pesan WhatsApp:
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    <button
                      type="button"
                      onClick={() => setReminderTemplateType('sopan')}
                      className={`px-3 py-2 rounded-xl text-xs font-bold border transition-all text-left flex items-center gap-1.5 ${
                        reminderTemplateType === 'sopan'
                          ? 'bg-emerald-700 text-white border-emerald-800 shadow-xs'
                          : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-100'
                      }`}
                    >
                      <span>💬 Sopan & Santun</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setReminderTemplateType('jatuh_tempo')}
                      className={`px-3 py-2 rounded-xl text-xs font-bold border transition-all text-left flex items-center gap-1.5 ${
                        reminderTemplateType === 'jatuh_tempo'
                          ? 'bg-amber-600 text-white border-amber-700 shadow-xs'
                          : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-100'
                      }`}
                    >
                      <Clock className="w-3.5 h-3.5" />
                      <span>⏰ Jatuh Tempo</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setReminderTemplateType('kritis')}
                      className={`px-3 py-2 rounded-xl text-xs font-bold border transition-all text-left flex items-center gap-1.5 ${
                        reminderTemplateType === 'kritis'
                          ? 'bg-rose-700 text-white border-rose-800 shadow-xs'
                          : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-100'
                      }`}
                    >
                      <ShieldAlert className="w-3.5 h-3.5" />
                      <span>⚠️ Tunggakan &gt;3 Bln</span>
                    </button>
                  </div>
                </div>

                <div className="flex items-center gap-2 self-end sm:self-auto">
                  {/* RT Filter */}
                  <div>
                    <label className="text-[10px] font-bold text-slate-500 block mb-0.5">Filter Wilayah RT:</label>
                    <select
                      value={reminderRtFilter}
                      onChange={(e) => setReminderRtFilter(e.target.value)}
                      className="py-1.5 px-2.5 text-xs bg-white border border-slate-300 rounded-xl font-semibold text-slate-700"
                    >
                      <option value="all">Semua RT</option>
                      <option value="01">RT 01</option>
                      <option value="02">RT 02</option>
                      <option value="03">RT 03</option>
                      <option value="04">RT 04</option>
                      <option value="05">RT 05</option>
                      <option value="06">RT 06</option>
                    </select>
                  </div>

                  {/* Arrears Filter */}
                  <div>
                    <label className="text-[10px] font-bold text-slate-500 block mb-0.5">Rentang Tunggakan:</label>
                    <select
                      value={reminderArrearsFilter}
                      onChange={(e) => setReminderArrearsFilter(e.target.value as any)}
                      className="py-1.5 px-2.5 text-xs bg-white border border-slate-300 rounded-xl font-semibold text-slate-700"
                    >
                      <option value="all">Semua Belum Bayar</option>
                      <option value="1-month">1 Bulan Saja</option>
                      <option value="multiple-months">2 - 3 Bulan</option>
                      <option value="critical">&gt; 3 Bulan (Kritis)</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Summary Metrics Bar */}
              {(() => {
                const targetUnpaidList = visibleCitizens.filter(c => {
                  const unpaidList = Object.entries(c.monthlyDues)
                    .filter(([k, v]) => !(v as any).paid && k.startsWith('2026'))
                    .map(([k]) => k);
                  
                  if (unpaidList.length === 0) return false;
                  if (reminderRtFilter !== 'all' && c.rt !== reminderRtFilter) return false;

                  if (reminderArrearsFilter === '1-month' && unpaidList.length !== 1) return false;
                  if (reminderArrearsFilter === 'multiple-months' && (unpaidList.length < 2 || unpaidList.length > 3)) return false;
                  if (reminderArrearsFilter === 'critical' && unpaidList.length <= 3) return false;

                  return true;
                });

                const totalPotential = targetUnpaidList.reduce((sum, c) => {
                  const unpaidCount = Object.entries(c.monthlyDues)
                    .filter(([k, v]) => !(v as any).paid && k.startsWith('2026')).length;
                  const { totalMonthlyDues } = calculateCitizenMonthlyDues(
                    c,
                    settings.baseDuesAmount || settings.duesAmount || 5000,
                    settings.extraMemberDuesAmount || 3000
                  );
                  return sum + (unpaidCount * totalMonthlyDues);
                }, 0);

                const sentCount = targetUnpaidList.filter(c => sentCitizenIds[c.id]).length;

                return (
                  <div className="flex flex-wrap items-center justify-between gap-2 p-2.5 bg-white rounded-xl border border-slate-200 text-xs">
                    <div className="flex items-center gap-4">
                      <span>🎯 <strong>{targetUnpaidList.length} KK</strong> Terpilih Belum Bayar</span>
                      <span>💰 Potensi Kas: <strong className="font-mono text-emerald-700">{formatRupiah(totalPotential)}</strong></span>
                      <span>✅ Terkirim Sesi Ini: <strong className="text-emerald-700">{sentCount} KK</strong></span>
                    </div>

                    <button
                      onClick={() => {
                        exportDuesReportCsv(targetUnpaidList, '2026-08', settings);
                      }}
                      className="flex items-center gap-1 text-[11px] font-bold text-emerald-800 hover:text-emerald-950 px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 rounded-lg border border-emerald-200 transition-all cursor-pointer"
                      title="Unduh Daftar Warga Belum Bayar yang Terfilter ke File CSV/Excel"
                    >
                      <FileSpreadsheet className="w-3.5 h-3.5" />
                      <span>Unduh Daftar Ini (Excel/CSV)</span>
                    </button>
                  </div>
                );
              })()}
            </div>

            {/* Scrollable Citizen List */}
            <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-3">
              {(() => {
                const targetUnpaidList = visibleCitizens.filter(c => {
                  const unpaidList = Object.entries(c.monthlyDues)
                    .filter(([k, v]) => !(v as any).paid && k.startsWith('2026'))
                    .map(([k]) => k);
                  
                  if (unpaidList.length === 0) return false;
                  if (reminderRtFilter !== 'all' && c.rt !== reminderRtFilter) return false;

                  if (reminderArrearsFilter === '1-month' && unpaidList.length !== 1) return false;
                  if (reminderArrearsFilter === 'multiple-months' && (unpaidList.length < 2 || unpaidList.length > 3)) return false;
                  if (reminderArrearsFilter === 'critical' && unpaidList.length <= 3) return false;

                  return true;
                });

                if (targetUnpaidList.length === 0) {
                  return (
                    <div className="text-center py-12 text-slate-400 space-y-2">
                      <CheckCircle2 className="w-12 h-12 text-emerald-500 mx-auto" />
                      <p className="font-extrabold text-sm text-slate-700">Semua Warga pada Kriteria Ini Telah Lunas!</p>
                      <p className="text-xs text-slate-500">Tidak ada tunggakan iuran yang memerlukan pengingat WhatsApp.</p>
                    </div>
                  );
                }

                return targetUnpaidList.map(c => {
                  const unpaidMonths = Object.entries(c.monthlyDues)
                    .filter(([k, v]) => !(v as any).paid && k.startsWith('2026'))
                    .map(([k]) => k);

                  const { totalMonthlyDues } = calculateCitizenMonthlyDues(
                    c,
                    settings.baseDuesAmount || settings.duesAmount || 5000,
                    settings.extraMemberDuesAmount || 3000
                  );
                  const totalTagihan = unpaidMonths.length * totalMonthlyDues;
                  const isSent = sentCitizenIds[c.id];
                  const isCritical = unpaidMonths.length > 3;

                  return (
                    <div 
                      key={c.id} 
                      className={`p-4 rounded-2xl border transition-all flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 ${
                        isSent
                          ? 'bg-emerald-50/50 border-emerald-200'
                          : isCritical
                          ? 'bg-rose-50/40 border-rose-200 hover:bg-rose-50/70'
                          : 'bg-white border-slate-200/90 hover:border-slate-300 shadow-xs'
                      }`}
                    >
                      <div className="space-y-1 flex-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <h4 className="font-black text-sm text-slate-900">
                            {c.headOfFamily}
                          </h4>
                          {c.block && (
                            <span className="text-[10px] font-black px-2 py-0.5 bg-emerald-100 text-emerald-900 rounded">
                              {c.block} {c.houseNumber || ''}
                            </span>
                          )}
                          <span className="text-[10px] font-bold px-2 py-0.5 bg-slate-100 text-slate-700 rounded">
                            RT {c.rt} / RW {c.rw}
                          </span>
                          <span className={`text-[10px] font-black px-2 py-0.5 rounded-full ${
                            isCritical ? 'bg-rose-600 text-white animate-pulse' : 'bg-rose-100 text-rose-800'
                          }`}>
                            Tunggak {unpaidMonths.length} Bulan
                          </span>

                          {isSent && (
                            <span className="text-[10px] font-bold px-2 py-0.5 bg-emerald-600 text-white rounded-full flex items-center gap-1">
                              <Check className="w-3 h-3" />
                              <span>Diingatkan pk {isSent}</span>
                            </span>
                          )}
                        </div>

                        <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 font-mono">
                          <span>KK: <strong>{c.noKK}</strong></span>
                          <span>•</span>
                          <span>📞 {c.phone || <span className="text-rose-500 font-sans italic font-bold">No. WA Belum Ada</span>}</span>
                          <span>•</span>
                          <span>Tertanggung: {c.members.length} Jiwa</span>
                        </div>

                        {/* Unpaid Month Badges */}
                        <div className="flex flex-wrap items-center gap-1 pt-1">
                          <span className="text-[10px] text-slate-400 font-semibold">Bulan:</span>
                          {unpaidMonths.map(m => (
                            <span key={m} className="text-[10px] font-bold px-1.5 py-0.5 bg-rose-50 text-rose-700 border border-rose-200 rounded">
                              {getMonthNameFromKey(m).split(' ')[0]}
                            </span>
                          ))}
                        </div>
                      </div>

                      {/* Right Tagihan & Action Buttons */}
                      <div className="flex sm:flex-col items-end justify-between w-full sm:w-auto gap-2 shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-100">
                        <div className="text-left sm:text-right">
                          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                            Total Tagihan
                          </span>
                          <span className="text-base font-black font-mono text-slate-900 block">
                            {formatRupiah(totalTagihan)}
                          </span>
                        </div>

                        <div className="flex items-center gap-1.5">
                          {/* Copy Message Button */}
                          <button
                            type="button"
                            onClick={() => handleCopyCitizenReminder(c)}
                            title="Salin Pesan WhatsApp untuk Warga Ini"
                            className="p-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1"
                          >
                            <Copy className="w-3.5 h-3.5" />
                            <span className="text-[11px]">{copiedCitizenId === c.id ? 'Tersalin!' : 'Salin'}</span>
                          </button>

                          {/* Quick Edit/Preview Modal Button */}
                          <button
                            type="button"
                            onClick={() => handleOpenWaReminder(c)}
                            title="Kustomisasi Teks / Ganti Nomor WA"
                            className="p-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition-all cursor-pointer"
                          >
                            <FileText className="w-3.5 h-3.5" />
                          </button>

                          {/* One-Click Send WhatsApp Button */}
                          <button
                            type="button"
                            onClick={() => handleSendQuickReminder(c)}
                            title="Buka WhatsApp & Kirim Pesan Otomatis"
                            className="px-3 py-2 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white font-bold text-xs rounded-xl shadow-xs transition-all flex items-center gap-1.5 cursor-pointer"
                          >
                            <Send className="w-3.5 h-3.5" />
                            <span>Kirim WA</span>
                          </button>
                        </div>
                      </div>

                    </div>
                  );
                });
              })()}
            </div>

            {/* Modal Footer */}
            <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between gap-3">
              <span className="text-xs text-slate-500 font-medium hidden sm:inline">
                💡 Tip: Klik <strong>Kirim WA</strong> untuk membuka WhatsApp Web/Aplikasi dengan teks tagihan otomatis siap kirim.
              </span>

              <button
                type="button"
                onClick={() => setShowAutoReminderModal(false)}
                className="px-5 py-2.5 bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold text-xs rounded-xl transition-all cursor-pointer ml-auto"
              >
                Selesai / Tutup
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
