import React, { useState, useEffect } from 'react';
import { 
  Bell, 
  BellRing, 
  AlertTriangle, 
  HeartHandshake, 
  Volume2, 
  VolumeX, 
  X, 
  ChevronRight, 
  ExternalLink,
  MessageSquare,
  ShieldAlert,
  CheckCircle2
} from 'lucide-react';
import { useRkm } from '../context/RkmContext';
import { formatDateIndo, formatRupiah } from '../utils/formatters';

interface DashboardAlertToastsProps {
  onNavigateTab?: (tab: string) => void;
  onOpenWhatsAppReminder?: () => void;
}

export const DashboardAlertToasts: React.FC<DashboardAlertToastsProps> = ({ 
  onNavigateTab,
  onOpenWhatsAppReminder
}) => {
  const { deathNotices, citizens, openLelayuModal } = useRkm();

  const [browserNotificationAllowed, setBrowserNotificationAllowed] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [dismissedAlerts, setDismissedAlerts] = useState<string[]>([]);
  const [minimized, setMinimized] = useState(false);

  // Play gentle alert tone using Web Audio API
  const playChime = (type: 'death' | 'dues') => {
    if (!soundEnabled) return;
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);

      if (type === 'death') {
        // Solemn deeper chime
        osc.frequency.setValueAtTime(440, ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(330, ctx.currentTime + 0.4);
      } else {
        // High alert double pip
        osc.frequency.setValueAtTime(587.33, ctx.currentTime);
        osc.frequency.setValueAtTime(880, ctx.currentTime + 0.15);
      }

      gain.gain.setValueAtTime(0.08, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.6);

      osc.start();
      osc.stop(ctx.currentTime + 0.6);
    } catch {}
  };

  // Check browser notification permission status on mount
  useEffect(() => {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      setBrowserNotificationAllowed(Notification.permission === 'granted');
    }
  }, []);

  // Request browser notification permission
  const requestNotificationPermission = async () => {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      try {
        const permission = await Notification.requestPermission();
        if (permission === 'granted') {
          setBrowserNotificationAllowed(true);
          new Notification('RKM MPP Digital', {
            body: 'Notifikasi browser berhasil diaktifkan! Anda akan menerima peringatan otomatis untuk laporan duka dan jatuh tempo iuran.',
            icon: '/favicon.ico'
          });
        }
      } catch (err) {
        console.error('Notification permission error:', err);
      }
    }
  };

  // Find most recent death notice (within last 14 days or active)
  const latestDeathNotice = React.useMemo(() => {
    if (!deathNotices || deathNotices.length === 0) return null;
    return deathNotices[0];
  }, [deathNotices]);

  // Find citizens with >3 unpaid months
  const criticalArrearsCitizens = React.useMemo(() => {
    const currentYear = new Date().getFullYear();
    const currentMonth = new Date().getMonth() + 1;

    return citizens.filter(c => {
      if (c.status === 'Pindah' || c.status === 'Non-Aktif') return false;
      let unpaidCount = 0;
      for (let m = 1; m <= currentMonth; m++) {
        const key = `${currentYear}-${m.toString().padStart(2, '0')}`;
        const payment = c.monthlyDues?.[key];
        if (!payment || payment.status === 'Belum Bayar') {
          unpaidCount++;
        }
      }
      return unpaidCount > 3;
    });
  }, [citizens]);

  // Trigger browser notification when a new alert condition arises
  useEffect(() => {
    if (browserNotificationAllowed && typeof window !== 'undefined' && 'Notification' in window) {
      if (latestDeathNotice && !dismissedAlerts.includes(`death-${latestDeathNotice.id}`)) {
        try {
          new Notification('🚨 Laporan Duka RKM MPP', {
            body: `Inna lillahi wa inna ilaihi raji'un. Telah berpulang Alm/Almh. ${latestDeathNotice.deceasedName} di RT ${latestDeathNotice.rt}. Tim Satgas Siaga 24 Jam.`,
            tag: `death-${latestDeathNotice.id}`
          });
        } catch {}
      }
    }
  }, [latestDeathNotice, browserNotificationAllowed, dismissedAlerts]);

  const dismissAlert = (id: string) => {
    setDismissedAlerts(prev => [...prev, id]);
  };

  const showDeathAlert = latestDeathNotice && !dismissedAlerts.includes(`death-${latestDeathNotice.id}`);
  const showArrearsAlert = criticalArrearsCitizens.length > 0 && !dismissedAlerts.includes('critical-arrears');

  if (!showDeathAlert && !showArrearsAlert) {
    return null;
  }

  return (
    <aside aria-label="Notifikasi dan Peringatan Sistem" className="mb-6 space-y-3">
      {/* Toast Bar Controls */}
      <div className="flex items-center justify-between px-1">
        <div className="flex items-center gap-2">
          <span className="flex h-2.5 w-2.5 relative">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75" />
            <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-rose-600" />
          </span>
          <h2 className="text-xs font-black uppercase tracking-wider text-slate-700">
            Sistem Peringatan Siaga & Jatuh Tempo (Live Alerts)
          </h2>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setSoundEnabled(!soundEnabled)}
            className="text-[11px] font-semibold text-slate-500 hover:text-slate-800 flex items-center gap-1 bg-white px-2.5 py-1 rounded-lg border border-slate-200"
            title={soundEnabled ? 'Matikan Suara Bel Notifikasi' : 'Aktifkan Suara Bel Notifikasi'}
          >
            {soundEnabled ? <Volume2 className="w-3.5 h-3.5 text-emerald-600" /> : <VolumeX className="w-3.5 h-3.5 text-slate-400" />}
            <span className="hidden sm:inline">{soundEnabled ? 'Bel Aktif' : 'Senyap'}</span>
          </button>

          {!browserNotificationAllowed && typeof window !== 'undefined' && 'Notification' in window && (
            <button
              onClick={requestNotificationPermission}
              className="text-[11px] font-bold text-emerald-700 hover:text-emerald-800 flex items-center gap-1 bg-emerald-50 hover:bg-emerald-100 px-2.5 py-1 rounded-lg border border-emerald-200 transition-colors cursor-pointer"
              title="Aktifkan notifikasi desktop browser"
            >
              <BellRing className="w-3.5 h-3.5 text-emerald-600" />
              <span>Izinkan Notif Browser</span>
            </button>
          )}

          <button
            onClick={() => setMinimized(!minimized)}
            className="text-xs text-slate-500 hover:text-slate-800 font-bold px-2 py-1"
          >
            {minimized ? 'Tampilkan' : 'Sembunyikan'}
          </button>
        </div>
      </div>

      {!minimized && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
          {/* 1. Laporan Duka Baru Alert */}
          {showDeathAlert && latestDeathNotice && (
            <div className="bg-gradient-to-r from-rose-950 via-slate-900 to-slate-900 text-white p-4 rounded-2xl border border-rose-800/60 shadow-md flex items-start justify-between gap-3 relative overflow-hidden">
              <div className="flex items-start gap-3 relative z-10">
                <span className="p-2.5 bg-rose-600/30 text-rose-300 rounded-xl shrink-0 mt-0.5 border border-rose-500/30">
                  <ShieldAlert className="w-5 h-5 text-rose-400 animate-pulse" />
                </span>
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-[10px] font-black uppercase tracking-wider bg-rose-600 text-white px-2 py-0.5 rounded-md">
                      Laporan Duka Terkini
                    </span>
                    <span className="text-[11px] text-rose-200 font-medium">
                      {formatDateIndo(latestDeathNotice.deathDate)}
                    </span>
                  </div>

                  <h3 className="text-sm font-black text-white mt-1">
                    Alm/Almh. {latestDeathNotice.deceasedName} bin/binti {latestDeathNotice.binBinti}
                  </h3>
                  <p className="text-xs text-slate-300 mt-0.5 line-clamp-1">
                    Keluarga Bpk/Ibu {latestDeathNotice.contactPerson} • RT {latestDeathNotice.rt}/RW {latestDeathNotice.rw} • Santunan: {formatRupiah(latestDeathNotice.rkmAssistanceAmount)}
                  </p>

                  <div className="flex items-center gap-2 mt-2.5">
                    <button
                      onClick={() => openLelayuModal(latestDeathNotice)}
                      className="px-3 py-1 bg-white text-slate-950 text-xs font-bold rounded-lg hover:bg-slate-100 transition-all flex items-center gap-1 cursor-pointer"
                    >
                      <HeartHandshake className="w-3.5 h-3.5 text-rose-600" />
                      <span>Lihat Maklumat Lelayu</span>
                    </button>
                    {onNavigateTab && (
                      <button
                        onClick={() => onNavigateTab('layanan-duka')}
                        className="px-3 py-1 bg-white/10 hover:bg-white/20 text-xs font-bold text-white rounded-lg transition-all"
                      >
                        Posko Satgas & Piket
                      </button>
                    )}
                  </div>
                </div>
              </div>

              <button
                onClick={() => dismissAlert(`death-${latestDeathNotice.id}`)}
                className="text-slate-400 hover:text-white p-1 rounded-lg shrink-0 relative z-10"
                title="Tutup pemberitahuan ini"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* 2. Jatuh Tempo Iuran Warga (>3 Bulan) Alert */}
          {showArrearsAlert && (
            <div className="bg-gradient-to-r from-amber-50 via-white to-amber-50/40 p-4 rounded-2xl border border-amber-300 shadow-sm flex items-start justify-between gap-3 text-slate-800">
              <div className="flex items-start gap-3">
                <span className="p-2.5 bg-amber-500/20 text-amber-800 rounded-xl shrink-0 mt-0.5 border border-amber-300">
                  <AlertTriangle className="w-5 h-5 text-amber-600" />
                </span>
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-[10px] font-black uppercase tracking-wider bg-amber-600 text-white px-2 py-0.5 rounded-md">
                      Jatuh Tempo Iuran Kritis
                    </span>
                    <span className="text-[11px] font-bold text-amber-900">
                      {criticalArrearsCitizens.length} Kepala Keluarga
                    </span>
                  </div>

                  <h3 className="text-sm font-black text-slate-900 mt-1">
                    Warga Menunggak Lebih Dari 3 Bulan
                  </h3>
                  <p className="text-xs text-slate-600 mt-0.5">
                    Terdapat {criticalArrearsCitizens.length} KK warga berstatus menunggak kritis. Hubungi warga bersangkutan untuk rekonsiliasi iuran wajib.
                  </p>

                  <div className="flex items-center gap-2 mt-2.5">
                    {onNavigateTab && (
                      <button
                        onClick={() => onNavigateTab('warga')}
                        className="px-3 py-1 bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold rounded-lg transition-all flex items-center gap-1 cursor-pointer"
                      >
                        <span>Buka Direktori Warga</span>
                        <ChevronRight className="w-3.5 h-3.5" />
                      </button>
                    )}
                    {onOpenWhatsAppReminder && (
                      <button
                        onClick={onOpenWhatsAppReminder}
                        className="px-3 py-1 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-lg transition-all flex items-center gap-1 cursor-pointer"
                      >
                        <MessageSquare className="w-3.5 h-3.5" />
                        <span>Kirim WA Pengingat</span>
                      </button>
                    )}
                  </div>
                </div>
              </div>

              <button
                onClick={() => dismissAlert('critical-arrears')}
                className="text-slate-400 hover:text-slate-700 p-1 rounded-lg shrink-0"
                title="Tutup pemberitahuan ini"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      )}
    </aside>
  );
};
