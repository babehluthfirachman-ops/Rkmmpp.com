import React, { useState, useMemo } from 'react';
import { 
  Wallet, 
  TrendingUp, 
  TrendingDown, 
  Users, 
  CreditCard, 
  PlusCircle, 
  HeartHandshake, 
  Box, 
  ArrowUpRight, 
  ArrowDownRight, 
  ShieldCheck, 
  Calendar, 
  Clock, 
  Phone, 
  Sparkles, 
  FileText, 
  CheckCircle2, 
  AlertCircle,
  ExternalLink,
  ChevronRight,
  Scale,
  BarChart3,
  Filter,
  DollarSign,
  PieChart as PieIcon
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  LineChart,
  Line,
  AreaChart,
  Area,
  ComposedChart,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ReferenceLine,
  Cell
} from 'recharts';
import { useRkm } from '../context/RkmContext';
import { formatRupiah, formatDateIndo, formatDateTimeIndo, getDirectImageUrl, MONTH_NAMES, getMonthNameFromKey } from '../utils/formatters';
import { DashboardAlertToasts } from './DashboardAlertToasts';

interface DashboardViewProps {
  setActiveTab: (tab: string) => void;
}

interface CustomTooltipProps {
  active?: boolean;
  payload?: any[];
  chartYear: string;
  totalFamilies: number;
}

const CustomChartTooltip: React.FC<CustomTooltipProps> = ({ active, payload, chartYear, totalFamilies }) => {
  if (active && payload && payload.length) {
    const data = payload[0].payload;
    const isSurplus = data.netCashflow >= 0;
    return (
      <div className="bg-slate-900/95 backdrop-blur-md text-white p-4 rounded-2xl shadow-xl border border-slate-700 text-xs font-sans space-y-2.5 min-w-[260px]">
        <div className="flex items-center justify-between border-b border-slate-700 pb-2">
          <span className="font-bold text-sm text-emerald-400">
            {data.monthName} {chartYear}
          </span>
          <span className="text-[10px] bg-slate-800 text-slate-300 px-2 py-0.5 rounded-full font-semibold">
            {data.paidFamilies}/{totalFamilies} KK ({data.compliancePct}%)
          </span>
        </div>

        <div className="space-y-1.5 pt-0.5">
          {/* Total Cumulative Cash Balance Badge */}
          <div className="p-2 bg-indigo-950/70 border border-indigo-500/30 rounded-xl flex items-center justify-between">
            <span className="text-indigo-300 font-bold flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-indigo-400 inline-block" />
              Total Saldo Kas:
            </span>
            <span className="font-mono font-black text-indigo-200 text-sm">
              {formatRupiah(data.cumulativeBalance)}
            </span>
          </div>

          <div className="flex justify-between items-center text-slate-200 pt-1">
            <span className="flex items-center gap-1.5 text-emerald-400 font-semibold">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 inline-block" />
              Penerimaan Iuran:
            </span>
            <span className="font-mono font-bold text-white">
              +{formatRupiah(data.duesCollection)}
            </span>
          </div>

          <div className="flex justify-between items-center text-slate-200">
            <span className="flex items-center gap-1.5 text-rose-400 font-semibold">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500 inline-block" />
              Pengeluaran & Santunan:
            </span>
            <span className="font-mono font-bold text-white">
              -{formatRupiah(data.expenses)}
            </span>
          </div>

          <div className="pt-2 border-t border-slate-800 flex justify-between items-center">
            <span className="text-slate-400 font-medium">Surplus / Defisit Bulan:</span>
            <span className={`font-mono font-black ${isSurplus ? 'text-emerald-400' : 'text-rose-400'}`}>
              {isSurplus ? '+' : ''}{formatRupiah(data.netCashflow)}
            </span>
          </div>
        </div>
      </div>
    );
  }
  return null;
};

export const DashboardView: React.FC<DashboardViewProps> = ({ setActiveTab }) => {
  const { 
    currentUser, 
    currentRole, 
    citizens, 
    transactions, 
    deathNotices, 
    assets, 
    settings, 
    openLelayuModal, 
    openKtaModal,
    openReceiptModal 
  } = useRkm();

  const [chartYear, setChartYear] = useState<string>('2026');
  const [chartViewMode, setChartViewMode] = useState<'all-year' | 'last-6-months'>('all-year');
  const [chartMetricType, setChartMetricType] = useState<'combined' | 'balance' | 'comparison'>('combined');

  // Overall Financial Calculations
  const totalIn = transactions.filter(t => t.type === 'in').reduce((acc, t) => acc + t.amount, 0);
  const totalOut = transactions.filter(t => t.type === 'out').reduce((acc, t) => acc + t.amount, 0);
  const totalBalance = totalIn - totalOut;

  // Month stats (Agustus 2026)
  const currentMonthTxIn = transactions.filter(t => t.type === 'in' && t.date.startsWith('2026-08')).reduce((acc, t) => acc + t.amount, 0);
  const currentMonthTxOut = transactions.filter(t => t.type === 'out' && t.date.startsWith('2026-08')).reduce((acc, t) => acc + t.amount, 0);

  // Citizens stats
  const totalFamilies = citizens.length;
  const totalLives = citizens.reduce((acc, c) => acc + c.members.filter(m => m.status === 'Hidup').length, 0);

  // Compliance for current month (2026-08)
  const paidCountAug = citizens.filter(c => c.monthlyDues['2026-08']?.paid).length;
  const complianceRate = Math.round((paidCountAug / (totalFamilies || 1)) * 100);

  const activeLelayu = deathNotices.find(d => d.status === 'Aktif') || deathNotices[0];
  const recentTransactions = transactions.slice(0, 6);

  // RT breakdown
  const rtList = ['01', '02', '03', '04', '05', '06'];
  const rtStats = rtList.map(rtNum => {
    const famsInRt = citizens.filter(c => c.rt === rtNum);
    const paidInRt = famsInRt.filter(c => c.monthlyDues['2026-08']?.paid).length;
    const rate = famsInRt.length > 0 ? Math.round((paidInRt / famsInRt.length) * 100) : 0;
    return { rt: rtNum, total: famsInRt.length, paid: paidInRt, rate };
  });

  // Calculate monthly data for Recharts (Monthly dues collection vs. expenses)
  const monthlyChartData = useMemo(() => {
    const months = MONTH_NAMES.map(m => {
      const monthKey = `${chartYear}-${m.key}`;

      // Calculate dues collected from citizens database for this month
      const duesFromCitizens = citizens.reduce((sum, cit) => {
        const d = cit.monthlyDues?.[monthKey];
        return sum + (d?.paid ? (d.amount || 5000) : 0);
      }, 0);

      // Calculate transactions for this month
      const txInMonth = transactions.filter(t => t.date && t.date.startsWith(monthKey));
      
      const duesTxIn = txInMonth
        .filter(t => t.type === 'in' && t.category === 'Iuran Wajib')
        .reduce((sum, t) => sum + t.amount, 0);

      const otherIn = txInMonth
        .filter(t => t.type === 'in' && t.category !== 'Iuran Wajib')
        .reduce((sum, t) => sum + t.amount, 0);

      // Use max of citizen dues tally or transaction dues tally to ensure accurate visualization
      const duesCollected = Math.max(duesFromCitizens, duesTxIn);
      const totalIncome = duesCollected + otherIn;

      const totalExpenses = txInMonth
        .filter(t => t.type === 'out')
        .reduce((sum, t) => sum + t.amount, 0);

      const paidFamiliesCount = citizens.filter(c => c.monthlyDues?.[monthKey]?.paid).length;
      const netCashflow = totalIncome - totalExpenses;

      return {
        monthKey,
        monthName: m.name,
        monthShort: m.short,
        label: `${m.short} '${chartYear.slice(2)}`,
        duesCollection: duesCollected,
        otherIncome: otherIn,
        totalIncome,
        expenses: totalExpenses,
        netCashflow,
        paidFamilies: paidFamiliesCount,
        compliancePct: Math.round((paidFamiliesCount / (totalFamilies || 1)) * 100)
      };
    });

    // Compute running/cumulative total cash balance across months
    const priorTx = transactions.filter(t => t.date && t.date < `${chartYear}-01-01`);
    const priorIn = priorTx.filter(t => t.type === 'in').reduce((sum, t) => sum + t.amount, 0);
    const priorOut = priorTx.filter(t => t.type === 'out').reduce((sum, t) => sum + t.amount, 0);
    let runningBal = priorIn - priorOut;

    const monthsWithBalance = months.map(m => {
      runningBal += m.netCashflow;
      return {
        ...m,
        cumulativeBalance: runningBal
      };
    });

    if (chartViewMode === 'last-6-months') {
      return monthsWithBalance.slice(2, 8); // Mar to Aug
    }

    return monthsWithBalance;
  }, [citizens, transactions, chartYear, chartViewMode, totalFamilies]);

  // Aggregate stats for the chart header
  const chartSummary = useMemo(() => {
    const totalDues = monthlyChartData.reduce((acc, d) => acc + d.duesCollection, 0);
    const totalExp = monthlyChartData.reduce((acc, d) => acc + d.expenses, 0);
    const netTotal = totalDues - totalExp;
    const avgMonthlyDues = Math.round(totalDues / (monthlyChartData.length || 1));
    const avgMonthlyExp = Math.round(totalExp / (monthlyChartData.length || 1));

    return {
      totalDues,
      totalExp,
      netTotal,
      avgMonthlyDues,
      avgMonthlyExp
    };
  }, [monthlyChartData]);

  return (
    <div className="space-y-6 pb-12 animate-fade-in">
      
      {/* Toast Notifikasi Browser & Dashboard Jatuh Tempo Iuran / Berita Duka */}
      <DashboardAlertToasts onNavigateTab={setActiveTab} />

      {/* Welcome Banner */}
      <div className="bg-gradient-to-r from-emerald-900 via-teal-900 to-slate-900 text-white rounded-3xl p-6 sm:p-8 shadow-xl relative overflow-hidden border border-emerald-700/40">
        <div className="absolute -right-10 -bottom-10 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
            {settings.logoUrl && (
              <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-white p-1.5 shadow-lg shrink-0 border border-white/20 ring-4 ring-emerald-500/20">
                <img 
                  src={getDirectImageUrl(settings.logoUrl)} 
                  alt={settings.orgName}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-contain"
                />
              </div>
            )}
            <div className="space-y-1.5 max-w-xl">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-semibold border border-emerald-500/30">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Sistem Kas & Paguyuban Rukun Kematian Terpadu</span>
              </div>
              <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white">
                Assalamu'alaikum, {currentUser?.name || 'Warga'}
              </h1>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                Selamat datang di portal transparansi <strong>{settings.orgName}</strong>. 
                Pantau kas masuk, penyaluran santunan duka, kuitansi digital, dan status iuran secara real-time.
              </p>
            </div>
          </div>

          {/* Quick Buttons on Banner */}
          <div className="flex flex-wrap gap-2.5 shrink-0">
            <button
              onClick={() => setActiveTab(currentRole === 'warga' ? 'portal-warga' : 'iuran')}
              className="flex items-center gap-2 px-4 py-2.5 bg-emerald-500 hover:bg-emerald-600 active:scale-98 text-slate-950 font-bold text-xs sm:text-sm rounded-xl shadow-lg transition-all"
            >
              <CreditCard className="w-4 h-4" />
              <span>{currentRole === 'warga' ? 'Bayar Iuran Saya' : 'Kasir / Input Iuran'}</span>
            </button>

            <button
              onClick={() => setActiveTab('buku-kas')}
              className="flex items-center gap-2 px-4 py-2.5 bg-white/10 hover:bg-white/20 active:scale-98 text-white font-semibold text-xs sm:text-sm rounded-xl border border-white/20 transition-all"
            >
              <Wallet className="w-4 h-4 text-emerald-400" />
              <span>Laporan Kas Real-Time</span>
            </button>
          </div>
        </div>
      </div>

      {/* Widget Ringkasan Statistik Real-Time Khusus Pengurus */}
      {currentRole !== 'warga' && (
        <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200/90 shadow-sm space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2.5">
              <div className="p-2 bg-emerald-100 text-emerald-800 rounded-xl">
                <BarChart3 className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="font-extrabold text-base text-slate-900">Ringkasan Statistik Real-Time Pengurus</h2>
                  <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-100 text-emerald-800 animate-pulse">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-600" />
                    Live Sync
                  </span>
                </div>
                <p className="text-xs text-slate-500">
                  Ikhtisar cepat operasional dan akuntabilitas paguyuban RKM per hari ini.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setActiveTab('buku-kas')}
                className="px-3 py-1.5 text-xs font-bold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 rounded-xl transition-all"
              >
                Detail Kasir & Kas &rarr;
              </button>
              <button
                onClick={() => setActiveTab('warga')}
                className="px-3 py-1.5 text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition-all"
              >
                Data KK Warga &rarr;
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            
            {/* 1. Total Dana Terkumpul Bulan Ini */}
            <div className="p-4 rounded-2xl bg-gradient-to-br from-emerald-50 via-teal-50 to-white border border-emerald-200/70 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-emerald-950 uppercase tracking-wider">
                  Total Dana Terkumpul Bulan Ini
                </span>
                <div className="p-2 bg-emerald-600 text-white rounded-xl shadow-sm">
                  <TrendingUp className="w-4 h-4" />
                </div>
              </div>
              <div>
                <div className="text-2xl sm:text-3xl font-black text-emerald-950 tracking-tight">
                  {formatRupiah(currentMonthTxIn)}
                </div>
                <div className="flex items-center justify-between text-xs text-emerald-800 mt-1">
                  <span>Iuran & Infaq (Agu 2026)</span>
                  <span className="font-bold">{paidCountAug} KK telah lunas</span>
                </div>
              </div>
              {/* Progress bar */}
              <div className="w-full bg-emerald-200/60 rounded-full h-2 overflow-hidden">
                <div 
                  className="bg-emerald-600 h-2 rounded-full transition-all duration-500" 
                  style={{ width: `${Math.min(100, Math.max(5, Math.round((currentMonthTxIn / ((totalFamilies * (settings.duesAmount || 5000)) || 1)) * 100)))}%` }}
                />
              </div>
              <div className="flex justify-between text-[11px] text-slate-500 font-medium">
                <span>Target Iuran Pokok: {formatRupiah(totalFamilies * (settings.duesAmount || 5000))}</span>
                <span className="text-emerald-700 font-bold">
                  {Math.round((currentMonthTxIn / ((totalFamilies * (settings.duesAmount || 5000)) || 1)) * 100)}%
                </span>
              </div>
            </div>

            {/* 2. Jumlah Warga Aktif */}
            <div className="p-4 rounded-2xl bg-gradient-to-br from-blue-50 via-indigo-50 to-white border border-blue-200/70 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-blue-950 uppercase tracking-wider">
                  Jumlah Warga Aktif
                </span>
                <div className="p-2 bg-blue-600 text-white rounded-xl shadow-sm">
                  <Users className="w-4 h-4" />
                </div>
              </div>
              <div>
                <div className="text-2xl sm:text-3xl font-black text-blue-950 tracking-tight">
                  {citizens.filter(c => c.status === 'Aktif').length} <span className="text-base font-bold text-blue-700">KK Aktif</span>
                </div>
                <div className="flex items-center justify-between text-xs text-blue-800 mt-1">
                  <span>Dari Total {totalFamilies} KK Terdaftar</span>
                  <span className="font-bold">{totalLives} Jiwa</span>
                </div>
              </div>
              {/* Status pill distribution */}
              <div className="flex items-center gap-1.5 text-[11px]">
                <span className="px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800 font-bold">
                  {citizens.filter(c => c.status === 'Aktif').length} Aktif
                </span>
                <span className="px-2 py-0.5 rounded-md bg-amber-100 text-amber-800 font-bold">
                  {citizens.filter(c => c.status === 'Masa Tenggang' || c.status === 'Menunggak').length} Tenggang/Tunggak
                </span>
              </div>
              <div className="flex justify-between text-[11px] text-slate-500 font-medium">
                <span>Kepatuhan Pembayaran:</span>
                <span className="text-blue-700 font-bold">{complianceRate}% KK Tertib</span>
              </div>
            </div>

            {/* 3. Laporan Duka yang Sedang Ditangani */}
            <div className="p-4 rounded-2xl bg-gradient-to-br from-slate-50 via-rose-50 to-white border border-rose-200/70 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-rose-950 uppercase tracking-wider">
                  Laporan Duka Sedang Ditangani
                </span>
                <div className="p-2 bg-rose-600 text-white rounded-xl shadow-sm">
                  <HeartHandshake className="w-4 h-4" />
                </div>
              </div>
              <div>
                <div className="text-2xl sm:text-3xl font-black text-rose-950 tracking-tight">
                  {deathNotices.filter(d => d.status === 'Aktif').length} <span className="text-base font-bold text-rose-700">Peristiwa Siaga</span>
                </div>
                <div className="text-xs text-rose-800 mt-1">
                  {deathNotices.filter(d => d.status === 'Aktif').length > 0 ? (
                    <span className="font-semibold text-rose-900">
                      Alm/Almh. {deathNotices.find(d => d.status === 'Aktif')?.deceasedName} ({deathNotices.find(d => d.status === 'Aktif')?.blockRt})
                    </span>
                  ) : (
                    <span>Semua penanganan duka telah tuntas disalurkan.</span>
                  )}
                </div>
              </div>
              <div className="flex items-center justify-between pt-1">
                <span className="text-[11px] text-slate-500">
                  Total Riwayat Lelayu: <strong>{deathNotices.length}</strong>
                </span>
                <button
                  onClick={() => setActiveTab('lelayu')}
                  className="px-2.5 py-1 bg-rose-600 hover:bg-rose-700 text-white font-bold text-[11px] rounded-lg transition-all"
                >
                  Buka Siaga Duka &rarr;
                </button>
              </div>
              <div className="text-[11px] text-slate-500 font-medium">
                Santunan Siaga Standar: <span className="font-bold text-rose-700">{formatRupiah(settings.deathBenefitAmount || 3000000)}</span>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-5">
        
        {/* Total Saldo Kas */}
        <div className="bg-white p-5 sm:p-6 rounded-2xl border border-slate-200/80 shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Saldo Kas Paguyuban</span>
            <div className="p-2.5 bg-emerald-50 text-emerald-600 rounded-xl">
              <Wallet className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
              {formatRupiah(totalBalance)}
            </div>
            <div className="flex items-center gap-1.5 mt-2 text-xs font-medium text-emerald-700">
              <ShieldCheck className="w-4 h-4" />
              <span>Kas Transparan & Akuntabel</span>
            </div>
          </div>
        </div>

        {/* Pemasukan Bulan Ini */}
        <div className="bg-white p-5 sm:p-6 rounded-2xl border border-slate-200/80 shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Pemasukan (Agu 2026)</span>
            <div className="p-2.5 bg-teal-50 text-teal-600 rounded-xl">
              <TrendingUp className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
              {formatRupiah(currentMonthTxIn)}
            </div>
            <div className="flex items-center gap-1 mt-2 text-xs text-slate-500">
              <span className="font-semibold text-emerald-600">+ Iuran & Infaq</span>
              <span>warga bulan berjalan</span>
            </div>
          </div>
        </div>

        {/* Pengeluaran Bulan Ini */}
        <div className="bg-white p-5 sm:p-6 rounded-2xl border border-slate-200/80 shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Pengeluaran & Santunan</span>
            <div className="p-2.5 bg-rose-50 text-rose-600 rounded-xl">
              <TrendingDown className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
              {formatRupiah(currentMonthTxOut)}
            </div>
            <div className="flex items-center gap-1 mt-2 text-xs text-slate-500">
              <span className="font-semibold text-rose-600">Santunan Duka</span>
              <span>& kain kafan / makam</span>
            </div>
          </div>
        </div>

        {/* Data Warga & Kepatuhan */}
        <div className="bg-white p-5 sm:p-6 rounded-2xl border border-slate-200/80 shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Warga & Kepatuhan</span>
            <div className="p-2.5 bg-indigo-50 text-indigo-600 rounded-xl">
              <Users className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3">
            <div className="flex items-baseline gap-2">
              <span className="text-2xl sm:text-3xl font-black text-slate-900">{totalFamilies} KK</span>
              <span className="text-xs font-bold text-indigo-600">({totalLives} Jiwa)</span>
            </div>
            <div className="mt-2">
              <div className="flex justify-between text-[11px] font-semibold text-slate-600 mb-1">
                <span>Kepatuhan Agu: {complianceRate}%</span>
                <span>{paidCountAug}/{totalFamilies} KK Lunas</span>
              </div>
              <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-indigo-600 rounded-full transition-all duration-500" 
                  style={{ width: `${complianceRate}%` }}
                />
              </div>
            </div>
          </div>
        </div>

      </div>

      {/* Visualisasi Tren Keuangan Bulanan (Recharts Interactive Chart) */}
      <div className="bg-white rounded-3xl border border-slate-200/80 p-5 sm:p-7 shadow-sm">
        
        {/* Chart Header & Controls */}
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-5 border-b border-slate-100">
          <div className="space-y-1">
            <div className="flex items-center gap-2.5">
              <div className="p-2 bg-emerald-100 text-emerald-700 rounded-xl">
                <BarChart3 className="w-5 h-5" />
              </div>
              <h2 className="text-base sm:text-lg font-extrabold text-slate-900">
                Tren Iuran Warga & Total Saldo Kas Paguyuban
              </h2>
            </div>
            <p className="text-xs text-slate-500 pl-9">
              Visualisasi interaktif pergerakan akumulasi saldo kas dan perbandingan iuran bulanan warga vs. penyaluran dana duka.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2 self-start lg:self-auto pl-9 lg:pl-0">
            {/* Visual Type Selector */}
            <div className="inline-flex p-1 bg-slate-100 rounded-xl text-xs font-bold text-slate-600">
              <button
                onClick={() => setChartMetricType('combined')}
                className={`px-3 py-1.5 rounded-lg transition-all flex items-center gap-1.5 cursor-pointer ${
                  chartMetricType === 'combined' 
                    ? 'bg-white text-emerald-900 shadow-xs' 
                    : 'hover:text-slate-900'
                }`}
                title="Kombinasi Bar Iuran & Garis Saldo Kas"
              >
                <span>📊 Kombinasi</span>
              </button>
              <button
                onClick={() => setChartMetricType('balance')}
                className={`px-3 py-1.5 rounded-lg transition-all flex items-center gap-1.5 cursor-pointer ${
                  chartMetricType === 'balance' 
                    ? 'bg-white text-indigo-900 shadow-xs' 
                    : 'hover:text-slate-900'
                }`}
                title="Visualisasi Tren Akumulasi Saldo Kas Saja"
              >
                <span>📈 Saldo Kas</span>
              </button>
              <button
                onClick={() => setChartMetricType('comparison')}
                className={`px-3 py-1.5 rounded-lg transition-all flex items-center gap-1.5 cursor-pointer ${
                  chartMetricType === 'comparison' 
                    ? 'bg-white text-slate-900 shadow-xs' 
                    : 'hover:text-slate-900'
                }`}
                title="Perbandingan Penerimaan Iuran vs Pengeluaran"
              >
                <span>📉 Iuran vs Beban</span>
              </button>
            </div>

            {/* Timeframe Toggle */}
            <div className="inline-flex p-1 bg-slate-100 rounded-xl text-xs font-bold text-slate-600">
              <button
                onClick={() => setChartViewMode('all-year')}
                className={`px-2.5 py-1.5 rounded-lg transition-all cursor-pointer ${
                  chartViewMode === 'all-year' 
                    ? 'bg-white text-slate-900 shadow-xs' 
                    : 'hover:text-slate-900'
                }`}
              >
                1 Tahun ({chartYear})
              </button>
              <button
                onClick={() => setChartViewMode('last-6-months')}
                className={`px-2.5 py-1.5 rounded-lg transition-all cursor-pointer ${
                  chartViewMode === 'last-6-months' 
                    ? 'bg-white text-slate-900 shadow-xs' 
                    : 'hover:text-slate-900'
                }`}
              >
                6 Bln Terakhir
              </button>
            </div>

            {/* Quick Link to Cashbook */}
            <button
              onClick={() => setActiveTab('buku-kas')}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200 rounded-xl text-xs font-bold transition-all cursor-pointer"
            >
              <span>Buku Kas</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Mini Summary Cards for Chart */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 my-5">
          <div className="p-3.5 rounded-2xl bg-emerald-50/80 border border-emerald-200/80">
            <span className="text-[10px] font-bold text-emerald-800 uppercase tracking-wider block">
              Total Iuran Terkumpul
            </span>
            <span className="text-sm sm:text-base font-black font-mono text-emerald-950 mt-1 block">
              +{formatRupiah(chartSummary.totalDues)}
            </span>
          </div>

          <div className="p-3.5 rounded-2xl bg-rose-50/80 border border-rose-200/80">
            <span className="text-[10px] font-bold text-rose-800 uppercase tracking-wider block">
              Total Pengeluaran Kas
            </span>
            <span className="text-sm sm:text-base font-black font-mono text-rose-950 mt-1 block">
              -{formatRupiah(chartSummary.totalExp)}
            </span>
          </div>

          <div className="p-3.5 rounded-2xl bg-amber-50/80 border border-amber-200/80">
            <span className="text-[10px] font-bold text-amber-800 uppercase tracking-wider block">
              Surplus Bersih Kas
            </span>
            <span className={`text-sm sm:text-base font-black font-mono mt-1 block ${
              chartSummary.netTotal >= 0 ? 'text-amber-950' : 'text-rose-950'
            }`}>
              {chartSummary.netTotal >= 0 ? '+' : ''}{formatRupiah(chartSummary.netTotal)}
            </span>
          </div>

          <div className="p-3.5 rounded-2xl bg-indigo-50/80 border border-indigo-200/80">
            <span className="text-[10px] font-bold text-indigo-800 uppercase tracking-wider block">
              Total Saldo Kas Terkini
            </span>
            <span className="text-sm sm:text-base font-black font-mono text-indigo-950 mt-1 block">
              {formatRupiah(totalBalance)}
            </span>
          </div>
        </div>

        {/* Recharts Container */}
        <div className="w-full h-[330px] sm:h-[360px] mt-2">
          <ResponsiveContainer width="100%" height="100%">
            {chartMetricType === 'balance' ? (
              /* Area Chart for Cumulative Cash Balance */
              <AreaChart
                data={monthlyChartData}
                margin={{ top: 15, right: 15, left: 10, bottom: 5 }}
              >
                <defs>
                  <linearGradient id="balanceGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#4f46e5" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#4f46e5" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                <XAxis 
                  dataKey="monthShort" 
                  tick={{ fill: '#64748b', fontSize: 11, fontWeight: 600 }}
                  axisLine={{ stroke: '#cbd5e1' }}
                  tickLine={false}
                />
                <YAxis 
                  tickFormatter={(val) => {
                    if (val === 0) return 'Rp 0';
                    if (Math.abs(val) >= 1000000) return `${(val / 1000000).toFixed(1)}jt`;
                    return `${val / 1000}rb`;
                  }}
                  tick={{ fill: '#64748b', fontSize: 10 }}
                  axisLine={false}
                  tickLine={false}
                  width={55}
                />
                <Tooltip content={<CustomChartTooltip chartYear={chartYear} totalFamilies={totalFamilies} />} />
                <Legend 
                  verticalAlign="top"
                  align="right"
                  wrapperStyle={{ paddingBottom: 12, fontSize: 12, fontWeight: 600 }}
                  formatter={(val) => <span className="text-xs text-slate-700 font-bold mr-3">{val}</span>}
                />
                <Area 
                  type="monotone" 
                  dataKey="cumulativeBalance" 
                  name="Akumulasi Saldo Kas Bersih" 
                  stroke="#4f46e5" 
                  strokeWidth={3}
                  fillOpacity={1} 
                  fill="url(#balanceGradient)" 
                  activeDot={{ r: 6, fill: '#4f46e5', stroke: '#ffffff', strokeWidth: 2 }}
                />
              </AreaChart>
            ) : chartMetricType === 'comparison' ? (
              /* Bar Chart for Inflow vs Outflow Comparison */
              <BarChart
                data={monthlyChartData}
                margin={{ top: 15, right: 15, left: 10, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                <XAxis 
                  dataKey="monthShort" 
                  tick={{ fill: '#64748b', fontSize: 11, fontWeight: 600 }}
                  axisLine={{ stroke: '#cbd5e1' }}
                  tickLine={false}
                />
                <YAxis 
                  tickFormatter={(val) => {
                    if (val === 0) return 'Rp 0';
                    if (Math.abs(val) >= 1000000) return `${(val / 1000000).toFixed(1)}jt`;
                    return `${val / 1000}rb`;
                  }}
                  tick={{ fill: '#64748b', fontSize: 10 }}
                  axisLine={false}
                  tickLine={false}
                  width={55}
                />
                <Tooltip content={<CustomChartTooltip chartYear={chartYear} totalFamilies={totalFamilies} />} />
                <Legend 
                  verticalAlign="top"
                  align="right"
                  wrapperStyle={{ paddingBottom: 12, fontSize: 12, fontWeight: 600 }}
                  formatter={(val) => <span className="text-xs text-slate-700 font-bold mr-3">{val}</span>}
                />
                <Bar 
                  dataKey="duesCollection" 
                  name="Penerimaan Iuran Warga" 
                  fill="#10b981" 
                  radius={[6, 6, 0, 0]} 
                  maxBarSize={32}
                />
                <Bar 
                  dataKey="expenses" 
                  name="Pengeluaran & Santunan" 
                  fill="#f43f5e" 
                  radius={[6, 6, 0, 0]} 
                  maxBarSize={32}
                />
              </BarChart>
            ) : (
              /* ComposedChart: Bar for Dues & Expenses + Line for Cumulative Cash Balance */
              <ComposedChart
                data={monthlyChartData}
                margin={{ top: 15, right: 20, left: 10, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                <XAxis 
                  dataKey="monthShort" 
                  tick={{ fill: '#64748b', fontSize: 11, fontWeight: 600 }}
                  axisLine={{ stroke: '#cbd5e1' }}
                  tickLine={false}
                />
                {/* Left Y Axis for Monthly Cash Flow */}
                <YAxis 
                  yAxisId="left"
                  tickFormatter={(val) => {
                    if (val === 0) return 'Rp 0';
                    if (Math.abs(val) >= 1000000) return `${(val / 1000000).toFixed(1)}jt`;
                    return `${val / 1000}rb`;
                  }}
                  tick={{ fill: '#64748b', fontSize: 10 }}
                  axisLine={false}
                  tickLine={false}
                  width={50}
                />
                {/* Right Y Axis for Total Balance */}
                <YAxis 
                  yAxisId="right"
                  orientation="right"
                  tickFormatter={(val) => {
                    if (val === 0) return 'Rp 0';
                    if (Math.abs(val) >= 1000000) return `${(val / 1000000).toFixed(1)}jt`;
                    return `${val / 1000}rb`;
                  }}
                  tick={{ fill: '#4f46e5', fontSize: 10, fontWeight: 700 }}
                  axisLine={false}
                  tickLine={false}
                  width={50}
                />
                <Tooltip content={<CustomChartTooltip chartYear={chartYear} totalFamilies={totalFamilies} />} />
                <Legend 
                  verticalAlign="top"
                  align="right"
                  wrapperStyle={{ paddingBottom: 12, fontSize: 12, fontWeight: 600 }}
                  formatter={(val) => <span className="text-xs text-slate-700 font-bold mr-3">{val}</span>}
                />
                <Bar 
                  yAxisId="left"
                  dataKey="duesCollection" 
                  name="Iuran Terkumpul" 
                  fill="#10b981" 
                  radius={[5, 5, 0, 0]} 
                  maxBarSize={28}
                />
                <Bar 
                  yAxisId="left"
                  dataKey="expenses" 
                  name="Pengeluaran & Santunan" 
                  fill="#f43f5e" 
                  radius={[5, 5, 0, 0]} 
                  maxBarSize={28}
                />
                <Line 
                  yAxisId="right"
                  type="monotone" 
                  dataKey="cumulativeBalance" 
                  name="Total Saldo Kas" 
                  stroke="#4f46e5" 
                  strokeWidth={3}
                  dot={{ r: 4, fill: '#4f46e5', stroke: '#ffffff', strokeWidth: 2 }}
                  activeDot={{ r: 6, fill: '#4f46e5', stroke: '#ffffff', strokeWidth: 2 }}
                />
              </ComposedChart>
            )}
          </ResponsiveContainer>
        </div>

        {/* Footnote information */}
        <div className="mt-4 pt-3 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-2">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            <span>Iuran Wajib RKM: {formatRupiah(settings.duesAmount)}/KK/Bulan (Sesuai AD/ART)</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-rose-500" />
            <span>Hak Santunan Kematian: {formatRupiah(settings.deathBenefitAmount)}/Kematian</span>
          </div>
        </div>

      </div>

      {/* Lelayu / Berita Duka Cita Widget */}
      {activeLelayu && (
        <div className="bg-gradient-to-r from-slate-900 to-emerald-950 text-white rounded-2xl p-5 sm:p-6 shadow-lg border border-slate-700">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex items-start gap-3.5">
              <div className="p-3 bg-rose-500/20 text-rose-400 rounded-xl shrink-0 mt-1">
                <HeartHandshake className="w-6 h-6" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="px-2 py-0.5 rounded bg-rose-500 text-white text-[10px] font-extrabold uppercase tracking-wider">
                    BERITA DUKA CITA
                  </span>
                  <span className="text-xs text-slate-400">{formatDateIndo(activeLelayu.createdAt)}</span>
                </div>
                <h3 className="text-lg font-bold text-white mt-1">
                  Almh. {activeLelayu.deceasedName} bin/binti {activeLelayu.binBinti} ({activeLelayu.age} Thn)
                </h3>
                <p className="text-xs text-slate-300 mt-0.5">
                  Wafat di {activeLelayu.passAwayLocation} • Dimakamkan di <strong>{activeLelayu.cemeteryName}</strong>
                </p>
                <div className="flex flex-wrap gap-3 mt-2 text-xs text-emerald-400 font-medium">
                  <span>✓ Santunan {formatRupiah(activeLelayu.rkmAssistanceAmount)}</span>
                  <span>✓ Kain Kafan Lengkap</span>
                  <span>✓ Mobil Jenazah Siaga</span>
                </div>
              </div>
            </div>

            <div className="flex flex-wrap gap-2 shrink-0">
              <button
                onClick={() => openLelayuModal(activeLelayu)}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow transition-all"
              >
                Lihat Detail & Broadcast WA
              </button>
              <button
                onClick={() => setActiveTab('layanan-duka')}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold rounded-xl border border-slate-700 transition-all"
              >
                Semua Layanan Duka
              </button>
            </div>
          </div>
        </div>
      )}

      {/* AD/ART RKM MPP 2024-2027 Legal Foundation Highlight */}
      <div className="bg-gradient-to-r from-slate-900 via-emerald-950 to-slate-900 text-white rounded-2xl p-5 sm:p-6 border border-emerald-700/50 shadow-md flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-start sm:items-center gap-3.5">
          <div className="w-11 h-11 rounded-2xl bg-emerald-500/20 text-emerald-300 flex items-center justify-center shrink-0 border border-emerald-500/30">
            <Scale className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-sm text-white">Landasan Hukum & Regulasi Resmi</span>
              <span className="text-[10px] bg-amber-500/20 text-amber-300 font-extrabold px-2 py-0.5 rounded-full border border-amber-500/30">
                AD/ART 2024–2027
              </span>
            </div>
            <p className="text-xs text-slate-300 mt-1 max-w-xl">
              Hak santunan duka ({formatRupiah(settings.deathBenefitAmount)}), bebas biaya kain kafan, ambulan 24 jam, dan tata kelola iuran {formatRupiah(settings.duesAmount)}/KK diatur sah dalam <strong>AD-ART RKM MPP Periode 2024–2027</strong>.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={() => setActiveTab('ad-art')}
            className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 active:scale-98 text-white font-bold text-xs rounded-xl shadow transition-all flex items-center gap-1.5"
          >
            <span>Buka AD/ART & Kalkulator Hak</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
          <a
            href="https://drive.google.com/file/d/1itGAXcxzcn0Wg9uqoHnc1fniJzUJKX83/view?usp=sharing"
            target="_blank"
            rel="noreferrer"
            className="p-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl border border-slate-700 transition-colors"
            title="Download PDF AD/ART 2024-2027"
          >
            <FileText className="w-4 h-4 text-emerald-400" />
          </a>
        </div>
      </div>

      {/* Main 2-Column Content: Mutasi Kas Terkini & Statistik Kepatuhan RT */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left 2 Cols: Mutasi Kas Terkini */}
        <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200/80 p-5 sm:p-6 shadow-sm">
          <div className="flex items-center justify-between pb-4 border-b border-slate-100">
            <div>
              <h2 className="font-bold text-base text-slate-900">Mutasi Kas & Transparansi Keuangan</h2>
              <p className="text-xs text-slate-500">Pencatatan real-time kas masuk dan kas keluar paguyuban</p>
            </div>
            <button
              onClick={() => setActiveTab('buku-kas')}
              className="text-xs font-bold text-emerald-700 hover:text-emerald-800 flex items-center gap-1"
            >
              <span>Buka Buku Kas</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          <div className="mt-4 divide-y divide-slate-100">
            {recentTransactions.map((tx) => {
              const isIncome = tx.type === 'in';
              return (
                <div key={tx.id} className="py-3.5 flex items-center justify-between gap-4 hover:bg-slate-50/60 rounded-xl px-2 transition-colors">
                  <div className="flex items-center gap-3 min-w-0">
                    <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                      isIncome ? 'bg-emerald-100 text-emerald-700' : 'bg-rose-100 text-rose-700'
                    }`}>
                      {isIncome ? <ArrowDownRight className="w-5 h-5" /> : <ArrowUpRight className="w-5 h-5" />}
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-xs sm:text-sm text-slate-900 truncate">
                          {tx.category}
                        </span>
                        <span className="text-[10px] px-2 py-0.2 rounded font-semibold bg-slate-100 text-slate-600 shrink-0">
                          {tx.paymentMethod}
                        </span>
                      </div>
                      <p className="text-xs text-slate-500 truncate mt-0.5">
                        {tx.description}
                      </p>
                      <div className="text-[11px] text-slate-400 flex items-center gap-2 mt-0.5">
                        <span>{formatDateIndo(tx.date, false)}</span>
                        <span>•</span>
                        <span>{tx.recipientOrPayer}</span>
                      </div>
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <div className={`font-black text-sm sm:text-base font-mono ${
                      isIncome ? 'text-emerald-700' : 'text-rose-700'
                    }`}>
                      {isIncome ? '+' : '-'}{formatRupiah(tx.amount)}
                    </div>
                    <span className="text-[10px] text-slate-400">Verif: {tx.verifiedBy}</span>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="mt-4 pt-4 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
            <span>Menampilkan 6 transaksi terakhir</span>
            <button
              onClick={() => setActiveTab('buku-kas')}
              className="text-emerald-700 font-bold hover:underline"
            >
              Lihat Seluruh Riwayat Kas & LPJ &rarr;
            </button>
          </div>
        </div>

        {/* Right 1 Col: Kepatuhan Iuran Per RT & Emergency Contacts */}
        <div className="space-y-6">
          
          {/* Kepatuhan RT */}
          <div className="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-sm">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="font-bold text-sm text-slate-900">Kepatuhan Iuran per RT</h3>
              <span className="text-xs text-slate-400 font-medium">Bulan Agustus 2026</span>
            </div>

            <div className="mt-4 space-y-3">
              {rtStats.map((item) => (
                <div key={item.rt} className="space-y-1">
                  <div className="flex justify-between text-xs font-semibold">
                    <span className="text-slate-800">RT {item.rt}</span>
                    <span className="text-slate-600 font-mono">{item.rate}% ({item.paid}/{item.total} KK)</span>
                  </div>
                  <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                    <div 
                      className={`h-full rounded-full ${
                        item.rate >= 80 ? 'bg-emerald-500' : item.rate >= 50 ? 'bg-amber-500' : 'bg-rose-500'
                      }`}
                      style={{ width: `${item.rate}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-4 pt-3 border-t border-slate-100">
              <button
                onClick={() => setActiveTab('iuran')}
                className="w-full py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition-colors text-center block"
              >
                Buka Matriks Pembayaran Warga
              </button>
            </div>
          </div>

          {/* Siaga Kematian 24 Jam Satgas */}
          <div className="bg-gradient-to-br from-emerald-50 to-teal-50 rounded-2xl border border-emerald-200/80 p-5 shadow-sm">
            <div className="flex items-center gap-2.5">
              <div className="p-2 bg-emerald-600 text-white rounded-lg">
                <Phone className="w-4 h-4" />
              </div>
              <div>
                <h4 className="font-bold text-xs text-emerald-950 uppercase tracking-wider">Satgas Siaga Duka 24 Jam</h4>
                <p className="text-[11px] text-emerald-800 font-medium">{settings.contactCenter}</p>
              </div>
            </div>

            <p className="text-xs text-slate-600 mt-3 leading-relaxed">
              Jika ada warga yang wafat, segera hubungi Satgas Kematian untuk persiapan kain kafan, tim pemulasaraan, mobil jenazah, dan penggalian makam.
            </p>

            <div className="mt-3 flex gap-2">
              <a
                href={`https://wa.me/${settings.waAdmin}`}
                target="_blank"
                rel="noreferrer"
                className="flex-1 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl text-center shadow-sm transition-all"
              >
                Hubungi WA Satgas
              </a>
              <button
                onClick={() => setActiveTab('layanan-duka')}
                className="px-3 py-2 bg-white hover:bg-slate-100 text-slate-700 text-xs font-semibold rounded-xl border border-slate-300 transition-all"
              >
                Lapor Wafat
              </button>
            </div>
          </div>

        </div>

      </div>

    </div>
  );
};
