import React, { useState } from 'react';
import { 
  X, 
  HeartHandshake, 
  Search, 
  ShieldCheck, 
  AlertTriangle, 
  MapPin, 
  Calendar, 
  Clock, 
  Phone, 
  CheckCircle2, 
  Plus, 
  Trash2, 
  Coins, 
  Car, 
  Sparkles,
  FileText,
  Lock,
  LogIn
} from 'lucide-react';
import { useRkm } from '../context/RkmContext';
import { 
  formatRupiah, 
  DEFAULT_DEATH_BUDGET_BREAKDOWN, 
  getAdArtCitizenStatus, 
  BLOCK_OPTIONS, 
  RT_OPTIONS 
} from '../utils/formatters';
import { Citizen, DeathNotice, FamilyMember, FamilyAddOnItem } from '../types';

interface ReportDeathModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigateToLogin?: () => void;
}

export const ReportDeathModal: React.FC<ReportDeathModalProps> = ({ isOpen, onClose, onNavigateToLogin }) => {
  const { citizens, addDeathNotice, addTransaction, currentUser, settings } = useRkm();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCitizenId, setSelectedCitizenId] = useState<string>('');
  const [selectedMemberName, setSelectedMemberName] = useState<string>('');
  
  // Custom non-member input if applicable
  const [isNonMember, setIsNonMember] = useState(false);
  const [deceasedName, setDeceasedName] = useState('');
  const [binBinti, setBinBinti] = useState('');
  const [gender, setGender] = useState<'L' | 'P'>('L');
  const [age, setAge] = useState<number>(60);
  const [noKK, setNoKK] = useState('');
  const [address, setAddress] = useState('Perumahan Metro Parung Panjang, Blok B6 No. 12');
  const [rt, setRt] = useState('002');
  const [rw, setRw] = useState('08');

  // Death details
  const [passAwayTime, setPassAwayTime] = useState(
    new Date().toLocaleDateString('id-ID', { day: '2-digit', month: 'short', year: 'numeric' }) + ', Pukul 08:30 WIB'
  );
  const [passAwayLocation, setPassAwayLocation] = useState('Kediaman Rumah Duka, Perumahan Metro Parung Panjang');
  const [funeralTime, setFuneralTime] = useState('Ba’da Ashar (Pukul 15:30 WIB)');
  const [mosqueName, setMosqueName] = useState('Masjid Jami’ Al-Muhajirin MPP');
  const [cemeteryName, setCemeteryName] = useState('TPU Desa Gerowong / Makam RKM MPP');
  const [cemeteryType, setCemeteryType] = useState<'makam_rkm_gerowong' | 'luar_rkm_nonmuslim'>('makam_rkm_gerowong');
  
  // Contact
  const [contactPerson, setContactPerson] = useState('');
  const [contactPhone, setContactPhone] = useState('081234567890');

  // Budget Breakdown (Rp 1.900.000 Default)
  const [budgetBreakdown, setBudgetBreakdown] = useState(DEFAULT_DEATH_BUDGET_BREAKDOWN);
  const [applyStandardPackage, setApplyStandardPackage] = useState(true);

  // Add-ons for family request
  const [familyAddOns, setFamilyAddOns] = useState<FamilyAddOnItem[]>([
    { id: '1', name: 'Sewa Tenda Ekstra 2 Plong', cost: 300000, paidByFamily: true },
    { id: '2', name: 'Paket Kembang & Air Mawar 7 Rupa', cost: 75000, paidByFamily: true }
  ]);
  const [newAddOnName, setNewAddOnName] = useState('');
  const [newAddOnCost, setNewAddOnCost] = useState<number>(0);

  // Dana Talangan
  const [hasBridgeLoan, setHasBridgeLoan] = useState(false);
  const [bridgeLoanAmount, setBridgeLoanAmount] = useState<number>(1900000);
  const [bridgeLenderName, setBridgeLenderName] = useState('H. Bambang Sutrisno (Ketua Paguyuban)');

  // Selected Citizen Context
  const selectedCitizen = citizens.find(c => c.id === selectedCitizenId);
  const citizenAdArt = selectedCitizen ? getAdArtCitizenStatus(selectedCitizen) : null;

  if (!isOpen) return null;

  // Enforce Login: Guest users cannot access the death report form directly
  if (!currentUser) {
    return (
      <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto animate-fade-in">
        <div className="bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 w-full max-w-md overflow-hidden p-6 sm:p-8 text-center space-y-5">
          <div className="w-16 h-16 rounded-3xl bg-amber-500/10 text-amber-500 flex items-center justify-center mx-auto ring-8 ring-amber-500/5">
            <Lock className="w-8 h-8" />
          </div>

          <div className="space-y-2">
            <span className="text-[10px] font-extrabold px-3 py-1 bg-amber-500/10 text-amber-600 dark:text-amber-400 rounded-full uppercase tracking-wider">
              Akses Terbatas Warga & Pengurus
            </span>
            <h2 className="text-xl font-black text-slate-900 dark:text-white">
              Wajib Masuk / Login Akun
            </h2>
            <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
              Untuk menjamin keabsahan informasi musibah duka, pencairan santunan kematian, dan verifikasi KK anggota keluarga, formulir pelaporan musibah duka 24 jam wajib diakses setelah Anda masuk ke akun.
            </p>
          </div>

          {/* Emergency direct phone option if in immediate need */}
          <div className="bg-slate-50 dark:bg-slate-800/80 rounded-2xl p-4 border border-slate-200 dark:border-slate-700/80 text-left space-y-2">
            <div className="flex items-center gap-2 text-xs font-bold text-slate-800 dark:text-slate-200">
              <Phone className="w-4 h-4 text-emerald-500" />
              <span>Butuh Bantuan Mendesak / Darurat?</span>
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              Anda juga dapat menghubungi Satgas Siaga Kematian 24 Jam secara langsung melalui WhatsApp atau Telepon.
            </p>
            <a
              href={`https://wa.me/${settings.waAdmin}?text=Assalamu%27alaikum%20Satgas%20RKM%2C%20saya%20ingin%20melaporkan%20musibah%20kematian%20warga`}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-600 dark:text-emerald-400 hover:underline pt-1"
            >
              <span>Hubungi WA Satgas ({settings.contactCenter})</span>
              <span>&rarr;</span>
            </a>
          </div>

          <div className="flex flex-col sm:flex-row gap-2.5 pt-2">
            <button
              onClick={() => {
                onClose();
                if (onNavigateToLogin) {
                  onNavigateToLogin();
                }
              }}
              className="flex-1 py-3 bg-emerald-600 hover:bg-emerald-700 active:scale-98 text-white rounded-xl text-xs font-bold shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <LogIn className="w-4 h-4" />
              <span>Masuk Akun Sekarang</span>
            </button>

            <button
              onClick={onClose}
              className="py-3 px-4 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-bold transition-all cursor-pointer"
            >
              Tutup
            </button>
          </div>
        </div>
      </div>
    );
  }

  const filteredCitizens = searchQuery
    ? citizens.filter(c => 
        c.headOfFamily.toLowerCase().includes(searchQuery.toLowerCase()) ||
        c.noKK.includes(searchQuery) ||
        (c.block && c.block.toLowerCase().includes(searchQuery.toLowerCase()))
      )
    : citizens.slice(0, 10);

  const handleSelectCitizen = (c: Citizen) => {
    setSelectedCitizenId(c.id);
    setNoKK(c.noKK);
    setAddress(c.address);
    setRt(c.rt);
    setRw(c.rw);
    setContactPerson(c.headOfFamily);
    setContactPhone(c.phone);
    if (c.members && c.members.length > 0) {
      setSelectedMemberName(c.members[0].name);
      setDeceasedName(c.members[0].name);
      setGender(c.members[0].gender);
    }
  };

  const handleAddAddOn = () => {
    if (!newAddOnName || newAddOnCost <= 0) return;
    setFamilyAddOns(prev => [
      ...prev,
      {
        id: `addon-${Date.now()}`,
        name: newAddOnName,
        cost: newAddOnCost,
        paidByFamily: true
      }
    ]);
    setNewAddOnName('');
    setNewAddOnCost(0);
  };

  const handleRemoveAddOn = (id: string) => {
    setFamilyAddOns(prev => prev.filter(a => a.id !== id));
  };

  const totalPackageCost = applyStandardPackage
    ? (Object.values(budgetBreakdown) as number[]).reduce((acc: number, val: number) => acc + val, 0)
    : 0;

  const totalAddOnCost = familyAddOns.reduce((acc, item) => acc + item.cost, 0);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const finalDeceasedName = isNonMember ? deceasedName : (deceasedName || selectedMemberName || 'Almarhum/Almarhumah');
    const finalNoKK = isNonMember ? (noKK || 'NON-ANGGOTA') : (selectedCitizen?.noKK || noKK);

    const eligibility = citizenAdArt?.isEligibleFullBenefit
      ? 'Santunan Penuh'
      : citizenAdArt?.isEligibleServiceOnly
      ? 'Layanan Tanpa Santunan'
      : 'Non-Anggota';

    const newNotice: DeathNotice = {
      id: `notice-${Date.now()}`,
      deceasedName: finalDeceasedName,
      binBinti: binBinti || 'Fulan',
      gender,
      age: Number(age) || 50,
      noKK: finalNoKK,
      address,
      rt,
      rw,
      passAwayTime,
      passAwayLocation,
      funeralTime,
      mosqueName,
      cemeteryName: cemeteryType === 'makam_rkm_gerowong' ? 'TPU Desa Gerowong / Makam RKM MPP' : cemeteryName,
      cemeteryType,
      contactPerson: contactPerson || 'Keluarga Ahli Waris',
      contactPhone,
      rkmAssistanceAmount: applyStandardPackage ? totalPackageCost : 0,
      shroudsProvided: true,
      ambulanceProvided: true,
      graveDiggerAssigned: true,
      budgetBreakdown: applyStandardPackage ? budgetBreakdown : undefined,
      familyAddOns,
      bridgeFundLoan: hasBridgeLoan ? {
        hasLoan: true,
        amount: bridgeLoanAmount,
        lenderName: bridgeLenderName,
        lenderRole: 'Pengurus Lingkungan/Blok',
        date: new Date().toISOString().split('T')[0],
        isReimbursed: false
      } : undefined,
      taskChecklist: {
        bathingDone: false,
        shroudingDone: false,
        prayerDone: false,
        transportDone: false,
        burialDone: false,
        adminDone: false
      },
      benefitEligibility: eligibility,
      status: 'Aktif',
      createdAt: new Date().toISOString()
    };

    addDeathNotice(newNotice);

    // If there is dana talangan recorded, log into cashbook transactions as in/out
    if (hasBridgeLoan) {
      addTransaction({
        type: 'in',
        category: 'Dana Talangan Pengurus',
        amount: bridgeLoanAmount,
        date: new Date().toISOString().split('T')[0],
        description: `Penerimaan Pinjaman Dana Talangan Pemulasaraan Jenazah Alm/Almh ${finalDeceasedName} dari ${bridgeLenderName}`,
        recipientOrPayer: bridgeLenderName,
        paymentMethod: 'Tunai',
        verifiedBy: currentUser?.name || 'Bendahara RKM'
      });
    }

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/75 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-3xl overflow-hidden animate-fade-in my-6 max-h-[90vh] flex flex-col">
        
        {/* Modal Top Header */}
        <div className="bg-slate-900 text-white p-5 flex items-center justify-between border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-rose-600 flex items-center justify-center text-white shadow-lg shadow-rose-950/40">
              <HeartHandshake className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">Form Laporan Musibah Duka Cita (Lelayu)</h2>
              <p className="text-xs text-slate-400">Verifikasi Hak Santunan AD/ART 2024–2027 & Alokasi Paket Rp 1.900.000</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-6 overflow-y-auto">
          
          {/* Opsi Anggota atau Non-Anggota */}
          <div className="flex items-center justify-between p-3.5 bg-slate-50 rounded-2xl border border-slate-200">
            <div>
              <span className="text-xs font-bold text-slate-800">Status Keanggotaan Jenazah:</span>
              <p className="text-[11px] text-slate-500">Pilih dari Master Data KK atau input Non-Anggota</p>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setIsNonMember(false)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                  !isNonMember ? 'bg-emerald-600 text-white shadow-sm' : 'bg-white text-slate-700 border border-slate-200'
                }`}
              >
                Anggota Terdaftar KK
              </button>
              <button
                type="button"
                onClick={() => setIsNonMember(true)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                  isNonMember ? 'bg-amber-600 text-white shadow-sm' : 'bg-white text-slate-700 border border-slate-200'
                }`}
              >
                Warga Baru / Non-Anggota
              </button>
            </div>
          </div>

          {/* Section 1: Data Anggota / Almarhum */}
          {!isNonMember ? (
            <div className="space-y-3 bg-slate-50/70 p-4 rounded-2xl border border-slate-200">
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                1. Pilih Kepala Keluarga (KK) & Anggota Meninggal
              </label>

              <div className="relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Cari Nama KK, No. KK, atau Blok..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 bg-white border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-emerald-500 outline-none"
                />
              </div>

              <select
                value={selectedCitizenId}
                onChange={(e) => {
                  const cit = citizens.find(c => c.id === e.target.value);
                  if (cit) handleSelectCitizen(cit);
                }}
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-bold text-slate-800 focus:ring-2 focus:ring-emerald-500 outline-none"
              >
                <option value="">-- Pilih Kepala Keluarga Terdaftar --</option>
                {filteredCitizens.map(c => (
                  <option key={c.id} value={c.id}>
                    {c.headOfFamily} — No. KK: {c.noKK} | {c.block ? `Blok ${c.block}` : `RT ${c.rt}`} ({c.members.length} Jiwa)
                  </option>
                ))}
              </select>

              {/* Status Eligibility Verification Box */}
              {selectedCitizen && citizenAdArt && (
                <div className={`p-4 rounded-2xl border text-xs ${
                  citizenAdArt.isEligibleFullBenefit
                    ? 'bg-emerald-50 border-emerald-300 text-emerald-950'
                    : citizenAdArt.isEligibleServiceOnly
                    ? 'bg-amber-50 border-amber-300 text-amber-950'
                    : 'bg-rose-50 border-rose-300 text-rose-950'
                }`}>
                  <div className="flex items-center justify-between">
                    <span className="font-bold flex items-center gap-1.5">
                      <ShieldCheck className="w-4 h-4 text-emerald-600" />
                      Verifikasi Hak AD/ART RKM:
                    </span>
                    <span className={`px-2.5 py-0.5 rounded-full font-extrabold text-[10px] border ${citizenAdArt.statusBadgeColor}`}>
                      {citizenAdArt.statusBadgeText}
                    </span>
                  </div>
                  <p className="mt-1.5 text-[11px] leading-relaxed">
                    {citizenAdArt.notes}
                  </p>
                  <div className="mt-2 pt-2 border-t border-slate-200/60 flex items-center justify-between text-[11px] font-medium">
                    <span>Tunggakan Iuran: <strong>{citizenAdArt.unpaidMonthsCount} Bulan</strong></span>
                    <span>Hak Santunan: <strong>{citizenAdArt.isEligibleFullBenefit ? 'Rp 1.900.000 (Penuh)' : 'Hanya Pelayanan'}</strong></span>
                  </div>
                </div>
              )}

              {/* Pilih Jiwa dalam KK */}
              {selectedCitizen && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Pilih Jiwa Anggota yang Meninggal:
                    </label>
                    <select
                      value={selectedMemberName}
                      onChange={(e) => {
                        setSelectedMemberName(e.target.value);
                        setDeceasedName(e.target.value);
                        const mem = selectedCitizen.members.find(m => m.name === e.target.value);
                        if (mem) setGender(mem.gender);
                      }}
                      className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-bold text-slate-800 outline-none"
                    >
                      {selectedCitizen.members.map((m, idx) => (
                        <option key={idx} value={m.name}>
                          {m.name} ({m.relation} - {m.gender === 'L' ? 'Laki-laki' : 'Perempuan'})
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Nama Bin / Binti:
                    </label>
                    <input
                      type="text"
                      placeholder="Contoh: Bin H. Sulaeman"
                      value={binBinti}
                      onChange={(e) => setBinBinti(e.target.value)}
                      className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs outline-none"
                    />
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="space-y-3 bg-amber-50/60 p-4 rounded-2xl border border-amber-200 text-xs">
              <span className="font-bold text-amber-900 block">Input Manual Warga Baru / Non-Anggota:</span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Nama Almarhum/Almarhumah</label>
                  <input
                    type="text"
                    required
                    value={deceasedName}
                    onChange={(e) => setDeceasedName(e.target.value)}
                    placeholder="Nama Lengkap Jenazah"
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl outline-none"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Bin / Binti</label>
                  <input
                    type="text"
                    value={binBinti}
                    onChange={(e) => setBinBinti(e.target.value)}
                    placeholder="Nama Ayah Kandung"
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl outline-none"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Jenis Kelamin & Usia</label>
                  <div className="flex gap-2">
                    <select
                      value={gender}
                      onChange={(e) => setGender(e.target.value as any)}
                      className="px-3 py-2 bg-white border border-slate-300 rounded-xl outline-none"
                    >
                      <option value="L">Laki-laki</option>
                      <option value="P">Perempuan</option>
                    </select>
                    <input
                      type="number"
                      value={age}
                      onChange={(e) => setAge(Number(e.target.value))}
                      placeholder="Usia (Th)"
                      className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl outline-none"
                    />
                  </div>
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Nomor KK (Opsional)</label>
                  <input
                    type="text"
                    value={noKK}
                    onChange={(e) => setNoKK(e.target.value)}
                    placeholder="16 Digit No KK"
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl outline-none"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Section 2: Waktu & Lokasi Penyelenggaraan */}
          <div className="space-y-3">
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
              2. Waktu, Lokasi Rumah Duka & Pemakaman
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Waktu Wafat</label>
                <input
                  type="text"
                  value={passAwayTime}
                  onChange={(e) => setPassAwayTime(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl outline-none"
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Rencana Waktu Pemakaman</label>
                <input
                  type="text"
                  value={funeralTime}
                  onChange={(e) => setFuneralTime(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl outline-none"
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Alamat Rumah Duka</label>
                <input
                  type="text"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl outline-none"
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Masjid Tempat Sholat Jenazah</label>
                <input
                  type="text"
                  value={mosqueName}
                  onChange={(e) => setMosqueName(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl outline-none"
                />
              </div>
              <div className="sm:col-span-2">
                <label className="block font-semibold text-slate-700 mb-1">Pilihan Tempat Pemakaman</label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setCemeteryType('makam_rkm_gerowong');
                      setCemeteryName('TPU Desa Gerowong / Makam RKM MPP');
                    }}
                    className={`p-2.5 rounded-xl text-left border transition-all ${
                      cemeteryType === 'makam_rkm_gerowong'
                        ? 'bg-emerald-50 border-emerald-500 ring-2 ring-emerald-500/20'
                        : 'bg-white border-slate-200'
                    }`}
                  >
                    <span className="font-bold text-slate-800 block">TPU Desa Gerowong (Makam RKM MPP)</span>
                    <span className="text-[11px] text-slate-500">Termasuk dalam paket santunan RKM Rp 1.900.000</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setCemeteryType('luar_rkm_nonmuslim');
                      setCemeteryName('TPU Luar RKM / Kampung Halaman');
                    }}
                    className={`p-2.5 rounded-xl text-left border transition-all ${
                      cemeteryType === 'luar_rkm_nonmuslim'
                        ? 'bg-amber-50 border-amber-500 ring-2 ring-amber-500/20'
                        : 'bg-white border-slate-200'
                    }`}
                  >
                    <span className="font-bold text-slate-800 block">Luar RKM / Non-Muslim / Luar Kota</span>
                    <span className="text-[11px] text-slate-500">Disediakan santunan tunai setara & ambulance lokal</span>
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Section 3: Alokasi Anggaran Paket Rp 1.900.000 */}
          <div className="space-y-3 bg-slate-900 text-white p-4 rounded-2xl">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-emerald-400">
                  3. Breakdown Alokasi Paket Santunan (AD/ART Rp 1.900.000)
                </span>
                <p className="text-[11px] text-slate-400">Otomatis dialokasikan untuk operasional satgas fardhu kifayah</p>
              </div>
              <label className="flex items-center gap-2 cursor-pointer text-xs">
                <input
                  type="checkbox"
                  checked={applyStandardPackage}
                  onChange={(e) => setApplyStandardPackage(e.target.checked)}
                  className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500"
                />
                <span>Gunakan Paket Standar</span>
              </label>
            </div>

            {applyStandardPackage && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs pt-2">
                <div className="p-2 bg-slate-800 rounded-xl flex justify-between">
                  <span className="text-slate-300">1. Kain Kafan 1 Set Lengkap:</span>
                  <span className="font-bold text-emerald-400">{formatRupiah(budgetBreakdown.shroud)}</span>
                </div>
                <div className="p-2 bg-slate-800 rounded-xl flex justify-between">
                  <span className="text-slate-300">2. Tim Memandikan (2 Org):</span>
                  <span className="font-bold text-emerald-400">{formatRupiah(budgetBreakdown.bathing)}</span>
                </div>
                <div className="p-2 bg-slate-800 rounded-xl flex justify-between">
                  <span className="text-slate-300">3. Shalat Jenazah + Amplop Imam:</span>
                  <span className="font-bold text-emerald-400">{formatRupiah(budgetBreakdown.prayer)}</span>
                </div>
                <div className="p-2 bg-slate-800 rounded-xl flex justify-between">
                  <span className="text-slate-300">4. Operasional Mobil Jenazah:</span>
                  <span className="font-bold text-emerald-400">{formatRupiah(budgetBreakdown.transport)}</span>
                </div>
                <div className="p-2 bg-slate-800 rounded-xl flex justify-between">
                  <span className="text-slate-300">5. Gali Kubur & Papan Penutup:</span>
                  <span className="font-bold text-emerald-400">{formatRupiah(budgetBreakdown.gravedigger)}</span>
                </div>
                <div className="p-2 bg-slate-800 rounded-xl flex justify-between">
                  <span className="text-slate-300">6. Administrasi Makam Kecamatan:</span>
                  <span className="font-bold text-emerald-400">{formatRupiah(budgetBreakdown.adminDistrict)}</span>
                </div>
                <div className="p-2 bg-slate-800 rounded-xl flex justify-between sm:col-span-2">
                  <span className="text-slate-300">7. Biaya Taktis Operasional Satgas:</span>
                  <span className="font-bold text-emerald-400">{formatRupiah(budgetBreakdown.tactical)}</span>
                </div>
              </div>
            )}
          </div>

          {/* Section 4: Add-on Biaya Tambahan Permintaan Keluarga */}
          <div className="space-y-3 bg-slate-50 p-4 rounded-2xl border border-slate-200 text-xs">
            <div className="flex items-center justify-between">
              <div>
                <span className="font-bold text-slate-800 uppercase tracking-wider block">
                  4. Add-on / Biaya Tambahan Permintaan Keluarga
                </span>
                <p className="text-[11px] text-slate-500">
                  Di luar paket santunan Rp 1.9jt & dibebankan terpisah kepada pihak keluarga ahli waris
                </p>
              </div>
              <span className="font-extrabold text-slate-900">{formatRupiah(totalAddOnCost)}</span>
            </div>

            <div className="space-y-1.5">
              {familyAddOns.map(item => (
                <div key={item.id} className="flex items-center justify-between p-2 bg-white rounded-xl border border-slate-200">
                  <span className="font-medium text-slate-700">{item.name}</span>
                  <div className="flex items-center gap-3">
                    <span className="font-bold text-slate-900">{formatRupiah(item.cost)}</span>
                    <button
                      type="button"
                      onClick={() => handleRemoveAddOn(item.id)}
                      className="text-rose-500 hover:text-rose-700 p-1"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {/* Input New Addon */}
            <div className="flex gap-2 pt-1">
              <input
                type="text"
                placeholder="Nama Tambahan (Contoh: Sewa Kursi 50 unit)"
                value={newAddOnName}
                onChange={(e) => setNewAddOnName(e.target.value)}
                className="flex-1 px-3 py-1.5 bg-white border border-slate-300 rounded-xl text-xs outline-none"
              />
              <input
                type="number"
                placeholder="Nominal (Rp)"
                value={newAddOnCost || ''}
                onChange={(e) => setNewAddOnCost(Number(e.target.value) || 0)}
                className="w-32 px-3 py-1.5 bg-white border border-slate-300 rounded-xl text-xs outline-none"
              />
              <button
                type="button"
                onClick={handleAddAddOn}
                className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs flex items-center gap-1"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Tambah</span>
              </button>
            </div>
          </div>

          {/* Section 5: Dana Talangan Pengurus */}
          <div className="p-4 bg-amber-50/70 border border-amber-200 rounded-2xl text-xs space-y-2">
            <div className="flex items-center justify-between">
              <label className="flex items-center gap-2 cursor-pointer font-bold text-amber-900">
                <input
                  type="checkbox"
                  checked={hasBridgeLoan}
                  onChange={(e) => setHasBridgeLoan(e.target.checked)}
                  className="w-4 h-4 rounded text-amber-600 focus:ring-amber-500"
                />
                <span>Gunakan Opsi Dana Talangan (Jika Kas RKM Sedang Menipis)</span>
              </label>
              <Coins className="w-4 h-4 text-amber-600" />
            </div>

            {hasBridgeLoan && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Nominal Talangan Dipinjamkan (Rp)</label>
                  <input
                    type="number"
                    value={bridgeLoanAmount}
                    onChange={(e) => setBridgeLoanAmount(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl outline-none font-bold"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Nama Peminjam / Pengurus Lingkungan</label>
                  <input
                    type="text"
                    value={bridgeLenderName}
                    onChange={(e) => setBridgeLenderName(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl outline-none"
                  />
                </div>
                <p className="sm:col-span-2 text-[11px] text-amber-800 leading-tight">
                  *Dana talangan akan dicatat sebagai hutang operasional dan akan diganti oleh Bendahara saat kas masuk dari iuran warga berikutnya.
                </p>
              </div>
            )}
          </div>

          {/* Bottom Action Footer */}
          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200 shrink-0">
            <button
              type="button"
              onClick={onClose}
              className="px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs transition-colors"
            >
              Batal
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-xl text-xs shadow-lg shadow-rose-950/20 active:scale-95 transition-all flex items-center gap-2"
            >
              <HeartHandshake className="w-4 h-4" />
              <span>Terbitkan Laporan & Siagakan Satgas</span>
            </button>
          </div>

        </form>
      </div>
    </div>
  );
};
