import React, { useEffect, useState } from 'react';
import { ShieldCheck, HeartHandshake, Sparkles, CheckCircle2 } from 'lucide-react';
import { useRkm } from '../context/RkmContext';
import { getDirectImageUrl } from '../utils/formatters';

interface LoadingScreenProps {
  onFinish?: () => void;
  minDuration?: number;
}

export const LoadingScreen: React.FC<LoadingScreenProps> = ({ 
  onFinish, 
  minDuration = 1200 
}) => {
  const { settings } = useRkm();
  const [progress, setProgress] = useState(15);
  const [statusText, setStatusText] = useState('Memuat sistem kas digital...');
  const [fadeOut, setFadeOut] = useState(false);

  useEffect(() => {
    const t1 = setTimeout(() => {
      setProgress(45);
      setStatusText('Sinkronisasi database warga & fardhu kifayah...');
    }, minDuration * 0.25);

    const t2 = setTimeout(() => {
      setProgress(80);
      setStatusText('Memvalidasi modul kuitansi & buku kas...');
    }, minDuration * 0.6);

    const t3 = setTimeout(() => {
      setProgress(100);
      setStatusText('Sistem siap. Membuka Portal Masuk...');
    }, minDuration * 0.88);

    const t4 = setTimeout(() => {
      setFadeOut(true);
    }, minDuration);

    const t5 = setTimeout(() => {
      if (onFinish) onFinish();
    }, minDuration + 400);

    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
      clearTimeout(t3);
      clearTimeout(t4);
      clearTimeout(t5);
    };
  }, [minDuration, onFinish]);

  return (
    <div 
      className={`fixed inset-0 z-[9999] flex flex-col items-center justify-center bg-gradient-to-br from-slate-950 via-slate-900 to-emerald-950 text-white transition-opacity duration-400 ${
        fadeOut ? 'opacity-0 pointer-events-none' : 'opacity-100'
      }`}
    >
      {/* Background Decorative Rings */}
      <div className="absolute w-96 h-96 rounded-full bg-emerald-500/10 blur-3xl pointer-events-none animate-pulse" />
      <div className="absolute w-72 h-72 rounded-full bg-teal-500/10 blur-2xl pointer-events-none" />

      <div className="relative z-10 flex flex-col items-center max-w-sm w-full px-6 text-center">
        {/* Animated Logo Container */}
        <div className="relative mb-6">
          <div className="absolute -inset-2 bg-gradient-to-r from-emerald-500 to-teal-400 rounded-3xl blur opacity-40 animate-pulse" />
          <div className="relative w-24 h-24 sm:w-28 sm:h-28 rounded-3xl bg-slate-900 border-2 border-emerald-500/40 p-2 shadow-2xl flex items-center justify-center">
            {settings.logoUrl ? (
              <img 
                src={getDirectImageUrl(settings.logoUrl)} 
                alt={settings.orgName} 
                referrerPolicy="no-referrer"
                className="w-full h-full object-contain drop-shadow-md"
              />
            ) : (
              <div className="w-full h-full rounded-2xl bg-emerald-600 flex items-center justify-center text-white">
                <HeartHandshake className="w-12 h-12" />
              </div>
            )}
          </div>
          
          <div className="absolute -bottom-2 -right-2 p-1.5 bg-emerald-500 text-slate-950 rounded-xl shadow-lg">
            <ShieldCheck className="w-4 h-4" />
          </div>
        </div>

        {/* Title */}
        <h1 className="text-xl sm:text-2xl font-black tracking-tight text-white mb-1">
          {settings.shortName || 'RKM MPP'}
        </h1>
        <p className="text-xs sm:text-sm font-semibold text-emerald-400 mb-1">
          {settings.orgName}
        </p>
        <p className="text-[11px] text-slate-400 mb-6">
          {settings.rtRw} • {settings.village}, {settings.district}
        </p>

        {/* Progress Bar */}
        <div className="w-full bg-slate-800/80 rounded-full h-2 overflow-hidden p-0.5 border border-slate-700/60 mb-3 shadow-inner">
          <div 
            className="h-full bg-gradient-to-r from-emerald-500 to-teal-400 rounded-full transition-all duration-300 ease-out"
            style={{ width: `${progress}%` }}
          />
        </div>

        {/* Progress Status Text */}
        <div className="flex items-center gap-2 text-[11px] text-slate-300 font-medium h-5">
          <span className="inline-block w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
          <span>{statusText}</span>
        </div>

        {/* Footer Badge */}
        <div className="mt-8 text-[10px] text-slate-500 flex items-center gap-1.5">
          <Sparkles className="w-3 h-3 text-emerald-500" />
          <span>Sistem Digital Layanan Kematian & Transparansi Kas 2024–2027</span>
        </div>
      </div>
    </div>
  );
};
