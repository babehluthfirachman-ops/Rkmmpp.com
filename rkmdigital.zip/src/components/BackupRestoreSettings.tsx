import React, { useState, useRef } from 'react';
import { 
  FileText, 
  Download, 
  Upload, 
  AlertTriangle, 
  CheckCircle2, 
  FileSpreadsheet, 
  RefreshCw, 
  Layers, 
  Users, 
  DollarSign, 
  Heart, 
  Package, 
  ShieldCheck, 
  X, 
  Clock, 
  Database,
  Check
} from 'lucide-react';
import { useRkm } from '../context/RkmContext';
import { downloadCsvForTable } from '../utils/googleSheetsSync';
import { formatDateTimeIndo } from '../utils/formatters';

export const BackupRestoreSettings: React.FC = () => {
  const { 
    citizens, 
    transactions, 
    deathNotices, 
    assets, 
    assetLoans, 
    officers, 
    dutySchedules,
    feedbacks, 
    users, 
    settings, 
    importFullData, 
    resetToDefaultData,
    addAuditLog,
    currentUser
  } = useRkm();

  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [importMessage, setImportMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [previewBackupData, setPreviewBackupData] = useState<any | null>(null);
  const [showPreviewModal, setShowPreviewModal] = useState(false);
  const [isRestoring, setIsRestoring] = useState(false);
  const [toastBackup, setToastBackup] = useState<{ show: boolean; message: string; timestamp: string } | null>(null);

  // Trigger Backup function that serializes the current RKMContext state into a blob and downloads it, providing an immediate visual toast notification upon completion
  const handleTriggerBackup = () => {
    const fullState = {
      appName: 'RKM MPP DIGITAL',
      version: '2.5.0',
      exportedAt: new Date().toISOString(),
      systemInfo: {
        totalCitizens: citizens.length,
        totalTransactions: transactions.length,
        totalDeathNotices: deathNotices.length,
        totalAssets: assets.length
      },
      settings,
      citizens,
      transactions,
      deathNotices,
      dutySchedules,
      assets,
      assetLoans,
      officers,
      feedbacks,
      users
    };

    const blob = new Blob([JSON.stringify(fullState, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    const dateStr = new Date().toISOString().slice(0, 10);
    link.download = `BACKUP_RKM_MPP_${dateStr}.json`;
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);

    addAuditLog({
      userName: currentUser?.name || 'Super Admin',
      userRole: currentUser?.role || 'superadmin',
      action: 'DATABASE_BACKUP',
      details: `Trigger Backup database sukses: ${citizens.length} KK Warga, ${transactions.length} Transaksi`,
      ipAddress: '182.253.14.88 (Backup Trigger)',
      status: 'Success'
    });

    setToastBackup({
      show: true,
      message: `Cadangan database berhasil di-serialize dan diunduh (BACKUP_RKM_MPP_${dateStr}.json).`,
      timestamp: new Date().toLocaleTimeString('id-ID')
    });

    setTimeout(() => {
      setToastBackup(prev => prev ? { ...prev, show: false } : null);
    }, 5000);
  };

  // Export Full JSON Backup / Download Data
  const handleExportJSON = () => {
    handleTriggerBackup();
  };

  // When a JSON file is selected, parse and show preview modal first
  const handleFileSelected = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const content = event.target?.result as string;
        const parsed = JSON.parse(content);

        // Basic validation
        if (!parsed || (typeof parsed !== 'object')) {
          setImportMessage({ type: 'error', text: 'Format file JSON tidak valid.' });
          return;
        }

        setPreviewBackupData(parsed);
        setShowPreviewModal(true);
        if (fileInputRef.current) fileInputRef.current.value = '';
      } catch (err: any) {
        setImportMessage({ type: 'error', text: 'Gagal membaca file JSON: ' + (err?.message || 'Format salah') });
      }
    };
    reader.readAsText(file);
  };

  // Confirm Restore Handler
  const handleConfirmRestore = () => {
    if (!previewBackupData) return;

    setIsRestoring(true);
    try {
      const success = importFullData(previewBackupData);
      if (success) {
        setImportMessage({
          type: 'success',
          text: `✓ Pemulihan database berhasil! Data aktif diperbarui (${previewBackupData.citizens?.length || 0} KK Warga, ${previewBackupData.transactions?.length || 0} Transaksi Kas).`
        });

        addAuditLog({
          userName: currentUser?.name || 'Super Admin',
          userRole: currentUser?.role || 'superadmin',
          action: 'DATABASE_RESTORE',
          details: `Pemulihan database dari berkas JSON cadangan (${previewBackupData.citizens?.length || 0} KK Warga)`,
          ipAddress: '182.253.14.88 (Pengaturan)',
          status: 'Success'
        });

        setShowPreviewModal(false);
        setPreviewBackupData(null);
      } else {
        setImportMessage({
          type: 'error',
          text: 'Gagal memulihkan database. Struktur data tidak cocok.'
        });
      }
    } catch (err: any) {
      setImportMessage({
        type: 'error',
        text: 'Terjadi kesalahan saat memulihkan: ' + (err?.message || 'Error')
      });
    } finally {
      setIsRestoring(false);
    }
  };

  return (
    <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/80 shadow-sm space-y-6">
      
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-100">
        <div className="flex items-center gap-2.5">
          <div className="p-2.5 bg-emerald-100 text-emerald-800 rounded-2xl">
            <Database className="w-5 h-5" />
          </div>
          <div>
            <h2 className="font-extrabold text-base text-slate-900">
              Import/Export Database & Pemulihan Sistem RKM MPP
            </h2>
            <p className="text-xs text-slate-500">
              Kelola pencadangan mandiri, serialisasi state JSON, pemulihan data lokal, dan ekspor tabel database.
            </p>
          </div>
        </div>
      </div>

      {/* Immediate Visual Toast Notification for Trigger Backup */}
      {toastBackup && toastBackup.show && (
        <div className="p-4 bg-emerald-600 text-white rounded-2xl shadow-lg flex items-center justify-between animate-fade-in text-xs">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-full bg-white/20 flex items-center justify-center font-bold">
              <Check className="w-4 h-4 text-white" />
            </div>
            <div>
              <span className="font-black block text-sm">Backup Berhasil Dibuat!</span>
              <span className="text-emerald-100 text-[11px] font-medium">
                {toastBackup.message} • Pukul {toastBackup.timestamp} WIB
              </span>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setToastBackup(null)}
            className="px-3 py-1 bg-white/20 hover:bg-white/30 text-white text-[11px] font-bold rounded-lg cursor-pointer transition-colors"
          >
            Tutup
          </button>
        </div>
      )}

      {/* Alert / Notification Message */}
      {importMessage && (
        <div className={`p-4 rounded-2xl text-xs font-bold flex items-center justify-between animate-fade-in ${
          importMessage.type === 'success' 
            ? 'bg-emerald-50 text-emerald-900 border border-emerald-200' 
            : 'bg-rose-50 text-rose-900 border border-rose-200'
        }`}>
          <div className="flex items-center gap-2">
            {importMessage.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            ) : (
              <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
            )}
            <span>{importMessage.text}</span>
          </div>
          <button 
            onClick={() => setImportMessage(null)} 
            className="underline ml-2 text-slate-600 hover:text-slate-900"
          >
            Tutup
          </button>
        </div>
      )}

      {/* Section: Import/Export Database */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-black text-slate-900 flex items-center gap-2">
            <Layers className="w-4 h-4 text-emerald-600" />
            <span>Import/Export Database</span>
          </h3>
          <span className="text-[11px] text-slate-500 font-mono">Format Standar: JSON v2.5</span>
        </div>

        {/* Main 2-Cards: JSON Backup & JSON Restore */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs">
          
          {/* Card 1: Export / Download Data / Trigger Backup */}
          <div className="p-5 bg-slate-50/80 rounded-2xl border border-slate-200 space-y-4 flex flex-col justify-between">
            <div className="space-y-2">
              <div className="flex items-center gap-2 font-bold text-sm text-slate-900">
                <Download className="w-4 h-4 text-emerald-600" />
                <span>Export & Cadangkan Database Penuh (.JSON)</span>
              </div>
              <p className="text-slate-600 leading-relaxed text-xs">
                Serialisasi seluruh state aplikasi RKMContext ke dalam berkas blob JSON: 
                <strong> {citizens.length} KK Warga</strong>, 
                <strong> {transactions.length} Transaksi Kas</strong>, 
                <strong> {deathNotices.length} Berita Lelayu</strong>, 
                <strong> {assets.length} Aset Inventaris</strong>, dan pengaturan sistem.
              </p>
              <div className="pt-1 flex items-center gap-2 text-[11px] text-slate-500 font-mono">
                <Clock className="w-3.5 h-3.5" />
                <span>Waktu Pembuatan: {new Date().toLocaleDateString('id-ID')}</span>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-2">
              <button
                id="btn-backup-database"
                type="button"
                onClick={handleTriggerBackup}
                className="flex items-center justify-center gap-2 px-3 py-2.5 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white font-bold rounded-xl shadow-xs transition-all cursor-pointer text-xs"
                title="Backup Database (Disaster Recovery) - Unduh state warga, buku kas, dan aset sebagai file JSON terstruktur"
              >
                <Download className="w-4 h-4" />
                <span>Backup Database (.JSON)</span>
              </button>

              <button
                id="btn-trigger-backup"
                type="button"
                onClick={handleTriggerBackup}
                className="flex items-center justify-center gap-2 px-3 py-2.5 bg-slate-900 hover:bg-slate-800 active:scale-95 text-white font-bold rounded-xl shadow-xs transition-all cursor-pointer text-xs border border-slate-700"
                title="Serialize RKMContext state ke blob, unduh dan tampilkan visual toast"
              >
                <RefreshCw className="w-4 h-4 text-emerald-400" />
                <span>Trigger Backup</span>
              </button>
            </div>
          </div>

          {/* Card 2: Restore from JSON */}
          <div className="p-5 bg-slate-50/80 rounded-2xl border border-slate-200 space-y-4 flex flex-col justify-between">
            <div className="space-y-2">
              <div className="flex items-center gap-2 font-bold text-sm text-slate-900">
                <Upload className="w-4 h-4 text-blue-600" />
                <span>Import & Pulihkan Database (File Picker .JSON)</span>
              </div>
              <p className="text-slate-600 leading-relaxed text-xs">
                Gunakan file picker di bawah untuk memilih file cadangan .JSON yang valid. Data akan dipulihkan secara instan ke state aplikasi RKMContext.
              </p>
              <div className="p-2.5 bg-amber-50 rounded-xl border border-amber-200 text-[11px] text-amber-900">
                💡 Aman: Validasi struktur format dilakukan sebelum data disinkronkan ke memori kerja.
              </div>
            </div>

            <div className="space-y-2 pt-2">
              <input
                id="import-database-file-picker"
                type="file"
                ref={fileInputRef}
                onChange={handleFileSelected}
                accept=".json,application/json"
                className="block w-full text-xs text-slate-500 file:mr-3 file:py-2 file:px-3 file:rounded-xl file:border-0 file:text-xs file:font-extrabold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100 cursor-pointer border border-slate-300 rounded-xl p-1 bg-white"
              />
              <button
                id="btn-select-json-file"
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 active:scale-95 text-white font-bold rounded-xl shadow-xs transition-all cursor-pointer text-xs"
              >
                <Upload className="w-4 h-4" />
                <span>Buka File Picker (.JSON)</span>
              </button>
            </div>
          </div>

        </div>
      </div>

      {/* CSV Export Table Options */}
      <div className="p-5 bg-slate-50/80 border border-slate-200 rounded-2xl space-y-3">
        <div className="flex items-center justify-between pb-2 border-b border-slate-200">
          <div className="flex items-center gap-2 font-bold text-xs text-slate-900">
            <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
            <span>Ekspor Manual Tabel Format CSV (Kompatibel dengan Microsoft Excel & Google Sheets):</span>
          </div>
          <span className="text-[11px] text-slate-500 hidden sm:inline">Format UTF-8 Berstandar</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5 pt-1">
          
          <button
            type="button"
            onClick={() => downloadCsvForTable('warga', { citizens })}
            className="p-3 bg-white hover:bg-slate-100 border border-slate-200 rounded-xl font-bold text-slate-700 flex flex-col items-center justify-center gap-1.5 text-xs shadow-2xs transition-all text-center"
          >
            <Users className="w-4 h-4 text-emerald-600" />
            <span>Master Warga</span>
            <span className="text-[10px] text-slate-400 font-normal">({citizens.length} KK)</span>
          </button>

          <button
            type="button"
            onClick={() => downloadCsvForTable('kas', { transactions })}
            className="p-3 bg-white hover:bg-slate-100 border border-slate-200 rounded-xl font-bold text-slate-700 flex flex-col items-center justify-center gap-1.5 text-xs shadow-2xs transition-all text-center"
          >
            <DollarSign className="w-4 h-4 text-blue-600" />
            <span>Buku Kas</span>
            <span className="text-[10px] text-slate-400 font-normal">({transactions.length} Mutasi)</span>
          </button>

          <button
            type="button"
            onClick={() => downloadCsvForTable('iuran', { citizens })}
            className="p-3 bg-white hover:bg-slate-100 border border-slate-200 rounded-xl font-bold text-slate-700 flex flex-col items-center justify-center gap-1.5 text-xs shadow-2xs transition-all text-center"
          >
            <Layers className="w-4 h-4 text-purple-600" />
            <span>Rekap Iuran</span>
            <span className="text-[10px] text-slate-400 font-normal">(12 Bulan)</span>
          </button>

          <button
            type="button"
            onClick={() => downloadCsvForTable('lelayu', { deathNotices })}
            className="p-3 bg-white hover:bg-slate-100 border border-slate-200 rounded-xl font-bold text-slate-700 flex flex-col items-center justify-center gap-1.5 text-xs shadow-2xs transition-all text-center"
          >
            <Heart className="w-4 h-4 text-rose-600" />
            <span>Lelayu Duka</span>
            <span className="text-[10px] text-slate-400 font-normal">({deathNotices.length} Arsip)</span>
          </button>

          <button
            type="button"
            onClick={() => downloadCsvForTable('aset', { assets })}
            className="p-3 bg-white hover:bg-slate-100 border border-slate-200 rounded-xl font-bold text-slate-700 flex flex-col items-center justify-center gap-1.5 text-xs shadow-2xs transition-all text-center"
          >
            <Package className="w-4 h-4 text-amber-600" />
            <span>Inventaris Aset</span>
            <span className="text-[10px] text-slate-400 font-normal">({assets.length} Item)</span>
          </button>

          <button
            type="button"
            onClick={() => downloadCsvForTable('pengurus', { officers })}
            className="p-3 bg-white hover:bg-slate-100 border border-slate-200 rounded-xl font-bold text-slate-700 flex flex-col items-center justify-center gap-1.5 text-xs shadow-2xs transition-all text-center"
          >
            <ShieldCheck className="w-4 h-4 text-indigo-600" />
            <span>Data Pengurus</span>
            <span className="text-[10px] text-slate-400 font-normal">({officers.length} Satgas)</span>
          </button>

        </div>
      </div>

      {/* Reset Section */}
      <div className="pt-3 border-t border-slate-100">
        <div className="bg-rose-50/70 rounded-2xl p-5 border border-rose-200/80 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div>
            <h3 className="font-extrabold text-sm text-rose-950 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-600" />
              Reset ke Pengaturan Pabrik (Kosongkan Semua Data)
            </h3>
            <p className="text-xs text-rose-800 mt-0.5">
              Kosongkan seluruh data sistem (user, pengurus, data warga, buku kas, aset, lelayu, log) dan sisakan hanya akun Super Admin (Babeh/admin).
            </p>
          </div>

          <button
            id="btn-factory-reset"
            type="button"
            onClick={() => {
              if (confirm('PERINGATAN RESIKO TINGGI:\nApakah Anda yakin ingin mengosongkan seluruh database (kembali ke pengaturan pabrik)?\n\nSemua data warga, pengurus, buku kas, inventaris aset, dan user non-superadmin akan dihapus bersih tanpa database.')) {
                resetToDefaultData();
                setImportMessage({
                  type: 'success',
                  text: '✓ Seluruh data berhasil dikosongkan (kembali ke pengaturan pabrik). Hanya akun Super Admin yang dipertahankan.'
                });
              }
            }}
            className="px-4 py-2.5 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold rounded-xl shadow transition-all whitespace-nowrap active:scale-95 cursor-pointer"
          >
            Reset ke Pengaturan Pabrik
          </button>
        </div>
      </div>

      {/* Modal Pratinjau Pemulihan (Restore Preview Modal) */}
      {showPreviewModal && previewBackupData && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-xs animate-fade-in">
          <div className="bg-white rounded-3xl p-6 max-w-lg w-full shadow-2xl border border-slate-200/80 space-y-4">
            
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-blue-100 text-blue-800 rounded-xl">
                  <Database className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-base text-slate-900">
                    Konfirmasi Pemulihan Database
                  </h3>
                  <p className="text-xs text-slate-500">Pratinjau isi file cadangan JSON</p>
                </div>
              </div>

              <button
                onClick={() => setShowPreviewModal(false)}
                className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-slate-500">Aplikasi Sumber:</span>
                  <span className="font-bold text-slate-800">{previewBackupData.appName || 'RKM MPP DIGITAL'}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-500">Versi Cadangan:</span>
                  <span className="font-mono text-slate-800">{previewBackupData.version || '2.5.0'}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-500">Tanggal Ekspor:</span>
                  <span className="font-mono text-slate-800">
                    {previewBackupData.exportDate ? formatDateTimeIndo(previewBackupData.exportDate) : 'Tidak tercatat'}
                  </span>
                </div>
              </div>

              {/* Data Summary Breakdown */}
              <div className="grid grid-cols-2 gap-2">
                <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200 text-center">
                  <span className="font-black text-base text-emerald-800 font-mono block">
                    {Array.isArray(previewBackupData.citizens) ? previewBackupData.citizens.length : 0}
                  </span>
                  <span className="text-[11px] text-emerald-900 font-bold">Kartu Keluarga (KK)</span>
                </div>

                <div className="p-3 bg-blue-50 rounded-xl border border-blue-200 text-center">
                  <span className="font-black text-base text-blue-800 font-mono block">
                    {Array.isArray(previewBackupData.transactions) ? previewBackupData.transactions.length : 0}
                  </span>
                  <span className="text-[11px] text-blue-900 font-bold">Transaksi Buku Kas</span>
                </div>

                <div className="p-3 bg-rose-50 rounded-xl border border-rose-200 text-center">
                  <span className="font-black text-base text-rose-800 font-mono block">
                    {Array.isArray(previewBackupData.deathNotices) ? previewBackupData.deathNotices.length : 0}
                  </span>
                  <span className="text-[11px] text-rose-900 font-bold">Arsip Lelayu Duka</span>
                </div>

                <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-center">
                  <span className="font-black text-base text-amber-800 font-mono block">
                    {Array.isArray(previewBackupData.assets) ? previewBackupData.assets.length : 0}
                  </span>
                  <span className="text-[11px] text-amber-900 font-bold">Item Aset Inventaris</span>
                </div>
              </div>

              <div className="p-3 bg-rose-50 rounded-xl border border-rose-200 text-rose-900 text-[11px] flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                <span>
                  Perhatian: Tindakan ini akan menimpa data yang sedang aktif pada peramban Anda dengan isi berkas cadangan di atas.
                </span>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2.5">
              <button
                type="button"
                onClick={() => setShowPreviewModal(false)}
                className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl"
              >
                Batal
              </button>

              <button
                type="button"
                disabled={isRestoring}
                onClick={handleConfirmRestore}
                className="flex items-center gap-2 px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow transition-all disabled:opacity-50 cursor-pointer active:scale-98"
              >
                {isRestoring ? (
                  <RefreshCw className="w-4 h-4 animate-spin" />
                ) : (
                  <Check className="w-4 h-4" />
                )}
                <span>{isRestoring ? 'Memulihkan...' : 'Konfirmasi & Pulihkan Database'}</span>
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
