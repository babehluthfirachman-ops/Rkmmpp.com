import React, { useState } from 'react';
import { 
  HeartHandshake, 
  Plus, 
  Share2, 
  Printer, 
  MapPin, 
  Clock, 
  CheckCircle2, 
  AlertCircle, 
  ShieldCheck, 
  Calendar,
  Send,
  MessageSquare,
  Users,
  Box,
  Truck,
  Scale,
  FileText,
  ExternalLink,
  Copy
} from 'lucide-react';
import { useRkm } from '../context/RkmContext';
import { formatRupiah, formatDateIndo, createWhatsAppUrl } from '../utils/formatters';
import { DeathNotice } from '../types';
import { DutyScheduleManager } from './DutyScheduleManager';

export const DeathServicesView: React.FC = () => {
  const { 
    deathNotices, 
    addDeathNotice, 
    updateDeathNotice,
    openLelayuModal, 
    settings, 
    citizens, 
    currentRole 
  } = useRkm();

  const [activeSubTab, setActiveSubTab] = useState<'notices' | 'piket'>('notices');
  const [showAddModal, setShowAddModal] = useState(false);
  const [waBroadcastNotice, setWaBroadcastNotice] = useState<DeathNotice | null>(null);
  const [selectedWaGroup, setSelectedWaGroup] = useState<string>('all');
  const [customBroadcastText, setCustomBroadcastText] = useState<string>('');
  const [copiedBroadcast, setCopiedBroadcast] = useState(false);
  const [broadcastSentSuccess, setBroadcastSentSuccess] = useState(false);

  // Add Death Notice Form
  const [deceasedName, setDeceasedName] = useState('');
  const [binBinti, setBinBinti] = useState('');
  const [age, setAge] = useState<number | ''>(65);
  const [gender, setGender] = useState<'Laki-laki' | 'Perempuan'>('Perempuan');
  const [passAwayTime, setPassAwayTime] = useState('04:30 WIB');
  const [funeralTime, setFuneralTime] = useState('Ba\'da Dzuhur (13:00 WIB)');
  const [cemeteryName, setCemeteryName] = useState('TPU Parung Panjang');
  const [address, setAddress] = useState('Perumahan Metro Parung Panjang');
  const [rt, setRt] = useState('02');
  const [rw, setRw] = useState('08');
  const [noKK, setNoKK] = useState('3201082903820002');
  const [mosqueName, setMosqueName] = useState('Masjid Metro Parung Panjang');
  const [passAwayLocation, setPassAwayLocation] = useState('Rumah Duka');
  const [contactPerson, setContactPerson] = useState('');
  const [contactPhone, setContactPhone] = useState('');
  const [rkmAssistanceAmount, setRkmAssistanceAmount] = useState<number>(settings.deathBenefitAmount);
  const [notes, setNotes] = useState('');

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!deceasedName.trim() || !binBinti.trim()) return;

    const newNotice: Omit<DeathNotice, 'id' | 'createdAt'> = {
      deceasedName,
      binBinti,
      gender,
      age: Number(age) || 60,
      noKK,
      address,
      rt,
      rw,
      passAwayTime,
      passAwayLocation,
      funeralTime,
      mosqueName,
      cemeteryName,
      contactPerson: contactPerson || 'Ahli Waris',
      contactPhone: contactPhone || '08123456789',
      rkmAssistanceAmount: Number(rkmAssistanceAmount) || settings.deathBenefitAmount,
      shroudsProvided: true,
      ambulanceProvided: true,
      graveDiggerAssigned: true,
      status: 'Aktif',
      notes
    };

    addDeathNotice(newNotice);
    setShowAddModal(false);
  };

  const handleOpenWaBroadcast = (notice: DeathNotice) => {
    setWaBroadcastNotice(notice);
    setBroadcastSentSuccess(false);
    
    const msg = 
`*BERITA DUKA CITA (LELAYU)*
*${settings.orgName.toUpperCase()}*
────────────────────────────
_Inna lillahi wa inna ilaihi raji'un_
(إِنَّا لِلَّٰهِ وَإِنَّا إِلَيْهِ رَاجِعُونَ)

Telah berpulang ke Rahmatullah, saudara/i kita tercinta:

*Nama Almarhum/ah:*
*${notice.deceasedName} bin/binti ${notice.binBinti}*
• *Usia:* ${notice.age} Tahun
• *Alamat Duka:* ${notice.address} (RT ${notice.rt} / RW ${notice.rw})

*INFORMASI PEMAKAMAN:*
• *Waktu Wafat:* ${notice.passAwayTime}
• *Tempat Wafat:* ${notice.passAwayLocation}
• *Sholat Jenazah:* ${notice.funeralTime}
• *Lokasi Sholat:* ${notice.mosqueName}
• *Pemakaman:* ${notice.cemeteryName}

*KONTAK KELUARGA / AHLI WARIS:*
• ${notice.contactPerson} (${notice.contactPhone})

*PELAYANAN FARDHU KIFAYAH RKM MPP:*
${notice.shroudsProvided ? '✓ Perlengkapan Kain Kafan & Tim Pemulasaraan Siaga\n' : ''}${notice.ambulanceProvided ? '✓ Mobil Ambulance Jenazah Siaga\n' : ''}${notice.graveDiggerAssigned ? '✓ Koordinasi Tim Penggali Makam TPU\n' : ''}✓ Uang Santunan Duka: ${formatRupiah(notice.rkmAssistanceAmount)}

Semoga Almarhum/ah diampuni segala dosa-dosanya, diterima seluruh amal ibadahnya, dan keluarga yang ditinggalkan diberikan ketabahan dan keikhlasan. Aamiin ya Rabbal 'Alamin.

_Pengurus Paguyuban RKM MPP_
*Pusat Bantuan 24 Jam:* ${settings.contactCenter}`;

    setCustomBroadcastText(msg);
  };

  const handleSendWaBroadcast = () => {
    if (!customBroadcastText) return;
    const url = `https://api.whatsapp.com/send?text=${encodeURIComponent(customBroadcastText)}`;
    window.open(url, '_blank');
    setBroadcastSentSuccess(true);
    setTimeout(() => {
      setBroadcastSentSuccess(false);
    }, 4000);
  };

  const handleCopyBroadcastText = () => {
    navigator.clipboard.writeText(customBroadcastText);
    setCopiedBroadcast(true);
    setTimeout(() => setCopiedBroadcast(false), 2500);
  };

  const handleContactFamily = (phone: string, name: string) => {
    const cleanPhone = phone.replace(/[^0-9]/g, '');
    const formattedPhone = cleanPhone.startsWith('0') ? '62' + cleanPhone.slice(1) : cleanPhone;
    const text = encodeURIComponent(`Assalamu'alaikum Wr. Wb. Kami dari Pengurus RKM MPP ingin berkoordinasi terkait pemulasaraan jenazah dan santunan duka almarhum/ah keluarga Bapak/Ibu ${name}.`);
    window.open(`https://wa.me/${formattedPhone}?text=${text}`, '_blank');
  };

  return (
    <div className="space-y-6 pb-12 animate-fade-in">
      
      {/* Header */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 bg-rose-100 text-rose-700 rounded-xl">
              <HeartHandshake className="w-5 h-5" />
            </span>
            <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900">Layanan Duka & Berita Lelayu</h1>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Protokol penanganan jenazah terpadu, santunan kematian, dan broadcast kabar duka ke warga.
          </p>
        </div>

        {currentRole !== 'warga' && (
          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-2 px-5 py-2.5 bg-rose-600 hover:bg-rose-700 active:scale-98 text-white font-bold text-xs sm:text-sm rounded-xl shadow-md transition-all self-start md:self-auto"
          >
            <Plus className="w-4 h-4" />
            <span>Lapor Kematian / Input Lelayu</span>
          </button>
        )}
      </div>

      {/* Sub-Tab Navigation Bar */}
      <div className="flex items-center gap-2 bg-slate-100 p-1.5 rounded-2xl w-fit">
        <button
          onClick={() => setActiveSubTab('notices')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            activeSubTab === 'notices'
              ? 'bg-white text-slate-900 shadow-sm'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <HeartHandshake className="w-4 h-4 text-rose-600" />
          <span>Berita Duka & Maklumat Lelayu ({deathNotices.length})</span>
        </button>

        <button
          onClick={() => setActiveSubTab('piket')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            activeSubTab === 'piket'
              ? 'bg-white text-slate-900 shadow-sm'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Calendar className="w-4 h-4 text-emerald-600" />
          <span>Jadwal Piket Petugas Satgas 24 Jam</span>
        </button>
      </div>

      {activeSubTab === 'piket' ? (
        <DutyScheduleManager />
      ) : (
        <>
          {/* SOP 5 Langkah Siaga Kematian Paguyuban */}
          <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-emerald-950 text-white rounded-3xl p-6 sm:p-7 shadow-lg border border-slate-800">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-extrabold text-base text-emerald-400 flex items-center gap-2">
                <ShieldCheck className="w-5 h-5" />
                Standar Operasional Prosedur (SOP) Penanganan Jenazah RKM
              </h3>
              <span className="text-[10px] bg-amber-500/20 text-amber-300 font-extrabold px-2 py-0.5 rounded-full border border-amber-500/30">
                AD/ART 2024–2027
              </span>
            </div>
            <p className="text-xs text-slate-300 mt-1">
              Layanan cepat tanggap 24 jam fardhu kifayah bagi seluruh keluarga anggota berduka sesuai Pasal 2, 3 & 6 ART RKM MPP.
            </p>
          </div>

          <a
            href="https://drive.google.com/file/d/1itGAXcxzcn0Wg9uqoHnc1fniJzUJKX83/view?usp=sharing"
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-emerald-300 text-xs font-semibold border border-white/20 transition-all shrink-0 self-start sm:self-auto"
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Regulasi AD/ART PDF</span>
            <ExternalLink className="w-3 h-3" />
          </a>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 mt-5">
          <div className="bg-white/10 p-3.5 rounded-2xl border border-white/10">
            <div className="w-6 h-6 rounded-full bg-emerald-500 text-slate-950 font-black text-xs flex items-center justify-center mb-2">1</div>
            <h4 className="font-bold text-xs text-white">Logistik & Kain Kafan</h4>
            <p className="text-[11px] text-slate-300 mt-1">Petugas mengantarkan 1 set kain kafan, sabun, wewangian, dan tikar ke rumah duka.</p>
          </div>

          <div className="bg-white/10 p-3.5 rounded-2xl border border-white/10">
            <div className="w-6 h-6 rounded-full bg-emerald-500 text-slate-950 font-black text-xs flex items-center justify-center mb-2">2</div>
            <h4 className="font-bold text-xs text-white">Peralatan & Tenda</h4>
            <p className="text-[11px] text-slate-300 mt-1">Pemasangan tenda duka, kursi pelayat, keranda jenazah, dan sound system.</p>
          </div>

          <div className="bg-white/10 p-3.5 rounded-2xl border border-white/10">
            <div className="w-6 h-6 rounded-full bg-emerald-500 text-slate-950 font-black text-xs flex items-center justify-center mb-2">3</div>
            <h4 className="font-bold text-xs text-white">Pemulasaraan & Sholat</h4>
            <p className="text-[11px] text-slate-300 mt-1">Pendampingan tim ustadz/ustadzah untuk memandikan, mengkafani, dan mensholatkan.</p>
          </div>

          <div className="bg-white/10 p-3.5 rounded-2xl border border-white/10">
            <div className="w-6 h-6 rounded-full bg-emerald-500 text-slate-950 font-black text-xs flex items-center justify-center mb-2">4</div>
            <h4 className="font-bold text-xs text-white">Ambulance & Makam</h4>
            <p className="text-[11px] text-slate-300 mt-1">Mobil ambulance siap antar & koordinasi tim penggali kubur di TPU setempat.</p>
          </div>

          <div className="bg-white/10 p-3.5 rounded-2xl border border-white/10">
            <div className="w-6 h-6 rounded-full bg-emerald-500 text-slate-950 font-black text-xs flex items-center justify-center mb-2">5</div>
            <h4 className="font-bold text-xs text-white">Santunan Tunai Duka</h4>
            <p className="text-[11px] text-slate-300 mt-1">Penyerahan santunan tunai {formatRupiah(settings.deathBenefitAmount)} ke ahli waris.</p>
          </div>
        </div>
      </div>

      {/* List of Death Notices (Lelayu) */}
      <div className="space-y-4">
        <h2 className="font-extrabold text-base text-slate-900">
          Daftar Catatan Berita Lelayu & Santunan
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {deathNotices.map((notice) => (
            <div
              key={notice.id}
              className="bg-white rounded-3xl border border-slate-200/80 p-6 shadow-sm hover:shadow-md transition-all flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className={`text-[10px] font-extrabold px-2.5 py-0.5 rounded-full uppercase tracking-wider ${
                        notice.status === 'Aktif' ? 'bg-rose-100 text-rose-800' : 'bg-slate-100 text-slate-700'
                      }`}>
                        {notice.status === 'Aktif' ? 'PROSES PEMAKAMAN AKTIF' : 'SELESAI PEMAKAMAN'}
                      </span>
                      <button
                        type="button"
                        onClick={() => updateDeathNotice(notice.id, { status: notice.status === 'Aktif' ? 'Selesai' : 'Aktif' })}
                        className="text-[10px] font-bold text-slate-500 hover:text-emerald-700 bg-slate-100 hover:bg-slate-200 px-2 py-0.5 rounded-md cursor-pointer transition-colors"
                        title="Klik untuk ubah status laporan duka (otomatis terekam ke Activity Log)"
                      >
                        {notice.status === 'Aktif' ? 'Tandai Selesai' : 'Aktifkan Kembali'}
                      </button>
                    </div>
                    <h3 className="text-lg font-black text-slate-900 mt-2">
                      Almh. {notice.deceasedName}
                    </h3>
                    <p className="text-xs text-slate-600 font-medium">
                      Bin/Binti: <strong>{notice.binBinti}</strong> • Usia: {notice.age} Tahun
                    </p>
                  </div>

                  <div className="p-3 bg-slate-100 rounded-2xl text-slate-700 shrink-0">
                    <HeartHandshake className="w-6 h-6 text-rose-600" />
                  </div>
                </div>

                {/* Details list */}
                <div className="mt-4 space-y-2 text-xs text-slate-600 bg-slate-50 p-4 rounded-2xl">
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-slate-400 shrink-0" />
                    <span><strong>Waktu Wafat:</strong> {notice.passAwayTime} ({notice.passAwayLocation})</span>
                  </div>

                  <div className="flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-slate-400 shrink-0" />
                    <span><strong>Rumah Duka:</strong> {notice.address}</span>
                  </div>

                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-slate-400 shrink-0" />
                    <span><strong>Makam:</strong> {notice.cemeteryName} ({notice.funeralTime})</span>
                  </div>

                  <div className="flex items-center gap-2 pt-2 border-t border-slate-200/60 font-bold text-emerald-800">
                    <span>💵 Santunan RKM: {formatRupiah(notice.rkmAssistanceAmount)} (Lunas diserahkan)</span>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="mt-5 pt-3 border-t border-slate-100 flex flex-wrap gap-2">
                <button
                  onClick={() => openLelayuModal(notice)}
                  className="flex-1 min-w-[130px] py-2.5 px-3 bg-slate-900 hover:bg-slate-800 active:scale-98 text-white font-bold text-xs rounded-xl shadow-sm transition-all flex items-center justify-center gap-1.5"
                >
                  <FileText className="w-4 h-4 text-emerald-400" />
                  <span>Surat Lelayu</span>
                </button>

                <button
                  onClick={() => handleOpenWaBroadcast(notice)}
                  className="flex-1 min-w-[140px] py-2.5 px-3 bg-emerald-600 hover:bg-emerald-700 active:scale-98 text-white font-bold text-xs rounded-xl shadow-sm transition-all flex items-center justify-center gap-1.5"
                >
                  <MessageSquare className="w-4 h-4" />
                  <span>Broadcast WA Grup</span>
                </button>

                {notice.contactPhone && (
                  <button
                    onClick={() => handleContactFamily(notice.contactPhone, notice.deceasedName)}
                    className="p-2.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 rounded-xl text-xs font-bold transition-all flex items-center gap-1"
                    title={`Hubungi Ahli Waris (${notice.contactPerson}): ${notice.contactPhone}`}
                  >
                    <Send className="w-4 h-4 text-emerald-600" />
                    <span className="hidden sm:inline">Hubungi Keluarga</span>
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </>
  )}

      {/* Add Death Notice Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-sm animate-fade-in">
          <div className="bg-white rounded-3xl p-6 max-w-xl w-full shadow-2xl border border-slate-100 max-h-[90vh] overflow-y-auto">
            
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="font-extrabold text-base text-slate-900">
                Formulir Laporan Kematian & Terbit Lelayu
              </h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleAddSubmit} className="mt-4 space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-700 font-bold block mb-1">Nama Almarhum/Almarhumah:</label>
                  <input
                    type="text"
                    placeholder="Nama lengkap almarhum"
                    value={deceasedName}
                    onChange={(e) => setDeceasedName(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-bold text-slate-900"
                    required
                  />
                </div>

                <div>
                  <label className="text-slate-700 font-bold block mb-1">Bin / Binti:</label>
                  <input
                    type="text"
                    placeholder="Nama ayah kandung"
                    value={binBinti}
                    onChange={(e) => setBinBinti(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-semibold"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="text-slate-700 font-bold block mb-1">Usia (Tahun):</label>
                  <input
                    type="number"
                    value={age}
                    onChange={(e) => setAge(Number(e.target.value) || '')}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-semibold"
                    required
                  />
                </div>

                <div>
                  <label className="text-slate-700 font-bold block mb-1">Jam / Waktu Wafat:</label>
                  <input
                    type="text"
                    placeholder="05:30 WIB (Pagi)"
                    value={passAwayTime}
                    onChange={(e) => setPassAwayTime(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-semibold"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="text-slate-700 font-bold block mb-1">Alamat Lengkap Rumah Duka:</label>
                <input
                  type="text"
                  placeholder="Jl. Melati No. 4 RT 03/RW 08"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-semibold"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-700 font-bold block mb-1">Lokasi Pemakaman (TPU):</label>
                  <input
                    type="text"
                    placeholder="TPU Sirnaraga"
                    value={cemeteryName}
                    onChange={(e) => setCemeteryName(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-semibold"
                    required
                  />
                </div>

                <div>
                  <label className="text-slate-700 font-bold block mb-1">Waktu Pemakaman:</label>
                  <input
                    type="text"
                    placeholder="Ba'da Ashar (16:00 WIB)"
                    value={funeralTime}
                    onChange={(e) => setFuneralTime(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-semibold"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-700 font-bold block mb-1">Nama Kontak Ahli Waris:</label>
                  <input
                    type="text"
                    placeholder="Nama perwakilan keluarga"
                    value={contactPerson}
                    onChange={(e) => setContactPerson(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-semibold"
                  />
                </div>

                <div>
                  <label className="text-slate-700 font-bold block mb-1">No. HP Ahli Waris:</label>
                  <input
                    type="text"
                    placeholder="08123456789"
                    value={contactPhone}
                    onChange={(e) => setContactPhone(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-semibold"
                  />
                </div>
              </div>

              <div>
                <label className="text-slate-700 font-bold block mb-1">Nominal Santunan Duka Kas Paguyuban (Rp):</label>
                <input
                  type="number"
                  value={rkmAssistanceAmount}
                  onChange={(e) => setRkmAssistanceAmount(Number(e.target.value) || 0)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-mono font-bold text-emerald-800"
                  required
                />
              </div>

              <div className="pt-3 border-t border-slate-100 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-6 py-2 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-xl shadow"
                >
                  Terbitkan Lelayu & Santunan
                </button>
              </div>
            </form>

          </div>
        </div>
      )}

      {/* WhatsApp Community Broadcast Modal */}
      {waBroadcastNotice && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-sm animate-fade-in">
          <div className="bg-white rounded-3xl p-6 max-w-lg w-full shadow-2xl border border-slate-100 max-h-[90vh] overflow-y-auto">
            
            {/* Header */}
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-emerald-100 text-emerald-700 rounded-2xl">
                  <MessageSquare className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[10px] font-extrabold text-emerald-700 uppercase tracking-widest bg-emerald-50 px-2 py-0.5 rounded">
                    GATEWAY BROADCAST WHATSAPP
                  </span>
                  <h3 className="text-base font-extrabold text-slate-900 mt-0.5">
                    Sebarkan Berita Duka (Lelayu)
                  </h3>
                </div>
              </div>

              <button
                onClick={() => setWaBroadcastNotice(null)}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100"
              >
                ✕
              </button>
            </div>

            {/* Target Group Selector */}
            <div className="my-4 space-y-2">
              <label className="text-xs font-bold text-slate-700 block">
                Pilih Target WhatsApp Grup:
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {[
                  { id: 'all', label: 'Semua RT (Umum)' },
                  { id: 'rt01', label: 'Grup RT 01' },
                  { id: 'rt02', label: 'Grup RT 02' },
                  { id: 'rt03', label: 'Grup RT 03' },
                  { id: 'rt04', label: 'Grup RT 04' },
                  { id: 'rt05', label: 'Grup RT 05' },
                  { id: 'rt06', label: 'Grup RT 06' },
                  { id: 'dkm', label: 'Grup DKM / RW' }
                ].map(grp => (
                  <button
                    key={grp.id}
                    type="button"
                    onClick={() => setSelectedWaGroup(grp.id)}
                    className={`py-1.5 px-2 text-[11px] font-bold rounded-xl border transition-all ${
                      selectedWaGroup === grp.id
                        ? 'bg-emerald-700 text-white border-emerald-800 shadow-sm'
                        : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    {grp.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Message Preview / Editor */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-slate-700">
                  Format Teks Broadcast WhatsApp:
                </label>
                <button
                  type="button"
                  onClick={handleCopyBroadcastText}
                  className="text-[11px] font-bold text-emerald-700 hover:text-emerald-800 flex items-center gap-1"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>{copiedBroadcast ? 'Tersalin!' : 'Salin Teks'}</span>
                </button>
              </div>

              <textarea
                rows={10}
                value={customBroadcastText}
                onChange={(e) => setCustomBroadcastText(e.target.value)}
                className="w-full p-3 bg-slate-900 text-emerald-400 font-mono text-[11px] rounded-2xl border border-slate-800 focus:ring-2 focus:ring-emerald-500 leading-relaxed shadow-inner"
              />
            </div>

            {/* Notification alert */}
            {broadcastSentSuccess && (
              <div className="mt-3 p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs flex items-center gap-2 font-medium animate-fade-in">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>WhatsApp berhasil dibuka! Pesan duka siap disebarkan ke grup warga.</span>
              </div>
            )}

            {/* Footer Buttons */}
            <div className="mt-5 pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setWaBroadcastNotice(null)}
                className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl"
              >
                Tutup
              </button>

              <button
                type="button"
                onClick={handleSendWaBroadcast}
                className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white font-extrabold text-xs rounded-xl shadow-md transition-all flex items-center gap-2"
              >
                <Share2 className="w-4 h-4" />
                <span>Buka & Sebarkan ke WA</span>
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
