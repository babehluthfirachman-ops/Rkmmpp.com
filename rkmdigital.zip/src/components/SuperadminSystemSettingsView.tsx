import React, { useState } from 'react';
import { useRkm } from '../context/RkmContext';
import { SuperadminSystemSettings } from '../types';
import {
  ShieldAlert,
  Save,
  CheckCircle2,
  AlertTriangle,
  Building2,
  Camera,
  Lock,
  Database,
  Mail,
  RefreshCw,
  Download,
  KeyRound,
  FileText,
  Sliders,
  ExternalLink,
  Info,
  Server,
  Sparkles,
  HelpCircle,
  FileCheck
} from 'lucide-react';

interface ToastMessage {
  type: 'success' | 'error' | 'info';
  text: string;
}

export const SuperadminSystemSettingsView: React.FC = () => {
  const {
    currentUser,
    superadminSettings,
    updateSuperadminSettings,
    auditLogs,
    addAuditLog,
    citizens,
    transactions,
    deathNotices,
    assets
  } = useRkm();

  const [activeTab, setActiveTab] = useState<'general' | 'ocr' | 'security' | 'backup_logs'>('general');
  const [formData, setFormData] = useState<SuperadminSystemSettings>(superadminSettings);
  const [isSaving, setIsSaving] = useState(false);
  const [toast, setToast] = useState<ToastMessage | null>(null);
  const [isBackingUp, setIsBackingUp] = useState(false);
  const [backupStats, setBackupStats] = useState<{ timestamp: string; sizeKb: number } | null>(null);

  // Sync state if context changes
  React.useEffect(() => {
    setFormData(superadminSettings);
  }, [superadminSettings]);

  const showToast = (type: 'success' | 'error' | 'info', text: string) => {
    setToast({ type, text });
    setTimeout(() => {
      setToast(null);
    }, 4500);
  };

  const handleInputChange = (field: keyof SuperadminSystemSettings, value: any) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleSmtpChange = (field: keyof SuperadminSystemSettings['smtp'], value: any) => {
    setFormData(prev => ({
      ...prev,
      smtp: {
        ...prev.smtp,
        [field]: value
      }
    }));
  };

  const handleSaveChanges = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);

    try {
      // Basic client-side validation
      if (!formData.appName || formData.appName.trim() === '') {
        showToast('error', 'Nama aplikasi/sistem tidak boleh kosong.');
        setIsSaving(false);
        return;
      }

      if (formData.sessionTimeoutMinutes < 5 || formData.sessionTimeoutMinutes > 1440) {
        showToast('error', 'Durasi sesi login harus antara 5 s/d 1440 menit.');
        setIsSaving(false);
        return;
      }

      if (formData.maxUploadFileSizeMb < 1 || formData.maxUploadFileSizeMb > 100) {
        showToast('error', 'Batas ukuran file harus antara 1 s/d 100 MB.');
        setIsSaving(false);
        return;
      }

      // 1. Call Backend API
      const response = await fetch('/api/superadmin/settings', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-user-role': currentUser?.role || 'superadmin',
          'x-user-name': currentUser?.name || 'Super Admin'
        },
        body: JSON.stringify(formData)
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || `Server HTTP ${response.status}`);
      }

      const result = await response.json();
      const updated = result.settings || formData;

      // 2. Update Global Context
      await updateSuperadminSettings(updated);

      showToast('success', '✓ Pengaturan Sistem Superadmin berhasil disimpan dan disinkronisasi ke server.');
      
      addAuditLog({
        userName: currentUser?.name || 'Super Admin',
        userRole: 'superadmin',
        action: 'SUPERADMIN_SETTINGS_SAVED',
        details: `Simpan konfigurasi sistem (Tab: ${activeTab}, Maintenance: ${formData.maintenanceMode ? 'Aktif' : 'Non-Aktif'})`,
        ipAddress: '182.253.14.88 (Admin Panel)',
        status: 'Success'
      });
    } catch (err: any) {
      console.warn('API sync warning, applying local fallback:', err);
      // Fallback local update
      await updateSuperadminSettings(formData);
      showToast('info', 'Pengaturan disimpan di penyimpanan lokal (Server respons: ' + (err.message || 'offline') + ')');
    } finally {
      setIsSaving(false);
    }
  };

  // Trigger Manual Backup
  const handleTriggerManualBackup = async () => {
    setIsBackingUp(true);
    try {
      const backupPayload = {
        meta: {
          appName: formData.appName,
          version: '2024–2027 v2.4',
          exportDate: new Date().toISOString(),
          exportedBy: currentUser?.name || 'Super Admin',
          checksum: `SHA-${Date.now().toString(36).toUpperCase()}`
        },
        systemSettings: formData,
        database: {
          citizensCount: citizens.length,
          transactionsCount: transactions.length,
          deathNoticesCount: deathNotices.length,
          assetsCount: assets.length,
          auditLogsCount: auditLogs.length,
          citizens,
          transactions,
          deathNotices,
          assets,
          auditLogs
        }
      };

      // Call server backup route
      try {
        await fetch('/api/superadmin/backup', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-user-role': currentUser?.role || 'superadmin',
            'x-user-name': currentUser?.name || 'Super Admin'
          }
        });
      } catch (e) {
        // Continue if offline
      }

      // Download JSON File
      const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(backupPayload, null, 2));
      const downloadAnchor = document.createElement('a');
      const filename = `RKM_FULL_DATABASE_BACKUP_${new Date().toISOString().slice(0, 10)}.json`;
      downloadAnchor.setAttribute('href', dataStr);
      downloadAnchor.setAttribute('download', filename);
      document.body.appendChild(downloadAnchor);
      downloadAnchor.click();
      downloadAnchor.remove();

      const approxKb = Math.round(JSON.stringify(backupPayload).length / 1024);
      setBackupStats({
        timestamp: new Date().toLocaleTimeString('id-ID'),
        sizeKb: approxKb
      });

      handleInputChange('lastBackupDate', new Date().toLocaleString('id-ID'));

      addAuditLog({
        userName: currentUser?.name || 'Super Admin',
        userRole: 'superadmin',
        action: 'DATABASE_BACKUP_MANUAL',
        details: `Ekspor backup manual database penuh (${citizens.length} KK, ${transactions.length} Transaksi) - ${approxKb} KB`,
        ipAddress: '182.253.14.88 (Superadmin View)',
        status: 'Success'
      });

      showToast('success', `✓ File cadangan database berhasil diunduh (${approxKb} KB).`);
    } catch (err: any) {
      showToast('error', 'Gagal memicu backup database: ' + (err.message || 'Error'));
    } finally {
      setIsBackingUp(false);
    }
  };

  // Export Audit Logs as CSV
  const handleDownloadAuditLogsCsv = () => {
    try {
      let csv = 'ID,Waktu,Pengguna,Role,Aksi,Detail,IP Address,Status\n';
      auditLogs.forEach(l => {
        csv += `"${l.id}","${l.timestamp}","${l.userName}","${l.userRole}","${l.action}","${(l.details || '').replace(/"/g, '""')}","${l.ipAddress}","${l.status}"\n`;
      });

      const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.setAttribute('href', url);
      link.setAttribute('download', `RKM_AUDIT_LOGS_${new Date().toISOString().slice(0, 10)}.csv`);
      document.body.appendChild(link);
      link.click();
      link.remove();
      showToast('success', `✓ ${auditLogs.length} baris log audit berhasil diekspor ke format CSV.`);
    } catch (err: any) {
      showToast('error', 'Gagal mengekspor log audit.');
    }
  };

  // Export Error Logs as Text
  const handleDownloadErrorLogs = () => {
    try {
      const errorEntries = auditLogs.filter(l => l.status === 'Failed' || l.status === 'Warning');
      const content = [
        '====================================================================',
        'SYSTEM ERROR & WARNING AUDIT REPORT - RKM MPP DIGITAL',
        `Tanggal Ekstraksi: ${new Date().toLocaleString('id-ID')}`,
        `Total Entri Error/Warning: ${errorEntries.length}`,
        '====================================================================\n',
        ...errorEntries.map(e => `[${e.timestamp}] [${e.status}] [${e.action}] ${e.details} (User: ${e.userName} | Role: ${e.userRole} | IP: ${e.ipAddress})`)
      ].join('\n');

      const blob = new Blob([content], { type: 'text/plain;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.setAttribute('href', url);
      link.setAttribute('download', `RKM_SYSTEM_ERROR_LOGS_${new Date().toISOString().slice(0, 10)}.txt`);
      document.body.appendChild(link);
      link.click();
      link.remove();
      showToast('success', '✓ Laporan System Error Logs berhasil diunduh.');
    } catch (err) {
      showToast('error', 'Gagal mengunduh error logs.');
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Top Header Card */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-7 border border-slate-200 dark:border-slate-800 shadow-xs">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="flex items-start sm:items-center gap-3.5">
            <div className="p-3 bg-indigo-100 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-400 rounded-2xl shrink-0">
              <Sliders className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg sm:text-xl font-black text-slate-900 dark:text-white tracking-tight">
                  Pengaturan Sistem Superadmin
                </h1>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800">
                  Akses Khusus
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                Kendali penuh identitas brand, konfigurasi OCR & integrasi, kebijakan keamanan, dan manajemen backup sistem.
              </p>
            </div>
          </div>

          {/* Quick Actions & Status */}
          <div className="flex items-center gap-2.5">
            {formData.maintenanceMode && (
              <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-100 dark:bg-amber-950/70 border border-amber-300 dark:border-amber-800 text-amber-800 dark:text-amber-300 text-xs font-bold animate-pulse">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <span>Maintenance Mode Aktif</span>
              </div>
            )}
            <div className="text-right hidden sm:block">
              <span className="text-[10px] text-slate-600 block">Terakhir Disinkronisasi</span>
              <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                {formData.updatedAt || 'Baru Saja'}
              </span>
            </div>
          </div>
        </div>

        {/* Toast Feedback Notification */}
        {toast && (
          <div
            className={`mt-4 p-4 rounded-2xl text-xs font-bold flex items-center justify-between transition-all ${
              toast.type === 'success'
                ? 'bg-emerald-50 dark:bg-emerald-950/50 text-emerald-900 dark:text-emerald-200 border border-emerald-200 dark:border-emerald-800'
                : toast.type === 'error'
                ? 'bg-rose-50 dark:bg-rose-950/50 text-rose-900 dark:text-rose-200 border border-rose-200 dark:border-rose-800'
                : 'bg-sky-50 dark:bg-sky-950/50 text-sky-900 dark:text-sky-200 border border-sky-200 dark:border-sky-800'
            }`}
          >
            <div className="flex items-center gap-2">
              {toast.type === 'success' ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
              ) : toast.type === 'error' ? (
                <AlertTriangle className="w-4 h-4 text-rose-600 dark:text-rose-400 shrink-0" />
              ) : (
                <Info className="w-4 h-4 text-sky-600 dark:text-sky-400 shrink-0" />
              )}
              <span>{toast.text}</span>
            </div>
            <button
              type="button"
              onClick={() => setToast(null)}
              className="text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 text-xs cursor-pointer"
            >
              ✕
            </button>
          </div>
        )}

        {/* Tab Navigation Controls */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 mt-6 border-b border-slate-100 dark:border-slate-800">
          <button
            id="tab-superadmin-general"
            type="button"
            onClick={() => setActiveTab('general')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs font-extrabold transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'general'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-900/20'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700'
            }`}
          >
            <Building2 className="w-4 h-4" />
            <span>1. Identitas & Brand</span>
          </button>

          <button
            id="tab-superadmin-ocr"
            type="button"
            onClick={() => setActiveTab('ocr')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs font-extrabold transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'ocr'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-900/20'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700'
            }`}
          >
            <Camera className="w-4 h-4" />
            <span>2. OCR & Integrasi</span>
          </button>

          <button
            id="tab-superadmin-security"
            type="button"
            onClick={() => setActiveTab('security')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs font-extrabold transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'security'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-900/20'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700'
            }`}
          >
            <Lock className="w-4 h-4" />
            <span>3. Keamanan & Akses</span>
          </button>

          <button
            id="tab-superadmin-backup"
            type="button"
            onClick={() => setActiveTab('backup_logs')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs font-extrabold transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'backup_logs'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-900/20'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700'
            }`}
          >
            <Database className="w-4 h-4" />
            <span>4. Backup & Log Sistem</span>
          </button>
        </div>
      </div>

      {/* Main Settings Form */}
      <form onSubmit={handleSaveChanges} className="space-y-6">
        
        {/* TAB 1: IDENTITAS & BRAND APLIKASI + SMTP */}
        {activeTab === 'general' && (
          <div className="space-y-6">
            <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-7 border border-slate-200 dark:border-slate-800 shadow-xs space-y-5">
              <div className="border-b border-slate-100 dark:border-slate-800 pb-3">
                <h3 className="font-extrabold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                  <Building2 className="w-4 h-4 text-indigo-600" />
                  Identitas Brand & Tampilan Portal
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Atur nama resmi aplikasi, visual logo paguyuban, favicon browser, dan teks footer hak cipta.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    Nama Aplikasi / Sistem *
                  </label>
                  <input
                    id="input-app-name"
                    type="text"
                    required
                    value={formData.appName}
                    onChange={(e) => handleInputChange('appName', e.target.value)}
                    placeholder="Contoh: RKM MPP DIGITAL"
                    className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-2xl text-xs font-semibold text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  />
                  <p className="text-[11px] text-slate-600 mt-1">Ditampilkan pada judul browser, sidebar, dan header kuitansi.</p>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    URL Favicon (Ikon Tab Browser)
                  </label>
                  <input
                    id="input-favicon-url"
                    type="text"
                    value={formData.faviconUrl}
                    onChange={(e) => handleInputChange('faviconUrl', e.target.value)}
                    placeholder="/favicon.ico atau tautan HTTPS"
                    className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-2xl text-xs font-semibold text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  />
                </div>

                <div className="md:col-span-2">
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    URL Logo Resmi Paguyuban
                  </label>
                  <div className="flex flex-col sm:flex-row items-center gap-3">
                    <input
                      id="input-logo-url"
                      type="url"
                      value={formData.logoUrl}
                      onChange={(e) => handleInputChange('logoUrl', e.target.value)}
                      placeholder="https://... format PNG atau JPG"
                      className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-2xl text-xs font-semibold text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                    />
                    {formData.logoUrl && (
                      <div className="shrink-0 flex items-center gap-2 p-1.5 bg-slate-100 dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700">
                        <img
                          src={formData.logoUrl}
                          alt="Preview Logo"
                          className="w-9 h-9 object-cover rounded-xl"
                          onError={(e) => {
                            (e.target as HTMLElement).style.display = 'none';
                          }}
                        />
                        <span className="text-[10px] font-bold text-slate-500 px-1">Pratinjau</span>
                      </div>
                    )}
                  </div>
                </div>

                <div className="md:col-span-2">
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    Teks Footer & Hak Cipta
                  </label>
                  <input
                    id="input-footer-text"
                    type="text"
                    value={formData.footerText}
                    onChange={(e) => handleInputChange('footerText', e.target.value)}
                    placeholder="© 2024–2027 Rukun Kematian Metro Parung Panjang..."
                    className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-2xl text-xs font-semibold text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  />
                </div>
              </div>
            </div>

            {/* SMTP Configuration */}
            <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-7 border border-slate-200 dark:border-slate-800 shadow-xs space-y-5">
              <div className="border-b border-slate-100 dark:border-slate-800 pb-3 flex items-center justify-between">
                <div>
                  <h3 className="font-extrabold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                    <Mail className="w-4 h-4 text-indigo-600" />
                    Konfigurasi Alamat Email Sistem (SMTP)
                  </h3>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Pengaturan server mailer keluar untuk pengiriman kuitansi iuran, notifikasi lelayu, dan pemulihan akun.
                  </p>
                </div>
                <span className="px-2.5 py-1 rounded-full text-[10px] font-extrabold bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700">
                  SMTP Gateway
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    SMTP Host *
                  </label>
                  <input
                    type="text"
                    value={formData.smtp.host}
                    onChange={(e) => handleSmtpChange('host', e.target.value)}
                    placeholder="smtp.gmail.com"
                    className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-2xl text-xs font-semibold text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    SMTP Port *
                  </label>
                  <input
                    type="number"
                    value={formData.smtp.port}
                    onChange={(e) => handleSmtpChange('port', Number(e.target.value))}
                    placeholder="587 atau 465"
                    className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-2xl text-xs font-semibold text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  />
                </div>

                <div className="flex items-center pt-6">
                  <label className="flex items-center gap-2.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formData.smtp.secure}
                      onChange={(e) => handleSmtpChange('secure', e.target.checked)}
                      className="w-4 h-4 text-indigo-600 rounded-md border-slate-300 focus:ring-indigo-500"
                    />
                    <span className="text-xs font-bold text-slate-700 dark:text-slate-300">
                      Gunakan SSL/TLS Enkripsi
                    </span>
                  </label>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    SMTP Username / Email Akun *
                  </label>
                  <input
                    type="text"
                    value={formData.smtp.username}
                    onChange={(e) => handleSmtpChange('username', e.target.value)}
                    placeholder="rkmmpp@gmail.com"
                    className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-2xl text-xs font-semibold text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    SMTP Password / App Password
                  </label>
                  <input
                    type="password"
                    value={formData.smtp.password || ''}
                    onChange={(e) => handleSmtpChange('password', e.target.value)}
                    placeholder="••••••••••••••••"
                    className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-2xl text-xs font-semibold text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    Nama Pengirim Resmi (Sender Name)
                  </label>
                  <input
                    type="text"
                    value={formData.smtp.senderName}
                    onChange={(e) => handleSmtpChange('senderName', e.target.value)}
                    placeholder="RKM Metro Parung Panjang Notifikasi"
                    className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-2xl text-xs font-semibold text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  />
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: KONFIGURASI SISTEM OCR & INTEGRASI */}
        {activeTab === 'ocr' && (
          <div className="space-y-6">
            <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-7 border border-slate-200 dark:border-slate-800 shadow-xs space-y-5">
              <div className="border-b border-slate-100 dark:border-slate-800 pb-3">
                <h3 className="font-extrabold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                  <Camera className="w-4 h-4 text-indigo-600" />
                  Konfigurasi Layanan OCR (Optical Character Recognition)
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Ekstraksi otomatis No. KK, NIK, dan nama anggota keluarga langsung dari foto fisik Kartu Keluarga atau KTP warga.
                </p>
              </div>

              {/* Toggle Switch: Auto-Scan Kamera OCR */}
              <div className="p-4 rounded-2xl bg-indigo-50/50 dark:bg-indigo-950/30 border border-indigo-100 dark:border-indigo-900/60 flex items-center justify-between">
                <div className="space-y-0.5">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-extrabold text-slate-900 dark:text-white">
                      Aktifkan Fitur Auto-Scan Kamera OCR
                    </span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-extrabold bg-indigo-200/60 dark:bg-indigo-900 text-indigo-800 dark:text-indigo-300">
                      Live Video Scanner
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-600 dark:text-slate-400">
                    Bila aktif, pengurus dapat membuka kamera smartphone/laptop untuk mendeteksi KK secara langsung tanpa upload manual.
                  </p>
                </div>

                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    id="toggle-auto-scan-ocr"
                    type="checkbox"
                    checked={formData.autoScanCameraOcr}
                    onChange={(e) => handleInputChange('autoScanCameraOcr', e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
                </label>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    Endpoint Layanan OCR Vision / AI
                  </label>
                  <input
                    id="input-ocr-endpoint"
                    type="text"
                    value={formData.ocrEndpoint}
                    onChange={(e) => handleInputChange('ocrEndpoint', e.target.value)}
                    placeholder="https://generativelanguage.googleapis.com/..."
                    className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-2xl text-xs font-semibold text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  />
                  <p className="text-[11px] text-slate-600 mt-1">
                    Gunakan Gemini Vision API atau service proxy server bawaan.
                  </p>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    Batas Maksimal Ukuran File Unggahan (Max Upload Size in MB) *
                  </label>
                  <div className="relative">
                    <input
                      id="input-max-upload-size"
                      type="number"
                      min={1}
                      max={50}
                      value={formData.maxUploadFileSizeMb}
                      onChange={(e) => handleInputChange('maxUploadFileSizeMb', Number(e.target.value))}
                      className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-2xl text-xs font-semibold text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                    />
                    <span className="absolute right-4 top-2.5 text-xs font-bold text-slate-600">MB</span>
                  </div>
                  <p className="text-[11px] text-slate-600 mt-1">
                    Mencegah crash browser saat mengunggah foto resolusi tinggi kamera HP.
                  </p>
                </div>

                <div className="md:col-span-2">
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    API Key Layanan OCR / Google Cloud Vision (Opsional bila server-side)
                  </label>
                  <input
                    id="input-ocr-api-key"
                    type="password"
                    value={formData.ocrApiKey || ''}
                    onChange={(e) => handleInputChange('ocrApiKey', e.target.value)}
                    placeholder="AIzaSy... (Aman tersimpan dan tidak terekspos ke publik)"
                    className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-2xl text-xs font-semibold text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  />
                </div>
              </div>
            </div>

            {/* Google Workspace Integration */}
            <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-7 border border-slate-200 dark:border-slate-800 shadow-xs space-y-5">
              <div className="border-b border-slate-100 dark:border-slate-800 pb-3">
                <h3 className="font-extrabold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                  <Server className="w-4 h-4 text-indigo-600" />
                  Integrasi Google Workspace & Spreadsheet
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Sinkronisasi dua arah database warga dan laporan rekapitulasi kas ke Google Sheets cloud.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    Google Apps Script Webhook Endpoint
                  </label>
                  <input
                    type="url"
                    value={formData.googleWorkspaceEndpoint || ''}
                    onChange={(e) => handleInputChange('googleWorkspaceEndpoint', e.target.value)}
                    placeholder="https://script.google.com/macros/s/AKfycb.../exec"
                    className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-2xl text-xs font-semibold text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    Google Workspace Service Key / Token
                  </label>
                  <input
                    type="password"
                    value={formData.googleWorkspaceApiKey || ''}
                    onChange={(e) => handleInputChange('googleWorkspaceApiKey', e.target.value)}
                    placeholder="G-Suite Webhook Secret Key..."
                    className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-2xl text-xs font-semibold text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  />
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: KEAMANAN & KONTROL AKSES */}
        {activeTab === 'security' && (
          <div className="space-y-6">
            <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-7 border border-slate-200 dark:border-slate-800 shadow-xs space-y-5">
              <div className="border-b border-slate-100 dark:border-slate-800 pb-3">
                <h3 className="font-extrabold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                  <Lock className="w-4 h-4 text-indigo-600" />
                  Kebijakan Keamanan & Kontrol Akses Sistem
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Konfigurasi proteksi serangan brute force, batas kedaluwarsa sesi login, dan mode darurat pemeliharaan.
                </p>
              </div>

              {/* Maintenance Mode Toggle Card */}
              <div className={`p-4 sm:p-5 rounded-2xl border transition-all ${
                formData.maintenanceMode 
                  ? 'bg-amber-50 dark:bg-amber-950/40 border-amber-300 dark:border-amber-800' 
                  : 'bg-slate-50 dark:bg-slate-800/50 border-slate-200 dark:border-slate-700'
              }`}>
                <div className="flex items-center justify-between">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-black text-slate-900 dark:text-white">
                        Mode Perbaikan Sistem (Maintenance Mode)
                      </span>
                      {formData.maintenanceMode && (
                        <span className="px-2 py-0.5 rounded text-[10px] font-extrabold bg-amber-200 text-amber-900 dark:bg-amber-900 dark:text-amber-200">
                          Sedang Aktif
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-600 dark:text-slate-400 max-w-xl">
                      Bila diaktifkan, akses pengguna umum (warga, petugas lapangan) akan dialihkan ke halaman pemeliharaan sementara. Hanya akun dengan hak Super Admin yang dapat masuk.
                    </p>
                  </div>

                  <label className="relative inline-flex items-center cursor-pointer shrink-0">
                    <input
                      id="toggle-maintenance-mode"
                      type="checkbox"
                      checked={formData.maintenanceMode}
                      onChange={(e) => handleInputChange('maintenanceMode', e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-12 h-6 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-amber-600"></div>
                  </label>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    Batas Waktu Sesi Login (Session Timeout in minutes) *
                  </label>
                  <div className="relative">
                    <input
                      id="input-session-timeout"
                      type="number"
                      min={5}
                      max={1440}
                      value={formData.sessionTimeoutMinutes}
                      onChange={(e) => handleInputChange('sessionTimeoutMinutes', Number(e.target.value))}
                      className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-2xl text-xs font-semibold text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                    />
                    <span className="absolute right-4 top-2.5 text-xs font-bold text-slate-600">Menit</span>
                  </div>
                  <p className="text-[11px] text-slate-600 mt-1">
                    Sesi tidak aktif akan logout otomatis demi keamanan kas. (Default: 120 Menit).
                  </p>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    Batas Maksimal Percobaan Login Gagal (Max Login Attempts) *
                  </label>
                  <div className="relative">
                    <input
                      id="input-max-login-attempts"
                      type="number"
                      min={3}
                      max={10}
                      value={formData.maxLoginAttempts}
                      onChange={(e) => handleInputChange('maxLoginAttempts', Number(e.target.value))}
                      className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-2xl text-xs font-semibold text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                    />
                    <span className="absolute right-4 top-2.5 text-xs font-bold text-slate-600">Kali</span>
                  </div>
                  <p className="text-[11px] text-slate-600 mt-1">
                    Akun akan terkunci otomatis setelah mencapai batas percobaan salah.
                  </p>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    Minimal Panjang Karakter Password Baru *
                  </label>
                  <input
                    id="input-min-password-len"
                    type="number"
                    min={6}
                    max={24}
                    value={formData.passwordMinLength}
                    onChange={(e) => handleInputChange('passwordMinLength', Number(e.target.value))}
                    className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-2xl text-xs font-semibold text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  />
                </div>

                <div className="space-y-3 pt-2">
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
                    Aturan Kompleksitas Password
                  </label>
                  <div className="space-y-2">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={formData.passwordRequireNumber}
                        onChange={(e) => handleInputChange('passwordRequireNumber', e.target.checked)}
                        className="w-4 h-4 text-indigo-600 rounded-md border-slate-300 focus:ring-indigo-500"
                      />
                      <span className="text-xs font-medium text-slate-700 dark:text-slate-300">
                        Wajib menyertakan minimal 1 angka (0-9)
                      </span>
                    </label>

                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={formData.passwordRequireSpecialChar}
                        onChange={(e) => handleInputChange('passwordRequireSpecialChar', e.target.checked)}
                        className="w-4 h-4 text-indigo-600 rounded-md border-slate-300 focus:ring-indigo-500"
                      />
                      <span className="text-xs font-medium text-slate-700 dark:text-slate-300">
                        Wajib menyertakan simbol atau karakter khusus (!@#$%^&*)
                      </span>
                    </label>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: FITUR BACKUP & LOG SISTEM */}
        {activeTab === 'backup_logs' && (
          <div className="space-y-6">
            
            {/* Realtime Database Snapshot Stats */}
            <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-7 border border-slate-200 dark:border-slate-800 shadow-xs space-y-5">
              <div className="border-b border-slate-100 dark:border-slate-800 pb-3 flex items-center justify-between">
                <div>
                  <h3 className="font-extrabold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                    <Database className="w-4 h-4 text-indigo-600" />
                    Manajemen Backup Database & Rekam Cadangan
                  </h3>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Buat salinan data lengkap sistem RKM untuk proteksi arsip musyawarah warga dan audit keuangan.
                  </p>
                </div>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
                  Data Terproteksi
                </span>
              </div>

              {/* Database Counters */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="p-3.5 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200/80 dark:border-slate-700">
                  <span className="text-[10px] text-slate-600 block">Total Data KK Warga</span>
                  <span className="text-lg font-black text-slate-900 dark:text-white">{citizens.length} KK</span>
                </div>
                <div className="p-3.5 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200/80 dark:border-slate-700">
                  <span className="text-[10px] text-slate-600 block">Riwayat Transaksi Kas</span>
                  <span className="text-lg font-black text-slate-900 dark:text-white">{transactions.length} Baris</span>
                </div>
                <div className="p-3.5 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200/80 dark:border-slate-700">
                  <span className="text-[10px] text-slate-600 block">Laporan Duka & Santunan</span>
                  <span className="text-lg font-black text-slate-900 dark:text-white">{deathNotices.length} Kasus</span>
                </div>
                <div className="p-3.5 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200/80 dark:border-slate-700">
                  <span className="text-[10px] text-slate-600 block">Log Audit Aktivitas</span>
                  <span className="text-lg font-black text-slate-900 dark:text-white">{auditLogs.length} Entri</span>
                </div>
              </div>

              {/* Manual Backup Trigger Button */}
              <div className="p-4 rounded-2xl bg-indigo-50/60 dark:bg-indigo-950/30 border border-indigo-100 dark:border-indigo-900/60 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="space-y-1">
                  <span className="text-xs font-extrabold text-slate-900 dark:text-white block">
                    Trigger Manual Backup Database Lengkap
                  </span>
                  <p className="text-[11px] text-slate-600 dark:text-slate-400">
                    Menghasilkan file arsip JSON terenkripsi berisi seluruh tabel database paguyuban dan langsung mengunduh ke perangkat Anda.
                  </p>
                  {backupStats && (
                    <span className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400 block pt-1">
                      ✓ Terakhir dicadangkan pada pukul {backupStats.timestamp} ({backupStats.sizeKb} KB)
                    </span>
                  )}
                </div>

                <button
                  id="btn-trigger-manual-backup"
                  type="button"
                  onClick={handleTriggerManualBackup}
                  disabled={isBackingUp}
                  className="flex items-center justify-center gap-2 px-4 py-2.5 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold text-xs shadow-md shadow-indigo-900/20 cursor-pointer transition-all disabled:opacity-50 shrink-0"
                >
                  <Download className="w-4 h-4" />
                  <span>{isBackingUp ? 'Memproses Arsip...' : 'Trigger Manual Backup Database'}</span>
                </button>
              </div>
            </div>

            {/* System Logs Download Section */}
            <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-7 border border-slate-200 dark:border-slate-800 shadow-xs space-y-5">
              <div className="border-b border-slate-100 dark:border-slate-800 pb-3">
                <h3 className="font-extrabold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                  <FileText className="w-4 h-4 text-indigo-600" />
                  Pengunduhan Log Aktivitas & Laporan Sistem
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Unduh rekaman jejak audit pengguna dan berkas laporan error untuk keperluan pengawasan dan perbaikan bug.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                
                {/* Download Audit Logs CSV */}
                <div className="p-4 rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50/70 dark:bg-slate-800/40 flex flex-col justify-between space-y-3">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <FileCheck className="w-4 h-4 text-emerald-600" />
                      <span className="text-xs font-extrabold text-slate-900 dark:text-white">
                        Log Aktivitas Sistem (Audit Logs)
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-500">
                      Berisi seluruh rekam jejak pembayaran iuran, mutasi warga, login pengurus, dan pencairan santunan duka ({auditLogs.length} baris data).
                    </p>
                  </div>
                  <button
                    id="btn-download-audit-logs-csv"
                    type="button"
                    onClick={handleDownloadAuditLogsCsv}
                    className="flex items-center justify-center gap-2 px-3 py-2 bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 rounded-xl text-xs font-bold transition-all cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Unduh Audit Logs (.CSV)</span>
                  </button>
                </div>

                {/* Download System Error Logs */}
                <div className="p-4 rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50/70 dark:bg-slate-800/40 flex flex-col justify-between space-y-3">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <AlertTriangle className="w-4 h-4 text-amber-600" />
                      <span className="text-xs font-extrabold text-slate-900 dark:text-white">
                        System Error & Warning Logs
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-500">
                      Rekaman kejadian kegagalan sistem, insiden login terblokir, atau kendala sinkronisasi API untuk tim teknis.
                    </p>
                  </div>
                  <button
                    id="btn-download-error-logs"
                    type="button"
                    onClick={handleDownloadErrorLogs}
                    className="flex items-center justify-center gap-2 px-3 py-2 bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 rounded-xl text-xs font-bold transition-all cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Unduh System Error Logs (.TXT)</span>
                  </button>
                </div>

              </div>
            </div>
          </div>
        )}

        {/* Global Save Button Sticky Bar */}
        <div className="sticky bottom-4 z-20 p-4 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xl flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs text-slate-500">
            <Info className="w-4 h-4 text-indigo-600 shrink-0" />
            <span className="hidden sm:inline">Perubahan akan langsung berlaku pada seluruh portal dan diselaraskan ke database server.</span>
            <span className="sm:hidden">Klik simpan untuk menerapkan pengaturan.</span>
          </div>

          <div className="flex items-center gap-3">
            <button
              id="btn-save-superadmin-settings"
              type="submit"
              disabled={isSaving}
              className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 active:scale-95 text-white font-extrabold text-xs shadow-md shadow-indigo-900/20 transition-all cursor-pointer disabled:opacity-50"
            >
              {isSaving ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Menyimpan...</span>
                </>
              ) : (
                <>
                  <Save className="w-4 h-4" />
                  <span>Simpan Perubahan</span>
                </>
              )}
            </button>
          </div>
        </div>

      </form>

    </div>
  );
};
