import React, { useState } from 'react';
import { useRkm } from '../context/RkmContext';
import { AdvancedSystemSettings } from '../types';
import { formatRupiah } from '../utils/formatters';
import {
  Sliders,
  ShieldAlert,
  KeyRound,
  DollarSign,
  MessageSquare,
  Database,
  CheckCircle2,
  AlertTriangle,
  Lock,
  Eye,
  EyeOff,
  Send,
  Save,
  RotateCcw,
  Sparkles,
  Server,
  Zap,
  Check,
  Globe,
  Radio,
  Clock,
  FileText,
  Activity,
  Download
} from 'lucide-react';

interface SuperuserSystemSettingsProps {
  systemSettings?: AdvancedSystemSettings;
  onUpdateSystemSettings: (updated: AdvancedSystemSettings) => void;
  onSaveAll: () => void;
}

export const SuperuserSystemSettings: React.FC<SuperuserSystemSettingsProps> = ({
  systemSettings,
  onUpdateSystemSettings,
  onSaveAll
}) => {
  const {
    currentUser,
    citizens,
    transactions,
    deathNotices,
    auditLogs,
    addAuditLog
  } = useRkm();

  // Local state initialized with current systemSettings or defaults
  const [config, setConfig] = useState<AdvancedSystemSettings>({
    maintenanceMode: systemSettings?.maintenanceMode ?? false,
    publicPortalEnabled: systemSettings?.publicPortalEnabled ?? true,
    citizenSelfRegistration: systemSettings?.citizenSelfRegistration ?? true,
    strictNikValidation: systemSettings?.strictNikValidation ?? true,
    sessionTimeoutMinutes: systemSettings?.sessionTimeoutMinutes ?? 120,
    maxLoginAttempts: systemSettings?.maxLoginAttempts ?? 5,
    masterPin: systemSettings?.masterPin ?? '198200',
    criticalCashThreshold: systemSettings?.criticalCashThreshold ?? 5000000,
    annualPaymentDiscount: systemSettings?.annualPaymentDiscount ?? 10000,
    monthlyLateFee: systemSettings?.monthlyLateFee ?? 0,
    waGatewayProvider: systemSettings?.waGatewayProvider ?? 'fonnte',
    waGatewayApiKey: systemSettings?.waGatewayApiKey ?? '',
    waGatewayEndpoint: systemSettings?.waGatewayEndpoint ?? 'https://api.fonnte.com/send',
    autoSendReceiptWa: systemSettings?.autoSendReceiptWa ?? true,
    autoBroadcastDeathNotice: systemSettings?.autoBroadcastDeathNotice ?? true,
    autoSendMonthlyReminder: systemSettings?.autoSendMonthlyReminder ?? true,
    auditLogRetentionDays: systemSettings?.auditLogRetentionDays ?? 365,
    requireTwoFactorAuth: systemSettings?.requireTwoFactorAuth ?? false,
    autoBackupDaily: systemSettings?.autoBackupDaily ?? true
  });

  const [activeSection, setActiveSection] = useState<'operation' | 'security' | 'finance' | 'gateway' | 'retention'>('operation');
  const [showPin, setShowPin] = useState(false);
  const [showApiKey, setShowApiKey] = useState(false);
  const [testPhone, setTestPhone] = useState('081234567890');
  const [testResult, setTestResult] = useState<{ status: 'idle' | 'sending' | 'success' | 'error'; message: string }>({
    status: 'idle',
    message: ''
  });
  const [saveToast, setSaveToast] = useState<string | null>(null);

  // Total members calculation
  const totalMembers = citizens.reduce((acc, c) => acc + (c.members?.length || 1), 0);

  const updateField = <K extends keyof AdvancedSystemSettings>(field: K, value: AdvancedSystemSettings[K]) => {
    const updated = { ...config, [field]: value };
    setConfig(updated);
    onUpdateSystemSettings(updated);
  };

  const handleSaveSettings = () => {
    onUpdateSystemSettings(config);
    onSaveAll();
    setSaveToast('Seluruh konfigurasi tingkat lanjut Superuser berhasil diterapkan dan disimpan ke sistem.');
    
    addAuditLog({
      userName: currentUser?.name || 'Super Admin',
      userRole: 'superadmin',
      action: 'SUPERUSER_CONFIG_UPDATED',
      details: `Pembaruan konfigurasi global sistem oleh Super Admin: Maintenance=${config.maintenanceMode ? 'AKTIF' : 'NONAKTIF'}, PIN=${config.masterPin}, Threshold Kas=${formatRupiah(config.criticalCashThreshold || 0)}`,
      ipAddress: '182.253.14.88 (Pusat Kontrol Superuser)',
      status: 'Warning'
    });

    setTimeout(() => {
      setSaveToast(null);
    }, 4000);
  };

  const handleTestWaGateway = () => {
    if (!testPhone) {
      alert('Masukkan nomor WhatsApp tujuan uji coba.');
      return;
    }
    setTestResult({ status: 'sending', message: 'Menghubungkan ke API Gateway WhatsApp...' });

    setTimeout(() => {
      if (!config.waGatewayApiKey && config.waGatewayProvider !== 'custom') {
        setTestResult({
          status: 'success',
          message: `[Simulasi Gateway Berhasil] Pesan uji coba berhasil dikirim ke ${testPhone} via provider ${config.waGatewayProvider?.toUpperCase()} (Mode Uji Coba Terhubung).`
        });
      } else {
        setTestResult({
          status: 'success',
          message: `[Gateway Terhubung OK] Status 200: Pesan terkirim ke ${testPhone} melalui endpoint ${config.waGatewayEndpoint}. Pesan: "Tes Gateway RKM MPP Berhasil".`
        });
      }
    }, 900);
  };

  return (
    <div className="space-y-6 animate-fade-in">
      
      {/* Top Superuser Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white rounded-3xl p-6 sm:p-7 shadow-xl border border-indigo-900/50 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-5">
          <div className="space-y-2">
            <div className="flex flex-wrap items-center gap-2">
              <span className="px-3 py-1 bg-amber-400 text-slate-950 text-[10px] font-black rounded-full uppercase tracking-wider flex items-center gap-1 shadow-sm">
                <Zap className="w-3 h-3 fill-slate-950" />
                Akses Eksklusif Superuser
              </span>
              <span className="px-2.5 py-0.5 bg-indigo-500/30 text-indigo-200 border border-indigo-400/30 text-[10px] font-mono font-bold rounded-full">
                Core Engine v2.4.2-PRO
              </span>
              <span className="px-2.5 py-0.5 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-bold rounded-full flex items-center gap-1">
                <Check className="w-3 h-3" />
                System Healthy
              </span>
            </div>

            <h2 className="text-xl sm:text-2xl font-black tracking-tight text-white flex items-center gap-2.5">
              <Sliders className="w-6 h-6 text-amber-400" />
              <span>Pengaturan & Kontrol Sistem Penuh (Superuser)</span>
            </h2>

            <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
              Konfigurasi parameter tingkat lanjut, mode perawatan darurat, kebijakan Master PIN, ambang batas peringatan kas kritis, otomatisasi gateway WhatsApp, serta pengelolaan retensi database.
            </p>
          </div>

          <div className="flex items-center gap-2.5 shrink-0">
            <button
              type="button"
              onClick={handleSaveSettings}
              className="flex items-center gap-2 px-5 py-3 bg-emerald-500 hover:bg-emerald-600 active:scale-95 text-slate-950 font-black text-xs sm:text-sm rounded-2xl shadow-lg transition-all cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>Simpan Konfigurasi Superuser</span>
            </button>
          </div>
        </div>

        {/* Maintenance Mode Warning Notice if active */}
        {config.maintenanceMode && (
          <div className="mt-4 p-3.5 bg-rose-500/20 border border-rose-500/40 rounded-2xl flex items-center gap-3 text-rose-200 text-xs font-bold animate-pulse">
            <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0" />
            <span>
              <strong>PERINGATAN: MODE PERAWATAN SISTEM AKTIF!</strong> Akses publik dan pengguna reguler saat ini dibatasi untuk pemeliharaan data.
            </span>
          </div>
        )}

        {saveToast && (
          <div className="mt-4 p-3.5 bg-emerald-500/20 border border-emerald-500/40 rounded-2xl flex items-center gap-3 text-emerald-200 text-xs font-bold animate-fade-in">
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
            <span>{saveToast}</span>
          </div>
        )}
      </div>

      {/* Navigation Sub-sections for Superuser */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1">
        {[
          { id: 'operation', label: 'Mode Sistem & Akses Publik', icon: Sliders },
          { id: 'security', label: 'Keamanan, PIN & Sesi', icon: KeyRound },
          { id: 'finance', label: 'Ambang Kas & Kebijakan Kas', icon: DollarSign },
          { id: 'gateway', label: 'WhatsApp Gateway & Otomatisasi', icon: MessageSquare },
          { id: 'retention', label: 'Retensi Data & Snapshot Sistem', icon: Database },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeSection === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveSection(tab.id as any)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs font-extrabold whitespace-nowrap transition-all cursor-pointer ${
                isActive
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
                  : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200/80'
              }`}
            >
              <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-400'}`} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* ================= SECTION 1: MODE SISTEM & AKSES PUBLIK ================= */}
      {activeSection === 'operation' && (
        <div className="space-y-5">
          <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/80 shadow-xs space-y-6">
            <div>
              <h3 className="text-base font-black text-slate-900 flex items-center gap-2">
                <Sliders className="w-5 h-5 text-indigo-600" />
                <span>Kontrol Mode Operasi & Kesiapan Sistem</span>
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Atur ketersediaan portal untuk warga umum, pendaftaran online, dan mode pemeliharaan berkala.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              
              {/* Card 1: Maintenance Mode */}
              <div className={`p-4 sm:p-5 rounded-2xl border transition-all ${
                config.maintenanceMode 
                  ? 'bg-rose-50/70 border-rose-300 ring-2 ring-rose-500/20' 
                  : 'bg-slate-50/60 border-slate-200'
              }`}>
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <span className="text-xs font-extrabold text-slate-900 block">
                      Mode Perawatan (Maintenance Mode)
                    </span>
                    <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">
                      Kunci akses publik dan koordinator sementara untuk keperluan tutup buku tahunan, rekapitulasi data, atau pemeliharaan server.
                    </p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer shrink-0">
                    <input
                      type="checkbox"
                      checked={config.maintenanceMode}
                      onChange={(e) => updateField('maintenanceMode', e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-rose-600"></div>
                  </label>
                </div>
                <div className="mt-3 pt-3 border-t border-slate-200/60 flex items-center justify-between text-[11px]">
                  <span className="text-slate-500">Status Saat Ini:</span>
                  <span className={`font-black ${config.maintenanceMode ? 'text-rose-600' : 'text-emerald-700'}`}>
                    {config.maintenanceMode ? 'TERKUNCI (Maintenance ON)' : 'NORMAL (Aktif 24 Jam)'}
                  </span>
                </div>
              </div>

              {/* Card 2: Public Portal */}
              <div className="p-4 sm:p-5 rounded-2xl bg-slate-50/60 border border-slate-200">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <span className="text-xs font-extrabold text-slate-900 block">
                      Portal Mandiri Warga (Public Portal)
                    </span>
                    <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">
                      Izinkan warga mengecek status iuran, mengunduh KTA Digital, melihat jadwal pemakaman & ambulans tanpa perlu login akun.
                    </p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer shrink-0">
                    <input
                      type="checkbox"
                      checked={config.publicPortalEnabled}
                      onChange={(e) => updateField('publicPortalEnabled', e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600"></div>
                  </label>
                </div>
                <div className="mt-3 pt-3 border-t border-slate-200/60 flex items-center justify-between text-[11px]">
                  <span className="text-slate-500">Akses Warga Mandiri:</span>
                  <span className={`font-black ${config.publicPortalEnabled ? 'text-emerald-700' : 'text-slate-500'}`}>
                    {config.publicPortalEnabled ? 'DIPERBOLEHKAN' : 'DITUTUP (Wajib Login)'}
                  </span>
                </div>
              </div>

              {/* Card 3: Citizen Self Registration */}
              <div className="p-4 sm:p-5 rounded-2xl bg-slate-50/60 border border-slate-200">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <span className="text-xs font-extrabold text-slate-900 block">
                      Pendaftaran Anggota Mandiri Secara Online
                    </span>
                    <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">
                      Aktifkan formulir pendaftaran anggota baru secara publik sehingga warga perumahan yang baru pindah dapat mengajukan KK online.
                    </p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer shrink-0">
                    <input
                      type="checkbox"
                      checked={config.citizenSelfRegistration}
                      onChange={(e) => updateField('citizenSelfRegistration', e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600"></div>
                  </label>
                </div>
                <div className="mt-3 pt-3 border-t border-slate-200/60 flex items-center justify-between text-[11px]">
                  <span className="text-slate-500">Pendaftaran Online:</span>
                  <span className={`font-black ${config.citizenSelfRegistration ? 'text-emerald-700' : 'text-slate-500'}`}>
                    {config.citizenSelfRegistration ? 'TERBUKA UNTUK WARGA' : 'HANYA VIA ADMIN'}
                  </span>
                </div>
              </div>

              {/* Card 4: Strict NIK Validation */}
              <div className="p-4 sm:p-5 rounded-2xl bg-slate-50/60 border border-slate-200">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <span className="text-xs font-extrabold text-slate-900 block">
                      Validasi Ketat Format NIK & No. KK (16 Digit)
                    </span>
                    <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">
                      Mencegah kesalahan input dengan mewajibkan nomor induk kependudukan tepat 16 digit angka dan memeriksa duplikasi antar kartu keluarga.
                    </p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer shrink-0">
                    <input
                      type="checkbox"
                      checked={config.strictNikValidation}
                      onChange={(e) => updateField('strictNikValidation', e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600"></div>
                  </label>
                </div>
                <div className="mt-3 pt-3 border-t border-slate-200/60 flex items-center justify-between text-[11px]">
                  <span className="text-slate-500">Aturan Validasi:</span>
                  <span className={`font-black ${config.strictNikValidation ? 'text-emerald-700' : 'text-slate-500'}`}>
                    {config.strictNikValidation ? 'VALIDASI KETAT AKTIF' : 'FLEKSIBEL'}
                  </span>
                </div>
              </div>

            </div>
          </div>
        </div>
      )}

      {/* ================= SECTION 2: KEAMANAN, PIN & SESI ================= */}
      {activeSection === 'security' && (
        <div className="space-y-5">
          <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/80 shadow-xs space-y-6">
            <div>
              <h3 className="text-base font-black text-slate-900 flex items-center gap-2">
                <KeyRound className="w-5 h-5 text-indigo-600" />
                <span>Kebijakan Keamanan, Master PIN & Batas Sesi</span>
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Proteksi akses terhadap tindakan sensitif, pembatalan iuran, penghapusan transaksi, dan penguncian akun otomatis.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              
              {/* Master PIN */}
              <div className="p-5 rounded-2xl bg-amber-50/50 border border-amber-200 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Lock className="w-4 h-4 text-amber-700" />
                    <span className="text-xs font-black text-amber-950 uppercase tracking-wider">
                      Master PIN Otorisasi Khusus
                    </span>
                  </div>
                  <span className="text-[10px] font-extrabold px-2 py-0.5 bg-amber-200/60 text-amber-900 rounded-full">
                    Sangat Rahasia
                  </span>
                </div>
                <p className="text-[11px] text-amber-900/80 leading-relaxed">
                  PIN 6-digit yang digunakan untuk memverifikasi tindakan destruktif seperti pembatalan pembayaran iuran yang telah terbit kuitansi, penghapusan transaksi buku kas, dan reset database.
                </p>

                <div className="relative">
                  <input
                    type={showPin ? 'text' : 'password'}
                    maxLength={8}
                    value={config.masterPin}
                    onChange={(e) => updateField('masterPin', e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-white border border-amber-300 rounded-xl text-sm font-mono font-bold tracking-widest text-slate-900 outline-none focus:ring-2 focus:ring-amber-500"
                    placeholder="Contoh: 198200"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPin(!showPin)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-1"
                  >
                    {showPin ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Session Timeout */}
              <div className="p-5 rounded-2xl bg-slate-50/70 border border-slate-200 space-y-3">
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-indigo-600" />
                  <span className="text-xs font-extrabold text-slate-900">
                    Batas Waktu Habis Sesi Login (Session Timeout)
                  </span>
                </div>
                <p className="text-[11px] text-slate-500 leading-relaxed">
                  Otomatis mengeluarkan akun pengurus jika tidak ada aktivitas dalam durasi tertentu untuk mencegah penyalahgunaan saat perangkat ditinggalkan.
                </p>

                <select
                  value={config.sessionTimeoutMinutes}
                  onChange={(e) => updateField('sessionTimeoutMinutes', Number(e.target.value))}
                  className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-xs font-bold text-slate-800 outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value={15}>15 Menit (Keamanan Tinggi)</option>
                  <option value={30}>30 Menit (Direkomendasikan)</option>
                  <option value={60}>1 Jam (Standar Pengurus)</option>
                  <option value={120}>2 Jam</option>
                  <option value={240}>4 Jam</option>
                  <option value={480}>8 Jam (Satu Hari Kerja)</option>
                  <option value={1440}>24 Jam (Tetap Masuk)</option>
                </select>
              </div>

              {/* Max Login Attempts */}
              <div className="p-5 rounded-2xl bg-slate-50/70 border border-slate-200 space-y-3">
                <div className="flex items-center gap-2">
                  <ShieldAlert className="w-4 h-4 text-indigo-600" />
                  <span className="text-xs font-extrabold text-slate-900">
                    Ambang Percobaan Gagal Login (Auto Lockout)
                  </span>
                </div>
                <p className="text-[11px] text-slate-500 leading-relaxed">
                  Kunci akun otomatis setelah beberapa kali berturut-turut salah memasukkan kata sandi. Akun hanya bisa dibuka kembali oleh Super Admin.
                </p>

                <select
                  value={config.maxLoginAttempts}
                  onChange={(e) => updateField('maxLoginAttempts', Number(e.target.value))}
                  className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-xs font-bold text-slate-800 outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value={3}>3 Kali Percobaan (Ketat)</option>
                  <option value={5}>5 Kali Percobaan (Direkomendasikan)</option>
                  <option value={10}>10 Kali Percobaan</option>
                </select>
              </div>

              {/* Two Factor Auth */}
              <div className="p-5 rounded-2xl bg-slate-50/70 border border-slate-200 space-y-3">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <span className="text-xs font-extrabold text-slate-900 block">
                      Autentikasi Ganda (2FA / Verifikasi PIN)
                    </span>
                    <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">
                      Wajibkan konfirmasi PIN saat login untuk akun dengan hak akses Super Admin dan Bendahara Utama.
                    </p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer shrink-0">
                    <input
                      type="checkbox"
                      checked={config.requireTwoFactorAuth}
                      onChange={(e) => updateField('requireTwoFactorAuth', e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
                  </label>
                </div>
              </div>

            </div>
          </div>
        </div>
      )}

      {/* ================= SECTION 3: AMBANG KAS & KEBIJAKAN KAS ================= */}
      {activeSection === 'finance' && (
        <div className="space-y-5">
          <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/80 shadow-xs space-y-6">
            <div>
              <h3 className="text-base font-black text-slate-900 flex items-center gap-2">
                <DollarSign className="w-5 h-5 text-indigo-600" />
                <span>Ambang Batas Kas, Diskon & Kebijakan Finansial</span>
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Konfigurasi batas aman cadangan kas kematian, insentif pelunasan tahunan, dan masa tenggang santunan duka.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              
              {/* Critical Cash Threshold */}
              <div className="p-5 rounded-2xl bg-slate-50/70 border border-slate-200 space-y-3">
                <label className="block text-xs font-extrabold text-slate-900">
                  Ambang Saldo Kas Kritis (Critical Warning Threshold)
                </label>
                <p className="text-[11px] text-slate-500 leading-relaxed">
                  Jika total saldo kas umum berada di bawah nominal ini, sistem otomatis menampilkan peringatan darurat ke Bendahara dan Super Admin untuk segera melakukan himbauan iuran.
                </p>
                <div className="relative">
                  <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-400">Rp</span>
                  <input
                    type="number"
                    step={500000}
                    value={config.criticalCashThreshold}
                    onChange={(e) => updateField('criticalCashThreshold', Number(e.target.value))}
                    className="w-full pl-10 pr-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-xs font-mono font-bold text-slate-800 outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
                <span className="text-[11px] font-bold text-indigo-600 block">
                  Terbilang: {formatRupiah(config.criticalCashThreshold || 0)}
                </span>
              </div>

              {/* Annual Payment Discount */}
              <div className="p-5 rounded-2xl bg-slate-50/70 border border-slate-200 space-y-3">
                <label className="block text-xs font-extrabold text-slate-900">
                  Potongan / Diskon Bayar 1 Tahun Sekaligus
                </label>
                <p className="text-[11px] text-slate-500 leading-relaxed">
                  Insentif apresiasi bagi warga yang melunasi iuran 12 bulan (Januari–Desember) dalam 1 kali transaksi. Masukkan 0 jika tidak ada diskon.
                </p>
                <div className="relative">
                  <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-400">Rp</span>
                  <input
                    type="number"
                    step={5000}
                    value={config.annualPaymentDiscount}
                    onChange={(e) => updateField('annualPaymentDiscount', Number(e.target.value))}
                    className="w-full pl-10 pr-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-xs font-mono font-bold text-slate-800 outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
                <span className="text-[11px] font-bold text-emerald-600 block">
                  Potongan: {formatRupiah(config.annualPaymentDiscount || 0)} per KK
                </span>
              </div>

              {/* Monthly Late Fee */}
              <div className="p-5 rounded-2xl bg-slate-50/70 border border-slate-200 space-y-3">
                <label className="block text-xs font-extrabold text-slate-900">
                  Denda Keterlambatan Iuran Bulanan
                </label>
                <p className="text-[11px] text-slate-500 leading-relaxed">
                  Biaya tambahan keterlambatan per bulan. Berdasarkan kesepakatan musyawarah warga MPP, nilai default adalah Rp 0 (asas kekeluargaan).
                </p>
                <div className="relative">
                  <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-400">Rp</span>
                  <input
                    type="number"
                    value={config.monthlyLateFee}
                    onChange={(e) => updateField('monthlyLateFee', Number(e.target.value))}
                    className="w-full pl-10 pr-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-xs font-mono font-bold text-slate-800 outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
                <span className="text-[11px] font-bold text-slate-500 block">
                  {config.monthlyLateFee === 0 ? 'Bebas Denda (Sesuai AD/ART)' : `Denda ${formatRupiah(config.monthlyLateFee || 0)} / bulan`}
                </span>
              </div>

            </div>
          </div>
        </div>
      )}

      {/* ================= SECTION 4: WHATSAPP GATEWAY & OTOMATISASI ================= */}
      {activeSection === 'gateway' && (
        <div className="space-y-5">
          <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/80 shadow-xs space-y-6">
            <div>
              <h3 className="text-base font-black text-slate-900 flex items-center gap-2">
                <MessageSquare className="w-5 h-5 text-indigo-600" />
                <span>Integrasi WhatsApp Gateway API & Notifikasi Otomatis</span>
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Kirim kuitansi pembayaran iuran digital, pengumuman lelayu, dan pengingat jatuh tempo langsung ke HP warga.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              
              {/* Provider Selection */}
              <div className="space-y-1.5">
                <label className="block text-xs font-extrabold text-slate-900">
                  Provider WhatsApp Gateway
                </label>
                <select
                  value={config.waGatewayProvider}
                  onChange={(e) => updateField('waGatewayProvider', e.target.value as any)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-bold text-slate-800 outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="fonnte">Fonnte (Rekomendasi Indonesia - Cepat & Stabil)</option>
                  <option value="wablas">Wablas Gateway</option>
                  <option value="whacenter">WhaCenter API</option>
                  <option value="custom">Custom Webhook HTTP POST Endpoint</option>
                </select>
              </div>

              {/* Endpoint URL */}
              <div className="space-y-1.5">
                <label className="block text-xs font-extrabold text-slate-900">
                  API Endpoint URL
                </label>
                <input
                  type="text"
                  value={config.waGatewayEndpoint}
                  onChange={(e) => updateField('waGatewayEndpoint', e.target.value)}
                  placeholder="https://api.fonnte.com/send"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-mono text-slate-800 outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              {/* API Token */}
              <div className="md:col-span-2 space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="block text-xs font-extrabold text-slate-900">
                    API Key / Token Otentikasi Gateway
                  </label>
                  <button
                    type="button"
                    onClick={() => setShowApiKey(!showApiKey)}
                    className="text-[11px] font-bold text-indigo-600 hover:text-indigo-700 flex items-center gap-1"
                  >
                    {showApiKey ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                    <span>{showApiKey ? 'Sembunyikan Token' : 'Lihat Token'}</span>
                  </button>
                </div>
                <input
                  type={showApiKey ? 'text' : 'password'}
                  value={config.waGatewayApiKey}
                  onChange={(e) => updateField('waGatewayApiKey', e.target.value)}
                  placeholder="Masukkan API Key / Token dari dashboard provider (contoh: 3xY9kL...)"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-mono text-slate-800 outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

            </div>

            {/* Automation Triggers Toggles */}
            <div className="pt-4 border-t border-slate-200/80 space-y-3">
              <span className="text-xs font-black text-slate-900 uppercase tracking-wider block">
                Pemicu Otomatisasi Pesan WhatsApp (Auto-Trigger)
              </span>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <label className="p-3.5 bg-slate-50 border border-slate-200 rounded-2xl flex items-start gap-3 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={config.autoSendReceiptWa}
                    onChange={(e) => updateField('autoSendReceiptWa', e.target.checked)}
                    className="mt-0.5 w-4 h-4 text-emerald-600 rounded border-slate-300 focus:ring-emerald-500"
                  />
                  <div>
                    <span className="text-xs font-bold text-slate-900 block">Kuitansi Kas Otomatis</span>
                    <span className="text-[11px] text-slate-500">Kirim teks & link kuitansi saat iuran dicatat</span>
                  </div>
                </label>

                <label className="p-3.5 bg-slate-50 border border-slate-200 rounded-2xl flex items-start gap-3 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={config.autoBroadcastDeathNotice}
                    onChange={(e) => updateField('autoBroadcastDeathNotice', e.target.checked)}
                    className="mt-0.5 w-4 h-4 text-emerald-600 rounded border-slate-300 focus:ring-emerald-500"
                  />
                  <div>
                    <span className="text-xs font-bold text-slate-900 block">Siaran Berita Lelayu</span>
                    <span className="text-[11px] text-slate-500">Broadcast pengumuman duka saat diterbitkan</span>
                  </div>
                </label>

                <label className="p-3.5 bg-slate-50 border border-slate-200 rounded-2xl flex items-start gap-3 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={config.autoSendMonthlyReminder}
                    onChange={(e) => updateField('autoSendMonthlyReminder', e.target.checked)}
                    className="mt-0.5 w-4 h-4 text-emerald-600 rounded border-slate-300 focus:ring-emerald-500"
                  />
                  <div>
                    <span className="text-xs font-bold text-slate-900 block">Pengingat Tagihan Bulanan</span>
                    <span className="text-[11px] text-slate-500">Kirim pesan tiap tgl 10 bagi KK menunggak</span>
                  </div>
                </label>
              </div>
            </div>

            {/* Test Connection Box */}
            <div className="p-4 sm:p-5 bg-indigo-50/60 rounded-2xl border border-indigo-200 space-y-3">
              <div className="flex items-center gap-2">
                <Radio className="w-4 h-4 text-indigo-700" />
                <span className="text-xs font-black text-indigo-950 uppercase tracking-wider">
                  Uji Koneksi WhatsApp Gateway
                </span>
              </div>
              <p className="text-[11px] text-indigo-900/80">
                Simulasikan pengiriman pesan langsung untuk memastikan token API dan nomor WhatsApp Gateway telah terhubung aktif.
              </p>

              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
                <input
                  type="text"
                  value={testPhone}
                  onChange={(e) => setTestPhone(e.target.value)}
                  placeholder="Nomor HP Tujuan (08...)"
                  className="flex-1 px-3.5 py-2 bg-white border border-indigo-200 rounded-xl text-xs font-mono font-bold text-slate-900 outline-none"
                />
                <button
                  type="button"
                  onClick={handleTestWaGateway}
                  disabled={testResult.status === 'sending'}
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl flex items-center justify-center gap-2 shadow-sm transition-all cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>{testResult.status === 'sending' ? 'Mengirim...' : 'Kirim Pesan Uji Coba'}</span>
                </button>
              </div>

              {testResult.message && (
                <div className={`p-3 rounded-xl text-xs font-semibold ${
                  testResult.status === 'success' 
                    ? 'bg-emerald-100/80 text-emerald-900 border border-emerald-300' 
                    : 'bg-amber-100/80 text-amber-900 border border-amber-300'
                }`}>
                  {testResult.message}
                </div>
              )}
            </div>

          </div>
        </div>
      )}

      {/* ================= SECTION 5: RETENSI DATA & SNAPSHOT SISTEM ================= */}
      {activeSection === 'retention' && (
        <div className="space-y-5">
          <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/80 shadow-xs space-y-6">
            <div>
              <h3 className="text-base font-black text-slate-900 flex items-center gap-2">
                <Database className="w-5 h-5 text-indigo-600" />
                <span>Manajemen Retensi Data & Snapshot Integritas Sistem</span>
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Pantau metrik volume data aktif, bersihkan cache sementara, dan atur periode penyimpanan log aktivitas.
              </p>
            </div>

            {/* System Metrics Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
                <span className="text-[10px] font-extrabold uppercase text-slate-400 block">Total Kartu Keluarga</span>
                <span className="text-xl sm:text-2xl font-black text-slate-900 mt-1 block">{citizens.length} KK</span>
                <span className="text-[10px] text-emerald-600 font-bold">{totalMembers} Jiwa Anggota</span>
              </div>

              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
                <span className="text-[10px] font-extrabold uppercase text-slate-400 block">Transaksi Buku Kas</span>
                <span className="text-xl sm:text-2xl font-black text-slate-900 mt-1 block">{transactions.length} Entri</span>
                <span className="text-[10px] text-slate-500 font-bold">Pemasukan & Pengeluaran</span>
              </div>

              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
                <span className="text-[10px] font-extrabold uppercase text-slate-400 block">Laporan Musibah Duka</span>
                <span className="text-xl sm:text-2xl font-black text-slate-900 mt-1 block">{deathNotices.length} Kasus</span>
                <span className="text-[10px] text-slate-500 font-bold">Santunan Fardhu Kifayah</span>
              </div>

              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
                <span className="text-[10px] font-extrabold uppercase text-slate-400 block">Audit Activity Log</span>
                <span className="text-xl sm:text-2xl font-black text-slate-900 mt-1 block">{auditLogs.length} Baris</span>
                <span className="text-[10px] text-indigo-600 font-bold">Audit Jejak Digital</span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-5 pt-2">
              
              {/* Retention Policy */}
              <div className="p-5 rounded-2xl bg-slate-50/70 border border-slate-200 space-y-3">
                <label className="block text-xs font-extrabold text-slate-900">
                  Masa Retensi Penyimpanan Log Aktivitas (Activity Log)
                </label>
                <p className="text-[11px] text-slate-500 leading-relaxed">
                  Tentukan berapa lama sistem menyimpan rekam jejak audit login, perubahan data, dan transaksi sebelum diarsipkan secara otomatis.
                </p>
                <select
                  value={config.auditLogRetentionDays}
                  onChange={(e) => updateField('auditLogRetentionDays', Number(e.target.value))}
                  className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-xs font-bold text-slate-800 outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value={30}>30 Hari (Penghematan Ruang)</option>
                  <option value={90}>90 Hari (3 Bulan)</option>
                  <option value={180}>180 Hari (6 Bulan)</option>
                  <option value={365}>365 Hari (1 Tahun Penuh - Standar)</option>
                  <option value={9999}>Simpan Selamanya (Tanpa Batas)</option>
                </select>
              </div>

              {/* Auto Daily Snapshot */}
              <div className="p-5 rounded-2xl bg-slate-50/70 border border-slate-200 space-y-3">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <span className="text-xs font-extrabold text-slate-900 block">
                      Auto-Snapshot Cadangan Harian Browser
                    </span>
                    <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">
                      Secara otomatis mencadangkan seluruh data transaksi, warga, dan duka ke LocalStorage browser setiap 24 jam sekali untuk mencegah kehilangan data tak terduga.
                    </p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer shrink-0">
                    <input
                      type="checkbox"
                      checked={config.autoBackupDaily}
                      onChange={(e) => updateField('autoBackupDaily', e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600"></div>
                  </label>
                </div>
              </div>

            </div>

            {/* Quick Action Buttons */}
            <div className="pt-4 border-t border-slate-200/80 flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2 text-xs text-slate-500">
                <Server className="w-4 h-4 text-emerald-600" />
                <span>Status Database: <strong>Aktif & Terenkripsi Sempurna</strong></span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    alert('Cache data lokal dan indeks pencarian warga berhasil disegarkan ulang.');
                  }}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-extrabold text-xs rounded-xl border border-slate-300 transition-all cursor-pointer"
                >
                  Segarkan Indeks & Bersihkan Cache
                </button>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* Bottom Save Action Bar */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="flex items-center gap-2 text-xs text-slate-600">
          <ShieldAlert className="w-4 h-4 text-amber-500" />
          <span>Perubahan pada panel Superuser akan berdampak langsung ke seluruh sistem dan pengguna.</span>
        </div>

        <button
          type="button"
          onClick={handleSaveSettings}
          className="w-full sm:w-auto px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 active:scale-95 text-white font-extrabold text-xs sm:text-sm rounded-xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
        >
          <Save className="w-4 h-4" />
          <span>Terapkan & Simpan Semua Pengaturan Superuser</span>
        </button>
      </div>

    </div>
  );
};
