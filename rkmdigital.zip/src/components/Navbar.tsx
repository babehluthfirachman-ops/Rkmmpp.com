import React, { useState } from 'react';
import { 
  Building2, 
  User, 
  Shield, 
  Wallet, 
  Users, 
  HeartHandshake, 
  Box, 
  Settings, 
  FileText, 
  Smartphone, 
  ChevronDown, 
  LogOut, 
  Check, 
  Sparkles,
  LayoutDashboard,
  CreditCard,
  BookOpen,
  PhoneCall,
  RefreshCw,
  Bell,
  LogIn,
  Globe,
  Scale,
  ShieldCheck,
  UserCheck
} from 'lucide-react';
import { useRkm } from '../context/RkmContext';
import { UserRole } from '../types';
import { getDirectImageUrl, isSuperAdmin, getAvatarUrl } from '../utils/formatters';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ activeTab, setActiveTab }) => {
  const { 
    currentUser, 
    currentRole, 
    logout, 
    settings, 
    deathNotices, 
    openLelayuModal,
    syncGoogleSheets 
  } = useRkm();
  
  const [roleDropdownOpen, setRoleDropdownOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [pwaInstalled, setPwaInstalled] = useState(false);

  const activeLelayu = deathNotices.find(d => d.status === 'Aktif');
  const userIsSuperAdmin = isSuperAdmin(currentUser);

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, roles: ['superadmin', 'bendahara', 'ketua', 'petugas', 'tim_jenazah', 'koordinator'] },
    { id: 'portal-warga', label: 'Portal Warga', icon: UserCheck, roles: ['warga', 'superadmin', 'bendahara', 'ketua', 'petugas', 'tim_jenazah', 'koordinator'] },
    { id: 'iuran', label: 'Kasir Iuran', icon: CreditCard, roles: ['superadmin', 'bendahara', 'ketua', 'petugas', 'koordinator'] },
    { id: 'buku-kas', label: 'Buku Kas', icon: BookOpen, roles: ['superadmin', 'bendahara', 'ketua'] },
    { id: 'warga', label: 'Data Warga', icon: Users, roles: ['superadmin', 'bendahara', 'ketua', 'petugas', 'koordinator'] },
    { id: 'layanan-duka', label: 'Layanan Duka', icon: HeartHandshake, roles: ['superadmin', 'bendahara', 'ketua', 'petugas', 'tim_jenazah', 'koordinator'] },
    { id: 'inventaris', label: 'Inventaris', icon: Box, roles: ['superadmin', 'bendahara', 'ketua', 'petugas', 'tim_jenazah', 'koordinator'] },
    { id: 'ad-art', label: 'AD/ART 2024-2027', icon: Scale, roles: ['warga', 'superadmin', 'bendahara', 'ketua', 'petugas', 'tim_jenazah', 'koordinator'] },
    // Only Super Admin can access Pengaturan Sistem
    ...(userIsSuperAdmin ? [{ id: 'pengaturan', label: 'Pengaturan Sistem', icon: Settings, roles: ['superadmin', 'bendahara', 'ketua', 'petugas', 'warga'] }] : [])
  ];

  const filteredNavItems = navItems.filter(item => {
    if (userIsSuperAdmin) return true;
    return item.roles.includes(currentRole);
  });

  const roleColors: Record<UserRole, { bg: string, text: string, label: string }> = {
    superadmin: { bg: 'bg-amber-600', text: 'text-amber-100', label: 'Super Admin' },
    bendahara: { bg: 'bg-emerald-600', text: 'text-emerald-100', label: 'Bendahara' },
    koordinator: { bg: 'bg-blue-600', text: 'text-blue-100', label: 'Koordinator Blok' },
    tim_jenazah: { bg: 'bg-purple-600', text: 'text-purple-100', label: 'Tim Jenazah' },
    ketua: { bg: 'bg-indigo-600', text: 'text-indigo-100', label: 'Ketua' },
    petugas: { bg: 'bg-amber-600', text: 'text-amber-100', label: 'Petugas' },
    warga: { bg: 'bg-teal-600', text: 'text-teal-100', label: 'Warga' }
  };

  const handleSync = async () => {
    setIsSyncing(true);
    await syncGoogleSheets();
    setIsSyncing(false);
  };

  return (
    <header className="sticky top-0 z-40 bg-slate-900 border-b border-slate-800 text-white shadow-lg no-print">
      
      {/* Top Notification Bar (if active death notice) */}
      {activeLelayu && (
        <div className="bg-gradient-to-r from-amber-600 via-rose-600 to-amber-700 text-white px-4 py-2 text-xs flex items-center justify-between shadow-inner">
          <div className="flex items-center gap-2 max-w-4xl truncate">
            <span className="bg-black/30 px-2 py-0.5 rounded text-[10px] font-black uppercase tracking-wider">
              BERITA DUKA TERKINI
            </span>
            <span className="font-semibold truncate">
              Inna lillahi wa inna ilaihi raji'un: Telah wafat Almh. {activeLelayu.deceasedName} (RT {activeLelayu.rt})
            </span>
          </div>
          <button
            onClick={() => openLelayuModal(activeLelayu)}
            className="px-2.5 py-1 bg-white/20 hover:bg-white/30 text-white font-bold rounded-lg transition-all shrink-0 text-[11px] ml-2"
          >
            Lihat Detail & Broadcast
          </button>
        </div>
      )}

      {/* Main App Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">
          
          {/* Logo & Brand Identity */}
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => setActiveTab(currentRole === 'warga' ? 'portal-warga' : 'dashboard')}>
            {settings.logoUrl ? (
              <img 
                src={getDirectImageUrl(settings.logoUrl)} 
                alt={settings.shortName}
                referrerPolicy="no-referrer"
                className="w-10 h-10 rounded-xl object-contain bg-white p-1 ring-2 ring-emerald-400/40 shadow-md"
                onError={(e) => {
                  (e.currentTarget as HTMLElement).style.display = 'none';
                  const fallback = (e.currentTarget.nextElementSibling as HTMLElement);
                  if (fallback) fallback.style.display = 'flex';
                }}
              />
            ) : null}
            <div 
              style={{ display: settings.logoUrl ? 'none' : 'flex' }}
              className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-400 items-center justify-center font-black text-slate-950 text-sm shadow-md ring-2 ring-emerald-400/30 tracking-tighter"
            >
              MPP
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-base tracking-tight text-white">{settings.shortName}</span>
                <span className="hidden md:inline-flex items-center gap-1 px-2 py-0.5 text-[10px] font-bold bg-emerald-500/10 text-emerald-300 border border-emerald-500/30 rounded-full">
                  Periode 2024–2027
                </span>
              </div>
              <p className="text-[11px] text-emerald-400 font-semibold truncate max-w-[200px] sm:max-w-xs uppercase tracking-tight">
                {settings.orgName}
              </p>
            </div>
          </div>

          {/* Right Action Tools */}
          <div className="flex items-center gap-2.5">
            
            {/* Google Sheets Sync Button */}
            <button
              onClick={handleSync}
              title="Sinkronisasi Data Google Sheets"
              className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium border border-slate-700 transition-all"
            >
              <RefreshCw className={`w-3.5 h-3.5 text-emerald-400 ${isSyncing ? 'animate-spin' : ''}`} />
              <span className="hidden xl:inline">Sync Sheets</span>
            </button>

            {/* PWA Install Button */}
            <button
              onClick={() => {
                setPwaInstalled(true);
                alert('Aplikasi RKM MPP Digital siap digunakan sebagai PWA di HP Android/iOS via fitur Tambah ke Layar Utama!');
              }}
              className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/30 text-xs font-semibold transition-all"
            >
              <Smartphone className="w-3.5 h-3.5 text-emerald-400" />
              <span>Install PWA</span>
            </button>

            {/* Role / User Profile Menu */}
            {currentUser ? (
              <div className="relative">
                <button
                  onClick={() => setRoleDropdownOpen(!roleDropdownOpen)}
                  className="flex items-center gap-2 p-1.5 sm:px-3 sm:py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-left transition-all cursor-pointer"
                >
                  <img
                    src={getAvatarUrl(currentUser.name, currentUser.role, currentUser.avatar)}
                    alt={currentUser.name}
                    referrerPolicy="no-referrer"
                    className="w-7 h-7 rounded-lg object-cover shadow-sm ring-1 ring-emerald-500/40 shrink-0 bg-slate-700"
                  />
                  <div className="hidden md:block">
                    <div className="text-xs font-bold text-white truncate max-w-[130px]">{currentUser?.name}</div>
                    <div className="text-[10px] text-emerald-400 font-medium capitalize flex items-center gap-1">
                      {userIsSuperAdmin ? (
                        <span className="text-amber-300 font-bold flex items-center gap-0.5">
                          <ShieldCheck className="w-3 h-3" />
                          Super Admin
                        </span>
                      ) : (
                        <span>{currentUser?.title || currentRole}</span>
                      )}
                    </div>
                  </div>
                  <ChevronDown className="w-4 h-4 text-slate-400" />
                </button>

                {/* Profile Actions Dropdown: Only Settings (if Super Admin) & Logout */}
                {roleDropdownOpen && (
                  <div className="absolute right-0 mt-2 w-64 bg-slate-800 rounded-2xl shadow-2xl border border-slate-700 py-2 z-50 animate-fade-in">
                    <div className="px-4 py-3 border-b border-slate-700">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Akun Terautentikasi</span>
                        {userIsSuperAdmin && (
                          <span className="text-[9px] bg-amber-500/20 text-amber-300 border border-amber-500/30 px-2 py-0.5 rounded-full font-extrabold">
                            SUPER ADMIN
                          </span>
                        )}
                      </div>
                      <p className="text-sm font-bold text-white leading-tight">{currentUser?.name}</p>
                      <p className="text-xs text-emerald-400 mt-0.5">{currentUser?.title || `Peran: ${currentRole}`}</p>
                      {currentUser?.rt && (
                        <p className="text-[10px] text-slate-400 mt-0.5">Wilayah: RT {currentUser.rt} / RW {currentUser.rw || '08'}</p>
                      )}
                    </div>

                    <div className="px-2 py-1.5 space-y-1">
                      {/* Pengaturan Sistem - Only for Super Admin */}
                      {userIsSuperAdmin && (
                        <button
                          onClick={() => {
                            setRoleDropdownOpen(false);
                            setActiveTab('pengaturan');
                          }}
                          className="w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs text-slate-200 hover:bg-slate-700 hover:text-white font-semibold transition-colors"
                        >
                          <Settings className="w-4 h-4 text-amber-400" />
                          <span>Pengaturan Sistem</span>
                        </button>
                      )}

                      {/* Logout - Available for all logged in users */}
                      <button
                        onClick={() => {
                          setRoleDropdownOpen(false);
                          logout();
                          setActiveTab('login');
                        }}
                        className="w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs text-rose-300 hover:bg-rose-950/50 hover:text-rose-100 font-bold transition-colors"
                      >
                        <LogOut className="w-4 h-4 text-rose-400" />
                        <span>Keluar Akun (Logout)</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <button
                onClick={() => setActiveTab('login')}
                className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md transition-all active:scale-95"
              >
                <LogIn className="w-4 h-4" />
                <span>Masuk Akun</span>
              </button>
            )}

            {/* Mobile Menu Hamburger */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 rounded-xl bg-slate-800 text-slate-300 hover:text-white border border-slate-700"
            >
              <LayoutDashboard className="w-5 h-5" />
            </button>

          </div>
        </div>

        {/* Desktop Navigation Tabs */}
        <div className="hidden lg:flex items-center gap-1 py-1.5 border-t border-slate-800/80 overflow-x-auto">
          {filteredNavItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold transition-all whitespace-nowrap ${
                  isActive
                    ? 'bg-emerald-600 text-white shadow-md shadow-emerald-950/50'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>

      </div>

      {/* Mobile Drawer Navigation */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-slate-900 border-t border-slate-800 p-4 space-y-3 animate-fade-in">
          {currentUser && (
            <div className="p-3 bg-slate-800/90 rounded-2xl border border-slate-700/80 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className={`w-8 h-8 rounded-xl flex items-center justify-center font-black text-xs shadow-sm ring-1 ring-emerald-500/40 shrink-0 ${
                  userIsSuperAdmin ? 'bg-purple-700 text-white' :
                  currentRole === 'bendahara' ? 'bg-amber-600 text-white' :
                  currentRole === 'ketua' ? 'bg-blue-600 text-white' :
                  currentRole === 'tim_jenazah' ? 'bg-indigo-600 text-white' :
                  'bg-emerald-600 text-white'
                }`}>
                  {userIsSuperAdmin ? (
                    <ShieldCheck className="w-4 h-4" />
                  ) : (
                    <User className="w-4 h-4" />
                  )}
                </div>
                <div>
                  <p className="text-xs font-bold text-white truncate max-w-[150px]">{currentUser.name}</p>
                  <p className="text-[10px] text-emerald-400 font-medium">
                    {userIsSuperAdmin ? 'Super Admin' : currentUser.title || currentRole}
                  </p>
                </div>
              </div>
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  logout();
                  setActiveTab('login');
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-rose-600/20 hover:bg-rose-600/30 text-rose-300 border border-rose-500/30 rounded-xl text-xs font-bold transition-all"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Logout</span>
              </button>
            </div>
          )}

          <div className="space-y-1">
            {filteredNavItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setActiveTab(item.id);
                    setMobileMenuOpen(false);
                  }}
                  className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm font-semibold transition-colors ${
                    isActive ? 'bg-emerald-600 text-white font-bold' : 'text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      )}

    </header>
  );
};
