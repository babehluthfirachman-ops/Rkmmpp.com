import React, { useState } from 'react';
import { 
  Menu, 
  Search, 
  Bell, 
  ChevronDown, 
  LogOut, 
  Settings, 
  Users, 
  CreditCard,
  AlertTriangle, 
  CheckCircle2,
  Home,
  Camera,
  Moon,
  Sun,
  ShieldCheck,
  LogIn
} from 'lucide-react';
import { useRkm } from '../context/RkmContext';
import { isSuperAdmin, getAvatarUrl } from '../utils/formatters';
import { PwaInstallPrompt } from './PwaInstallPrompt';
import { NotificationsModal } from './NotificationsModal';

interface TopHeaderProps {
  onToggleMobileMenu: () => void;
  onOpenSearch: () => void;
  onOpenReportDeath: () => void;
  onOpenQuickDues: () => void;
  setActiveTab: (tab: string) => void;
}

export const TopHeader: React.FC<TopHeaderProps> = ({
  onToggleMobileMenu,
  onOpenSearch,
  setActiveTab
}) => {
  const { 
    currentUser, 
    currentRole, 
    logout, 
    deathNotices,
    openProfileModal,
    unreadNotificationsCount,
    theme,
    toggleTheme
  } = useRkm();
  
  const [roleDropdownOpen, setRoleDropdownOpen] = useState(false);
  const [isNotifModalOpen, setIsNotifModalOpen] = useState(false);
  const userIsSuperAdmin = isSuperAdmin(currentUser);

  const activeDeaths = deathNotices.filter(d => d.status === 'Aktif');

  return (
    <>
      <header className="sticky top-0 z-30 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200/90 dark:border-slate-800 shadow-xs transition-colors duration-200">
        <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 h-14 sm:h-16 flex items-center justify-between gap-2 sm:gap-3 w-full">
          
          {/* Left Section: Mobile Menu Toggle & Universal Search */}
          <div className="flex items-center gap-2 sm:gap-3 flex-1 min-w-0">
            <button
              onClick={onToggleMobileMenu}
              className="lg:hidden w-9 h-9 flex items-center justify-center rounded-xl text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-700 shrink-0 cursor-pointer transition-colors"
              aria-label="Buka Menu Navigasi"
            >
              <Menu className="w-5 h-5" />
            </button>

            {/* Universal Search Bar Trigger */}
            <div 
              onClick={onOpenSearch}
              className="relative w-full max-w-md cursor-pointer group min-w-0"
            >
              <div className="w-full h-9 flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-100/80 dark:bg-slate-800/80 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-400 dark:text-slate-500 group-hover:text-slate-600 dark:group-hover:text-slate-300 transition-all">
                <Search className="w-4 h-4 text-slate-400 group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition-colors shrink-0" />
                <span className="text-xs font-medium truncate sm:hidden">
                  Cari warga / KK / blok...
                </span>
                <span className="text-xs font-medium truncate hidden sm:inline">
                  Cari No. KK, Nama Kepala Keluarga, atau Blok A-Z...
                </span>
                <kbd className="hidden md:inline-block ml-auto text-[10px] font-mono bg-white dark:bg-slate-700 px-1.5 py-0.5 rounded border border-slate-300 dark:border-slate-600 text-slate-500 dark:text-slate-300 shadow-2xs shrink-0">
                  Ctrl+K
                </kbd>
              </div>
            </div>
          </div>

          {/* Right Section: Dark Mode, Notifications, PWA Install, and User Profile */}
          <div className="flex items-center gap-1.5 sm:gap-2.5 shrink-0">
            <PwaInstallPrompt />

            {/* Global High-Contrast Dark Mode Toggle Button */}
            <button
              id="global-dark-mode-toggle"
              type="button"
              onClick={() => {
                toggleTheme();
              }}
              className="h-9 px-2 sm:px-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-amber-300 border border-slate-300 dark:border-slate-700 hover:border-slate-400 dark:hover:border-amber-400/50 transition-all duration-200 cursor-pointer shadow-xs active:scale-95 flex items-center justify-center gap-1.5 select-none focus:outline-none focus:ring-2 focus:ring-emerald-500/40 shrink-0"
              title={theme === 'dark' ? 'Mode Gelap Aktif (Klik untuk beralih ke Mode Terang)' : 'Mode Terang Aktif (Klik untuk beralih ke Mode Gelap)'}
              aria-label={theme === 'dark' ? 'Beralih ke Mode Terang' : 'Beralih ke Mode Gelap'}
            >
              {theme === 'dark' ? (
                <>
                  <Sun className="w-4 h-4 text-amber-400 stroke-[2.5] transition-transform duration-300 hover:rotate-45 shrink-0" />
                  <span className="text-[11px] font-bold hidden md:inline text-amber-300 tracking-wide">Gelap</span>
                </>
              ) : (
                <>
                  <Moon className="w-4 h-4 text-slate-700 stroke-[2.5] transition-transform duration-300 hover:-rotate-12 shrink-0" />
                  <span className="text-[11px] font-bold hidden md:inline text-slate-700 tracking-wide">Terang</span>
                </>
              )}
            </button>
            
            {/* Notification Center Trigger */}
            <button
              onClick={() => setIsNotifModalOpen(true)}
              className="w-9 h-9 flex items-center justify-center rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 relative border border-slate-200 dark:border-slate-700 transition-colors cursor-pointer shrink-0"
              title="Notifikasi & Peringatan Duka"
              aria-label="Buka Pusat Notifikasi"
            >
              <Bell className="w-4 h-4" />
              {(unreadNotificationsCount > 0 || activeDeaths.length > 0) && (
                <span className="absolute -top-1 -right-1 w-4 h-4 bg-rose-600 text-white font-extrabold text-[9px] rounded-full flex items-center justify-center animate-pulse ring-2 ring-white dark:ring-slate-900">
                  {unreadNotificationsCount || activeDeaths.length}
                </span>
              )}
            </button>

            {/* User Profile Menu with Avatar & Notification Badge */}
            {currentUser ? (
              <div className="relative shrink-0">
                <button
                  onClick={() => setRoleDropdownOpen(!roleDropdownOpen)}
                  className="h-9 flex items-center gap-1.5 p-1 sm:px-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200/80 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 text-left transition-all cursor-pointer"
                  aria-label="Buka Menu Profil Pengguna"
                >
                  <div className="relative">
                    <img 
                      src={getAvatarUrl(currentUser.name, currentUser.role, currentUser.avatar)} 
                      alt={currentUser.name}
                      referrerPolicy="no-referrer"
                      className="w-7 h-7 rounded-lg object-cover shadow-xs ring-1 ring-emerald-500/40 shrink-0 bg-slate-200 dark:bg-slate-700"
                    />
                    {unreadNotificationsCount > 0 && (
                      <span className="absolute -top-1 -right-1 w-2 h-2 bg-emerald-500 rounded-full ring-2 ring-white dark:ring-slate-900 animate-pulse" />
                    )}
                  </div>
                  <div className="hidden md:block">
                    <div className="text-xs font-bold text-slate-900 dark:text-white truncate max-w-[120px]">{currentUser?.name}</div>
                    <div className="text-[10px] text-emerald-700 dark:text-emerald-400 font-semibold truncate">
                      {userIsSuperAdmin ? 'Super Admin' : currentUser?.title || currentRole}
                    </div>
                  </div>
                  <ChevronDown className="w-3.5 h-3.5 text-slate-400 dark:text-slate-500 hidden sm:inline" />
                </button>

                {roleDropdownOpen && (
                  <div className="absolute right-0 mt-2 w-72 sm:w-80 max-w-[calc(100vw-1.5rem)] bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 py-3 z-50 animate-fade-in">
                    
                    {/* Active Account Info Card with Avatar */}
                    <div className="px-4 pb-3 border-b border-slate-100 dark:border-slate-800 flex items-center gap-3">
                      <div className="relative">
                        <img 
                          src={getAvatarUrl(currentUser.name, currentUser.role, currentUser.avatar)} 
                          alt={currentUser.name}
                          referrerPolicy="no-referrer"
                          className="w-12 h-12 rounded-2xl object-cover shadow-sm ring-2 ring-emerald-500/30 shrink-0 bg-slate-200 dark:bg-slate-700"
                        />
                        {unreadNotificationsCount > 0 && (
                          <span className="absolute -top-1 -right-1 bg-emerald-500 text-white text-[9px] font-extrabold w-4 h-4 rounded-full flex items-center justify-center ring-2 ring-white dark:ring-slate-900">
                            {unreadNotificationsCount}
                          </span>
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1.5">
                          <p className="text-xs font-extrabold text-slate-900 dark:text-white truncate">{currentUser.name}</p>
                        </div>
                        <p className="text-[11px] text-emerald-700 dark:text-emerald-400 font-bold truncate">
                          {userIsSuperAdmin ? 'Super Administrator' : currentUser.title || currentRole}
                        </p>
                        <div className="flex items-center gap-2 mt-1">
                          <span className="inline-flex items-center gap-1 text-[10px] bg-emerald-50 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-300 font-bold px-2 py-0.5 rounded-full border border-emerald-200 dark:border-emerald-800">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                            <span>Akun Terverifikasi</span>
                          </span>
                          {currentUser.rt && (
                            <span className="text-[10px] text-slate-500 dark:text-slate-400 font-mono">
                              RT {currentUser.rt} / RW {currentUser.rw || '08'}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Account Quick Links */}
                    <div className="px-2 py-2 space-y-1 border-b border-slate-100 dark:border-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-300">
                      <button
                        onClick={() => {
                          setRoleDropdownOpen(false);
                          openProfileModal();
                        }}
                        className="w-full flex items-center justify-between px-3 py-2 bg-emerald-50/70 dark:bg-emerald-950/40 hover:bg-emerald-100/70 dark:hover:bg-emerald-900/50 rounded-xl transition-colors text-left cursor-pointer border border-emerald-200/60 dark:border-emerald-800/60"
                      >
                        <div className="flex items-center gap-2 text-emerald-950 dark:text-emerald-200 font-bold">
                          <Camera className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                          <span>Profil & Ganti Foto Avatar</span>
                        </div>
                        <span className="text-[10px] bg-emerald-600 text-white font-bold px-2 py-0.5 rounded-md">Edit</span>
                      </button>

                      <button
                        onClick={() => {
                          setRoleDropdownOpen(false);
                          setIsNotifModalOpen(true);
                        }}
                        className="w-full flex items-center justify-between px-3 py-2 hover:bg-slate-50 dark:hover:bg-slate-800/60 rounded-xl transition-colors text-left cursor-pointer"
                      >
                        <div className="flex items-center gap-2">
                          <Bell className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                          <span>Notifikasi In-App</span>
                        </div>
                        {unreadNotificationsCount > 0 ? (
                          <span className="text-[10px] bg-rose-500 text-white font-extrabold px-1.5 py-0.2 rounded-full">
                            {unreadNotificationsCount} Baru
                          </span>
                        ) : (
                          <span className="text-[10px] text-slate-400">Semua dibaca</span>
                        )}
                      </button>

                      <button
                        onClick={() => {
                          setRoleDropdownOpen(false);
                          setActiveTab('beranda');
                        }}
                        className="w-full flex items-center justify-between px-3 py-2 hover:bg-slate-50 dark:hover:bg-slate-800/60 rounded-xl transition-colors text-left cursor-pointer"
                      >
                        <div className="flex items-center gap-2">
                          <Home className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                          <span>Beranda & Info Publik</span>
                        </div>
                        <span className="text-[10px] text-slate-400">Lihat</span>
                      </button>

                      <button
                        onClick={() => {
                          setRoleDropdownOpen(false);
                          setActiveTab('warga');
                        }}
                        className="w-full flex items-center justify-between px-3 py-2 hover:bg-slate-50 dark:hover:bg-slate-800/60 rounded-xl transition-colors text-left cursor-pointer"
                      >
                        <div className="flex items-center gap-2">
                          <Users className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                          <span>Data Master Warga (KK)</span>
                        </div>
                        <span className="text-[10px] text-slate-400">Buka</span>
                      </button>

                      {currentRole !== 'warga' && (
                        <button
                          onClick={() => {
                            setRoleDropdownOpen(false);
                            setActiveTab('buku-kas');
                          }}
                          className="w-full flex items-center justify-between px-3 py-2 hover:bg-slate-50 dark:hover:bg-slate-800/60 rounded-xl transition-colors text-left cursor-pointer"
                        >
                          <div className="flex items-center gap-2">
                            <CreditCard className="w-4 h-4 text-teal-600 dark:text-teal-400" />
                            <span>Buku Kas & Keuangan</span>
                          </div>
                          <span className="text-[10px] text-slate-400">Lihat</span>
                        </button>
                      )}

                      {userIsSuperAdmin && (
                        <button
                          onClick={() => {
                            setRoleDropdownOpen(false);
                            setActiveTab('pengaturan');
                          }}
                          className="w-full flex items-center justify-between px-3 py-2 hover:bg-slate-50 dark:hover:bg-slate-800/60 rounded-xl transition-colors text-left font-bold text-slate-900 dark:text-white cursor-pointer"
                        >
                          <div className="flex items-center gap-2">
                            <Settings className="w-4 h-4 text-amber-500" />
                            <span>Pengaturan Sistem & Otomatisasi</span>
                          </div>
                          <span className="text-[9px] bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 px-1.5 py-0.5 rounded font-black">Super Admin</span>
                        </button>
                      )}
                    </div>

                    {/* Logout Button */}
                    <div className="px-2 pt-2">
                      <button
                        onClick={() => {
                          setRoleDropdownOpen(false);
                          logout();
                          setActiveTab('beranda');
                        }}
                        className="w-full flex items-center justify-center gap-2 px-3 py-2 text-xs font-bold text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-xl transition-colors active:scale-98 cursor-pointer"
                      >
                        <LogOut className="w-4 h-4" />
                        <span>Keluar Akun (Logout)</span>
                      </button>
                    </div>

                  </div>
                )}
              </div>
            ) : (
              <button
                onClick={() => setActiveTab('login')}
                className="flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-md transition-all active:scale-95 cursor-pointer"
              >
                <LogIn className="w-3.5 h-3.5" />
                <span>Masuk Akun</span>
              </button>
            )}

          </div>

        </div>
      </header>

      {/* Notifications In-App Modal */}
      <NotificationsModal
        isOpen={isNotifModalOpen}
        onClose={() => setIsNotifModalOpen(false)}
        onNavigate={(tab) => {
          setActiveTab(tab);
        }}
      />
    </>
  );
};
