import React, { useState, useRef } from 'react';
import { 
  X, 
  Camera, 
  Upload, 
  Check, 
  User, 
  ShieldCheck, 
  Users, 
  Phone, 
  Mail, 
  MapPin, 
  QrCode, 
  CreditCard, 
  CheckCircle2, 
  AlertCircle, 
  Building,
  RefreshCw,
  Sparkles,
  Calendar,
  HeartHandshake,
  Trash2,
  Lock,
  Eye,
  EyeOff,
  KeyRound
} from 'lucide-react';
import { useRkm } from '../context/RkmContext';
import { formatRupiah, formatDateIndo, calculateCitizenMonthlyDues, getAvatarUrl } from '../utils/formatters';
import { Citizen } from '../types';

interface CitizenProfileModalProps {
  isOpen?: boolean;
  onClose?: () => void;
  citizen?: Citizen | null;
  onOpenKta?: (citizen: Citizen) => void;
}

export const CitizenProfileModal: React.FC<CitizenProfileModalProps> = ({
  isOpen,
  onClose,
  citizen,
  onOpenKta
}) => {
  const { 
    currentUser, 
    updateUser, 
    updateCitizen, 
    citizens, 
    settings,
    isProfileModalOpen,
    selectedProfileCitizen,
    closeProfileModal,
    openKtaModal
  } = useRkm();

  const showModal = isOpen !== undefined ? isOpen : isProfileModalOpen;
  const handleClose = onClose || closeProfileModal;
  const handleOpenKta = onOpenKta || openKtaModal;

  // Find active citizen record: either prop citizen, or context selected, or matching currentUser by noKK, or first citizen
  const activeCitizen = citizen || selectedProfileCitizen || citizens.find(c => c.noKK === currentUser?.noKK) || citizens[0];

  const fileInputRef = useRef<HTMLInputElement>(null);
  const [avatarPreview, setAvatarPreview] = useState<string>(
    currentUser?.avatar || activeCitizen?.avatar || ''
  );
  const [phone, setPhone] = useState<string>(
    currentUser?.phone || activeCitizen?.phone || ''
  );
  const [email, setEmail] = useState<string>(
    currentUser?.email || ''
  );
  
  // Password change state
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [passwordError, setPasswordError] = useState('');
  const [passwordSuccess, setPasswordSuccess] = useState(false);

  const [isUploading, setIsUploading] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Sync states when activeCitizen or modal opens
  React.useEffect(() => {
    if (activeCitizen) {
      setAvatarPreview(currentUser?.avatar || activeCitizen.avatar || '');
      setPhone(currentUser?.phone || activeCitizen.phone || '');
      setEmail(currentUser?.email || '');
      setPasswordError('');
      setPasswordSuccess(false);
      setNewPassword('');
      setConfirmPassword('');
    }
  }, [activeCitizen?.noKK, showModal]);

  if (!showModal || !activeCitizen) return null;

  // Monthly dues calculations
  const baseRate = settings.baseDuesAmount || settings.duesAmount || 5000;
  const extraRate = settings.extraMemberDuesAmount || 3000;
  const duesCalc = calculateCitizenMonthlyDues(activeCitizen, baseRate, extraRate);

  const totalMonthsPaid = Object.values(activeCitizen.monthlyDues).filter(m => (m as any).paid).length;
  const unpaidMonthsList = Object.entries(activeCitizen.monthlyDues)
    .filter(([k, v]) => !(v as any).paid && k.startsWith('2026'))
    .map(([k]) => k);

  const isDuesActive = unpaidMonthsList.length <= (settings.maxGraceMonths || 3);

  // Handle local file selection and convert to optimized base64
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      alert('Mohon pilih file format gambar (JPG, PNG, atau WebP).');
      return;
    }

    setIsUploading(true);
    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        // Resize image to max 400x400 with canvas for fast storage and offline caching
        const canvas = document.createElement('canvas');
        const maxDim = 400;
        let width = img.width;
        let height = img.height;

        if (width > height) {
          if (width > maxDim) {
            height = Math.round((height * maxDim) / width);
            width = maxDim;
          }
        } else {
          if (height > maxDim) {
            width = Math.round((width * maxDim) / height);
            height = maxDim;
          }
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, width, height);
          const compressedBase64 = canvas.toDataURL('image/jpeg', 0.85);
          setAvatarPreview(compressedBase64);
        }
        setIsUploading(false);
      };
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  const handleRemoveAvatar = () => {
    setAvatarPreview('');
  };

  const handleSaveProfile = () => {
    setPasswordError('');

    // Handle Password Change validation if filled
    if (newPassword || confirmPassword) {
      if (newPassword.length < 4) {
        setPasswordError('Kata sandi baru minimal 4 karakter.');
        return;
      }
      if (newPassword !== confirmPassword) {
        setPasswordError('Konfirmasi kata sandi tidak cocok.');
        return;
      }
    }

    // 1. Update current logged-in user profile & password
    if (currentUser) {
      const userUpdate: any = {
        avatar: avatarPreview,
        phone: phone.trim() || currentUser.phone,
        email: email.trim()
      };
      if (newPassword) {
        userUpdate.password = newPassword;
        setPasswordSuccess(true);
      }
      updateUser(currentUser.id, userUpdate);
    }

    // 2. Update citizen family record if matching
    if (activeCitizen) {
      updateCitizen(activeCitizen.id, {
        avatar: avatarPreview,
        phone: phone.trim() || activeCitizen.phone
      });
    }

    setSaveSuccess(true);
    setTimeout(() => {
      setSaveSuccess(false);
      setPasswordSuccess(false);
      handleClose();
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-fade-in no-print">
      <div className="bg-white w-full max-w-2xl rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[92vh]">
        
        {/* Modal Header */}
        <div className="bg-gradient-to-r from-emerald-800 via-teal-800 to-slate-900 text-white p-5 sm:p-6 flex items-center justify-between relative shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/10 border border-white/20 flex items-center justify-center shadow-inner">
              <User className="w-5 h-5 text-emerald-300" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-black text-white">Profil & Keamanan Akun</h2>
              <p className="text-xs text-emerald-200">
                {currentUser ? `${currentUser.name} (${currentUser.role.toUpperCase()})` : activeCitizen.headOfFamily} • {settings.orgName}
              </p>
            </div>
          </div>

          <button
            onClick={handleClose}
            className="p-2 text-white/70 hover:text-white hover:bg-white/10 rounded-full transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body - Scrollable */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-6">
          
          {/* Avatar Upload & Profile Summary Hero */}
          <div className="bg-slate-50 border border-slate-200/90 rounded-3xl p-5 sm:p-6 flex flex-col sm:flex-row items-center sm:items-start gap-5">
            
            {/* Avatar with Upload Badge */}
            <div className="relative group shrink-0">
              <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-3xl overflow-hidden border-3 border-emerald-500/40 shadow-lg bg-emerald-900 flex items-center justify-center">
                <img
                  src={getAvatarUrl(currentUser?.name || activeCitizen.headOfFamily, currentUser?.role || 'warga', avatarPreview)}
                  alt={activeCitizen.headOfFamily}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
              </div>

              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                disabled={isUploading}
                className="absolute -bottom-2 -right-2 p-2.5 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white rounded-2xl shadow-md border-2 border-white transition-all cursor-pointer"
                title="Unggah Foto Avatar Baru"
              >
                {isUploading ? (
                  <RefreshCw className="w-4 h-4 animate-spin" />
                ) : (
                  <Camera className="w-4 h-4" />
                )}
              </button>
              
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleFileChange}
                className="hidden"
              />
            </div>

            {/* Header info & fast actions */}
            <div className="flex-1 text-center sm:text-left min-w-0">
              <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 mb-1.5">
                <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-300">
                  RT {activeCitizen.rt} / RW {activeCitizen.rw}
                </span>
                <span className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full ${
                  activeCitizen.status === 'Aktif' 
                    ? 'bg-emerald-100 text-emerald-800 border border-emerald-300' 
                    : 'bg-amber-100 text-amber-800 border border-amber-300'
                }`}>
                  Status: {activeCitizen.status}
                </span>
                {activeCitizen.block && (
                  <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-800 border border-blue-200">
                    Blok {activeCitizen.block}
                  </span>
                )}
              </div>

              <h3 className="text-xl font-black text-slate-900 truncate">
                {currentUser?.name || activeCitizen.headOfFamily}
              </h3>
              <p className="text-xs font-mono text-slate-500 mt-0.5">
                No. KK: <strong>{activeCitizen.noKK}</strong> • NIK: {activeCitizen.nik}
              </p>
              <p className="text-xs text-slate-600 mt-1 flex items-center justify-center sm:justify-start gap-1">
                <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                <span>{activeCitizen.address}</span>
              </p>

              {/* Avatar management tools */}
              <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 mt-3 pt-3 border-t border-slate-200/80">
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="px-3 py-1.5 bg-white hover:bg-slate-100 text-slate-700 text-xs font-bold rounded-xl border border-slate-300 shadow-2xs flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Upload className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Pilih Foto Avatar</span>
                </button>

                {avatarPreview && (
                  <button
                    type="button"
                    onClick={handleRemoveAvatar}
                    className="px-2.5 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 text-xs font-semibold rounded-xl border border-rose-200 flex items-center gap-1 transition-colors cursor-pointer"
                    title="Hapus foto kustom"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Reset</span>
                  </button>
                )}

                <button
                  type="button"
                  onClick={() => handleOpenKta(activeCitizen)}
                  className="px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 text-xs font-bold rounded-xl border border-emerald-300 flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <QrCode className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Lihat KTA</span>
                </button>
              </div>
            </div>

          </div>

          {/* Change Password Section for Security */}
          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 sm:p-5 space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-extrabold text-slate-900 flex items-center gap-2">
                <KeyRound className="w-4 h-4 text-emerald-600" />
                <span>Ubah Kata Sandi / Password Akun</span>
              </h4>
              <span className="text-[10px] bg-slate-200 text-slate-700 font-bold px-2 py-0.5 rounded-md">
                Keamanan
              </span>
            </div>

            <p className="text-xs text-slate-500">
              Setiap pengguna berhak merubah kata sandi mandiri demi menjaga keamanan data pribadi dan akses sistem.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  Kata Sandi Baru
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    placeholder="Masukkan password baru"
                    className="w-full pl-3 pr-9 py-2 text-xs bg-white border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 cursor-pointer"
                  >
                    {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  Konfirmasi Kata Sandi Baru
                </label>
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="Ulangi password baru"
                  className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>
            </div>

            {passwordError && (
              <p className="text-[11px] text-rose-600 font-bold flex items-center gap-1">
                <AlertCircle className="w-3.5 h-3.5" />
                <span>{passwordError}</span>
              </p>
            )}

            {passwordSuccess && (
              <p className="text-[11px] text-emerald-700 font-bold flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Kata sandi berhasil diperbarui!</span>
              </p>
            )}
          </div>

          {/* Membership & Fardhu Kifayah Status Banner */}
          <div className={`rounded-2xl p-4 border ${
            isDuesActive 
              ? 'bg-emerald-50/80 border-emerald-200 text-emerald-950' 
              : 'bg-amber-50/80 border-amber-200 text-amber-950'
          }`}>
            <div className="flex items-start gap-3">
              <div className={`p-2 rounded-xl shrink-0 ${
                isDuesActive ? 'bg-emerald-600 text-white' : 'bg-amber-600 text-white'
              }`}>
                {isDuesActive ? <ShieldCheck className="w-5 h-5" /> : <AlertCircle className="w-5 h-5" />}
              </div>
              <div className="flex-1 text-xs">
                <h4 className="font-extrabold text-sm">
                  {isDuesActive ? 'Hak Layanan Duka 100% Aktif' : 'Status Iuran Perlu Diperbarui'}
                </h4>
                <p className="mt-0.5 leading-relaxed text-slate-700">
                  {isDuesActive ? (
                    <>Keluarga Anda berhak menerima layanan fardhu kifayah lengkap (pemulasaraan, amil, kain kafan, keranda, ambulans) & santunan duka sesuai ketentuan AD/ART RKM 2024–2027.</>
                  ) : (
                    <>Terdapat tunggakan iuran kas kematian. Segera hubungi koordinator wilayah atau lakukan pembayaran mandiri agar status proteksi duka tetap aktif.</>
                  )}
                </p>
              </div>
            </div>
          </div>

          {/* 3-Col Key Metrics */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="bg-slate-50 border border-slate-200 p-3.5 rounded-2xl text-center">
              <span className="text-[10px] text-slate-500 uppercase font-bold tracking-wider block">
                Jiwa Tertanggung
              </span>
              <span className="text-xl font-black text-slate-900 mt-0.5 block">
                {activeCitizen.members?.length || 1} Jiwa
              </span>
              <span className="text-[10px] text-slate-500">
                {duesCalc.coreMembersCount} Inti + {duesCalc.extraMembersCount} Tambahan
              </span>
            </div>

            <div className="bg-slate-50 border border-slate-200 p-3.5 rounded-2xl text-center">
              <span className="text-[10px] text-slate-500 uppercase font-bold tracking-wider block">
                Tarif Iuran Bulanan
              </span>
              <span className="text-xl font-black text-emerald-700 mt-0.5 block">
                {formatRupiah(duesCalc.totalMonthlyDues)}
              </span>
              <span className="text-[10px] text-slate-500">
                Pokok {formatRupiah(duesCalc.baseFee)} {duesCalc.totalExtraDues > 0 && `+ ${formatRupiah(duesCalc.totalExtraDues)}`}
              </span>
            </div>

            <div className="bg-slate-50 border border-slate-200 p-3.5 rounded-2xl text-center">
              <span className="text-[10px] text-slate-500 uppercase font-bold tracking-wider block">
                Iuran Tahun 2026
              </span>
              <span className={`text-xl font-black mt-0.5 block ${
                unpaidMonthsList.length === 0 ? 'text-emerald-700' : 'text-amber-700'
              }`}>
                {totalMonthsPaid} / 12 Bln
              </span>
              <span className="text-[10px] text-slate-500">
                {unpaidMonthsList.length === 0 ? 'Lunas Penuh ✨' : `Tunggakan: ${unpaidMonthsList.length} Bulan`}
              </span>
            </div>
          </div>

          {/* Family Members Breakdown Table */}
          <div className="border border-slate-200 rounded-2xl overflow-hidden">
            <div className="bg-slate-100 px-4 py-2.5 border-b border-slate-200 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Users className="w-4 h-4 text-emerald-700" />
                <span className="text-xs font-extrabold text-slate-900">Daftar Anggota Keluarga (KTA)</span>
              </div>
              <span className="text-[10px] bg-slate-200 text-slate-700 px-2 py-0.5 rounded-full font-bold">
                {activeCitizen.members?.length || 0} Terdaftar
              </span>
            </div>

            <div className="divide-y divide-slate-100 max-h-48 overflow-y-auto">
              {activeCitizen.members && activeCitizen.members.length > 0 ? (
                activeCitizen.members.map((member, idx) => (
                  <div key={member.id || idx} className="p-3 hover:bg-slate-50 flex items-center justify-between gap-2 text-xs">
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div className="w-6 h-6 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center font-bold text-[10px]">
                        {idx + 1}
                      </div>
                      <div className="min-w-0">
                        <p className="font-bold text-slate-900 truncate">{member.name}</p>
                        <p className="text-[10px] text-slate-500">
                          {member.relation} • {member.gender}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <span className={`text-[10px] px-2 py-0.5 rounded-md font-semibold ${
                        member.category === 'Tambahan' 
                          ? 'bg-amber-50 text-amber-800 border border-amber-200' 
                          : 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                      }`}>
                        {member.category || 'Inti'}
                      </span>
                      <span className={`text-[10px] px-2 py-0.5 rounded-md font-bold ${
                        member.status === 'Meninggal'
                          ? 'bg-slate-200 text-slate-700'
                          : 'bg-teal-50 text-teal-800'
                      }`}>
                        {member.status || 'Hidup'}
                      </span>
                    </div>
                  </div>
                ))
              ) : (
                <div className="p-4 text-center text-xs text-slate-400">
                  Belum ada anggota keluarga terdaftar.
                </div>
              )}
            </div>
          </div>

          {/* Edit Contact Information Section */}
          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-3">
            <h4 className="text-xs font-extrabold text-slate-900 flex items-center gap-2">
              <Phone className="w-4 h-4 text-emerald-600" />
              <span>Perbarui Kontak Mandiri</span>
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  Nomor WhatsApp / HP
                </label>
                <input
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="08123456789"
                  className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  Alamat Email (Opsional)
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="warga@example.com"
                  className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>
            </div>
            <p className="text-[10px] text-slate-500">
              * Perubahan nomor WhatsApp dan foto avatar akan langsung terupdate di sistem kuitansi digital dan KTA.
            </p>
          </div>

        </div>

        {/* Modal Footer with Actions */}
        <div className="bg-slate-50 px-5 py-4 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0">
          <div className="text-xs text-slate-500">
            {saveSuccess && (
              <span className="text-emerald-700 font-bold flex items-center gap-1.5 animate-bounce">
                <CheckCircle2 className="w-4 h-4" />
                <span>Profil dan pengaturan berhasil disimpan!</span>
              </span>
            )}
          </div>

          <div className="flex items-center gap-2.5 w-full sm:w-auto">
            <button
              type="button"
              onClick={handleClose}
              className="flex-1 sm:flex-none px-4 py-2.5 bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold text-xs rounded-xl transition-colors cursor-pointer"
            >
              Batal
            </button>
            <button
              type="button"
              onClick={handleSaveProfile}
              className="flex-1 sm:flex-none px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 active:scale-98 text-white font-bold text-xs rounded-xl shadow-md flex items-center justify-center gap-2 transition-all cursor-pointer"
            >
              <Check className="w-4 h-4" />
              <span>Simpan Profil & Kata Sandi</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
