import React, { useState, useEffect, useRef, useMemo } from 'react';
import { 
  Settings, 
  Save, 
  RefreshCw, 
  Download, 
  Upload,
  FileSpreadsheet, 
  ShieldCheck, 
  Users, 
  UserPlus,
  Building, 
  CreditCard, 
  QrCode, 
  Phone,
  CheckCircle2,
  AlertTriangle,
  FileText,
  Mail,
  MapPin,
  Plus,
  Trash2,
  Check,
  Globe,
  DollarSign,
  ExternalLink,
  UserCheck,
  Shield,
  BadgeCheck,
  KeyRound,
  FileSpreadsheet as CsvIcon,
  Truck,
  MessageSquare,
  Map,
  Stamp,
  Layers,
  Award,
  Activity,
  X,
  Copy,
  Edit2,
  Sliders,
  Terminal
} from 'lucide-react';
import { useRkm } from '../context/RkmContext';
import { formatRupiah, formatDateIndo, getDirectImageUrl } from '../utils/formatters';
import { BankAccount, Officer } from '../types';
import { AccessManagementSettings } from './AccessManagementSettings';
import { OfficerManagementSettings } from './OfficerManagementSettings';
import { NewMemberRegistrationSettings } from './NewMemberRegistrationSettings';
import { OperationalSettings } from './OperationalSettings';
import { NotificationTemplateSettings } from './NotificationTemplateSettings';
import { BackupRestoreSettings } from './BackupRestoreSettings';
import { TerritorySettings } from './TerritorySettings';
import { SystemAuditLogsSettings } from './SystemAuditLogsSettings';
import { SuperuserSystemSettings } from './SuperuserSystemSettings';
import { generateGoogleAppsScriptCode, downloadCsvForTable } from '../utils/googleSheetsSync';

export const SettingsView: React.FC = () => {
  const { 
    settings, 
    updateSettings, 
    officers, 
    addOfficer, 
    deleteOfficer, 
    updateOfficer,
    resetToDefaultData, 
    resetToDemo, 
    citizens, 
    transactions,
    deathNotices,
    assets,
    assetLoans,
    feedbacks,
    syncGoogleSheets,
    importFullData,
    users,
    auditLogs,
    runAutoAging
  } = useRkm();

  type SettingsMainCategory = 'organization' | 'admin_user' | 'system_logs' | 'superuser';

  type SettingsSubTab = 
    | 'identity' 
    | 'rates' 
    | 'banks' 
    | 'operational'
    | 'templates'
    | 'territory'
    | 'signatories' 
    | 'officers' 
    | 'members' 
    | 'accounts' 
    | 'audit'
    | 'sheets' 
    | 'backup'
    | 'superuser_main';

  const [activeMainCategory, setActiveMainCategory] = useState<SettingsMainCategory>('organization');
  const [activeSubTab, setActiveSubTab] = useState<SettingsSubTab>('identity');
  const [formState, setFormState] = useState(settings);
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncMessage, setSyncMessage] = useState<string | null>(null);
  const [autoAgingResult, setAutoAgingResult] = useState<string | null>(null);
  const [isRunningAging, setIsRunningAging] = useState(false);
  const [importMessage, setImportMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [showScriptModal, setShowScriptModal] = useState(false);
  const [copiedScript, setCopiedScript] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Group definitions for clear structure
  const CATEGORY_TABS = [
    {
      id: 'organization' as SettingsMainCategory,
      title: 'Konfigurasi Organisasi',
      desc: 'Identitas, legalitas, tarif AD/ART, kas, rekening, ambulans & wilayah',
      icon: Building,
      subTabs: [
        { id: 'identity' as SettingsSubTab, label: 'Identitas & Legalitas', icon: Building },
        { id: 'rates' as SettingsSubTab, label: 'Tarif & Paket Fardhu Kifayah', icon: DollarSign },
        { id: 'banks' as SettingsSubTab, label: 'Rekening Bank & QRIS', icon: QrCode },
        { id: 'operational' as SettingsSubTab, label: 'Ambulans & Pemakaman', icon: Truck },
        { id: 'templates' as SettingsSubTab, label: 'Template WA & Penomoran', icon: MessageSquare },
        { id: 'territory' as SettingsSubTab, label: 'Master Wilayah RT & Blok', icon: Map },
        { id: 'signatories' as SettingsSubTab, label: 'Penandatangan Dokumen', icon: BadgeCheck },
      ]
    },
    {
      id: 'admin_user' as SettingsMainCategory,
      title: 'Pengaturan Admin & User',
      desc: 'Manajemen akun, hak akses RBAC, struktur pengurus & formulir anggota',
      icon: ShieldCheck,
      countBadge: users.length,
      subTabs: [
        { id: 'accounts' as SettingsSubTab, label: 'Akun & Hak Akses (RBAC)', icon: ShieldCheck, badge: users.length },
        { id: 'officers' as SettingsSubTab, label: 'Struktur Satgas & Pengurus', icon: Users, badge: officers.length },
        { id: 'members' as SettingsSubTab, label: 'Pendaftaran Warga Baru', icon: UserPlus, badge: citizens.length },
      ]
    },
    {
      id: 'system_logs' as SettingsMainCategory,
      title: 'Log Sistem & Pemeliharaan',
      desc: 'Riwayat audit trail, integrasi Google Sheets, cadangan database & reset',
      icon: Activity,
      countBadge: auditLogs.length,
      subTabs: [
        { id: 'audit' as SettingsSubTab, label: 'Log Audit & Riwayat Keamanan', icon: Activity, badge: auditLogs.length },
        { id: 'sheets' as SettingsSubTab, label: 'Google Sheets & Cloud', icon: Globe },
        { id: 'backup' as SettingsSubTab, label: 'Import/Export Database', icon: FileText },
      ]
    },
    {
      id: 'superuser' as SettingsMainCategory,
      title: 'Superuser & Kontrol Sistem',
      desc: 'Mode perawatan, otorisasi Master PIN, WhatsApp gateway, ambang kas & snapshot',
      icon: Sliders,
      badgeText: 'Super Admin',
      subTabs: [
        { id: 'superuser_main' as SettingsSubTab, label: 'Pusat Kontrol Superuser & Sistem', icon: Sliders },
      ]
    }
  ];

  // Handle Main Category Change
  const handleSelectCategory = (catId: SettingsMainCategory) => {
    setActiveMainCategory(catId);
    const category = CATEGORY_TABS.find(c => c.id === catId);
    if (category && category.subTabs.length > 0) {
      // If current sub-tab is not in the new category, switch to the first sub-tab
      const isSubTabInCategory = category.subTabs.some(s => s.id === activeSubTab);
      if (!isSubTabInCategory) {
        setActiveSubTab(category.subTabs[0].id);
      }
    }
  };

  // Sync internal form state when global settings update
  useEffect(() => {
    setFormState(settings);
  }, [settings]);

  // Bank Form State
  const [newBank, setNewBank] = useState('');
  const [newAccountNo, setNewAccountNo] = useState('');
  const [newAccountHolder, setNewAccountHolder] = useState('');
  const [showAddBank, setShowAddBank] = useState(false);
  const [editingBankIndex, setEditingBankIndex] = useState<number | null>(null);

  // Save Settings handler
  const handleSaveSettings = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    updateSettings(formState);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3500);
  };

  // Google Sheets Sync
  const handleSyncSheets = async () => {
    setIsSyncing(true);
    setSyncMessage(null);
    try {
      const success = await syncGoogleSheets();
      if (success) {
        setSyncMessage('✓ Sinkronisasi 2 arah dengan Google Spreadsheet Berhasil!');
      } else {
        setSyncMessage('Sinkronisasi cloud tersimpan secara offline.');
      }
    } catch {
      setSyncMessage('Gagal menyinkronkan data.');
    } finally {
      setIsSyncing(false);
      setTimeout(() => setSyncMessage(null), 5000);
    }
  };

  // Open Edit Bank
  const handleOpenEditBank = (index: number) => {
    const acc = formState.bankAccounts[index];
    if (acc) {
      setNewBank(acc.bank);
      setNewAccountNo(acc.accountNumber);
      setNewAccountHolder(acc.accountHolder);
      setEditingBankIndex(index);
      setShowAddBank(true);
    }
  };

  // Add or Edit Bank Account
  const handleAddBank = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newBank || !newAccountNo || !newAccountHolder) return;

    if (editingBankIndex !== null) {
      const updatedAccounts = formState.bankAccounts.map((acc, i) => {
        if (i === editingBankIndex) {
          return {
            ...acc,
            bank: newBank,
            accountNumber: newAccountNo,
            accountHolder: newAccountHolder
          };
        }
        return acc;
      });
      const updated = { ...formState, bankAccounts: updatedAccounts };
      setFormState(updated);
      updateSettings(updated);
      setEditingBankIndex(null);
    } else {
      const newAccount: BankAccount = {
        bank: newBank,
        accountNumber: newAccountNo,
        accountHolder: newAccountHolder,
        isPrimary: formState.bankAccounts.length === 0
      };

      const updated = {
        ...formState,
        bankAccounts: [...formState.bankAccounts, newAccount]
      };

      setFormState(updated);
      updateSettings(updated);
    }

    setNewBank('');
    setNewAccountNo('');
    setNewAccountHolder('');
    setShowAddBank(false);
  };

  // Remove Bank Account
  const handleRemoveBank = (index: number) => {
    const updatedAccounts = formState.bankAccounts.filter((_, i) => i !== index);
    if (updatedAccounts.length > 0 && !updatedAccounts.some(b => b.isPrimary)) {
      updatedAccounts[0].isPrimary = true;
    }
    const updated = { ...formState, bankAccounts: updatedAccounts };
    setFormState(updated);
    updateSettings(updated);
  };

  // Set Primary Bank
  const handleSetPrimaryBank = (index: number) => {
    const updatedAccounts = formState.bankAccounts.map((b, i) => ({
      ...b,
      isPrimary: i === index
    }));
    const updated = { ...formState, bankAccounts: updatedAccounts };
    setFormState(updated);
    updateSettings(updated);
  };

  // Export Full JSON Backup
  const handleExportJSON = () => {
    const fullBackup = {
      appName: 'RKM MPP DIGITAL',
      version: '2.5.0',
      exportDate: new Date().toISOString(),
      settings: formState,
      citizens,
      transactions,
      deathNotices,
      assets,
      assetLoans,
      officers,
      feedbacks,
      users
    };

    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(fullBackup, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `BACKUP_RKM_MPP_${new Date().toISOString().split('T')[0]}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  // Import Full JSON Backup
  const handleImportJSON = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const content = event.target?.result as string;
        const parsed = JSON.parse(content);
        const success = importFullData(parsed);
        if (success) {
          setImportMessage({ type: 'success', text: '✓ Seluruh database berhasil dipulihkan dari file cadangan JSON.' });
        } else {
          setImportMessage({ type: 'error', text: 'File cadangan tidak valid atau struktur tidak cocok.' });
        }
      } catch {
        setImportMessage({ type: 'error', text: 'Gagal memproses file JSON. Pastikan format file benar.' });
      }
    };
    reader.readAsText(file);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  // Dynamic Fardhu Kifayah allocation items
  const currentDeathPackageItems = useMemo(() => {
    if (formState.deathPackageItems && formState.deathPackageItems.length > 0) {
      return formState.deathPackageItems;
    }
    return [
      { id: 'shroud', name: 'Kain Kafan & Perlengkapan', amount: formState.deathPackageShroud || 150000 },
      { id: 'bathing', name: 'Tim Pemulasaraan / Memandikan Jenazah', amount: formState.deathPackageBathing || 100000 },
      { id: 'prayer', name: 'Imam Salat Jenazah & Doa', amount: formState.deathPackagePrayer || 450000 },
      { id: 'transport', name: 'BBM & Driver Ambulans', amount: formState.deathPackageTransport || 200000 },
      { id: 'gravedigger', name: 'Penggalian Liang Lahat (TPU)', amount: formState.deathPackageGravedigger || 800000 },
      { id: 'adminDistrict', name: 'Administrasi & Retribusi TPU', amount: formState.deathPackageAdminDistrict || 150000 },
      { id: 'tactical', name: 'Dana Taktis / Darurat Lapangan', amount: formState.deathPackageTactical || 50000 }
    ];
  }, [
    formState.deathPackageItems,
    formState.deathPackageShroud,
    formState.deathPackageBathing,
    formState.deathPackagePrayer,
    formState.deathPackageTransport,
    formState.deathPackageGravedigger,
    formState.deathPackageAdminDistrict,
    formState.deathPackageTactical
  ]);

  const totalPackageAllocated = useMemo(() => {
    return currentDeathPackageItems.reduce((acc, curr) => acc + (Number(curr.amount) || 0), 0);
  }, [currentDeathPackageItems]);

  const handleUpdatePackageItem = (id: string, field: 'name' | 'amount', value: string | number) => {
    const updated = currentDeathPackageItems.map(item => {
      if (item.id === id) {
        return {
          ...item,
          [field]: field === 'amount' ? (Number(value) || 0) : value
        };
      }
      return item;
    });
    setFormState(prev => ({
      ...prev,
      deathPackageItems: updated
    }));
  };

  const handleAddPackageItem = () => {
    const newItem = {
      id: `dp-${Date.now()}`,
      name: `Pos Biaya ${currentDeathPackageItems.length + 1}`,
      amount: 50000
    };
    setFormState(prev => ({
      ...prev,
      deathPackageItems: [...currentDeathPackageItems, newItem]
    }));
  };

  const handleRemovePackageItem = (id: string) => {
    if (currentDeathPackageItems.length <= 1) return;
    const updated = currentDeathPackageItems.filter(item => item.id !== id);
    setFormState(prev => ({
      ...prev,
      deathPackageItems: updated
    }));
  };

  const handleResetDefaultPackageItems = () => {
    const defaults = [
      { id: 'shroud', name: 'Kain Kafan & Perlengkapan', amount: 150000 },
      { id: 'bathing', name: 'Tim Pemulasaraan / Memandikan Jenazah', amount: 100000 },
      { id: 'prayer', name: 'Imam Salat Jenazah & Doa', amount: 450000 },
      { id: 'transport', name: 'BBM & Driver Ambulans', amount: 200000 },
      { id: 'gravedigger', name: 'Penggalian Liang Lahat (TPU)', amount: 800000 },
      { id: 'adminDistrict', name: 'Administrasi & Retribusi TPU', amount: 150000 },
      { id: 'tactical', name: 'Dana Taktis / Darurat Lapangan', amount: 50000 }
    ];
    setFormState(prev => ({
      ...prev,
      deathPackageItems: defaults
    }));
  };

  // Toast notification for trigger backup
  const [backupToast, setBackupToast] = useState<{ show: boolean; message: string; timestamp: string } | null>(null);

  // Trigger Backup Function that serializes current RKMContext state into a blob and downloads it
  const handleTriggerBackup = () => {
    const fullState = {
      appName: 'RKM MPP DIGITAL',
      version: '2.5.0',
      exportedAt: new Date().toISOString(),
      systemInfo: {
        totalCitizens: citizens.length,
        totalTransactions: transactions.length,
        totalDeathNotices: deathNotices.length,
        totalAssets: assets.length
      },
      settings: formState,
      citizens,
      transactions,
      deathNotices,
      assets,
      assetLoans,
      officers,
      feedbacks,
      users,
      auditLogs
    };

    const blob = new Blob([JSON.stringify(fullState, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    const dateStr = new Date().toISOString().slice(0, 10);
    link.download = `RKM_MPP_FULL_BACKUP_${dateStr}.json`;
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);

    setBackupToast({
      show: true,
      message: `Cadangan database berhasil dibuat dan diunduh (RKM_MPP_FULL_BACKUP_${dateStr}.json).`,
      timestamp: new Date().toLocaleTimeString('id-ID')
    });

    setTimeout(() => {
      setBackupToast(prev => prev ? { ...prev, show: false } : null);
    }, 5000);
  };

  return (
    <div className="space-y-6 pb-16 animate-fade-in">
      
      {/* Top Banner */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-2xl bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold">
            <Settings className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
              Pengaturan & Konfigurasi Sistem RKM MPP
            </h1>
            <p className="text-xs text-slate-500 mt-0.5">
              Kelola identitas, legalitas, tarif AD/ART, kas, rekening bank, ambulans, WhatsApp, dan hak akses pengurus.
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            id="btn-backup-database"
            type="button"
            onClick={handleTriggerBackup}
            className="flex items-center gap-2 px-4 py-2.5 bg-slate-900 hover:bg-slate-800 active:scale-95 text-white font-bold text-xs rounded-xl shadow-md transition-all border border-slate-700 cursor-pointer"
            title="Backup Database (Disaster Recovery) - Download salinan data warga, buku kas, dan aset dalam format JSON"
          >
            <Download className="w-4 h-4 text-emerald-400" />
            <span>Backup Database (.JSON)</span>
          </button>

          <button
            onClick={() => handleSaveSettings()}
            className="flex items-center gap-2 px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white font-bold text-xs rounded-xl shadow-md transition-all cursor-pointer"
          >
            <Save className="w-4 h-4" />
            <span>Simpan Semua Perubahan</span>
          </button>
        </div>
      </div>

      {/* Backup Toast Notification */}
      {backupToast && backupToast.show && (
        <div className="p-4 bg-emerald-600 text-white rounded-2xl shadow-lg flex items-center justify-between animate-fade-in text-xs">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-full bg-white/20 flex items-center justify-center font-bold">
              <Check className="w-4 h-4 text-white" />
            </div>
            <div>
              <span className="font-black block text-sm">Backup Database Berhasil Diunduh!</span>
              <span className="text-emerald-100 text-[11px] font-medium">
                {backupToast.message} • Pukul {backupToast.timestamp} WIB
              </span>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setBackupToast(null)}
            className="px-3 py-1 bg-white/20 hover:bg-white/30 text-white text-[11px] font-bold rounded-lg cursor-pointer transition-colors"
          >
            Tutup
          </button>
        </div>
      )}

      {/* Success Notification Alert */}
      {savedSuccess && (
        <div className="p-4 bg-emerald-50 border border-emerald-200 text-emerald-900 rounded-2xl flex items-center justify-between shadow-xs animate-fade-in">
          <div className="flex items-center gap-2.5 text-xs font-bold">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
            <span>Konfigurasi sistem berhasil disimpan dan diterapkan ke seluruh modul!</span>
          </div>
          <button onClick={() => setSavedSuccess(false)} className="text-emerald-700 font-bold text-xs hover:underline">
            Tutup
          </button>
        </div>
      )}

      {/* Main Category Tabs (Structured 4-Pillar Hierarchy) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
        {CATEGORY_TABS.map((category) => {
          const Icon = category.icon;
          const isCatActive = activeMainCategory === category.id;

          return (
            <button
              key={category.id}
              onClick={() => handleSelectCategory(category.id)}
              className={`text-left p-4 sm:p-5 rounded-3xl border transition-all relative overflow-hidden group cursor-pointer ${
                isCatActive
                  ? 'bg-slate-900 text-white border-slate-900 shadow-lg shadow-slate-950/20'
                  : 'bg-white hover:bg-slate-50 text-slate-800 border-slate-200/80 shadow-xs'
              }`}
            >
              <div className="flex items-start justify-between gap-2">
                <div className={`w-11 h-11 rounded-2xl flex items-center justify-center font-bold shrink-0 transition-transform group-hover:scale-105 ${
                  isCatActive 
                    ? category.id === 'superuser' ? 'bg-amber-400 text-slate-950 shadow-md' : 'bg-emerald-600 text-white shadow-md' 
                    : 'bg-slate-100 text-slate-700'
                }`}>
                  <Icon className="w-5 h-5" />
                </div>

                {category.badgeText ? (
                  <span className={`px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider ${
                    isCatActive
                      ? 'bg-amber-400 text-slate-950 shadow-xs'
                      : 'bg-amber-100 text-amber-900 border border-amber-200'
                  }`}>
                    {category.badgeText}
                  </span>
                ) : category.countBadge !== undefined ? (
                  <span className={`px-2.5 py-1 rounded-full text-[10px] font-black ${
                    isCatActive
                      ? 'bg-slate-800 text-emerald-300 border border-emerald-500/30'
                      : 'bg-slate-100 text-slate-600 border border-slate-200'
                  }`}>
                    {category.countBadge} Rekaman
                  </span>
                ) : null}
              </div>

              <div className="mt-3.5">
                <h3 className={`font-black text-sm sm:text-base tracking-tight ${
                  isCatActive ? 'text-white' : 'text-slate-900'
                }`}>
                  {category.title}
                </h3>
                <p className={`text-[11px] mt-1 leading-relaxed line-clamp-2 ${
                  isCatActive ? 'text-slate-300' : 'text-slate-500'
                }`}>
                  {category.desc}
                </p>
              </div>

              {isCatActive && (
                <div className={`absolute bottom-0 left-0 right-0 h-1.5 ${
                  category.id === 'superuser' ? 'bg-amber-400' : 'bg-emerald-500'
                }`} />
              )}
            </button>
          );
        })}
      </div>

      {/* Dynamic Sub-Tabs Navigation for the Active Category */}
      {(() => {
        const currentCategory = CATEGORY_TABS.find(c => c.id === activeMainCategory);
        if (!currentCategory) return null;

        return (
          <div className="bg-white rounded-2xl p-2 sm:p-2.5 border border-slate-200/80 shadow-xs">
            <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-0.5">
              {currentCategory.subTabs.map((tab) => {
                const Icon = tab.icon;
                const isActive = activeSubTab === tab.id;

                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveSubTab(tab.id)}
                    className={`flex items-center gap-2 px-3.5 py-2.5 rounded-xl font-bold text-xs whitespace-nowrap transition-all ${
                      isActive
                        ? 'bg-emerald-600 text-white shadow-md'
                        : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                    }`}
                  >
                    <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                    <span>{tab.label}</span>
                    {tab.badge !== undefined && (
                      <span className={`px-1.5 py-0.5 rounded-full text-[10px] font-extrabold ${
                        isActive ? 'bg-emerald-800 text-emerald-100' : 'bg-slate-100 text-slate-600'
                      }`}>
                        {tab.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        );
      })()}

      {/* TAB 1: IDENTITAS & LEGALITAS */}
      {activeSubTab === 'identity' && (
        <form onSubmit={handleSaveSettings} className="space-y-6">
          <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/80 shadow-sm space-y-6">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Building className="w-5 h-5 text-emerald-600" />
                <div>
                  <h2 className="font-extrabold text-base text-slate-900">Identitas & Legalitas Lembaga</h2>
                  <p className="text-xs text-slate-500">Nama dan identitas resmi yang tercetak pada KTA warga, kuitansi kasir, dan lelayu.</p>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              
              {/* Logo Paguyuban */}
              <div className="p-4 bg-emerald-50/50 border border-emerald-100 rounded-2xl space-y-2">
                <label className="font-bold text-slate-800 block">
                  Logo Resmi Paguyuban (Google Drive / Link Web / CDN):
                </label>
                <div className="flex flex-col sm:flex-row items-center gap-4">
                  <div className="w-16 h-16 rounded-2xl bg-white border-2 border-emerald-500/40 p-1 shadow-sm flex items-center justify-center shrink-0">
                    {formState.logoUrl ? (
                      <img 
                        src={getDirectImageUrl(formState.logoUrl)} 
                        alt="Logo"
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-contain"
                      />
                    ) : (
                      <Building className="w-6 h-6 text-emerald-600" />
                    )}
                  </div>
                  <div className="flex-1 w-full space-y-1">
                    <input
                      type="text"
                      value={formState.logoUrl || ''}
                      onChange={(e) => setFormState({ ...formState, logoUrl: e.target.value })}
                      placeholder="https://lh3.googleusercontent.com/d/..."
                      className="w-full p-2 bg-white border border-slate-300 rounded-xl font-mono text-[11px] text-slate-900"
                    />
                    <div className="flex justify-between text-[10px] text-slate-500">
                      <span>Tautan URL Gambar / Google Drive</span>
                      <button
                        type="button"
                        onClick={() => setFormState({ ...formState, logoUrl: 'https://lh3.googleusercontent.com/d/1ZLdrjSjY8eudTvhUhwPkl2dNBl407HYV' })}
                        className="text-emerald-700 hover:underline font-semibold"
                      >
                        Reset Logo Resmi
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Stempel Digital */}
              <div className="p-4 bg-indigo-50/50 border border-indigo-100 rounded-2xl space-y-2">
                <label className="font-bold text-slate-800 block">
                  Stempel Digital Resmi (Untuk Kuitansi & KTA):
                </label>
                <div className="flex flex-col sm:flex-row items-center gap-4">
                  <div className="w-16 h-16 rounded-2xl bg-white border-2 border-indigo-500/40 p-1 shadow-sm flex items-center justify-center shrink-0">
                    {formState.stampUrl ? (
                      <img 
                        src={getDirectImageUrl(formState.stampUrl)} 
                        alt="Stempel"
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-contain"
                      />
                    ) : (
                      <Stamp className="w-6 h-6 text-indigo-600" />
                    )}
                  </div>
                  <div className="flex-1 w-full space-y-1">
                    <input
                      type="text"
                      value={formState.stampUrl || ''}
                      onChange={(e) => setFormState({ ...formState, stampUrl: e.target.value })}
                      placeholder="https://images.unsplash.com/..."
                      className="w-full p-2 bg-white border border-slate-300 rounded-xl font-mono text-[11px] text-slate-900"
                    />
                    <div className="flex justify-between text-[10px] text-slate-500">
                      <span>Format PNG transparan dianjurkan</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="md:col-span-2">
                <label className="font-bold text-slate-700 block mb-1">Nama Organisasi / Masjid / Lembaga Resmi:</label>
                <input
                  type="text"
                  value={formState.orgName}
                  onChange={(e) => setFormState({ ...formState, orgName: e.target.value })}
                  placeholder="MASJID METRO PARUNG PANJANG"
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-bold text-sm text-slate-900 focus:bg-white focus:ring-2 focus:ring-emerald-500"
                  required
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Nama Singkat / Brand Portal:</label>
                <input
                  type="text"
                  value={formState.shortName}
                  onChange={(e) => setFormState({ ...formState, shortName: e.target.value })}
                  placeholder="RKM MPP DIGITAL"
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-bold text-slate-900"
                  required
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Nomor Legalitas / SK DKM:</label>
                <input
                  type="text"
                  value={formState.legalNumber || ''}
                  onChange={(e) => setFormState({ ...formState, legalNumber: e.target.value })}
                  placeholder="SK DKM Al-Muhajirin / 012/RKM-MPP/2024"
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-semibold text-slate-900"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Periode Masa Bakti AD/ART:</label>
                <input
                  type="text"
                  value={formState.adArtPeriod || '2024–2027'}
                  onChange={(e) => setFormState({ ...formState, adArtPeriod: e.target.value })}
                  placeholder="2024–2027"
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-bold text-emerald-800"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Tahun Berdiri:</label>
                <input
                  type="text"
                  value={formState.foundedYear || '2018'}
                  onChange={(e) => setFormState({ ...formState, foundedYear: e.target.value })}
                  placeholder="2018"
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl text-slate-900"
                />
              </div>

              <div className="md:col-span-2">
                <label className="font-bold text-slate-700 block mb-1">Slogan / Visi Paguyuban:</label>
                <input
                  type="text"
                  value={formState.slogan}
                  onChange={(e) => setFormState({ ...formState, slogan: e.target.value })}
                  placeholder="Bersama Mengabdi, Menolong Sesama dalam Duka & Kebajikan"
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl text-slate-900"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Cakupan Wilayah / Komplek / RT-RW:</label>
                <input
                  type="text"
                  value={formState.rtRw}
                  onChange={(e) => setFormState({ ...formState, rtRw: e.target.value })}
                  placeholder="Perumahan Metro Parung Panjang"
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl text-slate-900"
                  required
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Desa / Kelurahan:</label>
                <input
                  type="text"
                  value={formState.village}
                  onChange={(e) => setFormState({ ...formState, village: e.target.value })}
                  placeholder="Desa Parung Panjang"
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl text-slate-900"
                  required
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Kecamatan:</label>
                <input
                  type="text"
                  value={formState.district}
                  onChange={(e) => setFormState({ ...formState, district: e.target.value })}
                  placeholder="Kecamatan Parungpanjang"
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl text-slate-900"
                  required
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Kabupaten / Kota & Kode Pos:</label>
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="text"
                    value={formState.regency}
                    onChange={(e) => setFormState({ ...formState, regency: e.target.value })}
                    placeholder="Kabupaten Bogor"
                    className="p-2.5 bg-slate-50 border border-slate-300 rounded-xl text-slate-900"
                    required
                  />
                  <input
                    type="text"
                    value={formState.postalCode || '16360'}
                    onChange={(e) => setFormState({ ...formState, postalCode: e.target.value })}
                    placeholder="16360"
                    className="p-2.5 bg-slate-50 border border-slate-300 rounded-xl text-slate-900 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Provinsi:</label>
                <input
                  type="text"
                  value={formState.province}
                  onChange={(e) => setFormState({ ...formState, province: e.target.value })}
                  placeholder="Jawa Barat"
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl text-slate-900"
                  required
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Email Resmi Sekretariat:</label>
                <input
                  type="email"
                  value={formState.email}
                  onChange={(e) => setFormState({ ...formState, email: e.target.value })}
                  placeholder="rkmmpp@gmail.com"
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl text-slate-900"
                  required
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Call Center / Hotline Siaga 24 Jam:</label>
                <input
                  type="text"
                  value={formState.contactCenter}
                  onChange={(e) => setFormState({ ...formState, contactCenter: e.target.value })}
                  placeholder="0812-3456-7890 (Siaga 24 Jam)"
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl text-slate-900 font-bold"
                  required
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">WhatsApp Admin (Format: 6281...):</label>
                <input
                  type="text"
                  value={formState.waAdmin}
                  onChange={(e) => setFormState({ ...formState, waAdmin: e.target.value })}
                  placeholder="6281234567890"
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-mono text-slate-900"
                  required
                />
              </div>

              <div className="md:col-span-2">
                <label className="font-bold text-slate-700 block mb-1">Alamat Website / Portal URL:</label>
                <input
                  type="url"
                  value={formState.websiteUrl || 'https://portal.rkm-mpp.id'}
                  onChange={(e) => setFormState({ ...formState, websiteUrl: e.target.value })}
                  placeholder="https://portal.rkm-mpp.id"
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-mono text-slate-900"
                />
              </div>

            </div>

            <div className="flex justify-end pt-4 border-t border-slate-100">
              <button
                type="submit"
                className="flex items-center gap-2 px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow transition-all"
              >
                <Save className="w-4 h-4" />
                <span>Simpan Identitas Lembaga</span>
              </button>
            </div>
          </div>
        </form>
      )}

      {/* TAB 2: TARIF & PAKET FARDHU KIFAYAH */}
      {activeSubTab === 'rates' && (
        <form onSubmit={handleSaveSettings} className="space-y-6">
          <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/80 shadow-sm space-y-6">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <DollarSign className="w-5 h-5 text-emerald-600" />
                <div>
                  <h2 className="font-extrabold text-base text-slate-900">Tarif Iuran, Santunan & Alokasi Paket Fardhu Kifayah</h2>
                  <p className="text-xs text-slate-500">Parameter nominal iuran warga dan rincian alokasi biaya pengurusan jenazah sesuai AD/ART.</p>
                </div>
              </div>
            </div>

            {/* Parameter Iuran Pokok */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
                <label className="font-bold text-slate-800 block">
                  Iuran Pokok Wajib (Per KK / Bulan):
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-2.5 text-slate-500 font-bold">Rp</span>
                  <input
                    type="number"
                    value={formState.duesAmount}
                    onChange={(e) => setFormState({ ...formState, duesAmount: Number(e.target.value) })}
                    className="w-full pl-10 pr-3 py-2.5 bg-white border border-slate-300 rounded-xl font-bold text-slate-900 text-sm"
                    required
                  />
                </div>
                <p className="text-[11px] text-slate-500">Iuran pokok bulanan 1 KK (Kepala Keluarga, Istri, Anak Kandung).</p>
              </div>

              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
                <label className="font-bold text-slate-800 block">
                  Iuran Jiwa Tambahan (Per Jiwa / Bulan):
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-2.5 text-slate-500 font-bold">Rp</span>
                  <input
                    type="number"
                    value={formState.extraMemberDuesAmount || 3000}
                    onChange={(e) => setFormState({ ...formState, extraMemberDuesAmount: Number(e.target.value) })}
                    className="w-full pl-10 pr-3 py-2.5 bg-white border border-slate-300 rounded-xl font-bold text-slate-900 text-sm"
                  />
                </div>
                <p className="text-[11px] text-slate-500">Untuk anggota keluarga tambahan (Adik, Kakak, Orang Tua / Mertua).</p>
              </div>

              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
                <label className="font-bold text-slate-800 block">
                  Biaya Pendaftaran Anggota Baru:
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-2.5 text-slate-500 font-bold">Rp</span>
                  <input
                    type="number"
                    value={formState.registrationFee}
                    onChange={(e) => setFormState({ ...formState, registrationFee: Number(e.target.value) })}
                    className="w-full pl-10 pr-3 py-2.5 bg-white border border-slate-300 rounded-xl font-bold text-slate-900 text-sm"
                    required
                  />
                </div>
                <p className="text-[11px] text-slate-500">Infaq pendaftaran awal saat warga mendaftar pertama kali.</p>
              </div>
            </div>

            {/* Parameter Santunan & Masa Tenggang */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs pt-2">
              <div className="p-4 bg-amber-50/60 rounded-2xl border border-amber-200 space-y-2">
                <label className="font-bold text-amber-950 block">
                  Total Nilai Hak Fardhu Kifayah & Santunan:
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-2.5 text-amber-700 font-bold">Rp</span>
                  <input
                    type="number"
                    value={formState.deathBenefitAmount}
                    onChange={(e) => setFormState({ ...formState, deathBenefitAmount: Number(e.target.value) })}
                    className="w-full pl-10 pr-3 py-2.5 bg-white border border-amber-300 rounded-xl font-black text-amber-950 text-base"
                    required
                  />
                </div>
                <p className="text-[11px] text-amber-800 font-semibold">
                  Standar AD/ART 2024–2027: <strong>{formatRupiah(formState.deathBenefitAmount)}</strong>
                </p>
              </div>

              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
                <label className="font-bold text-slate-800 block">
                  Toleransi Tunggakan (Grace Period):
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    min="1"
                    max="12"
                    value={formState.gracePeriodMonths || 3}
                    onChange={(e) => setFormState({ ...formState, gracePeriodMonths: Number(e.target.value) })}
                    className="w-24 p-2.5 bg-white border border-slate-300 rounded-xl font-bold text-slate-900 text-sm"
                  />
                  <span className="text-xs font-semibold text-slate-600">Bulan</span>
                </div>
                <p className="text-[11px] text-slate-500">Masa toleransi tetap berhak santunan sebelum sanksi administrasi.</p>
              </div>

              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
                <label className="font-bold text-slate-800 block">
                  Batas Maksimal Tunggakan Non-Aktif:
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    min="1"
                    max="12"
                    value={formState.maxArrearsMonths || 3}
                    onChange={(e) => setFormState({ ...formState, maxArrearsMonths: Number(e.target.value) })}
                    className="w-24 p-2.5 bg-white border border-slate-300 rounded-xl font-bold text-slate-900 text-sm"
                  />
                  <span className="text-xs font-semibold text-slate-600">Bulan</span>
                </div>
                <p className="text-[11px] text-slate-500">Melewati batas ini status keanggotaan menjadi non-aktif / suspend.</p>
              </div>
            </div>

            {/* Auto-Aging Status Iuran Configuration Card */}
            <div className="p-5 bg-gradient-to-br from-emerald-950 via-slate-900 to-slate-950 text-white rounded-3xl border border-emerald-800/60 shadow-md space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-3 border-b border-emerald-800/40">
                <div className="flex items-center gap-3">
                  <div className="p-2.5 bg-emerald-500/20 text-emerald-400 rounded-2xl border border-emerald-500/30">
                    <Activity className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-bold text-sm text-white flex items-center gap-2">
                      <span>Otomatisasi Status Iuran (Auto-Aging System)</span>
                      <span className="px-2 py-0.5 rounded-full text-[10px] bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/30">
                        Otomatis
                      </span>
                    </h3>
                    <p className="text-xs text-slate-300 mt-0.5">
                      Sistem secara berkala dan otomatis mendeteksi keterlambatan pembayaran iuran dan mengalihkan status warga menjadi 'Tunggakan' jika melewati batas waktu yang ditentukan.
                    </p>
                  </div>
                </div>

                {/* Main Switch */}
                <label className="relative inline-flex items-center cursor-pointer shrink-0">
                  <input
                    type="checkbox"
                    checked={formState.autoAgingEnabled ?? true}
                    onChange={(e) => setFormState({ ...formState, autoAgingEnabled: e.target.checked })}
                    className="sr-only peer"
                  />
                  <div className="w-12 h-6 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-500"></div>
                  <span className="ml-3 text-xs font-bold text-slate-200">
                    {formState.autoAgingEnabled ? 'Aktif' : 'Non-Aktif'}
                  </span>
                </label>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                <div className="p-3.5 bg-slate-900/80 rounded-2xl border border-emerald-800/30 space-y-1.5">
                  <label className="font-bold text-slate-200 block">
                    Tanggal Jatuh Tempo Bulanan:
                  </label>
                  <div className="flex items-center gap-2">
                    <span className="text-slate-400 font-medium">Tanggal</span>
                    <input
                      type="number"
                      min="1"
                      max="28"
                      value={formState.autoAgingDueDay || 20}
                      onChange={(e) => setFormState({ ...formState, autoAgingDueDay: Number(e.target.value) })}
                      className="w-20 p-2 bg-slate-950 border border-emerald-800/50 rounded-xl font-bold text-white text-center"
                    />
                    <span className="text-slate-400 font-medium">setiap bulan</span>
                  </div>
                  <p className="text-[10.5px] text-slate-400">
                    Batas akhir pembayaran iuran bulanan sebelum masuk masa evaluasi tunggakan.
                  </p>
                </div>

                <div className="p-3.5 bg-slate-900/80 rounded-2xl border border-emerald-800/30 space-y-1.5">
                  <label className="font-bold text-slate-200 block">
                    Batas Toleransi Tenggang (Bulan):
                  </label>
                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      min="1"
                      max="12"
                      value={formState.autoAgingGraceMonths || 3}
                      onChange={(e) => setFormState({ ...formState, autoAgingGraceMonths: Number(e.target.value) })}
                      className="w-20 p-2 bg-slate-950 border border-emerald-800/50 rounded-xl font-bold text-white text-center"
                    />
                    <span className="text-slate-300 font-medium">Bulan Toleransi</span>
                  </div>
                  <p className="text-[10.5px] text-slate-400">
                    Warga yang menunggak {formState.autoAgingGraceMonths || 3} bulan akan otomatis ditandai status 'Tunggakan'.
                  </p>
                </div>
              </div>

              {/* Action runner bar */}
              <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2">
                <div className="text-[11px] text-slate-400">
                  Terakhir dijalankan: <strong className="text-emerald-400 font-mono">{formState.lastAutoAgingRun ? new Date(formState.lastAutoAgingRun).toLocaleString('id-ID') : 'Belum pernah'}</strong>
                </div>

                <button
                  type="button"
                  disabled={isRunningAging}
                  onClick={() => {
                    setIsRunningAging(true);
                    setAutoAgingResult(null);
                    setTimeout(() => {
                      const res = runAutoAging();
                      setIsRunningAging(false);
                      setAutoAgingResult(`✓ Auto-Aging selesai: ${res.updatedCount} warga diperiksa dan diperbarui status iurannya.`);
                      setTimeout(() => setAutoAgingResult(null), 6000);
                    }, 400);
                  }}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white font-bold text-xs rounded-xl shadow transition-all flex items-center gap-2"
                >
                  <Activity className={`w-3.5 h-3.5 ${isRunningAging ? 'animate-spin' : ''}`} />
                  <span>{isRunningAging ? 'Memproses Status...' : '⚡ Jalankan Evaluasi Auto-Aging Sekarang'}</span>
                </button>
              </div>

              {autoAgingResult && (
                <div className="p-3 bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs rounded-xl font-bold animate-fade-in">
                  {autoAgingResult}
                </div>
              )}
            </div>

            {/* Rincian Alokasi Paket Fardhu Kifayah (Detail) */}
            <div className="space-y-4 pt-4 border-t border-slate-100">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2">
                    <span>Rincian Alokasi Pos Biaya Paket Fardhu Kifayah</span>
                    <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 text-[10px] font-bold rounded-full">
                      {currentDeathPackageItems.length} Pos Biaya
                    </span>
                  </h3>
                  <p className="text-xs text-slate-500">
                    Standar alokasi pembiayaan per peristiwa kematian warga. Anda dapat menambah, mengubah, atau mengurangi pos biaya secara dinamis.
                  </p>
                </div>

                <div className="flex items-center gap-2 self-start sm:self-auto">
                  <button
                    type="button"
                    onClick={handleResetDefaultPackageItems}
                    className="flex items-center gap-1 px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-[11px] rounded-lg transition-colors cursor-pointer"
                    title="Kembalikan pos biaya ke standar 7 pos AD/ART"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>Reset Standar</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleAddPackageItem}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white font-bold text-[11px] rounded-lg shadow-xs transition-all cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Tambah Pos Biaya</span>
                  </button>
                </div>
              </div>

              {/* Dynamic Items Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 text-xs">
                {currentDeathPackageItems.map((item, index) => (
                  <div key={item.id} className="p-3 bg-slate-50 hover:bg-slate-100/70 transition-colors rounded-xl border border-slate-200 space-y-2 flex flex-col justify-between">
                    <div className="space-y-1.5">
                      <div className="flex items-center justify-between">
                        <span className="w-5 h-5 rounded-full bg-slate-200 text-slate-700 font-black text-[10px] flex items-center justify-center">
                          {index + 1}
                        </span>
                        <button
                          type="button"
                          disabled={currentDeathPackageItems.length <= 1}
                          onClick={() => handleRemovePackageItem(item.id)}
                          className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer disabled:opacity-30 disabled:cursor-not-allowed"
                          title={currentDeathPackageItems.length <= 1 ? "Minimal harus ada 1 pos biaya" : "Hapus pos biaya ini"}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <div>
                        <label className="text-[10px] font-bold text-slate-500 block mb-0.5">Nama Pos Biaya:</label>
                        <input
                          type="text"
                          value={item.name}
                          onChange={(e) => handleUpdatePackageItem(item.id, 'name', e.target.value)}
                          placeholder="Nama pos biaya..."
                          className="w-full px-2 py-1 bg-white border border-slate-300 rounded-lg text-xs font-semibold text-slate-800"
                        />
                      </div>

                      <div>
                        <label className="text-[10px] font-bold text-slate-500 block mb-0.5">Nominal Alokasi:</label>
                        <div className="relative">
                          <span className="absolute left-2.5 top-1.5 text-[10px] text-slate-400 font-bold">Rp</span>
                          <input
                            type="number"
                            min="0"
                            step="10000"
                            value={item.amount}
                            onChange={(e) => handleUpdatePackageItem(item.id, 'amount', e.target.value)}
                            className="w-full pl-7 pr-2 py-1 bg-white border border-slate-300 rounded-lg text-xs font-bold text-slate-900"
                          />
                        </div>
                      </div>
                    </div>

                    <div className="text-[10px] text-slate-400 font-mono text-right pt-1 border-t border-slate-200/60">
                      {formatRupiah(item.amount)}
                    </div>
                  </div>
                ))}

                {/* Sisa Santunan Tunai Ahli Waris Card */}
                <div className="p-3.5 bg-emerald-50 rounded-xl border border-emerald-300 flex flex-col justify-between text-center space-y-1">
                  <div>
                    <span className="text-[10px] text-emerald-800 font-bold uppercase tracking-wider block">Total Alokasi Operasional:</span>
                    <span className="text-sm font-black text-emerald-900 block">{formatRupiah(totalPackageAllocated)}</span>
                  </div>
                  <div className="pt-2 border-t border-emerald-200/70">
                    <span className="text-[10px] text-emerald-800 font-bold block">Sisa Santunan Tunai Ahli Waris:</span>
                    <span className="text-sm font-black text-emerald-950 block">
                      {formatRupiah(Math.max(0, formState.deathBenefitAmount - totalPackageAllocated))}
                    </span>
                    <span className="text-[9px] text-emerald-700">
                      (Dari Total Hak Santunan {formatRupiah(formState.deathBenefitAmount)})
                    </span>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex justify-end pt-4 border-t border-slate-100">
              <button
                type="submit"
                className="flex items-center gap-2 px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow transition-all"
              >
                <Save className="w-4 h-4" />
                <span>Simpan Tarif & Alokasi</span>
              </button>
            </div>

          </div>
        </form>
      )}

      {/* TAB 3: REKENING BANK & QRIS */}
      {activeSubTab === 'banks' && (
        <div className="space-y-6">
          
          {/* Bank Accounts Section */}
          <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/80 shadow-sm space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <CreditCard className="w-5 h-5 text-emerald-600" />
                <div>
                  <h2 className="font-extrabold text-base text-slate-900">Rekening Bank Resmi Kas RKM MPP</h2>
                  <p className="text-xs text-slate-500">Daftar nomor rekening bank penerimaan iuran yang ditampilkan kepada warga.</p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => {
                  setEditingBankIndex(null);
                  setNewBank('');
                  setNewAccountNo('');
                  setNewAccountHolder('');
                  setShowAddBank(!showAddBank);
                }}
                className="flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow transition-all self-start sm:self-auto cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Tambah Rekening Baru</span>
              </button>
            </div>

            {/* Add / Edit Bank Form */}
            {showAddBank && (
              <form onSubmit={handleAddBank} className="p-4 bg-emerald-50/70 border border-emerald-200 rounded-2xl space-y-4 animate-fade-in">
                <h3 className="text-xs font-extrabold text-emerald-950">
                  {editingBankIndex !== null ? 'Ubah Data Rekening Bank' : 'Form Tambah Rekening Bank'}
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                  <div>
                    <label className="font-bold text-slate-700 block mb-1">Nama Bank:</label>
                    <input
                      type="text"
                      value={newBank}
                      onChange={(e) => setNewBank(e.target.value)}
                      placeholder="Contoh: Bank Syariah Indonesia (BSI)"
                      className="w-full p-2 bg-white border border-slate-300 rounded-xl"
                      required
                    />
                  </div>
                  <div>
                    <label className="font-bold text-slate-700 block mb-1">Nomor Rekening:</label>
                    <input
                      type="text"
                      value={newAccountNo}
                      onChange={(e) => setNewAccountNo(e.target.value)}
                      placeholder="Contoh: 7192837465"
                      className="w-full p-2 bg-white border border-slate-300 rounded-xl font-mono"
                      required
                    />
                  </div>
                  <div>
                    <label className="font-bold text-slate-700 block mb-1">Atas Nama (Pemilik Rekening):</label>
                    <input
                      type="text"
                      value={newAccountHolder}
                      onChange={(e) => setNewAccountHolder(e.target.value)}
                      placeholder="RKM MASJID METRO PARUNG PANJANG"
                      className="w-full p-2 bg-white border border-slate-300 rounded-xl"
                      required
                    />
                  </div>
                </div>
                <div className="flex justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => {
                      setShowAddBank(false);
                      setEditingBankIndex(null);
                    }}
                    className="px-4 py-2 bg-slate-200 text-slate-700 text-xs font-semibold rounded-xl cursor-pointer"
                  >
                    Batal
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow cursor-pointer"
                  >
                    {editingBankIndex !== null ? 'Simpan Perubahan Rekening' : 'Simpan Rekening'}
                  </button>
                </div>
              </form>
            )}

            {/* Bank Accounts List */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {formState.bankAccounts.map((account, index) => (
                <div 
                  key={index}
                  className={`p-4 rounded-2xl border transition-all ${
                    account.isPrimary 
                      ? 'bg-emerald-50/60 border-emerald-300 shadow-sm' 
                      : 'bg-white border-slate-200'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-extrabold text-sm text-slate-900">{account.bank}</span>
                    {account.isPrimary ? (
                      <span className="px-2 py-0.5 bg-emerald-600 text-white text-[10px] font-bold rounded-full">
                        Utama
                      </span>
                    ) : (
                      <button
                        type="button"
                        onClick={() => handleSetPrimaryBank(index)}
                        className="text-[10px] text-slate-500 hover:text-emerald-600 font-semibold cursor-pointer"
                      >
                        Jadikan Utama
                      </button>
                    )}
                  </div>
                  <div className="font-mono text-base font-black text-slate-800 tracking-wider mb-1">
                    {account.accountNumber}
                  </div>
                  <div className="text-xs text-slate-500 truncate">
                    a.n. {account.accountHolder}
                  </div>

                  <div className="flex items-center justify-end gap-2 mt-3 pt-2 border-t border-slate-100">
                    <button
                      type="button"
                      onClick={() => handleOpenEditBank(index)}
                      className="text-xs text-slate-600 hover:text-emerald-700 font-semibold flex items-center gap-1 cursor-pointer"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                      <span>Edit</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleRemoveBank(index)}
                      className="text-xs text-rose-600 hover:text-rose-700 font-semibold flex items-center gap-1 cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Hapus</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* QRIS Code Section */}
          <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/80 shadow-sm space-y-6">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <QrCode className="w-5 h-5 text-emerald-600" />
                <div>
                  <h2 className="font-extrabold text-base text-slate-900">QRIS Kas Masuk Paguyuban</h2>
                  <p className="text-xs text-slate-500">Mendukung pembayaran iuran warga via GoPay, OVO, Dana, ShopeePay, BCA, dan Mobile Banking.</p>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-center">
              <div className="flex flex-col items-center p-4 bg-slate-50 border border-slate-200 rounded-2xl">
                <img
                  src={formState.qrisCodeUrl}
                  alt="QRIS RKM MPP"
                  className="w-44 h-44 rounded-xl border border-slate-300 shadow-sm bg-white p-2"
                />
                <span className="text-[11px] font-bold text-slate-700 mt-2">NMID: {formState.qrisMerchantId || 'ID1020038472911'}</span>
                <span className="text-[10px] text-slate-400">RKM METRO PARUNG PANJANG</span>
              </div>

              <div className="md:col-span-2 space-y-3 text-xs">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Merchant ID / NMID QRIS:</label>
                  <input
                    type="text"
                    value={formState.qrisMerchantId || 'ID1020038472911'}
                    onChange={(e) => setFormState({ ...formState, qrisMerchantId: e.target.value })}
                    placeholder="Contoh: ID1020038472911"
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-mono text-slate-900"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">Tautan Gambar QRIS (Image URL):</label>
                  <input
                    type="text"
                    value={formState.qrisCodeUrl || ''}
                    onChange={(e) => setFormState({ ...formState, qrisCodeUrl: e.target.value })}
                    placeholder="https://api.qrserver.com/..."
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-mono text-slate-900"
                  />
                  <span className="text-[10px] text-slate-400 block mt-1">
                    Gunakan tautan langsung gambar QRIS statis atau dynamic QR Code generator.
                  </span>
                </div>

                <div className="pt-2">
                  <button
                    type="button"
                    onClick={() => handleSaveSettings()}
                    className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow transition-all"
                  >
                    Perbarui QRIS & Rekening
                  </button>
                </div>
              </div>
            </div>

          </div>

        </div>
      )}

      {/* TAB 4: OPERASIONAL AMBULANS & PEMAKAMAN */}
      {activeSubTab === 'operational' && (
        <OperationalSettings 
          formState={formState} 
          setFormState={setFormState} 
          onSave={handleSaveSettings} 
        />
      )}

      {/* TAB 5: TEMPLATE WA & PENOMORAN */}
      {activeSubTab === 'templates' && (
        <NotificationTemplateSettings 
          formState={formState} 
          setFormState={setFormState} 
          onSave={handleSaveSettings} 
        />
      )}

      {/* TAB 6: MASTER WILAYAH RT & BLOK */}
      {activeSubTab === 'territory' && (
        <TerritorySettings 
          formState={formState} 
          setFormState={setFormState} 
          onSave={handleSaveSettings} 
        />
      )}

      {/* TAB 7: PENANDATANGAN DOKUMEN */}
      {activeSubTab === 'signatories' && (
        <form onSubmit={handleSaveSettings} className="space-y-6">
          <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/80 shadow-sm space-y-6">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <BadgeCheck className="w-5 h-5 text-emerald-600" />
                <div>
                  <h2 className="font-extrabold text-base text-slate-900">Pejabat & Penandatangan Dokumen Resmi</h2>
                  <p className="text-xs text-slate-500">Nama pejabat yang tercantum pada kuitansi kas, surat lelayu, laporan keuangan, dan KTA warga.</p>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              
              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
                <label className="font-bold text-slate-800 block">
                  Ketua Dewan Pembina / Ketua DKM:
                </label>
                <input
                  type="text"
                  value={formState.advisorName || 'K.H. Ahmad Syahid, Lc. (Ketua DKM)'}
                  onChange={(e) => setFormState({ ...formState, advisorName: e.target.value })}
                  placeholder="K.H. Ahmad Syahid, Lc."
                  className="w-full p-2.5 bg-white border border-slate-300 rounded-xl font-bold text-slate-900"
                />
              </div>

              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
                <label className="font-bold text-slate-800 block">
                  Ketua RKM Periode 2024–2027:
                </label>
                <input
                  type="text"
                  value={formState.chairmanName}
                  onChange={(e) => setFormState({ ...formState, chairmanName: e.target.value })}
                  placeholder="Drs. H. Bambang Sutrisno, M.Pd."
                  className="w-full p-2.5 bg-white border border-slate-300 rounded-xl font-bold text-slate-900"
                  required
                />
              </div>

              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
                <label className="font-bold text-slate-800 block">
                  Sekretaris Umum RKM:
                </label>
                <input
                  type="text"
                  value={formState.secretaryName}
                  onChange={(e) => setFormState({ ...formState, secretaryName: e.target.value })}
                  placeholder="M. Ridwan Prasetyo, S.Kom."
                  className="w-full p-2.5 bg-white border border-slate-300 rounded-xl font-bold text-slate-900"
                  required
                />
              </div>

              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
                <label className="font-bold text-slate-800 block">
                  Bendahara Umum (Penandatangan Kuitansi):
                </label>
                <input
                  type="text"
                  value={formState.treasurerName}
                  onChange={(e) => setFormState({ ...formState, treasurerName: e.target.value })}
                  placeholder="H. Rahmat Hidayat, S.E."
                  className="w-full p-2.5 bg-white border border-slate-300 rounded-xl font-bold text-slate-900"
                  required
                />
              </div>

              <div className="md:col-span-2 p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
                <label className="font-bold text-slate-800 block">
                  Koordinator Satgas Pemulasaraan Jenazah (Fardhu Kifayah):
                </label>
                <input
                  type="text"
                  value={formState.mortuaryCoordinatorName || ''}
                  onChange={(e) => setFormState({ ...formState, mortuaryCoordinatorName: e.target.value })}
                  placeholder="Ust. Abdul Somad Al-Banjari"
                  className="w-full p-2.5 bg-white border border-slate-300 rounded-xl font-bold text-slate-900"
                />
              </div>

            </div>

            <div className="flex justify-end pt-4 border-t border-slate-100">
              <button
                type="submit"
                className="flex items-center gap-2 px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow transition-all"
              >
                <Save className="w-4 h-4" />
                <span>Simpan Pejabat Penandatangan</span>
              </button>
            </div>

          </div>
        </form>
      )}

      {/* TAB 8: STRUKTUR SATGAS & PENGURUS */}
      {activeSubTab === 'officers' && (
        <OfficerManagementSettings />
      )}

      {/* TAB 9: PENDAFTARAN WARGA BARU */}
      {activeSubTab === 'members' && (
        <NewMemberRegistrationSettings />
      )}

      {/* TAB 10: AKUN & HAK AKSES */}
      {activeSubTab === 'accounts' && (
        <AccessManagementSettings />
      )}

      {/* TAB AUDIT: LOG AUDIT & RIWAYAT KEAMANAN SISTEM */}
      {activeSubTab === 'audit' && (
        <SystemAuditLogsSettings />
      )}

      {/* TAB 11: GOOGLE SHEETS & CLOUD */}
      {activeSubTab === 'sheets' && (
        <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/80 shadow-sm space-y-6">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <Globe className="w-5 h-5 text-emerald-600" />
              <div>
                <h2 className="font-extrabold text-base text-slate-900">Integrasi & Migrasi Database ke Google Spreadsheet</h2>
                <p className="text-xs text-slate-500">Sinkronisasi otomatis multi-sheet (Warga, Buku Kas, Lelayu Duka, Inventaris Aset & Konfigurasi) langsung ke Google Drive.</p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold ${
                formState.googleSheetConnected ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-600'
              }`}>
                <span className={`w-2 h-2 rounded-full ${formState.googleSheetConnected ? 'bg-emerald-500' : 'bg-slate-400'}`} />
                <span>{formState.googleSheetConnected ? 'Tersambung (Online)' : 'Terputus'}</span>
              </span>
            </div>
          </div>

          {/* Quick Setup Card */}
          <div className="p-4 bg-emerald-50/70 rounded-2xl border border-emerald-200/80 flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
            <div className="space-y-1">
              <span className="font-extrabold text-xs text-emerald-950 flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>Google Apps Script Otomatis (5 Sheet Terintegrasi)</span>
              </span>
              <p className="text-[11px] text-emerald-800">
                Gunakan skrip webhook gratis untuk membuat 5 lembar kerja otomatis di Google Spreadsheet Anda tanpa batasan kuota.
              </p>
            </div>
            <button
              type="button"
              onClick={() => setShowScriptModal(true)}
              className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl font-bold text-xs shadow-xs shrink-0 flex items-center gap-1.5"
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              <span>Lihat Kode Apps Script</span>
            </button>
          </div>

          <div className="space-y-4 text-xs">
            <div>
              <label className="font-bold text-slate-700 block mb-1">URL Google Spreadsheet Database:</label>
              <div className="flex items-center gap-2">
                <input
                  type="url"
                  value={formState.sheetUrl || ''}
                  onChange={(e) => setFormState({ ...formState, sheetUrl: e.target.value })}
                  placeholder="https://docs.google.com/spreadsheets/d/..."
                  className="flex-1 p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-mono text-slate-900"
                />
                {formState.sheetUrl && (
                  <a
                    href={formState.sheetUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="p-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl border border-slate-200"
                    title="Buka Spreadsheet di Tab Baru"
                  >
                    <ExternalLink className="w-4 h-4" />
                  </a>
                )}
              </div>
            </div>

            <div>
              <label className="font-bold text-slate-700 block mb-1">Google Apps Script Webhook Trigger URL (/exec):</label>
              <input
                type="url"
                value={formState.webhookUrl || ''}
                onChange={(e) => setFormState({ ...formState, webhookUrl: e.target.value })}
                placeholder="https://script.google.com/macros/s/.../exec"
                className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-mono text-slate-900"
              />
              <span className="text-[11px] text-slate-500 block mt-1">
                Endpoint Apps Script untuk menerima auto-sync database kas, warga, duka, dan aset secara real-time.
              </span>
            </div>

            {/* Auto Sync Toggle & Interval */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 p-4 bg-slate-50 border border-slate-200 rounded-2xl">
              <div className="flex items-center justify-between">
                <div>
                  <span className="font-extrabold text-slate-800 block">Auto-Sync Realtime</span>
                  <span className="text-[11px] text-slate-500">Kirim data ke Google Sheet setiap ada transaksi/perubahan data baru</span>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={Boolean(formState.autoSheetSyncEnabled)}
                    onChange={(e) => setFormState({ ...formState, autoSheetSyncEnabled: e.target.checked })}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-slate-300 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600"></div>
                </label>
              </div>

              <div className="space-y-1">
                <label className="font-bold text-slate-700 block">Interval Sinkronisasi Latar Belakang</label>
                <select
                  value={formState.autoSheetSyncIntervalMinutes || 15}
                  onChange={(e) => setFormState({ ...formState, autoSheetSyncIntervalMinutes: Number(e.target.value) })}
                  className="w-full p-2 bg-white border border-slate-300 rounded-xl font-bold text-slate-800"
                >
                  <option value={5}>Setiap 5 Menit (Sangat Cepat)</option>
                  <option value={10}>Setiap 10 Menit</option>
                  <option value={15}>Setiap 15 Menit (Disarankan)</option>
                  <option value={30}>Setiap 30 Menit</option>
                  <option value={60}>Setiap 1 Jam</option>
                </select>
              </div>
            </div>

            {/* Quick CSV Exporters */}
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-2">
              <span className="font-bold text-slate-800 block text-xs">Ekspor Manual Tabel Format CSV / Excel:</span>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                <button
                  type="button"
                  onClick={() => downloadCsvForTable('warga', { citizens })}
                  className="px-3 py-2 bg-white hover:bg-slate-100 border border-slate-200 rounded-xl font-bold text-slate-700 flex items-center justify-center gap-1.5 text-xs shadow-2xs"
                >
                  <Download className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Master Warga</span>
                </button>
                <button
                  type="button"
                  onClick={() => downloadCsvForTable('kas', { transactions })}
                  className="px-3 py-2 bg-white hover:bg-slate-100 border border-slate-200 rounded-xl font-bold text-slate-700 flex items-center justify-center gap-1.5 text-xs shadow-2xs"
                >
                  <Download className="w-3.5 h-3.5 text-blue-600" />
                  <span>Buku Kas</span>
                </button>
                <button
                  type="button"
                  onClick={() => downloadCsvForTable('lelayu', { deathNotices })}
                  className="px-3 py-2 bg-white hover:bg-slate-100 border border-slate-200 rounded-xl font-bold text-slate-700 flex items-center justify-center gap-1.5 text-xs shadow-2xs"
                >
                  <Download className="w-3.5 h-3.5 text-rose-600" />
                  <span>Lelayu Duka</span>
                </button>
                <button
                  type="button"
                  onClick={() => downloadCsvForTable('aset', { assets })}
                  className="px-3 py-2 bg-white hover:bg-slate-100 border border-slate-200 rounded-xl font-bold text-slate-700 flex items-center justify-center gap-1.5 text-xs shadow-2xs"
                >
                  <Download className="w-3.5 h-3.5 text-amber-600" />
                  <span>Inventaris Aset</span>
                </button>
              </div>
            </div>

            <div className="p-4 bg-emerald-50/60 rounded-2xl border border-emerald-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <span className="text-xs text-emerald-950 font-bold block">Status Sinkronisasi Terakhir:</span>
                <span className="text-xs text-emerald-800 font-mono">{formState.lastSheetSync || 'Belum disinkronkan'}</span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => handleSaveSettings()}
                  className="px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl shadow transition-all"
                >
                  Simpan Konfigurasi
                </button>
                <button
                  type="button"
                  onClick={handleSyncSheets}
                  disabled={isSyncing}
                  className="flex items-center justify-center gap-2 px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow transition-all disabled:opacity-50"
                >
                  <RefreshCw className={`w-4 h-4 ${isSyncing ? 'animate-spin' : ''}`} />
                  <span>{isSyncing ? 'Menyinkronkan...' : 'Migrasi & Sinkronkan Sekarang'}</span>
                </button>
              </div>
            </div>

            {syncMessage && (
              <div className="p-3 bg-emerald-100 text-emerald-900 text-xs font-bold rounded-xl animate-fade-in">
                {syncMessage}
              </div>
            )}
          </div>

          {/* Modal Google Apps Script Preview & Copy */}
          {showScriptModal && (
            <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center z-50 p-4 animate-fade-in">
              <div className="bg-white rounded-3xl p-6 max-w-3xl w-full border border-slate-200 shadow-2xl space-y-4 max-h-[90vh] flex flex-col">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                  <div className="flex items-center gap-2">
                    <FileSpreadsheet className="w-5 h-5 text-emerald-600" />
                    <div>
                      <h3 className="font-extrabold text-base text-slate-900">Kode Google Apps Script Auto-Sync</h3>
                      <p className="text-xs text-slate-500">Salin skrip berikut ke Apps Script pada Spreadsheet Anda</p>
                    </div>
                  </div>
                  <button
                    onClick={() => setShowScriptModal(false)}
                    className="p-2 hover:bg-slate-100 rounded-xl text-slate-400 hover:text-slate-600"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <div className="bg-slate-900 text-emerald-300 p-4 rounded-2xl font-mono text-xs overflow-y-auto flex-1 max-h-96 leading-relaxed select-all">
                  <pre>{generateGoogleAppsScriptCode(formState.sheetUrl)}</pre>
                </div>

                <div className="pt-2 flex items-center justify-between gap-3">
                  <span className="text-xs text-slate-500">
                    Otomatis membuat 5 sheet: MASTER_WARGA, BUKU_KAS, LELAYU_DUKA, INVENTARIS_ASET, PENGATURAN.
                  </span>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        navigator.clipboard.writeText(generateGoogleAppsScriptCode(formState.sheetUrl));
                        setCopiedScript(true);
                        setTimeout(() => setCopiedScript(false), 2500);
                      }}
                      className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-xs flex items-center gap-1.5"
                    >
                      {copiedScript ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                      <span>{copiedScript ? 'Tersalin ke Clipboard!' : 'Salin Kode Skrip'}</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setShowScriptModal(false)}
                      className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl"
                    >
                      Tutup
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 12: BACKUP & RESTORE */}
      {activeSubTab === 'backup' && (
        <BackupRestoreSettings />
      )}

      {/* TAB 13: SUPERUSER & KONTROL SISTEM PENUH */}
      {activeSubTab === 'superuser_main' && (
        <SuperuserSystemSettings
          systemSettings={formState.systemSettings}
          onUpdateSystemSettings={(updated) => {
            setFormState((prev) => ({ ...prev, systemSettings: updated }));
            updateSettings({ systemSettings: updated });
          }}
          onSaveAll={() => handleSaveSettings()}
        />
      )}

    </div>
  );
};
