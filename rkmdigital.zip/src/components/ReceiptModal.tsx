import React, { useState } from 'react';
import { 
  X, 
  Printer, 
  Share2, 
  Copy, 
  CheckCircle2, 
  Building2, 
  Calendar, 
  User, 
  CreditCard,
  MessageSquare,
  QrCode,
  ShieldCheck,
  FileText
} from 'lucide-react';
import { useRkm } from '../context/RkmContext';
import { formatRupiah, formatDateIndo, terbilangRupiah, getMonthNameFromKey, createWhatsAppUrl, getDirectImageUrl } from '../utils/formatters';

export const ReceiptModal: React.FC = () => {
  const { activeReceipt, closeReceiptModal, settings } = useRkm();
  const [copied, setCopied] = useState(false);
  const [receiptStyle, setReceiptStyle] = useState<'official' | 'thermal'>('official');

  if (!activeReceipt) return null;

  const {
    receiptNo,
    citizen,
    monthsPaid,
    duesAmount,
    infaqAmount,
    totalAmount,
    date,
    paymentMethod,
    collector
  } = activeReceipt;

  const monthLabels = monthsPaid.map(m => getMonthNameFromKey(m)).join(', ');
  
  // Calculate remaining unpaid months for this year
  const unpaidMonths = Object.entries(citizen.monthlyDues)
    .filter(([k, v]) => !(v as any).paid && k.startsWith('2026'))
    .map(([k]) => getMonthNameFromKey(k));

  // Build WhatsApp text
  const waMessage = 
`*KUITANSI PEMBAYARAN IURAN RKM MPP DIGITAL*
_${settings.orgName} - ${settings.village}_
────────────────────────────
*No. Kuitansi :* ${receiptNo}
*Tanggal      :* ${formatDateIndo(date)}
*Nama Warga   :* ${citizen.headOfFamily}
*No. KK       :* ${citizen.noKK}
*Wilayah      :* RT ${citizen.rt} / RW ${citizen.rw}

*RINCIAN PEMBAYARAN:*
• Iuran Bulan : ${monthLabels} (${monthsPaid.length} Bulan)
• Nominal     : ${formatRupiah(duesAmount)}
${infaqAmount > 0 ? `• Infaq/Donasi: ${formatRupiah(infaqAmount)}\n` : ''}• *TOTAL BAYAR : ${formatRupiah(totalAmount)}*
• *Status      : LUNAS [VERIFIED]*
• Metode      : ${paymentMethod}
• Diterima Oleh: ${collector}

_Terbilang: ${terbilangRupiah(totalAmount)}_
────────────────────────────
${unpaidMonths.length > 0 ? `*Catatan Tunggakan 2026:*\nSisa belum bayar: ${unpaidMonths.slice(0, 4).join(', ')}${unpaidMonths.length > 4 ? ` (+${unpaidMonths.length - 4} bln)` : ''}\n────────────────────────────\n` : '*Status 2026: LUNAS SEMUA BULAN* ✨\n────────────────────────────\n'}
Jazaakumullahu khairan katsiran atas partisipasi Anda dalam mendukung dana sosial kematian warga.

_Simpan bukti pembayaran digital ini sebagai dokumen sah._
*Portal Warga:* https://ais-pre-cv2s37pgsyomohrjz6xdeh-739471314639.asia-southeast1.run.app/`;

  const handleCopy = () => {
    navigator.clipboard.writeText(waMessage);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleSendWA = () => {
    const targetPhone = citizen.phone || settings.waAdmin;
    const url = createWhatsAppUrl(targetPhone, waMessage);
    window.open(url, '_blank');
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-sm animate-fade-in overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-slate-100 overflow-hidden my-8">
        
        {/* Header toolbar */}
        <div className="flex items-center justify-between px-6 py-4 bg-slate-900 text-white no-print">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-emerald-500/20 text-emerald-400 rounded-lg">
              <CheckCircle2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base text-white">Kuitansi Pembayaran Digital</h3>
              <p className="text-xs text-slate-400">Bukti sah transaksi iuran RKM</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex bg-slate-800 p-1 rounded-lg text-xs font-medium mr-2">
              <button
                onClick={() => setReceiptStyle('official')}
                className={`px-3 py-1 rounded-md transition-colors ${receiptStyle === 'official' ? 'bg-emerald-600 text-white' : 'text-slate-300 hover:text-white'}`}
              >
                Format Resmi
              </button>
              <button
                onClick={() => setReceiptStyle('thermal')}
                className={`px-3 py-1 rounded-md transition-colors ${receiptStyle === 'thermal' ? 'bg-emerald-600 text-white' : 'text-slate-300 hover:text-white'}`}
              >
                Struk Kasir (58mm)
              </button>
            </div>

            <button
              onClick={closeReceiptModal}
              className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Action Buttons Bar */}
        <div className="grid grid-cols-3 gap-3 p-4 bg-emerald-50 border-b border-emerald-100 no-print">
          <button
            onClick={handleSendWA}
            className="flex items-center justify-center gap-2 py-2.5 px-3 bg-emerald-600 hover:bg-emerald-700 active:scale-98 text-white font-semibold text-xs sm:text-sm rounded-xl shadow-sm transition-all"
          >
            <Share2 className="w-4 h-4" />
            <span>Kirim WhatsApp</span>
          </button>

          <button
            id="print-receipt-btn"
            type="button"
            onClick={handlePrint}
            className="flex items-center justify-center gap-2 py-2.5 px-3 bg-white hover:bg-slate-100 active:scale-98 text-slate-800 border border-slate-300 font-bold text-xs sm:text-sm rounded-xl shadow-xs transition-all cursor-pointer"
            title="Cetak Kuitansi Resmi / Struk (window.print)"
          >
            <Printer className="w-4 h-4 text-emerald-600" />
            <span>Print Receipt</span>
          </button>

          <button
            onClick={handleCopy}
            className="flex items-center justify-center gap-2 py-2.5 px-3 bg-white hover:bg-slate-100 active:scale-98 text-slate-700 border border-slate-300 font-semibold text-xs sm:text-sm rounded-xl shadow-sm transition-all"
          >
            {copied ? (
              <>
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span className="text-emerald-700">Tersalin!</span>
              </>
            ) : (
              <>
                <Copy className="w-4 h-4 text-slate-500" />
                <span>Salin Teks WA</span>
              </>
            )}
          </button>
        </div>

        {/* Printable & Visible Receipt Body */}
        <div id="printable-receipt" className="p-6 sm:p-8 bg-white">
          {receiptStyle === 'official' ? (
            /* Official Indonesian Kuitansi Voucher Style */
            <div className="border-2 border-emerald-800/80 rounded-xl p-6 relative bg-gradient-to-b from-emerald-50/20 via-white to-amber-50/10 shadow-inner">
              
              {/* Islamic Pattern & Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-5 border-b-2 border-emerald-800/40 gap-4">
                <div className="flex items-center gap-3">
                  {settings.logoUrl ? (
                    <img 
                      src={getDirectImageUrl(settings.logoUrl)} 
                      alt={settings.orgName}
                      referrerPolicy="no-referrer"
                      className="w-14 h-14 rounded-xl object-contain bg-white p-1 border-2 border-emerald-600 shadow-md"
                    />
                  ) : (
                    <div className="w-12 h-12 rounded-xl bg-emerald-700 text-white flex items-center justify-center font-bold text-xl shadow-md border-2 border-emerald-600">
                      RKM
                    </div>
                  )}
                  <div>
                    <h2 className="font-extrabold text-emerald-900 text-lg tracking-tight uppercase">
                      {settings.orgName}
                    </h2>
                    <p className="text-xs text-slate-600 font-medium">
                      {settings.village}, {settings.district}, {settings.regency}
                    </p>
                    <p className="text-[11px] text-slate-500">
                      Izin Paguyuban Sosial Warga • Layanan Siaga 24 Jam: {settings.contactCenter}
                    </p>
                  </div>
                </div>

                <div className="text-right bg-emerald-50/80 border border-emerald-200 px-3.5 py-2 rounded-lg">
                  <div className="text-[11px] font-bold text-emerald-800 uppercase tracking-wider">KUITANSI RESMI</div>
                  <div className="font-mono font-bold text-sm text-emerald-950">{receiptNo}</div>
                  <div className="text-[11px] text-slate-500">{formatDateIndo(date)}</div>
                </div>
              </div>

              {/* Body Fields */}
              <div className="mt-5 space-y-3.5 text-sm">
                <div className="flex flex-col sm:flex-row sm:items-center gap-1 sm:gap-4 py-1.5 border-b border-dashed border-slate-200">
                  <span className="w-40 text-slate-500 font-medium text-xs uppercase tracking-wider">Telah Diterima Dari</span>
                  <span className="font-bold text-slate-900 flex-1 text-base">
                    {citizen.headOfFamily} <span className="text-xs font-normal text-slate-500">(No. KK: {citizen.noKK})</span>
                  </span>
                </div>

                <div className="flex flex-col sm:flex-row sm:items-start gap-1 sm:gap-4 py-1.5 border-b border-dashed border-slate-200">
                  <span className="w-40 text-slate-500 font-medium text-xs uppercase tracking-wider">Alamat / RT</span>
                  <span className="font-medium text-slate-800 flex-1">
                    {citizen.address}, RT {citizen.rt} / RW {citizen.rw}
                  </span>
                </div>

                <div className="flex flex-col sm:flex-row sm:items-start gap-1 sm:gap-4 py-1.5 border-b border-dashed border-slate-200">
                  <span className="w-40 text-slate-500 font-medium text-xs uppercase tracking-wider">Guna Membayar</span>
                  <div className="flex-1">
                    <span className="font-semibold text-emerald-900">
                      Iuran Kas Rukun Kematian Bulan: {monthLabels}
                    </span>
                    <p className="text-xs text-slate-500 mt-0.5">
                      Tarif Iuran: {formatRupiah(settings.duesAmount)} / bulan × {monthsPaid.length} bulan = {formatRupiah(duesAmount)}
                    </p>
                    {infaqAmount > 0 && (
                      <p className="text-xs text-amber-700 font-medium mt-0.5">
                        + Infaq / Donasi Sukarela: {formatRupiah(infaqAmount)}
                      </p>
                    )}
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row sm:items-center gap-1 sm:gap-4 py-1.5 border-b border-dashed border-slate-200">
                  <span className="w-40 text-slate-500 font-medium text-xs uppercase tracking-wider">Metode & Petugas</span>
                  <span className="text-slate-800 font-medium flex-1">
                    {paymentMethod} • Diterima oleh: <strong className="text-slate-900">{collector}</strong>
                  </span>
                </div>

                <div className="flex flex-col sm:flex-row sm:items-center gap-1 sm:gap-4 py-2 bg-emerald-50/60 px-3 rounded-lg border border-emerald-200">
                  <span className="w-40 text-emerald-800 font-bold text-xs uppercase tracking-wider">Terbilang</span>
                  <span className="font-serif italic font-bold text-emerald-950 flex-1 text-sm">
                    "{terbilangRupiah(totalAmount)}"
                  </span>
                </div>
              </div>

              {/* Amount Box and Signatures */}
              <div className="mt-6 pt-4 border-t-2 border-emerald-800/30 flex flex-col sm:flex-row items-center justify-between gap-6">
                
                {/* Total Box */}
                <div className="bg-emerald-900 text-white px-5 py-3 rounded-xl shadow-md flex items-center gap-4 w-full sm:w-auto">
                  <div>
                    <div className="text-[10px] uppercase font-bold tracking-widest text-emerald-200">JUMLAH TOTAL</div>
                    <div className="text-2xl font-black text-white font-mono">{formatRupiah(totalAmount)}</div>
                  </div>
                  <div className="h-8 w-px bg-emerald-700" />
                  <div className="text-center">
                    <span className="inline-block px-2.5 py-1 bg-emerald-500 text-emerald-950 font-black text-xs rounded uppercase tracking-wider">
                      LUNAS
                    </span>
                  </div>
                </div>

                {/* Stamp & Signature */}
                <div className="flex items-center gap-6 w-full sm:w-auto justify-end">
                  
                  {/* Digital QR Code */}
                  <div className="text-center">
                    <div className="p-1 border border-slate-200 bg-white rounded-lg inline-block shadow-sm">
                      <img 
                        src={`https://api.qrserver.com/v1/create-qr-code/?size=70x70&data=VERIFIED-RKM-${receiptNo}-${totalAmount}`} 
                        alt="QR Verification" 
                        className="w-14 h-14"
                      />
                    </div>
                    <p className="text-[9px] text-slate-400 mt-1">Scan Keaslian</p>
                  </div>

                  {/* Stamp & Signature Box */}
                  <div className="text-center relative">
                    {/* Stamp Watermark */}
                    <div className="absolute -top-3 left-1/2 -translate-x-1/2 w-24 h-24 border-2 border-emerald-600/60 rounded-full flex items-center justify-center rotate-[-12deg] pointer-events-none select-none">
                      <div className="text-center text-[8px] font-black text-emerald-700/80 leading-tight uppercase tracking-tighter">
                        ★ RUKUN KEMATIAN ★<br />
                        <span className="text-[9px] text-emerald-800 font-extrabold">MASJID METRO</span><br />
                        <span className="text-[8px] text-emerald-700 font-bold">PARUNG PANJANG</span><br />
                        ★ SAH / LUNAS ★
                      </div>
                    </div>

                    <p className="text-xs text-slate-500">Bendahara / Petugas Kas</p>
                    <div className="h-10"></div>
                    <p className="text-xs font-bold text-slate-900 underline underline-offset-4">{collector || settings.treasurerName}</p>
                    <p className="text-[10px] text-slate-400">{settings.orgName}</p>
                  </div>

                </div>
              </div>

              <div className="mt-4 pt-2 border-t border-slate-100 flex items-center justify-between text-[10px] text-slate-400">
                <span>RKM MPP Digital System • Aplikasi Pengelolaan Kas & Kematian Warga</span>
                <span>Dicetak otomatis pada: {formatDateIndo(date, true)}</span>
              </div>
            </div>
          ) : (
            /* Thermal 58mm POS Cashier Receipt Style */
            <div className="max-w-xs mx-auto font-mono text-xs text-slate-800 p-4 border border-slate-300 rounded-lg bg-amber-50/20">
              <div className="text-center pb-3 border-b border-dashed border-slate-400">
                <h3 className="font-bold text-sm uppercase">{settings.orgName}</h3>
                <p className="text-[10px] text-slate-600">{settings.village}, {settings.district}</p>
                <p className="text-[10px] text-slate-600">WA: {settings.waAdmin}</p>
              </div>

              <div className="py-2 space-y-1 text-[11px] border-b border-dashed border-slate-400">
                <div className="flex justify-between">
                  <span>No. Struk:</span>
                  <span className="font-bold">{receiptNo}</span>
                </div>
                <div className="flex justify-between">
                  <span>Tgl:</span>
                  <span>{formatDateIndo(date, false)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Warga:</span>
                  <span className="font-bold truncate max-w-[150px]">{citizen.headOfFamily}</span>
                </div>
                <div className="flex justify-between">
                  <span>RT/RW:</span>
                  <span>RT {citizen.rt}/RW {citizen.rw}</span>
                </div>
              </div>

              <div className="py-2 space-y-1.5 border-b border-dashed border-slate-400">
                <div className="font-bold text-[11px]">Iuran Kas ({monthsPaid.length} bln):</div>
                <div className="text-[10px] text-slate-600 pl-2">{monthLabels}</div>
                <div className="flex justify-between font-medium">
                  <span>Subtotal Iuran</span>
                  <span>{formatRupiah(duesAmount)}</span>
                </div>
                {infaqAmount > 0 && (
                  <div className="flex justify-between text-amber-800">
                    <span>Infaq / Donasi</span>
                    <span>{formatRupiah(infaqAmount)}</span>
                  </div>
                )}
                <div className="flex justify-between font-bold text-sm pt-1 border-t border-slate-300">
                  <span>TOTAL</span>
                  <span>{formatRupiah(totalAmount)}</span>
                </div>
                <div className="flex justify-between text-[10px]">
                  <span>Metode Bayar:</span>
                  <span>{paymentMethod}</span>
                </div>
              </div>

              <div className="pt-3 text-center space-y-2">
                <div className="font-bold text-xs bg-slate-200 py-1 rounded uppercase tracking-wider">
                  *** LUNAS ***
                </div>
                <p className="text-[10px] text-slate-600 italic">
                  "Semoga Allah memberkahi harta & keluarga Anda"
                </p>
                <div className="flex justify-center pt-1">
                  <img 
                    src={`https://api.qrserver.com/v1/create-qr-code/?size=60x60&data=RKM-${receiptNo}`} 
                    alt="QR" 
                    className="w-12 h-12"
                  />
                </div>
                <p className="text-[9px] text-slate-400">Kasir: {collector}</p>
              </div>
            </div>
          )}
        </div>

        {/* Footer info banner */}
        <div className="px-6 py-3.5 bg-slate-100 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-600 no-print gap-3">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
            <span className="text-[11px] text-slate-500">Kuitansi sah tersimpan di database kas dan mutasi keuangan paguyuban.</span>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <button
              id="print-receipt-btn-footer"
              type="button"
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white font-bold text-xs rounded-xl shadow-xs transition-all cursor-pointer"
              title="Cetak struk / kuitansi langsung ke printer atau dokumen PDF"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print Receipt</span>
            </button>
            <button
              id="close-receipt-modal-btn"
              type="button"
              onClick={closeReceiptModal}
              className="px-3 py-1.5 bg-white hover:bg-slate-200 border border-slate-300 text-slate-700 font-semibold text-xs rounded-xl transition-all cursor-pointer"
            >
              Tutup
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
