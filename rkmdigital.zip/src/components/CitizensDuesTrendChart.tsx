import React, { useState, useMemo } from 'react';
import { 
  BarChart, 
  Bar, 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer 
} from 'recharts';
import { 
  TrendingUp, 
  Users, 
  CheckCircle2, 
  AlertCircle, 
  DollarSign, 
  ChevronDown, 
  ChevronUp, 
  BarChart3, 
  LineChart, 
  Award,
  Sparkles,
  Layers
} from 'lucide-react';
import { Citizen, OrganizationSettings } from '../types';
import { formatRupiah, MONTH_NAMES, calculateCitizenMonthlyDues } from '../utils/formatters';

interface CitizensDuesTrendChartProps {
  citizens: Citizen[];
  settings: OrganizationSettings;
}

// Custom Tooltip for Charts defined outside component to avoid unmount/remount on re-renders
const CustomChartTooltip: React.FC<any> = ({ active, payload }) => {
  if (active && payload && payload.length) {
    const data = payload[0].payload;
    return (
      <div className="p-3 bg-slate-900 text-white rounded-2xl shadow-xl border border-slate-700 text-xs space-y-1.5 min-w-[200px] animate-fade-in">
        <div className="font-bold text-emerald-400 pb-1 border-b border-slate-700 flex items-center justify-between">
          <span>{data.monthName} 2026</span>
          <span className="text-[10px] bg-emerald-950 text-emerald-300 px-2 py-0.5 rounded-full font-mono">
            {data.persentase}% Partisipasi
          </span>
        </div>
        
        <div className="space-y-1 text-[11px] pt-1">
          <div className="flex items-center justify-between">
            <span className="text-emerald-300 flex items-center gap-1">
              <CheckCircle2 className="w-3 h-3" /> KK Lunas:
            </span>
            <span className="font-bold text-white font-mono">{data.lunasKK} KK</span>
          </div>

          <div className="flex items-center justify-between">
            <span className="text-rose-300 flex items-center gap-1">
              <AlertCircle className="w-3 h-3" /> Belum Lunas:
            </span>
            <span className="font-bold text-white font-mono">{data.menunggakKK} KK</span>
          </div>

          <div className="pt-1.5 border-t border-slate-800 flex items-center justify-between">
            <span className="text-slate-400">Kas Terkumpul:</span>
            <span className="font-bold text-emerald-400 font-mono">{formatRupiah(data.nominalTerkumpul)}</span>
          </div>

          <div className="flex items-center justify-between text-slate-400">
            <span>Target Kas:</span>
            <span className="font-mono">{formatRupiah(data.targetNominal)}</span>
          </div>
        </div>
      </div>
    );
  }
  return null;
};

export const CitizensDuesTrendChart: React.FC<CitizensDuesTrendChartProps> = ({
  citizens,
  settings
}) => {
  const [isExpanded, setIsExpanded] = useState(true);
  const [chartMode, setChartMode] = useState<'bar' | 'area'>('bar');

  const baseRate = settings?.baseDuesAmount || settings?.duesAmount || 5000;
  const extraRate = settings?.extraMemberDuesAmount || 3000;

  // Active citizens (excluding Pindah)
  const activeCitizens = useMemo(() => {
    return (citizens || []).filter(c => c.status !== 'Pindah');
  }, [citizens]);

  // Aggregate monthly data for 2026 (Jan - Des)
  const chartData = useMemo(() => {
    return MONTH_NAMES.map(m => {
      const monthKey = `2026-${m.key}`;
      let lunasCount = 0;
      let belumCount = 0;
      let nominalTerkumpul = 0;
      let targetNominal = 0;

      activeCitizens.forEach(c => {
        const dues = calculateCitizenMonthlyDues(c, baseRate, extraRate);
        targetNominal += dues.totalMonthlyDues;

        const isPaid = c.monthlyDues?.[monthKey]?.paid;
        if (isPaid) {
          lunasCount++;
          nominalTerkumpul += dues.totalMonthlyDues;
        } else {
          belumCount++;
        }
      });

      const totalActive = activeCitizens.length || 1;
      const persentase = Math.round((lunasCount / totalActive) * 100);

      return {
        monthKey: m.key,
        monthName: m.name,
        monthShort: m.short,
        lunasKK: lunasCount,
        menunggakKK: belumCount,
        persentase,
        nominalTerkumpul,
        targetNominal,
        gapNominal: targetNominal - nominalTerkumpul
      };
    });
  }, [activeCitizens, baseRate, extraRate]);

  // KPI Calculations
  const averageParticipation = useMemo(() => {
    if (chartData.length === 0) return 0;
    // Calculate average for Jan - Aug (past months)
    const activeMonths = chartData.slice(0, 8);
    const sum = activeMonths.reduce((acc, curr) => acc + curr.persentase, 0);
    return Math.round(sum / activeMonths.length);
  }, [chartData]);

  const bestMonth = useMemo(() => {
    if (chartData.length === 0) return null;
    return [...chartData].sort((a, b) => b.persentase - a.persentase)[0];
  }, [chartData]);

  const totalCollectedThisYear = useMemo(() => {
    return chartData.reduce((acc, curr) => acc + curr.nominalTerkumpul, 0);
  }, [chartData]);

  // Count citizens with arrears > 3 months (Jan-Aug 2026)
  const criticalArrearsCount = useMemo(() => {
    let count = 0;
    activeCitizens.forEach(c => {
      let unpaid = 0;
      for (let m = 1; m <= 8; m++) {
        const mKey = `2026-${m.toString().padStart(2, '0')}`;
        if (!c.monthlyDues?.[mKey]?.paid) {
          unpaid++;
        }
      }
      if (unpaid > 3) {
        count++;
      }
    });
    return count;
  }, [activeCitizens]);

  return (
    <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-6 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-4">
      {/* Header with expand & mode toggles */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100 dark:border-slate-800">
        <div className="flex items-center gap-2.5">
          <div className="p-2.5 bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 rounded-2xl shrink-0">
            <TrendingUp className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="font-black text-base text-slate-900 dark:text-white">
                Tren Pembayaran & Partisipasi Iuran Warga (Tahun 2026)
              </h2>
              <span className="text-[10px] bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 font-extrabold px-2 py-0.5 rounded-full border border-emerald-200 dark:border-emerald-800/60">
                Visual Analytics
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Monitoring tingkat kepatuhan dan kolektibilitas iuran kas fardhu kifayah per bulan
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          {/* Mode Switcher */}
          <div className="flex items-center p-1 bg-slate-100 dark:bg-slate-800 rounded-xl text-xs font-bold border border-slate-200/70 dark:border-slate-700/70">
            <button
              type="button"
              onClick={() => setChartMode('bar')}
              className={`flex items-center gap-1.5 py-1.5 px-3 rounded-lg transition-all cursor-pointer ${
                chartMode === 'bar' 
                  ? 'bg-white dark:bg-slate-700 text-emerald-800 dark:text-emerald-300 shadow-xs' 
                  : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200'
              }`}
            >
              <BarChart3 className="w-3.5 h-3.5" />
              <span>Jumlah KK</span>
            </button>

            <button
              type="button"
              onClick={() => setChartMode('area')}
              className={`flex items-center gap-1.5 py-1.5 px-3 rounded-lg transition-all cursor-pointer ${
                chartMode === 'area' 
                  ? 'bg-white dark:bg-slate-700 text-emerald-800 dark:text-emerald-300 shadow-xs' 
                  : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200'
              }`}
            >
              <LineChart className="w-3.5 h-3.5" />
              <span>Persentase & Nominal</span>
            </button>
          </div>

          <button
            type="button"
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 rounded-xl transition-colors cursor-pointer border border-slate-200/70 dark:border-slate-700/70"
            title={isExpanded ? 'Sembunyikan Grafik' : 'Tampilkan Grafik'}
          >
            {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Expandable Chart Content */}
      {isExpanded && (
        <div className="space-y-4 animate-fade-in">
          
          {/* KPI Summary Cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-3.5">
            
            <div className="p-3.5 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700/80 flex items-center gap-3">
              <div className="p-2.5 bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 rounded-xl shrink-0">
                <TrendingUp className="w-4 h-4" />
              </div>
              <div className="min-w-0">
                <span className="text-[11px] text-slate-500 dark:text-slate-400 font-bold block truncate">Rata-Rata Partisipasi</span>
                <span className="text-base font-black text-slate-900 dark:text-white font-mono">{averageParticipation}%</span>
              </div>
            </div>

            <div className="p-3.5 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700/80 flex items-center gap-3">
              <div className="p-2.5 bg-blue-100 dark:bg-blue-950/60 text-blue-800 dark:text-blue-300 rounded-xl shrink-0">
                <Award className="w-4 h-4" />
              </div>
              <div className="min-w-0">
                <span className="text-[11px] text-slate-500 dark:text-slate-400 font-bold block truncate">Bulan Tertinggi</span>
                <span className="text-base font-black text-slate-900 dark:text-white font-mono truncate block">
                  {bestMonth?.monthShort} ({bestMonth?.persentase}%)
                </span>
              </div>
            </div>

            <div className="p-3.5 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700/80 flex items-center gap-3">
              <div className="p-2.5 bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 rounded-xl shrink-0">
                <DollarSign className="w-4 h-4" />
              </div>
              <div className="min-w-0">
                <span className="text-[11px] text-slate-500 dark:text-slate-400 font-bold block truncate">Total Iuran 2026</span>
                <span className="text-sm font-black text-slate-900 dark:text-white font-mono truncate block">
                  {formatRupiah(totalCollectedThisYear)}
                </span>
              </div>
            </div>

            <div className="p-3.5 bg-rose-50/70 dark:bg-rose-950/30 rounded-2xl border border-rose-200 dark:border-rose-900/60 flex items-center gap-3">
              <div className="p-2.5 bg-rose-100 dark:bg-rose-950/60 text-rose-800 dark:text-rose-300 rounded-xl shrink-0">
                <AlertCircle className="w-4 h-4" />
              </div>
              <div className="min-w-0">
                <span className="text-[11px] text-rose-900 dark:text-rose-300 font-bold block truncate">Tunggakan &gt;3 Bulan</span>
                <span className="text-base font-black text-rose-700 dark:text-rose-400 font-mono block">
                  {criticalArrearsCount} KK
                </span>
              </div>
            </div>

          </div>

          {/* Recharts Container */}
          <div className="w-full h-64 sm:h-72 pt-2">
            <ResponsiveContainer width="100%" height="100%">
              {chartMode === 'bar' ? (
                <BarChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#334155" strokeOpacity={0.2} />
                  <XAxis 
                    dataKey="monthShort" 
                    tick={{ fontSize: 11, fill: '#64748b', fontWeight: 600 }}
                    axisLine={{ stroke: '#94a3b8' }}
                    tickLine={false}
                  />
                  <YAxis 
                    tick={{ fontSize: 11, fill: '#64748b' }}
                    axisLine={false}
                    tickLine={false}
                  />
                  <Tooltip content={<CustomChartTooltip />} />
                  <Legend 
                    wrapperStyle={{ fontSize: 11, paddingTop: 8 }}
                    formatter={(value) => (
                      <span className="font-bold text-slate-700 dark:text-slate-300">
                        {value === 'lunasKK' ? 'KK Lunas (Hijau)' : 'KK Belum Bayar (Merah/Oranye)'}
                      </span>
                    )}
                  />
                  <Bar 
                    dataKey="lunasKK" 
                    name="lunasKK" 
                    stackId="a" 
                    fill="#059669" 
                    radius={[0, 0, 4, 4]} 
                  />
                  <Bar 
                    dataKey="menunggakKK" 
                    name="menunggakKK" 
                    stackId="a" 
                    fill="#f43f5e" 
                    radius={[6, 6, 0, 0]} 
                  />
                </BarChart>
              ) : (
                <AreaChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <defs>
                    <linearGradient id="colorPersen" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#059669" stopOpacity={0.4}/>
                      <stop offset="95%" stopColor="#059669" stopOpacity={0.0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#334155" strokeOpacity={0.2} />
                  <XAxis 
                    dataKey="monthShort" 
                    tick={{ fontSize: 11, fill: '#64748b', fontWeight: 600 }}
                    axisLine={{ stroke: '#94a3b8' }}
                    tickLine={false}
                  />
                  <YAxis 
                    unit="%" 
                    domain={[0, 100]}
                    tick={{ fontSize: 11, fill: '#64748b' }}
                    axisLine={false}
                    tickLine={false}
                  />
                  <Tooltip content={<CustomChartTooltip />} />
                  <Legend 
                    wrapperStyle={{ fontSize: 11, paddingTop: 8 }}
                    formatter={() => (
                      <span className="font-bold text-slate-700 dark:text-slate-300">
                        Tingkat Partisipasi Iuran Warga (%)
                      </span>
                    )}
                  />
                  <Area 
                    type="monotone" 
                    dataKey="persentase" 
                    stroke="#059669" 
                    strokeWidth={3} 
                    fillOpacity={1} 
                    fill="url(#colorPersen)" 
                  />
                </AreaChart>
              )}
            </ResponsiveContainer>
          </div>

          <div className="flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400 pt-2 border-t border-slate-100 dark:border-slate-800">
            <span>
              ℹ️ Menampilkan data partisipasi {activeCitizens.length} Kartu Keluarga aktif di Metro Parung Panjang.
            </span>
            <span className="font-mono font-semibold">Tahun Anggaran 2026</span>
          </div>

        </div>
      )}
    </div>
  );
};
