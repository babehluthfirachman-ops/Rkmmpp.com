import React, { useState, useMemo } from 'react';
import { useRkm } from '../context/RkmContext';
import { AccessAuditLog } from '../types';
import {
  History,
  ShieldCheck,
  ShieldAlert,
  Search,
  Filter,
  Download,
  Calendar,
  CreditCard,
  HeartHandshake,
  Users,
  Lock,
  Database,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  Eye,
  RefreshCw,
  Clock,
  ArrowUpDown,
  Trash2
} from 'lucide-react';

export const ActivityLog: React.FC = () => {
  const { currentUser, auditLogs, transactions, deathNotices, clearAuditLogs, addAuditLog } = useRkm();

  // Access Control: Super Admin Only
  const isSuperAdmin = currentUser?.role === 'superadmin';

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<'all' | 'iuran' | 'duka' | 'warga' | 'security'>('all');
  const [selectedStatus, setSelectedStatus] = useState<'all' | 'Success' | 'Warning' | 'Failed'>('all');
  const [timeRange, setTimeRange] = useState<'all' | 'today' | 'week' | 'month'>('all');
  const [selectedLog, setSelectedLog] = useState<AccessAuditLog | null>(null);
  const [showClearConfirmModal, setShowClearConfirmModal] = useState(false);
  const [clearToastMessage, setClearToastMessage] = useState<string | null>(null);

  // Filter logs based on category and metadata
  const filteredLogs = useMemo(() => {
    return auditLogs.filter(log => {
      // 1. Category check
      if (selectedCategory === 'iuran') {
        const isDues = 
          log.action.includes('IURAN') || 
          log.action.includes('DUES') || 
          log.action.includes('PAYMENT') || 
          log.action.includes('KAS') || 
          log.details.toLowerCase().includes('iuran') || 
          log.details.toLowerCase().includes('kwitansi') ||
          log.details.toLowerCase().includes('pembayaran');
        if (!isDues) return false;
      } else if (selectedCategory === 'duka') {
        const isDeath = 
          log.action.includes('DUKA') || 
          log.action.includes('SANTUNAN') || 
          log.action.includes('LELAYU') || 
          log.action.includes('STATUS_DUKA') ||
          log.details.toLowerCase().includes('wafat') || 
          log.details.toLowerCase().includes('santunan') ||
          log.details.toLowerCase().includes('jenazah');
        if (!isDeath) return false;
      } else if (selectedCategory === 'warga') {
        const isCitizen = log.action.includes('CITIZEN') || log.action.includes('MEMBER') || log.details.toLowerCase().includes('kk ') || log.details.toLowerCase().includes('jiwa');
        if (!isCitizen) return false;
      } else if (selectedCategory === 'security') {
        const isSec = log.action.includes('LOGIN') || log.action.includes('PASSWORD') || log.action.includes('SUPERADMIN') || log.action.includes('DATABASE') || log.action.includes('BACKUP') || log.action.includes('LOGS_CLEARED');
        if (!isSec) return false;
      }

      // 2. Status filter
      if (selectedStatus !== 'all' && log.status !== selectedStatus) {
        return false;
      }

      // 3. Search query
      if (searchTerm.trim()) {
        const q = searchTerm.toLowerCase();
        const matches = 
          log.userName.toLowerCase().includes(q) ||
          log.action.toLowerCase().includes(q) ||
          log.details.toLowerCase().includes(q) ||
          log.ipAddress.toLowerCase().includes(q);
        if (!matches) return false;
      }

      // 4. Time Range Filter
      if (timeRange !== 'all') {
        const logDate = new Date(log.timestamp.replace(' ', 'T'));
        const now = new Date();
        const diffMs = now.getTime() - logDate.getTime();
        const diffHours = diffMs / (1000 * 60 * 60);

        if (timeRange === 'today' && diffHours > 24) return false;
        if (timeRange === 'week' && diffHours > 24 * 7) return false;
        if (timeRange === 'month' && diffHours > 24 * 30) return false;
      }

      return true;
    });
  }, [auditLogs, selectedCategory, selectedStatus, searchTerm, timeRange]);

  const handleConfirmClearLogs = () => {
    clearAuditLogs();
    setShowClearConfirmModal(false);
    setClearToastMessage('Seluruh rekam riwayat Activity Log sistem berhasil dikosongkan oleh Super Admin.');
    
    // Add a record that logs were cleared
    setTimeout(() => {
      addAuditLog({
        userName: currentUser?.name || 'Super Admin',
        userRole: 'superadmin',
        action: 'LOGS_CLEARED',
        details: 'Seluruh riwayat log aktivitas dan audit sistem telah dikosongkan (Clear Logs) oleh Super Admin.',
        ipAddress: '182.253.14.88 (Pusat Audit)',
        status: 'Warning'
      });
    }, 100);

    setTimeout(() => {
      setClearToastMessage(null);
    }, 4500);
  };

  // Metric aggregates
  const totalDuesLogs = useMemo(() => 
    auditLogs.filter(l => l.action.includes('IURAN') || l.action.includes('DUES') || l.details.toLowerCase().includes('iuran')).length,
    [auditLogs]
  );

  const totalDeathLogs = useMemo(() => 
    auditLogs.filter(l => l.action.includes('DUKA') || l.action.includes('SANTUNAN') || l.details.toLowerCase().includes('wafat')).length,
    [auditLogs]
  );

  const totalSecurityLogs = useMemo(() => 
    auditLogs.filter(l => l.action.includes('LOGIN') || l.action.includes('BACKUP') || l.action.includes('SUPERADMIN') || l.action.includes('PASSWORD')).length,
    [auditLogs]
  );

  // Export CSV
  const handleExportCsv = () => {
    let csv = 'ID,Waktu,Pengguna,Peran,Aksi,Detail,Alamat IP,Status\n';
    filteredLogs.forEach(l => {
      csv += `"${l.id}","${l.timestamp}","${l.userName}","${l.userRole}","${l.action}","${(l.details || '').replace(/"/g, '""')}","${l.ipAddress}","${l.status}"\n`;
    });

    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `RKM_ACTIVITY_LOG_${selectedCategory}_${new Date().toISOString().slice(0, 10)}.csv`;
    document.body.appendChild(a);
    a.click();
    a.remove();
  };

  // Helper to render action category badges
  const getActionBadge = (action: string) => {
    if (action.includes('IURAN') || action.includes('DUES')) {
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-extrabold bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
          <CreditCard className="w-3 h-3" />
          Iuran Kas
        </span>
      );
    }
    if (action.includes('DUKA') || action.includes('SANTUNAN')) {
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-extrabold bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300 border border-rose-200 dark:border-rose-800">
          <HeartHandshake className="w-3 h-3" />
          Layanan Duka
        </span>
      );
    }
    if (action.includes('CITIZEN') || action.includes('MEMBER')) {
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-extrabold bg-sky-100 text-sky-800 dark:bg-sky-950 dark:text-sky-300 border border-sky-200 dark:border-sky-800">
          <Users className="w-3 h-3" />
          Data Warga
        </span>
      );
    }
    if (action.includes('BACKUP') || action.includes('DATABASE')) {
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-extrabold bg-purple-100 text-purple-800 dark:bg-purple-950 dark:text-purple-300 border border-purple-200 dark:border-purple-800">
          <Database className="w-3 h-3" />
          Database
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-extrabold bg-slate-100 text-slate-800 dark:bg-slate-800 dark:text-slate-300 border border-slate-200 dark:border-slate-700">
        <Lock className="w-3 h-3" />
        Sistem & Auth
      </span>
    );
  };

  // If user is not superadmin, render Access Denied Screen
  if (!isSuperAdmin) {
    return (
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-8 sm:p-12 border border-slate-200 dark:border-slate-800 shadow-xs text-center max-w-xl mx-auto space-y-4">
        <div className="w-16 h-16 bg-rose-100 dark:bg-rose-950/60 text-rose-600 rounded-full flex items-center justify-center mx-auto">
          <ShieldAlert className="w-8 h-8" />
        </div>
        <h2 className="text-xl font-black text-slate-900 dark:text-white">
          Akses Log Aktivitas Dibatasi
        </h2>
        <p className="text-xs text-slate-500 dark:text-slate-400">
          Komponen <strong>Activity Log Sistem</strong> memuat rekam jejak sensitif keuangan, audit kas, pelaporan kematian, dan data kredensial. Modul ini secara khusus hanya dapat diakses oleh akun dengan peran <strong>Super Admin</strong>.
        </p>
        <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-2xl text-xs text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700">
          Peran Anda Saat Ini: <span className="font-extrabold uppercase text-indigo-600">{currentUser?.role || 'Tamu / Warga'}</span>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      
      {/* Header Banner */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-7 border border-slate-200 dark:border-slate-800 shadow-xs">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="flex items-start sm:items-center gap-3.5">
            <div className="p-3 bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400 rounded-2xl shrink-0">
              <History className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg sm:text-xl font-black text-slate-900 dark:text-white tracking-tight">
                  Log Aktivitas & Audit Sistem (Activity Log)
                </h1>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
                  Super Admin Khusus
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                Pencatatan rekam jejak otomatis transaksi iuran kas, pelaporan layanan duka, mutasi data warga, dan aktivitas otentikasi.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              id="btn-export-activity-log-csv"
              type="button"
              onClick={handleExportCsv}
              className="flex items-center gap-2 px-3.5 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-extrabold rounded-xl border border-slate-200 dark:border-slate-700 transition-all cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Ekspor CSV ({filteredLogs.length})</span>
            </button>

            {isSuperAdmin && (
              <button
                id="btn-clear-activity-logs"
                type="button"
                onClick={() => setShowClearConfirmModal(true)}
                className="flex items-center gap-2 px-3.5 py-2 bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/40 dark:hover:bg-rose-900/60 text-rose-700 dark:text-rose-300 text-xs font-extrabold rounded-xl border border-rose-200 dark:border-rose-800 transition-all cursor-pointer shadow-xs active:scale-95"
                title="Hapus seluruh log aktivitas sistem (Hanya Super Admin)"
              >
                <Trash2 className="w-3.5 h-3.5 text-rose-600 dark:text-rose-400" />
                <span>Clear Logs</span>
              </button>
            )}
          </div>
        </div>

        {clearToastMessage && (
          <div className="mt-4 p-3.5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200 text-xs font-bold flex items-center justify-between animate-fade-in">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{clearToastMessage}</span>
            </div>
            <button
              onClick={() => setClearToastMessage(null)}
              className="text-slate-500 hover:text-slate-700 text-[11px] underline cursor-pointer"
            >
              Tutup
            </button>
          </div>
        )}

        {/* Counter Metric Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6">
          <div 
            onClick={() => setSelectedCategory('all')}
            className={`p-3.5 rounded-2xl border transition-all cursor-pointer ${
              selectedCategory === 'all' 
                ? 'bg-indigo-50/80 dark:bg-indigo-950/40 border-indigo-200 dark:border-indigo-800 ring-2 ring-indigo-500/20' 
                : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200/80 dark:border-slate-700'
            }`}
          >
            <span className="text-[10px] text-slate-500 font-bold block">Total Seluruh Log</span>
            <span className="text-lg font-black text-slate-900 dark:text-white">{auditLogs.length}</span>
          </div>

          <div 
            onClick={() => setSelectedCategory('iuran')}
            className={`p-3.5 rounded-2xl border transition-all cursor-pointer ${
              selectedCategory === 'iuran' 
                ? 'bg-emerald-50/80 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800 ring-2 ring-emerald-500/20' 
                : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200/80 dark:border-slate-700'
            }`}
          >
            <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-bold block">Pembayaran Iuran Kas</span>
            <span className="text-lg font-black text-emerald-700 dark:text-emerald-300">{totalDuesLogs}</span>
          </div>

          <div 
            onClick={() => setSelectedCategory('duka')}
            className={`p-3.5 rounded-2xl border transition-all cursor-pointer ${
              selectedCategory === 'duka' 
                ? 'bg-rose-50/80 dark:bg-rose-950/40 border-rose-200 dark:border-rose-800 ring-2 ring-rose-500/20' 
                : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200/80 dark:border-slate-700'
            }`}
          >
            <span className="text-[10px] text-rose-600 dark:text-rose-400 font-bold block">Layanan Duka & Santunan</span>
            <span className="text-lg font-black text-rose-700 dark:text-rose-300">{totalDeathLogs}</span>
          </div>

          <div 
            onClick={() => setSelectedCategory('security')}
            className={`p-3.5 rounded-2xl border transition-all cursor-pointer ${
              selectedCategory === 'security' 
                ? 'bg-purple-50/80 dark:bg-purple-950/40 border-purple-200 dark:border-purple-800 ring-2 ring-purple-500/20' 
                : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200/80 dark:border-slate-700'
            }`}
          >
            <span className="text-[10px] text-purple-600 dark:text-purple-400 font-bold block">Keamanan & Sistem</span>
            <span className="text-lg font-black text-purple-700 dark:text-purple-300">{totalSecurityLogs}</span>
          </div>
        </div>

        {/* Filter Controls Bar */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-3 mt-6 pt-5 border-t border-slate-100 dark:border-slate-800">
          
          {/* Search Box */}
          <div className="relative md:col-span-2">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Cari nama warga, petugas, aksi, atau detail..."
              className="w-full pl-9 pr-4 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          {/* Status Filter */}
          <div>
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value as any)}
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
            >
              <option value="all">Semua Status (Sukses / Peringatan / Gagal)</option>
              <option value="Success">Hanya Sukses (Success)</option>
              <option value="Warning">Peringatan (Warning)</option>
              <option value="Failed">Gagal / Terblokir (Failed)</option>
            </select>
          </div>

          {/* Time Range Filter */}
          <div>
            <select
              value={timeRange}
              onChange={(e) => setTimeRange(e.target.value as any)}
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
            >
              <option value="all">Semua Rentang Waktu</option>
              <option value="today">24 Jam Terakhir</option>
              <option value="week">7 Hari Terakhir</option>
              <option value="month">30 Hari Terakhir</option>
            </select>
          </div>

        </div>
      </div>

      {/* Main Activity Table */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-700 text-[11px] font-extrabold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                <th className="py-3.5 px-4">Waktu</th>
                <th className="py-3.5 px-4">Aktor / Pengguna</th>
                <th className="py-3.5 px-4">Kategori Aksi</th>
                <th className="py-3.5 px-4">Rincian Perubahan</th>
                <th className="py-3.5 px-4">Lokasi / IP</th>
                <th className="py-3.5 px-4 text-center">Status</th>
                <th className="py-3.5 px-4 text-right">Detail</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
              {filteredLogs.length > 0 ? (
                filteredLogs.map((log) => (
                  <tr 
                    key={log.id} 
                    className="hover:bg-slate-50/70 dark:hover:bg-slate-800/50 transition-colors"
                  >
                    <td className="py-3 px-4 font-mono text-[11px] text-slate-600 dark:text-slate-400 whitespace-nowrap">
                      {log.timestamp}
                    </td>

                    <td className="py-3 px-4 whitespace-nowrap">
                      <div className="font-extrabold text-slate-900 dark:text-white">{log.userName}</div>
                      <span className="text-[10px] text-slate-500 uppercase">{log.userRole}</span>
                    </td>

                    <td className="py-3 px-4 whitespace-nowrap">
                      {getActionBadge(log.action)}
                    </td>

                    <td className="py-3 px-4 max-w-md">
                      <div className="font-semibold text-slate-800 dark:text-slate-200 truncate" title={log.details}>
                        {log.details}
                      </div>
                      <span className="text-[10px] font-mono text-slate-600">{log.action}</span>
                    </td>

                    <td className="py-3 px-4 text-slate-500 whitespace-nowrap text-[11px]">
                      {log.ipAddress}
                    </td>

                    <td className="py-3 px-4 text-center whitespace-nowrap">
                      {log.status === 'Success' ? (
                        <span className="inline-flex items-center gap-1 text-[10px] font-extrabold text-emerald-600 dark:text-emerald-400">
                          <CheckCircle2 className="w-3 h-3" />
                          Sukses
                        </span>
                      ) : log.status === 'Warning' ? (
                        <span className="inline-flex items-center gap-1 text-[10px] font-extrabold text-amber-600 dark:text-amber-400">
                          <AlertTriangle className="w-3 h-3" />
                          Peringatan
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-[10px] font-extrabold text-rose-600 dark:text-rose-400">
                          <XCircle className="w-3 h-3" />
                          Gagal
                        </span>
                      )}
                    </td>

                    <td className="py-3 px-4 text-right whitespace-nowrap">
                      <button
                        type="button"
                        onClick={() => setSelectedLog(log)}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                        title="Lihat Detail Entri Log"
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-400">
                    <History className="w-8 h-8 mx-auto mb-2 opacity-40" />
                    <p className="font-bold text-sm">Tidak ada catatan aktivitas yang sesuai filter.</p>
                    <p className="text-xs mt-1">Coba sesuaikan kata kunci pencarian atau ubah filter kategori.</p>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Footer info bar */}
        <div className="p-4 bg-slate-50/60 dark:bg-slate-800/40 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500">
          <span>Menampilkan {filteredLogs.length} dari {auditLogs.length} entri riwayat</span>
          <span className="text-[11px]">Audit Engine v2.4 (Terhubung Real-time)</span>
        </div>
      </div>

      {/* Detailed Log Modal */}
      {selectedLog && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-lg w-full p-6 border border-slate-200 dark:border-slate-800 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <History className="w-5 h-5 text-indigo-600" />
                <h3 className="font-extrabold text-sm text-slate-900 dark:text-white">
                  Rincian Entri Log Aktivitas
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setSelectedLog(null)}
                className="text-slate-400 hover:text-slate-700 dark:hover:text-white text-sm"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-2 p-3 bg-slate-50 dark:bg-slate-800 rounded-2xl">
                <div>
                  <span className="text-slate-400 block text-[10px]">ID Log:</span>
                  <span className="font-mono font-bold text-slate-800 dark:text-slate-200">{selectedLog.id}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px]">Waktu Eksekusi:</span>
                  <span className="font-semibold text-slate-800 dark:text-slate-200">{selectedLog.timestamp}</span>
                </div>
              </div>

              <div>
                <span className="text-slate-400 block text-[10px]">Pengguna / Inisiator:</span>
                <span className="font-extrabold text-slate-900 dark:text-white">{selectedLog.userName} ({selectedLog.userRole})</span>
              </div>

              <div>
                <span className="text-slate-400 block text-[10px]">Aksi Terdaftar:</span>
                <span className="font-mono font-bold text-indigo-600 dark:text-indigo-400">{selectedLog.action}</span>
              </div>

              <div>
                <span className="text-slate-400 block text-[10px]">Detail Informasi:</span>
                <p className="p-3 bg-slate-100 dark:bg-slate-800/80 rounded-xl text-slate-700 dark:text-slate-300 font-medium leading-relaxed">
                  {selectedLog.details}
                </p>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <span className="text-slate-400 block text-[10px]">Alamat IP / Klien:</span>
                  <span className="font-mono text-slate-700 dark:text-slate-300">{selectedLog.ipAddress}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px]">Status:</span>
                  <span className="font-bold">{selectedLog.status}</span>
                </div>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex justify-end">
              <button
                type="button"
                onClick={() => setSelectedLog(null)}
                className="px-4 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-xl text-xs font-bold text-slate-700 dark:text-slate-200 cursor-pointer"
              >
                Tutup
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Confirmation Modal for Clear Logs */}
      {showClearConfirmModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-sm animate-fade-in">
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 max-w-md w-full shadow-2xl border border-slate-200 dark:border-slate-800 space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-rose-100 dark:bg-rose-950/60 text-rose-600 flex items-center justify-center">
              <Trash2 className="w-6 h-6" />
            </div>

            <div>
              <h3 className="font-extrabold text-base text-slate-900 dark:text-white">
                Konfirmasi Kosongkan Log Sistem
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1.5 leading-relaxed">
                Apakah Anda yakin ingin menghapus seluruh riwayat <strong>Activity Log & Audit Sistem</strong>? Tindakan ini hanya dapat dilakukan oleh Super Admin dan seluruh catatan aktivitas akan dikosongkan.
              </p>
            </div>

            <div className="p-3 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 rounded-xl text-[11px] text-rose-800 dark:text-rose-300">
              ⚠️ Peringatan: Tindakan ini permanen. Pastikan Anda telah mengunduh cadangan CSV jika data audit masih dibutuhkan.
            </div>

            <div className="flex items-center justify-end gap-2.5 pt-2">
              <button
                type="button"
                onClick={() => setShowClearConfirmModal(false)}
                className="px-4 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-bold rounded-xl transition-all cursor-pointer"
              >
                Batal
              </button>
              <button
                id="btn-confirm-clear-logs"
                type="button"
                onClick={handleConfirmClearLogs}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white text-xs font-extrabold rounded-xl shadow-xs transition-all cursor-pointer"
              >
                Ya, Kosongkan Log Sekarang
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
