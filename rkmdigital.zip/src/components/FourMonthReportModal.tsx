import React, { useState } from 'react';
import { X, Printer, Download, Calendar, ShieldCheck, FileSpreadsheet, Building2, CheckCircle } from 'lucide-react';
import { useRkm } from '../context/RkmContext';
import { formatRupiah, formatDateIndo } from '../utils/formatters';
import { exportFourMonthReportPdf } from '../utils/pdfExport';

interface FourMonthReportModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const FourMonthReportModal: React.FC<FourMonthReportModalProps> = ({ isOpen, onClose }) => {
  const { settings, transactions, citizens, deathNotices } = useRkm();
  const [selectedPeriod, setSelectedPeriod] = useState<'Caturwulan 1' | 'Caturwulan 2' | 'Caturwulan 3'>('Caturwulan 2');
  const [selectedYear, setSelectedYear] = useState('2026');

  if (!isOpen) return null;

  // Periods config
  const periodDetails = {
    'Caturwulan 1': { name: 'Caturwulan I (Januari - April)', months: ['01', '02', '03', '04'], initialBalance: 12500000 },
    'Caturwulan 2': { name: 'Caturwulan II (Mei - Agustus)', months: ['05', '06', '07', '08'], initialBalance: 18450000 },
    'Caturwulan 3': { name: 'Caturwulan III (September - Desember)', months: ['09', '10', '11', '12'], initialBalance: 24800000 }
  };

  const currentPeriod = periodDetails[selectedPeriod];

  // Filter transactions for period
  const periodTransactions = transactions.filter(t => {
    const [year, month] = t.date.split('-');
    return year === selectedYear && currentPeriod.months.includes(month);
  });

  const incomeTxs = periodTransactions.filter(t => t.type === 'in');
  const expenseTxs = periodTransactions.filter(t => t.type === 'out');

  const totalIncome = incomeTxs.reduce((sum, t) => sum + t.amount, 0);
  const totalExpense = expenseTxs.reduce((sum, t) => sum + t.amount, 0);
  const endingBalance = currentPeriod.initialBalance + totalIncome - totalExpense;

  // Breakdown income categories
  const duesIncome = incomeTxs.filter(t => t.category === 'Iuran Wajib').reduce((s, t) => s + t.amount, 0);
  const infaqIncome = incomeTxs.filter(t => t.category === 'Infaq / Sedekah' || t.category === 'Donasi / Hibah').reduce((s, t) => s + t.amount, 0);
  const otherIncome = totalIncome - duesIncome - infaqIncome;

  // Breakdown expense categories
  const deathAssistanceExpense = expenseTxs.filter(t => t.category === 'Santunan Kematian' || t.category === 'Perlengkapan Kain Kafan' || t.category === 'Gali Kubur / TPU').reduce((s, t) => s + t.amount, 0);
  const operationalExpense = expenseTxs.filter(t => t.category === 'Operasional Ambulance' || t.category === 'Perawatan Aset & Tenda' || t.category === 'Biaya Operasional Organisasi').reduce((s, t) => s + t.amount, 0);
  const otherExpense = totalExpense - deathAssistanceExpense - operationalExpense;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-4xl overflow-hidden animate-fade-in my-6 max-h-[92vh] flex flex-col">
        
        {/* Header Controls (Hidden on Print) */}
        <div className="bg-slate-900 text-white p-4 sm:p-5 flex items-center justify-between border-b border-slate-800 shrink-0 no-print">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-600 flex items-center justify-center text-white shadow-lg shadow-emerald-950/40">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">Generator Laporan Keuangan 4-Bulanan</h2>
              <p className="text-xs text-slate-400">Mandat Anggaran Rumah Tangga (ART) BAB V Pasal 7 RKM MPP</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                exportFourMonthReportPdf(
                  selectedPeriod,
                  parseInt(selectedYear, 10),
                  settings,
                  {
                    startBalance: currentPeriod.initialBalance,
                    totalIn: totalIncome,
                    totalOut: totalExpense,
                    endBalance: endingBalance
                  },
                  [
                    { category: 'Iuran Wajib Warga (Pokok & Ekstra)', count: duesIncome > 0 ? Math.round(duesIncome / 5000) : 0, amount: duesIncome },
                    { category: 'Infaq, Sedekah & Donasi Duka', count: incomeTxs.filter(t => t.category === 'Infaq / Sedekah' || t.category === 'Donasi / Hibah').length, amount: infaqIncome },
                    { category: 'Penerimaan Kas Lainnya', count: incomeTxs.filter(t => t.category !== 'Iuran Wajib' && t.category !== 'Infaq / Sedekah' && t.category !== 'Donasi / Hibah').length, amount: otherIncome }
                  ],
                  [
                    { category: 'Santunan Kematian & Kain Kafan', count: deathNotices.length, amount: deathAssistanceExpense },
                    { category: 'Operasional Satgas & Ambulans', count: expenseTxs.filter(t => t.category.includes('Operasional') || t.category.includes('Ambulance')).length, amount: operationalExpense },
                    { category: 'Pengeluaran Lain-Lain & Kas Kecil', count: expenseTxs.filter(t => !t.category.includes('Santunan') && !t.category.includes('Kain') && !t.category.includes('Operasional') && !t.category.includes('Ambulance')).length, amount: otherExpense }
                  ],
                  deathNotices.filter(d => d.status === 'Aktif').length
                );
              }}
              className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-md transition-all active:scale-95 cursor-pointer border border-emerald-500/30"
              title="Unduh Berkas PDF Laporan Resmi 4-Bulanan"
            >
              <Download className="w-4 h-4" />
              <span className="hidden sm:inline">Unduh PDF (A4)</span>
            </button>
            <button
              onClick={handlePrint}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 border border-slate-700 transition-all active:scale-95 cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              <span className="hidden sm:inline">Cetak Browser</span>
            </button>
            <button 
              onClick={onClose} 
              className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Period Selector (Hidden on Print) */}
        <div className="p-4 bg-slate-50 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3 shrink-0 no-print">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-slate-700">Pilih Periode:</span>
            <div className="flex rounded-xl bg-white border border-slate-300 p-1 shadow-sm">
              {(['Caturwulan 1', 'Caturwulan 2', 'Caturwulan 3'] as const).map(p => (
                <button
                  key={p}
                  onClick={() => setSelectedPeriod(p)}
                  className={`px-3 py-1 text-xs font-bold rounded-lg transition-all ${
                    selectedPeriod === p ? 'bg-emerald-600 text-white shadow-sm' : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {p}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-slate-700">Tahun Buku:</span>
            <select
              value={selectedYear}
              onChange={(e) => setSelectedYear(e.target.value)}
              className="px-3 py-1 bg-white border border-slate-300 rounded-xl text-xs font-bold text-slate-800 outline-none"
            >
              <option value="2026">2026</option>
              <option value="2025">2025</option>
              <option value="2024">2024</option>
            </select>
          </div>
        </div>

        {/* Printable Report Document Sheet */}
        <div className="p-8 sm:p-12 overflow-y-auto text-slate-900 font-sans space-y-6 bg-white" id="printable-report">
          
          {/* Official Letterhead */}
          <div className="border-b-4 border-double border-slate-900 pb-4 text-center relative">
            <h1 className="text-xl font-black tracking-wide text-slate-900 uppercase">
              PAGUYUBAN RUKUN KEMATIAN METRO PARUNG PANJANG (RKM MPP)
            </h1>
            <h2 className="text-sm font-extrabold text-slate-700 uppercase tracking-wider mt-0.5">
              LAPORAN PERTANGGUNGJAWABAN KEUANGAN KAS 4-BULANAN
            </h2>
            <p className="text-xs text-slate-600 mt-1">
              Periode: <strong>{currentPeriod.name} Tahun {selectedYear}</strong> — Berdasarkan ART BAB V Pasal 7
            </p>
            <p className="text-[10px] text-slate-500 mt-0.5">
              Sekretariat: {settings.address} | Hotline: {settings.contactCenter}
            </p>
          </div>

          {/* Executive Summary Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
              <span className="text-[10px] text-slate-500 uppercase block font-bold">Saldo Awal Periode</span>
              <span className="text-sm font-extrabold text-slate-800">{formatRupiah(currentPeriod.initialBalance)}</span>
            </div>
            <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200">
              <span className="text-[10px] text-emerald-700 uppercase block font-bold">Total Kas Masuk</span>
              <span className="text-sm font-extrabold text-emerald-800">+{formatRupiah(totalIncome)}</span>
            </div>
            <div className="p-3 bg-rose-50 rounded-xl border border-rose-200">
              <span className="text-[10px] text-rose-700 uppercase block font-bold">Total Pengeluaran</span>
              <span className="text-sm font-extrabold text-rose-800">-{formatRupiah(totalExpense)}</span>
            </div>
            <div className="p-3 bg-slate-900 text-white rounded-xl border border-slate-800">
              <span className="text-[10px] text-slate-400 uppercase block font-bold">Saldo Akhir Kas</span>
              <span className="text-sm font-black text-emerald-400">{formatRupiah(endingBalance)}</span>
            </div>
          </div>

          {/* Detailed Financial Summary Table */}
          <div className="border border-slate-300 rounded-xl overflow-hidden text-xs">
            <table className="w-full text-left">
              <thead className="bg-slate-100 border-b border-slate-300 text-slate-700 font-bold uppercase text-[10px]">
                <tr>
                  <th className="p-2.5">No</th>
                  <th className="p-2.5">Pos Anggaran / Uraian Mutasi</th>
                  <th className="p-2.5 text-right">Penerimaan (Rp)</th>
                  <th className="p-2.5 text-right">Pengeluaran (Rp)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                <tr className="bg-slate-50 font-bold">
                  <td className="p-2.5">A</td>
                  <td className="p-2.5">SALDO AWAL KAS</td>
                  <td className="p-2.5 text-right font-mono">{formatRupiah(currentPeriod.initialBalance)}</td>
                  <td className="p-2.5 text-right font-mono">-</td>
                </tr>
                <tr>
                  <td className="p-2.5">B.1</td>
                  <td className="p-2.5 pl-6">Iuran Wajib Anggota (KK & Anggota Tambahan)</td>
                  <td className="p-2.5 text-right font-mono text-emerald-700">{formatRupiah(duesIncome)}</td>
                  <td className="p-2.5 text-right font-mono">-</td>
                </tr>
                <tr>
                  <td className="p-2.5">B.2</td>
                  <td className="p-2.5 pl-6">Infaq Sukarela, Sedekah & Donasi Warga</td>
                  <td className="p-2.5 text-right font-mono text-emerald-700">{formatRupiah(infaqIncome)}</td>
                  <td className="p-2.5 text-right font-mono">-</td>
                </tr>
                <tr>
                  <td className="p-2.5">B.3</td>
                  <td className="p-2.5 pl-6">Penerimaan Lain-lain / Dana Masuk</td>
                  <td className="p-2.5 text-right font-mono text-emerald-700">{formatRupiah(otherIncome)}</td>
                  <td className="p-2.5 text-right font-mono">-</td>
                </tr>
                <tr className="bg-emerald-50/50 font-bold">
                  <td className="p-2.5"></td>
                  <td className="p-2.5">TOTAL PENERIMAAN KAS (B)</td>
                  <td className="p-2.5 text-right font-mono text-emerald-800">{formatRupiah(totalIncome)}</td>
                  <td className="p-2.5 text-right font-mono">-</td>
                </tr>

                <tr>
                  <td className="p-2.5">C.1</td>
                  <td className="p-2.5 pl-6">Santunan Kematian & Paket Fardhu Kifayah (@ Rp 1.900.000)</td>
                  <td className="p-2.5 text-right font-mono">-</td>
                  <td className="p-2.5 text-right font-mono text-rose-700">{formatRupiah(deathAssistanceExpense)}</td>
                </tr>
                <tr>
                  <td className="p-2.5">C.2</td>
                  <td className="p-2.5 pl-6">Operasional Ambulance, Perawatan Tenda & Inventaris</td>
                  <td className="p-2.5 text-right font-mono">-</td>
                  <td className="p-2.5 text-right font-mono text-rose-700">{formatRupiah(operationalExpense)}</td>
                </tr>
                <tr>
                  <td className="p-2.5">C.3</td>
                  <td className="p-2.5 pl-6">Biaya Operasional Organisasi & Konsumsi Musyawarah</td>
                  <td className="p-2.5 text-right font-mono">-</td>
                  <td className="p-2.5 text-right font-mono text-rose-700">{formatRupiah(otherExpense)}</td>
                </tr>
                <tr className="bg-rose-50/50 font-bold">
                  <td className="p-2.5"></td>
                  <td className="p-2.5">TOTAL PENGELUARAN KAS (C)</td>
                  <td className="p-2.5 text-right font-mono">-</td>
                  <td className="p-2.5 text-right font-mono text-rose-800">{formatRupiah(totalExpense)}</td>
                </tr>

                <tr className="bg-slate-900 text-white font-extrabold text-xs">
                  <td className="p-3">D</td>
                  <td className="p-3">SALDO AKHIR KAS (A + B - C)</td>
                  <td colSpan={2} className="p-3 text-right font-mono text-emerald-400 text-sm">
                    {formatRupiah(endingBalance)}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* List of Death notices handled during period */}
          <div className="space-y-2 text-xs">
            <h3 className="font-bold text-slate-800 uppercase tracking-wide">
              Rekapitulasi Layanan Jenazah Terlaksana Periode Ini:
            </h3>
            <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
              <p className="text-slate-600 text-[11px] leading-relaxed">
                Tercatat sebanyak <strong>{deathNotices.length} musibah duka cita</strong> telah dilayani dengan fardhu kifayah lengkap dan santunan AD/ART tersalurkan 100% tanpa kendala.
              </p>
            </div>
          </div>

          {/* Official Signatures */}
          <div className="pt-8 grid grid-cols-3 gap-6 text-center text-xs">
            <div className="space-y-16">
              <p className="text-slate-600">Mengetahui,<br /><strong>Ketua Umum RKM MPP</strong></p>
              <div>
                <p className="font-bold underline text-slate-900">Drs. H. Bambang Sutrisno, M.Pd.</p>
                <p className="text-[10px] text-slate-500">NIP/ID: RKM-MPP-001</p>
              </div>
            </div>

            <div className="space-y-16">
              <p className="text-slate-600">Disetujui,<br /><strong>Penasehat / DKM Masjid</strong></p>
              <div>
                <p className="font-bold underline text-slate-900">Ust. Syihabuddin</p>
                <p className="text-[10px] text-slate-500">DKM Al-Muhajirin MPP</p>
              </div>
            </div>

            <div className="space-y-16">
              <p className="text-slate-600">Parung Panjang, {formatDateIndo(new Date().toISOString())}<br /><strong>Bendahara RKM MPP</strong></p>
              <div>
                <p className="font-bold underline text-slate-900">H. Rahmat Hidayat, S.E.</p>
                <p className="text-[10px] text-slate-500">NIP/ID: RKM-MPP-003</p>
              </div>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
