import React, { useState } from 'react';
import { 
  Users, 
  User,
  ShieldCheck, 
  Shield,
  KeyRound, 
  Lock, 
  Unlock, 
  UserPlus, 
  UserCheck, 
  UserX, 
  Search, 
  Check, 
  Trash2, 
  Edit3, 
  Clock, 
  Activity, 
  Copy, 
  Send, 
  RefreshCw, 
  Sliders, 
  ShieldAlert, 
  Info, 
  CheckCircle2, 
  AlertTriangle,
  Smartphone,
  Phone,
  Eye,
  EyeOff,
  Filter,
  Layers,
  FileCheck
} from 'lucide-react';
import { useRkm } from '../context/RkmContext';
import { UserProfile, UserRole, SystemPermission, SecurityPolicy, AccessAuditLog } from '../types';
import { formatRupiah } from '../utils/formatters';

export const AccessManagementSettings: React.FC = () => {
  const { 
    users, 
    currentUser, 
    addUser, 
    updateUser, 
    deleteUser, 
    toggleUserStatus, 
    resetUserPassword,
    permissions,
    rolePermissions,
    updateRolePermission,
    resetRolePermissions,
    securityPolicy,
    updateSecurityPolicy,
    auditLogs,
    clearAuditLogs,
    addAuditLog,
    settings,
    citizens
  } = useRkm();

  // Internal tab state
  const [accessTab, setAccessTab] = useState<'users' | 'matrix' | 'policy' | 'audit'>('users');
  
  // Search & Filter state for users
  const [searchTerm, setSearchTerm] = useState('');
  const [roleFilter, setRoleFilter] = useState<string>('all');
  
  // User Modal State
  const [showUserModal, setShowUserModal] = useState(false);
  const [editingUserId, setEditingUserId] = useState<string | null>(null);
  const [userFormData, setUserFormData] = useState<Partial<UserProfile>>({
    name: '',
    username: '',
    role: 'petugas',
    phone: '',
    email: '',
    password: '',
    title: '',
    rt: '01',
    rw: '08',
    status: 'Aktif'
  });

  // Reset PIN / Password Modal State
  const [resetModalUser, setResetModalUser] = useState<UserProfile | null>(null);
  const [newPinValue, setNewPinValue] = useState('');
  const [copiedNotification, setCopiedNotification] = useState(false);

  // Security Policy Local Form
  const [policyForm, setPolicyForm] = useState<SecurityPolicy>(securityPolicy);
  const [policySaved, setPolicySaved] = useState(false);
  const [matrixSaved, setMatrixSaved] = useState(false);

  // Role Permissions Local Matrix State
  const [localMatrix, setLocalMatrix] = useState<Record<string, UserRole[]>>(rolePermissions);

  // Filtered users
  const filteredUsers = users.filter(u => {
    const matchSearch = 
      u.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      u.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
      u.phone.includes(searchTerm) ||
      (u.email && u.email.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchRole = roleFilter === 'all' || u.role === roleFilter;
    return matchSearch && matchRole;
  });

  // Handle Open Create User Modal
  const handleOpenCreateModal = () => {
    setEditingUserId(null);
    setUserFormData({
      name: '',
      username: '',
      role: 'petugas',
      phone: '',
      email: '',
      password: Math.floor(100000 + Math.random() * 900000).toString(), // Auto generate 6 digit pin
      title: 'Petugas Lapangan & Kolektor',
      rt: '01',
      rw: '08',
      assignedBlocks: [],
      status: 'Aktif',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80'
    });
    setShowUserModal(true);
  };

  // Handle Open Edit User Modal
  const handleOpenEditModal = (u: UserProfile) => {
    setEditingUserId(u.id);
    setUserFormData({
      name: u.name,
      username: u.username,
      role: u.role,
      phone: u.phone,
      email: u.email || '',
      password: u.password || '',
      title: u.title || '',
      rt: u.rt || '01',
      rw: u.rw || '08',
      assignedBlocks: u.assignedBlocks || [],
      status: u.status || 'Aktif',
      avatar: u.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
      noKK: u.noKK || ''
    });
    setShowUserModal(true);
  };

  // Handle Save User Modal
  const handleSaveUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (!userFormData.name?.trim() || !userFormData.username?.trim()) {
      alert('Nama lengkap dan username wajib diisi!');
      return;
    }

    if (editingUserId) {
      updateUser(editingUserId, userFormData);
    } else {
      addUser(userFormData as Omit<UserProfile, 'id'>);
    }
    setShowUserModal(false);
  };

  // Handle Open Reset PIN Modal
  const handleOpenResetPin = (u: UserProfile) => {
    setResetModalUser(u);
    setNewPinValue(Math.floor(100000 + Math.random() * 900000).toString());
  };

  // Handle Confirm Reset PIN
  const handleConfirmResetPin = () => {
    if (!resetModalUser) return;
    resetUserPassword(resetModalUser.id, newPinValue);
    alert(`✓ PIN / Password akun ${resetModalUser.name} berhasil diubah menjadi: ${newPinValue}`);
    setResetModalUser(null);
  };

  // Copy WA Credential Message
  const handleCopyWaCredentials = () => {
    if (!resetModalUser) return;
    const text = `*INFORMASI KREDENSIAL AKUN RKM MPP DIGITAL*\n\n` +
      `Assalamu'alaikum Wr. Wb. Bpk/Ibu *${resetModalUser.name}*,\n` +
      `Berikut adalah informasi akses akun Anda pada Portal Paguyuban Rukun Kematian MPP:\n\n` +
      `• *Username:* ${resetModalUser.username}\n` +
      `• *Peran Akses:* ${resetModalUser.role.toUpperCase()} (${resetModalUser.title || '-'})\n` +
      `• *PIN / Password Baru:* ${newPinValue}\n` +
      `• *Status:* Aktif\n\n` +
      `Silakan login dan jaga kerahasiaan PIN akses Anda sesuai amanat AD/ART RKM MPP.\n` +
      `_Pengurus RKM MPP 2024-2027_`;
    navigator.clipboard.writeText(text);
    setCopiedNotification(true);
    setTimeout(() => setCopiedNotification(false), 3000);
  };

  // Handle Matrix Role Toggle
  const handleTogglePermission = (permissionId: string, role: UserRole) => {
    setLocalMatrix(prev => {
      const currentRoles = prev[permissionId] || [];
      const hasRole = currentRoles.includes(role);
      const newRoles = hasRole 
        ? currentRoles.filter(r => r !== role)
        : [...currentRoles, role];
      return {
        ...prev,
        [permissionId]: newRoles
      };
    });
  };

  // Save Permissions Matrix
  const handleSaveMatrix = () => {
    Object.entries(localMatrix).forEach(([permId, roles]) => {
      updateRolePermission(permId, roles);
    });
    setMatrixSaved(true);
    setTimeout(() => setMatrixSaved(false), 3000);
    addAuditLog({
      userName: currentUser?.name || 'Super Admin',
      userRole: currentUser?.role || 'bendahara',
      action: 'SECURITY_MATRIX_UPDATED',
      details: 'Matriks hak akses (RBAC) seluruh modul sistem diperbarui',
      ipAddress: '182.253.14.88 (Dashboard Admin)',
      status: 'Success'
    });
  };

  // Reset Permissions Matrix
  const handleResetMatrix = () => {
    if (confirm('Kembalikan seluruh hak akses ke standar baku AD/ART RKM MPP 2024-2027?')) {
      resetRolePermissions();
      const initialMap: Record<string, UserRole[]> = {};
      permissions.forEach(p => {
        initialMap[p.id] = p.defaultRoles;
      });
      setLocalMatrix(initialMap);
      setMatrixSaved(true);
      setTimeout(() => setMatrixSaved(false), 3000);
    }
  };

  // Save Security Policy
  const handleSavePolicy = (e: React.FormEvent) => {
    e.preventDefault();
    updateSecurityPolicy(policyForm);
    setPolicySaved(true);
    setTimeout(() => setPolicySaved(false), 3000);
    addAuditLog({
      userName: currentUser?.name || 'Super Admin',
      userRole: currentUser?.role || 'bendahara',
      action: 'SECURITY_POLICY_SAVED',
      details: `Kebijakan sesi diubah: Timeout ${policyForm.sessionTimeoutHours} jam, Login No KK: ${policyForm.allowCitizenNoKkLogin ? 'Aktif' : 'Nonaktif'}`,
      ipAddress: '182.253.14.88 (Dashboard Admin)',
      status: 'Success'
    });
  };

  // Categories of permissions
  const categories = Array.from(new Set(permissions.map(p => p.category)));

  // Role Badge Styling Helper
  const getRoleBadge = (role: UserRole) => {
    switch (role) {
      case 'superadmin':
        return <span className="px-2.5 py-1 rounded-full text-[10px] font-extrabold bg-purple-100 text-purple-900 border border-purple-300 inline-flex items-center gap-1"><ShieldCheck className="w-3 h-3 text-purple-700" /> Super Admin</span>;
      case 'bendahara':
        return <span className="px-2.5 py-1 rounded-full text-[10px] font-extrabold bg-amber-100 text-amber-900 border border-amber-300 inline-flex items-center gap-1"><ShieldCheck className="w-3 h-3 text-amber-700" /> Bendahara / Admin</span>;
      case 'ketua':
        return <span className="px-2.5 py-1 rounded-full text-[10px] font-extrabold bg-blue-100 text-blue-900 border border-blue-300 inline-flex items-center gap-1"><Shield className="w-3 h-3 text-blue-700" /> Ketua Paguyuban</span>;
      case 'petugas':
        return <span className="px-2.5 py-1 rounded-full text-[10px] font-extrabold bg-emerald-100 text-emerald-900 border border-emerald-300 inline-flex items-center gap-1"><UserCheck className="w-3 h-3 text-emerald-700" /> Petugas / Satgas</span>;
      case 'koordinator':
        return <span className="px-2.5 py-1 rounded-full text-[10px] font-extrabold bg-teal-100 text-teal-900 border border-teal-300 inline-flex items-center gap-1"><UserCheck className="w-3 h-3 text-teal-700" /> Koordinator Blok</span>;
      case 'tim_jenazah':
        return <span className="px-2.5 py-1 rounded-full text-[10px] font-extrabold bg-indigo-100 text-indigo-900 border border-indigo-300 inline-flex items-center gap-1"><UserCheck className="w-3 h-3 text-indigo-700" /> Tim Jenazah</span>;
      case 'warga':
        return <span className="px-2.5 py-1 rounded-full text-[10px] font-extrabold bg-slate-100 text-slate-800 border border-slate-300 inline-flex items-center gap-1"><Users className="w-3 h-3 text-slate-600" /> Warga Anggota</span>;
      default:
        return <span className="px-2.5 py-1 rounded-full text-[10px] font-extrabold bg-slate-100 text-slate-700 border border-slate-300">{role}</span>;
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      
      {/* Top Banner & Overview Card */}
      <div className="bg-gradient-to-br from-slate-900 via-emerald-950 to-teal-950 text-white rounded-3xl p-6 shadow-xl relative overflow-hidden border border-emerald-800/40">
        <div className="absolute top-0 right-0 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 text-xs font-bold">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              Sistem Otentikasi & Keamanan Terpadu
            </div>
            <h2 className="text-xl md:text-2xl font-black text-white tracking-tight">
              Pengaturan Akun Pengguna & Hak Akses (RBAC)
            </h2>
            <p className="text-emerald-100/80 text-xs md:text-sm max-w-2xl leading-relaxed">
              Manajemen akun pengurus, koordinator RT, satgas pemulasaraan jenazah, dan warga sesuai mandat <strong className="text-emerald-300 font-semibold">AD/ART RKM MPP Periode 2024–2027</strong>.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5 shrink-0">
            <button
              onClick={handleOpenCreateModal}
              className="flex items-center gap-2 px-4 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-emerald-950 font-black text-xs rounded-2xl shadow-lg hover:shadow-emerald-500/25 transition-all active:scale-95"
            >
              <UserPlus className="w-4 h-4 text-emerald-950" />
              <span>+ Tambah Akun Baru</span>
            </button>
          </div>
        </div>

        {/* Quick Stat Counters */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6 pt-6 border-t border-white/10 text-xs">
          <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-3.5 border border-white/10">
            <span className="text-emerald-200/70 text-[11px] block font-medium">Total Akun Terdaftar</span>
            <div className="text-xl font-black text-white mt-0.5">{users.length} Akun</div>
            <span className="text-[10px] text-emerald-400 mt-1 block">Semua Peran Sistem</span>
          </div>
          <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-3.5 border border-white/10">
            <span className="text-emerald-200/70 text-[11px] block font-medium">Akun Aktif Siaga</span>
            <div className="text-xl font-black text-emerald-300 mt-0.5">{users.filter(u => u.status !== 'Terkunci').length} Aktif</div>
            <span className="text-[10px] text-emerald-400 mt-1 block">Akses Normal</span>
          </div>
          <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-3.5 border border-white/10">
            <span className="text-emerald-200/70 text-[11px] block font-medium">Izin Akses Terkatalog</span>
            <div className="text-xl font-black text-amber-300 mt-0.5">{permissions.length} Modul</div>
            <span className="text-[10px] text-amber-300/80 mt-1 block">5 Kategori Operasional</span>
          </div>
          <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-3.5 border border-white/10">
            <span className="text-emerald-200/70 text-[11px] block font-medium">Audit Trail Tercatat</span>
            <div className="text-xl font-black text-cyan-300 mt-0.5">{auditLogs.length} Aktivitas</div>
            <span className="text-[10px] text-cyan-300/80 mt-1 block">Keamanan Real-Time</span>
          </div>
        </div>
      </div>

      {/* Access Inner Navigation Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2 overflow-x-auto no-scrollbar">
        {[
          { id: 'users', label: 'Daftar Akun Pengguna', icon: Users, count: users.length },
          { id: 'matrix', label: 'Matriks Hak Akses (RBAC)', icon: Layers, count: permissions.length },
          { id: 'policy', label: 'Kebijakan Keamanan & Sesi', icon: KeyRound },
          { id: 'audit', label: 'Audit Log & Riwayat Akses', icon: Activity, count: auditLogs.length }
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = accessTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setAccessTab(tab.id as any)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs font-black transition-all whitespace-nowrap ${
                isActive 
                  ? 'bg-emerald-700 text-white shadow-md' 
                  : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200/80'
              }`}
            >
              <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-400'}`} />
              <span>{tab.label}</span>
              {tab.count !== undefined && (
                <span className={`px-2 py-0.5 rounded-full text-[10px] font-extrabold ${
                  isActive ? 'bg-emerald-900/60 text-emerald-200' : 'bg-slate-100 text-slate-600'
                }`}>
                  {tab.count}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* TAB 1: DAFTAR AKUN PENGGUNA */}
      {accessTab === 'users' && (
        <div className="space-y-4">
          
          {/* Filter & Search Bar */}
          <div className="bg-white p-4 rounded-3xl border border-slate-200/80 shadow-sm flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="relative w-full sm:w-80">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Cari nama, username (@admin), HP..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-9.5 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white"
              />
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto overflow-x-auto no-scrollbar">
              <span className="text-[11px] font-bold text-slate-400 shrink-0 flex items-center gap-1">
                <Filter className="w-3.5 h-3.5" /> Peran:
              </span>
              {[
                { id: 'all', label: 'Semua' },
                { id: 'superadmin', label: 'Super Admin' },
                { id: 'bendahara', label: 'Bendahara' },
                { id: 'ketua', label: 'Ketua' },
                { id: 'petugas', label: 'Petugas/Satgas' },
                { id: 'warga', label: 'Warga' }
              ].map(f => (
                <button
                  key={f.id}
                  onClick={() => setRoleFilter(f.id)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold shrink-0 transition-all ${
                    roleFilter === f.id
                      ? 'bg-emerald-600 text-white'
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>
          </div>

          {/* User Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredUsers.map((u) => {
              const isLocked = u.status === 'Terkunci';
              const isCurrentLoggedIn = currentUser?.id === u.id;

              return (
                <div 
                  key={u.id}
                  className={`bg-white rounded-3xl p-5 border transition-all relative flex flex-col justify-between shadow-sm hover:shadow-md ${
                    isLocked ? 'border-rose-300 bg-rose-50/20' : 'border-slate-200/80 hover:border-emerald-300'
                  }`}
                >
                  {/* Top Status & Role */}
                  <div>
                    <div className="flex items-start justify-between gap-2 mb-3">
                      <div className="flex items-center gap-3">
                        <div className="relative">
                          <div className={`w-12 h-12 rounded-2xl flex items-center justify-center font-black text-sm shadow-sm border-2 border-slate-100 ${
                            u.role === 'superadmin' ? 'bg-purple-700 text-white' :
                            u.role === 'bendahara' ? 'bg-amber-600 text-white' :
                            u.role === 'ketua' ? 'bg-blue-600 text-white' :
                            u.role === 'tim_jenazah' ? 'bg-indigo-600 text-white' :
                            u.role === 'koordinator' ? 'bg-teal-600 text-white' :
                            u.role === 'petugas' ? 'bg-emerald-600 text-white' :
                            'bg-slate-700 text-white'
                          }`}>
                            {u.role === 'superadmin' ? (
                              <ShieldCheck className="w-6 h-6" />
                            ) : (
                              <User className="w-6 h-6" />
                            )}
                          </div>
                          {isLocked && (
                            <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-rose-600 text-white rounded-full flex items-center justify-center border-2 border-white shadow">
                              <Lock className="w-2.5 h-2.5" />
                            </div>
                          )}
                        </div>
                        <div>
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <h3 className="font-black text-sm text-slate-900 leading-tight">{u.name}</h3>
                            {isCurrentLoggedIn && (
                              <span className="px-2 py-0.5 rounded-full text-[9px] font-black bg-emerald-600 text-white">Anda</span>
                            )}
                          </div>
                          <span className="text-xs font-mono font-bold text-emerald-700 block mt-0.5">@{u.username}</span>
                        </div>
                      </div>

                      {/* Status Pill */}
                      <button
                        onClick={() => toggleUserStatus(u.id)}
                        title={isLocked ? 'Klik untuk aktifkan akun' : 'Klik untuk kunci akun sementara'}
                        className={`px-2.5 py-1 rounded-full text-[10px] font-black flex items-center gap-1 shrink-0 transition-all ${
                          isLocked 
                            ? 'bg-rose-100 text-rose-800 border border-rose-300 hover:bg-rose-200' 
                            : 'bg-emerald-100 text-emerald-800 border border-emerald-300 hover:bg-emerald-200'
                        }`}
                      >
                        {isLocked ? <Lock className="w-3 h-3 text-rose-700" /> : <Unlock className="w-3 h-3 text-emerald-700" />}
                        {u.status || 'Aktif'}
                      </button>
                    </div>

                    {/* Role & Title */}
                    <div className="space-y-1.5 mb-4">
                      <div>{getRoleBadge(u.role)}</div>
                      <p className="text-xs text-slate-600 font-medium line-clamp-1">{u.title || 'Petugas RKM'}</p>
                    </div>

                    {/* Details Info List */}
                    <div className="space-y-1.5 text-xs text-slate-600 bg-slate-50/80 p-3 rounded-2xl border border-slate-100 mb-4">
                      <div className="flex items-center justify-between">
                        <span className="text-slate-400 font-medium">No. WhatsApp:</span>
                        <a 
                          href={`https://wa.me/${u.phone.replace(/\D/g, '')}`} 
                          target="_blank" 
                          rel="noreferrer"
                          className="font-bold text-emerald-700 hover:underline flex items-center gap-1"
                        >
                          <Phone className="w-3 h-3 text-emerald-600" />
                          {u.phone}
                        </a>
                      </div>
                      {u.email && (
                        <div className="flex items-center justify-between">
                          <span className="text-slate-400 font-medium">Email:</span>
                          <span className="font-bold text-slate-700">{u.email}</span>
                        </div>
                      )}
                      <div className="flex items-center justify-between">
                        <span className="text-slate-400 font-medium">Wilayah Binaan:</span>
                        <span className="font-extrabold text-slate-800">RT {u.rt || '01'} / RW {u.rw || '08'}</span>
                      </div>
                      {u.role === 'koordinator' && (
                        <>
                          <div className="pt-1.5 border-t border-slate-200/60">
                            <span className="text-slate-400 font-medium block mb-1">Blok Binaan:</span>
                            <div className="flex flex-wrap gap-1">
                              {(u.assignedBlocks && u.assignedBlocks.length > 0) ? (
                                u.assignedBlocks.map(blk => (
                                  <span key={blk} className="px-1.5 py-0.5 bg-teal-100 text-teal-900 rounded-md font-extrabold text-[10px]">
                                    {blk}
                                  </span>
                                ))
                              ) : (
                                <span className="text-[11px] text-amber-600 italic">Belum ada blok yang diplot</span>
                              )}
                            </div>
                          </div>
                          <div className="flex items-center justify-between pt-1 border-t border-slate-200/60 text-[11px]">
                            <span className="text-teal-700 font-bold">Anggota Downline:</span>
                            <span className="px-2 py-0.5 bg-teal-600 text-white rounded-full font-black text-[10px]">
                              {citizens.filter(c => c.assignedCollectorId === u.id || (u.assignedBlocks && u.assignedBlocks.includes(c.block))).length} KK
                            </span>
                          </div>
                        </>
                      )}
                      <div className="flex items-center justify-between pt-1 border-t border-slate-200/60 text-[11px]">
                        <span className="text-slate-400">Login Terakhir:</span>
                        <span className="font-semibold text-slate-700">{u.lastLogin || 'Belum pernah login'}</span>
                      </div>
                    </div>
                  </div>

                  {/* Actions Buttons */}
                  <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-1.5">
                    <button
                      onClick={() => handleOpenResetPin(u)}
                      className="flex-1 py-1.5 px-2 bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-200 rounded-xl text-xs font-bold flex items-center justify-center gap-1 transition-all"
                    >
                      <KeyRound className="w-3.5 h-3.5 text-amber-700" />
                      <span>Reset PIN</span>
                    </button>

                    <button
                      onClick={() => handleOpenEditModal(u)}
                      className="p-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl transition-all"
                      title="Edit Akun"
                    >
                      <Edit3 className="w-4 h-4" />
                    </button>

                    <button
                      onClick={() => {
                        if (users.length <= 1) {
                          alert('Minimal harus ada 1 akun admin tersisa dalam sistem!');
                          return;
                        }
                        if (confirm(`Apakah Anda yakin ingin menghapus akun ${u.name} (@${u.username})?`)) {
                          deleteUser(u.id);
                        }
                      }}
                      className="p-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 rounded-xl transition-all"
                      title="Hapus Akun"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

          {filteredUsers.length === 0 && (
            <div className="bg-white rounded-3xl p-12 text-center border border-slate-200">
              <Users className="w-12 h-12 text-slate-300 mx-auto mb-3" />
              <h4 className="font-black text-slate-800 text-base">Tidak ada akun yang sesuai</h4>
              <p className="text-xs text-slate-500 mt-1">Coba sesuaikan kata kunci pencarian atau filter peran.</p>
            </div>
          )}
        </div>
      )}

      {/* TAB 2: MATRIKS HAK AKSES (RBAC) */}
      {accessTab === 'matrix' && (
        <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-sm space-y-6">
          
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
            <div>
              <h3 className="font-black text-slate-900 text-lg flex items-center gap-2">
                <Layers className="w-5 h-5 text-emerald-600" />
                Matriks Hak Akses Berdasarkan Peran (Role-Based Access Control)
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Konfigurasikan kewenangan operasional setiap peran secara fleksibel dan transparan.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleResetMatrix}
                className="px-3.5 py-2 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100 border border-slate-200 transition-all flex items-center gap-1.5"
              >
                <RefreshCw className="w-3.5 h-3.5 text-slate-400" />
                <span>Reset ke AD/ART</span>
              </button>

              <button
                onClick={handleSaveMatrix}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-black shadow-md transition-all flex items-center gap-1.5"
              >
                <Check className="w-4 h-4" />
                <span>{matrixSaved ? '✓ Tersimpan!' : 'Simpan Matriks'}</span>
              </button>
            </div>
          </div>

          {/* RBAC Table */}
          <div className="space-y-6">
            {categories.map((cat) => {
              const catPermissions = permissions.filter(p => p.category === cat);
              return (
                <div key={cat} className="space-y-2.5">
                  <div className="flex items-center gap-2 px-3 py-1.5 bg-emerald-50 text-emerald-950 font-black text-xs rounded-xl border border-emerald-100">
                    <FileCheck className="w-4 h-4 text-emerald-700" />
                    <span>Modul: {cat}</span>
                    <span className="text-[10px] text-emerald-700 font-semibold ml-auto">({catPermissions.length} Izin)</span>
                  </div>

                  <div className="overflow-x-auto rounded-2xl border border-slate-200">
                    <table className="w-full text-left text-xs border-collapse">
                      <thead>
                        <tr className="bg-slate-100/80 text-slate-700 font-extrabold border-b border-slate-200">
                          <th className="p-3.5 pl-4 w-1/3 min-w-[220px]">Fungsi & Hak Akses</th>
                          <th className="p-3.5 text-center text-purple-900 bg-purple-50/70 border-x border-purple-100 min-w-[120px]">Super Admin (DKM/IT)</th>
                          <th className="p-3.5 text-center text-amber-900 bg-amber-50/50 min-w-[110px]">Bendahara (Admin)</th>
                          <th className="p-3.5 text-center text-blue-900 bg-blue-50/50 min-w-[110px]">Ketua Umum</th>
                          <th className="p-3.5 text-center text-emerald-900 bg-emerald-50/50 min-w-[110px]">Petugas / Satgas</th>
                          <th className="p-3.5 text-center text-slate-800 bg-slate-50 min-w-[100px]">Warga Anggota</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 font-medium">
                        {catPermissions.map((perm) => {
                          const assignedRoles = localMatrix[perm.id] || [];
                          return (
                            <tr key={perm.id} className="hover:bg-slate-50/80 transition-colors">
                              <td className="p-3.5 pl-4">
                                <div className="font-black text-slate-900">{perm.label}</div>
                                <div className="text-[11px] text-slate-500 font-normal mt-0.5 leading-snug">{perm.description}</div>
                              </td>
                              
                              {/* Super Admin */}
                              <td className="p-3.5 text-center bg-purple-50/30 border-x border-purple-100/60">
                                <input
                                  type="checkbox"
                                  checked={assignedRoles.includes('superadmin')}
                                  onChange={() => handleTogglePermission(perm.id, 'superadmin')}
                                  className="w-4 h-4 rounded text-purple-600 focus:ring-purple-500 cursor-pointer accent-purple-600"
                                />
                              </td>

                              {/* Bendahara */}
                              <td className="p-3.5 text-center bg-amber-50/20">
                                <input
                                  type="checkbox"
                                  checked={assignedRoles.includes('bendahara')}
                                  onChange={() => handleTogglePermission(perm.id, 'bendahara')}
                                  className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500 cursor-pointer accent-emerald-600"
                                />
                              </td>

                              {/* Ketua */}
                              <td className="p-3.5 text-center bg-blue-50/20">
                                <input
                                  type="checkbox"
                                  checked={assignedRoles.includes('ketua')}
                                  onChange={() => handleTogglePermission(perm.id, 'ketua')}
                                  className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500 cursor-pointer accent-emerald-600"
                                />
                              </td>

                              {/* Petugas */}
                              <td className="p-3.5 text-center bg-emerald-50/20">
                                <input
                                  type="checkbox"
                                  checked={assignedRoles.includes('petugas')}
                                  onChange={() => handleTogglePermission(perm.id, 'petugas')}
                                  className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500 cursor-pointer accent-emerald-600"
                                />
                              </td>

                              {/* Warga */}
                              <td className="p-3.5 text-center bg-slate-50/50">
                                <input
                                  type="checkbox"
                                  checked={assignedRoles.includes('warga')}
                                  onChange={() => handleTogglePermission(perm.id, 'warga')}
                                  className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500 cursor-pointer accent-emerald-600"
                                />
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Legal notes */}
          <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-200 text-xs text-emerald-950 space-y-1">
            <div className="font-extrabold flex items-center gap-1.5 text-emerald-900">
              <Info className="w-4 h-4 text-emerald-700" />
              Catatan Landasan AD/ART RKM MPP (Pasal Hak & Kewenangan Pengurus):
            </div>
            <p className="text-[11px] text-emerald-800 leading-relaxed">
              • <strong>Super Admin (DKM / Dewan Pembina / IT Master):</strong> Memiliki kewenangan penuh mencakup seluruh modul, konfigurasi keamanan, manajemen akun, dan audit trail.<br/>
              • <strong>Bendahara & Sekretaris:</strong> Bertanggung jawab penuh terhadap integritas buku kas, pencatatan mutasi, dan penyimpanan database warga.<br/>
              • <strong>Ketua Paguyuban:</strong> Memegang hak persetujuan pencairan santunan duka dan pengawasan transparansi laporan periodik.<br/>
              • <strong>Petugas / Satgas:</strong> Diberi wewenang penerbitan kuitansi iuran warga, mobilisasi mobil jenazah, pemulasaraan, dan logistik takziah.
            </p>
          </div>
        </div>
      )}

      {/* TAB 3: KEBIJAKAN KEAMANAN & SESI */}
      {accessTab === 'policy' && (
        <form onSubmit={handleSavePolicy} className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-sm space-y-6">
          <div className="flex items-center justify-between pb-4 border-b border-slate-100">
            <div>
              <h3 className="font-black text-slate-900 text-lg flex items-center gap-2">
                <Sliders className="w-5 h-5 text-emerald-600" />
                Kebijakan Sesi & Keamanan Portal
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Konfigurasi durasi login, proteksi brute-force, dan otentikasi cepat nomor KK warga.
              </p>
            </div>

            <button
              type="submit"
              className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-black shadow-md transition-all flex items-center gap-1.5"
            >
              <Check className="w-4 h-4" />
              <span>{policySaved ? '✓ Tersimpan!' : 'Simpan Kebijakan'}</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            {/* Session Timeout */}
            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
              <label className="block text-xs font-black text-slate-800">
                Durasi Masa Aktif Sesi Login (Session Timeout)
              </label>
              <p className="text-[11px] text-slate-500">
                Sesi pengurus akan otomatis kedaluwarsa setelah durasi waktu ini tidak ada aktivitas.
              </p>
              <select
                value={policyForm.sessionTimeoutHours}
                onChange={(e) => setPolicyForm({ ...policyForm, sessionTimeoutHours: Number(e.target.value) })}
                className="w-full p-2.5 bg-white border border-slate-300 rounded-xl text-xs font-bold text-slate-800 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              >
                <option value={6}>6 Jam (Keamanan Tinggi)</option>
                <option value={12}>12 Jam (Rekomendasi Kantor)</option>
                <option value={24}>24 Jam (Standar Operasional)</option>
                <option value={168}>7 Hari (Perangkat Terpercaya)</option>
              </select>
            </div>

            {/* Citizen Fast Login */}
            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 flex items-start justify-between gap-4">
              <div>
                <label className="block text-xs font-black text-slate-800">
                  Otentikasi Cepat Warga via Nomor KK / NIK
                </label>
                <p className="text-[11px] text-slate-500 mt-1 leading-snug">
                  Memungkinkan warga membuka portal transparansi dan KTA digital cukup dengan memasukkan 16 digit No. KK resmi.
                </p>
              </div>
              <input
                type="checkbox"
                checked={policyForm.allowCitizenNoKkLogin}
                onChange={(e) => setPolicyForm({ ...policyForm, allowCitizenNoKkLogin: e.target.checked })}
                className="w-5 h-5 rounded text-emerald-600 focus:ring-emerald-500 cursor-pointer accent-emerald-600 mt-1"
              />
            </div>

            {/* Auto Lock Failed Attempts */}
            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
              <label className="block text-xs font-black text-slate-800">
                Batas Toleransi Kesalahan PIN / Password
              </label>
              <p className="text-[11px] text-slate-500">
                Otomatis kunci akun sementara jika terjadi percobaan login gagal berulang kali.
              </p>
              <select
                value={policyForm.autoLockFailedAttempts}
                onChange={(e) => setPolicyForm({ ...policyForm, autoLockFailedAttempts: Number(e.target.value) })}
                className="w-full p-2.5 bg-white border border-slate-300 rounded-xl text-xs font-bold text-slate-800 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              >
                <option value={3}>3 Kali Percobaan (Ketat)</option>
                <option value={5}>5 Kali Percobaan (Standar)</option>
                <option value={10}>10 Kali Percobaan (Longgar)</option>
              </select>
            </div>

            {/* Audit Logging Active */}
            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 flex items-start justify-between gap-4">
              <div>
                <label className="block text-xs font-black text-slate-800">
                  Pencatatan Audit Trail Aktivitas Real-Time
                </label>
                <p className="text-[11px] text-slate-500 mt-1 leading-snug">
                  Merekam setiap aktivitas login, input iuran, mutasi kas, dan reset password demi kepatuhan pertanggungjawaban AD/ART.
                </p>
              </div>
              <input
                type="checkbox"
                checked={policyForm.enableAuditLogging}
                onChange={(e) => setPolicyForm({ ...policyForm, enableAuditLogging: e.target.checked })}
                className="w-5 h-5 rounded text-emerald-600 focus:ring-emerald-500 cursor-pointer accent-emerald-600 mt-1"
              />
            </div>

          </div>
        </form>
      )}

      {/* TAB 4: AUDIT LOG & RIWAYAT AKSES */}
      {accessTab === 'audit' && (
        <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-sm space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
            <div>
              <h3 className="font-black text-slate-900 text-lg flex items-center gap-2">
                <Activity className="w-5 h-5 text-emerald-600" />
                Riwayat Audit & Aktivitas Keamanan Sistem
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Log kronologis aktivitas otentikasi dan perubahan data penting dalam portal RKM MPP.
              </p>
            </div>

            <button
              onClick={() => {
                if (confirm('Bersihkan seluruh riwayat audit log sistem?')) {
                  clearAuditLogs();
                }
              }}
              className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition-all"
            >
              Bersihkan Log
            </button>
          </div>

          {/* Audit Logs Table */}
          <div className="overflow-x-auto rounded-2xl border border-slate-200">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-100/80 text-slate-700 font-extrabold border-b border-slate-200">
                  <th className="p-3 pl-4">Waktu (WIB)</th>
                  <th className="p-3">Pengguna</th>
                  <th className="p-3">Aksi Sistem</th>
                  <th className="p-3">Rincian Aktivitas</th>
                  <th className="p-3">Perangkat / IP</th>
                  <th className="p-3 text-center">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-medium">
                {auditLogs.map((log) => (
                  <tr key={log.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="p-3 pl-4 whitespace-nowrap text-slate-500 font-mono text-[11px]">
                      {log.timestamp}
                    </td>
                    <td className="p-3 whitespace-nowrap">
                      <span className="font-bold text-slate-900 block">{log.userName}</span>
                      <span className="text-[10px] text-slate-400 capitalize">{log.userRole}</span>
                    </td>
                    <td className="p-3 whitespace-nowrap">
                      <span className="px-2 py-0.5 rounded-lg bg-slate-100 text-slate-700 font-mono font-bold text-[10px]">
                        {log.action}
                      </span>
                    </td>
                    <td className="p-3 text-slate-700 text-[11px] max-w-xs sm:max-w-md">
                      {log.details}
                    </td>
                    <td className="p-3 whitespace-nowrap text-slate-500 text-[11px]">
                      {log.ipAddress}
                    </td>
                    <td className="p-3 text-center whitespace-nowrap">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-black ${
                        log.status === 'Success' 
                          ? 'bg-emerald-100 text-emerald-800' 
                          : log.status === 'Warning' 
                            ? 'bg-amber-100 text-amber-800' 
                            : 'bg-rose-100 text-rose-800'
                      }`}>
                        {log.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {auditLogs.length === 0 && (
            <div className="p-8 text-center text-slate-400 text-xs font-semibold">
              Belum ada catatan aktivitas audit baru.
            </div>
          )}
        </div>
      )}

      {/* MODAL: TAMBAH / EDIT AKUN */}
      {showUserModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 animate-scale-up space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="font-black text-base text-slate-900 flex items-center gap-2">
                <UserCheck className="w-5 h-5 text-emerald-600" />
                {editingUserId ? 'Edit Akun Pengguna' : 'Tambah Akun Pengguna Baru'}
              </h3>
              <button 
                onClick={() => setShowUserModal(false)}
                className="w-8 h-8 rounded-full bg-slate-100 text-slate-500 hover:bg-slate-200 flex items-center justify-center font-bold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveUser} className="space-y-4 text-xs">
              
              <div className="space-y-1">
                <label className="font-bold text-slate-700">Nama Lengkap & Gelar *</label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: H. Rahmat Hidayat, S.E."
                  value={userFormData.name || ''}
                  onChange={(e) => setUserFormData({ ...userFormData, name: e.target.value })}
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-semibold text-slate-800 focus:ring-2 focus:ring-emerald-500 focus:bg-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Username Login *</label>
                  <input
                    type="text"
                    required
                    placeholder="Contoh: asep_satgas"
                    value={userFormData.username || ''}
                    onChange={(e) => setUserFormData({ ...userFormData, username: e.target.value.toLowerCase().replace(/\s+/g, '') })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-mono font-bold text-emerald-800 focus:ring-2 focus:ring-emerald-500 focus:bg-white"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Peran Sistem (Role) *</label>
                  <select
                    value={userFormData.role || 'petugas'}
                    onChange={(e) => setUserFormData({ ...userFormData, role: e.target.value as UserRole })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-bold text-slate-800 focus:ring-2 focus:ring-emerald-500 focus:bg-white"
                  >
                    <option value="superadmin">Super Admin (DKM & Dewan Penasehat)</option>
                    <option value="bendahara">Bendahara (Admin Keuangan)</option>
                    <option value="ketua">Ketua Paguyuban</option>
                    <option value="petugas">Petugas Lapangan / Satgas</option>
                    <option value="koordinator">Koordinator Wilayah / Blok</option>
                    <option value="tim_jenazah">Tim Fardhu Kifayah / Jenazah</option>
                    <option value="warga">Warga Anggota</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Nomor WhatsApp *</label>
                  <input
                    type="text"
                    required
                    placeholder="081234567890"
                    value={userFormData.phone || ''}
                    onChange={(e) => setUserFormData({ ...userFormData, phone: e.target.value })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-semibold text-slate-800 focus:ring-2 focus:ring-emerald-500 focus:bg-white"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Email (Opsional)</label>
                  <input
                    type="email"
                    placeholder="pengurus@rkm-mpp.org"
                    value={userFormData.email || ''}
                    onChange={(e) => setUserFormData({ ...userFormData, email: e.target.value })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-semibold text-slate-800 focus:ring-2 focus:ring-emerald-500 focus:bg-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div className="col-span-2 space-y-1">
                  <label className="font-bold text-slate-700">Jabatan / Deskripsi Tugas</label>
                  <input
                    type="text"
                    placeholder="Contoh: Koordinator Penagihan RT 01-03"
                    value={userFormData.title || ''}
                    onChange={(e) => setUserFormData({ ...userFormData, title: e.target.value })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-semibold text-slate-800 focus:ring-2 focus:ring-emerald-500 focus:bg-white"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-700">RT Wilayah</label>
                  <select
                    value={userFormData.rt || '01'}
                    onChange={(e) => setUserFormData({ ...userFormData, rt: e.target.value })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-bold text-slate-800 focus:ring-2 focus:ring-emerald-500 focus:bg-white"
                  >
                    {['01', '02', '03', '04', '05', '06', '07', '08'].map(rt => (
                      <option key={rt} value={rt}>RT {rt}</option>
                    ))}
                  </select>
                </div>
              </div>

              {userFormData.role === 'koordinator' && (
                <div className="p-3 bg-teal-50/70 border border-teal-200 rounded-2xl space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="font-extrabold text-teal-900 text-xs">
                      Plotting Blok Binaan Koordinator (Downline Mandiri)
                    </label>
                    <span className="text-[10px] text-teal-700 font-bold">
                      {userFormData.assignedBlocks?.length || 0} Blok Terpilih
                    </span>
                  </div>
                  <p className="text-[11px] text-teal-700">
                    Koordinator hanya dapat mengakses & mencatat iuran warga pada blok yang dicentang berikut:
                  </p>
                  <div className="flex flex-wrap gap-1.5 pt-1 max-h-32 overflow-y-auto">
                    {(settings.blockList || ['Blok A', 'Blok B', 'Blok C', 'Blok D', 'Blok E', 'Blok F', 'Blok G', 'Blok H', 'Blok I', 'Blok J', 'Blok K', 'Blok L', 'Blok M', 'Blok N']).map(block => {
                      const isSelected = userFormData.assignedBlocks?.includes(block);
                      return (
                        <button
                          key={block}
                          type="button"
                          onClick={() => {
                            const current = userFormData.assignedBlocks || [];
                            const updated = isSelected 
                              ? current.filter(b => b !== block)
                              : [...current, block];
                            setUserFormData({ ...userFormData, assignedBlocks: updated });
                          }}
                          className={`px-2.5 py-1 rounded-xl text-xs font-bold transition-all ${
                            isSelected
                              ? 'bg-teal-600 text-white shadow-xs'
                              : 'bg-white border border-teal-200 text-teal-900 hover:bg-teal-100'
                          }`}
                        >
                          {isSelected ? `✓ ${block}` : block}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-slate-700">PIN / Password Akses *</label>
                  <input
                    type="text"
                    required
                    placeholder="6 digit PIN atau sandi"
                    value={userFormData.password || ''}
                    onChange={(e) => setUserFormData({ ...userFormData, password: e.target.value })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-mono font-bold text-slate-800 focus:ring-2 focus:ring-emerald-500 focus:bg-white"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Status Akun</label>
                  <select
                    value={userFormData.status || 'Aktif'}
                    onChange={(e) => setUserFormData({ ...userFormData, status: e.target.value as any })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-bold text-slate-800 focus:ring-2 focus:ring-emerald-500 focus:bg-white"
                  >
                    <option value="Aktif">Aktif (Bisa Login)</option>
                    <option value="Terkunci">Terkunci (Blokir Akses)</option>
                  </select>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowUserModal(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-black rounded-xl shadow-md"
                >
                  {editingUserId ? 'Simpan Perubahan' : 'Daftarkan Akun'}
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

      {/* MODAL: RESET PIN & SHARE KE WHATSAPP */}
      {resetModalUser && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200 animate-scale-up space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="font-black text-base text-slate-900 flex items-center gap-2">
                <KeyRound className="w-5 h-5 text-amber-600" />
                Reset PIN Akun Pengguna
              </h3>
              <button 
                onClick={() => setResetModalUser(null)}
                className="w-8 h-8 rounded-full bg-slate-100 text-slate-500 hover:bg-slate-200 flex items-center justify-center font-bold"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200">
                <span className="text-slate-400 block text-[11px]">Akun yang akan direset:</span>
                <span className="font-black text-slate-900 text-sm block mt-0.5">{resetModalUser.name}</span>
                <span className="font-mono text-emerald-700 font-bold">@{resetModalUser.username} ({resetModalUser.role})</span>
              </div>

              <div className="space-y-1">
                <label className="font-bold text-slate-700">PIN / Password Baru:</label>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={newPinValue}
                    onChange={(e) => setNewPinValue(e.target.value)}
                    className="flex-1 p-3 bg-white border-2 border-amber-300 rounded-xl font-mono text-center text-lg font-black tracking-widest text-slate-900 focus:ring-2 focus:ring-amber-500"
                  />
                  <button
                    type="button"
                    onClick={() => setNewPinValue(Math.floor(100000 + Math.random() * 900000).toString())}
                    className="p-3 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold"
                    title="Acak PIN Baru"
                  >
                    <RefreshCw className="w-5 h-5" />
                  </button>
                </div>
              </div>

              {/* WhatsApp Share Box */}
              <div className="p-3.5 bg-emerald-50 rounded-2xl border border-emerald-200 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-extrabold text-emerald-950 text-[11px] flex items-center gap-1.5">
                    <Smartphone className="w-3.5 h-3.5 text-emerald-700" />
                    Kirim Kredensial ke WhatsApp Pengurus:
                  </span>
                </div>
                <p className="text-[11px] text-emerald-800">
                  Salin teks format resmi untuk dikirimkan langsung ke nomor WA: <strong>{resetModalUser.phone}</strong>
                </p>
                <button
                  type="button"
                  onClick={handleCopyWaCredentials}
                  className="w-full py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl flex items-center justify-center gap-2 shadow-sm transition-all"
                >
                  <Copy className="w-4 h-4" />
                  <span>{copiedNotification ? '✓ Teks Kredensial Tersalin!' : 'Salin Pesan WhatsApp'}</span>
                </button>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setResetModalUser(null)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="button"
                  onClick={handleConfirmResetPin}
                  className="px-5 py-2 bg-amber-600 hover:bg-amber-700 text-white font-black rounded-xl shadow-md"
                >
                  Konfirmasi Simpan PIN
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
