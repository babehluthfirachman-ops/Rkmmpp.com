import React, { useState } from 'react';
import { X, Printer, Download, QrCode, ShieldCheck, Users, Calendar, MapPin, Phone } from 'lucide-react';
import { useRkm } from '../context/RkmContext';
import { formatDateIndo, getDirectImageUrl } from '../utils/formatters';

export const KtaCardModal: React.FC = () => {
  const { selectedKtaCitizen, closeKtaModal, settings } = useRkm();
  const [side, setSide] = useState<'front' | 'back'>('front');

  if (!selectedKtaCitizen) return null;

  const citizen = selectedKtaCitizen;
  const activeMembersCount = citizen.members.filter(m => m.status === 'Hidup').length;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-sm animate-fade-in overflow-y-auto">
      <div className="relative w-full max-w-lg bg-white rounded-2xl shadow-2xl border border-slate-100 overflow-hidden my-8">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-slate-900 text-white no-print">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-emerald-500/20 text-emerald-400 rounded-lg">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base text-white">Kartu Tanda Anggota (KTA)</h3>
              <p className="text-xs text-slate-400">Bukti Keanggotaan Rukun Kematian Digital</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex bg-slate-800 p-1 rounded-lg text-xs font-medium mr-2">
              <button
                onClick={() => setSide('front')}
                className={`px-3 py-1 rounded-md transition-colors ${side === 'front' ? 'bg-emerald-600 text-white' : 'text-slate-300 hover:text-white'}`}
              >
                Depan
              </button>
              <button
                onClick={() => setSide('back')}
                className={`px-3 py-1 rounded-md transition-colors ${side === 'back' ? 'bg-emerald-600 text-white' : 'text-slate-300 hover:text-white'}`}
              >
                Belakang (Tanggungan)
              </button>
            </div>

            <button
              onClick={closeKtaModal}
              className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Action Toolbar */}
        <div className="flex items-center justify-between p-4 bg-emerald-50 border-b border-emerald-100 no-print">
          <div className="flex items-center gap-2 text-xs text-emerald-900 font-medium">
            <span>Status: <strong className="px-2 py-0.5 bg-emerald-200 text-emerald-900 font-bold rounded-full">{citizen.status}</strong></span>
            {citizen.isOfficer && (
              <span className="px-2 py-0.5 bg-amber-200 text-amber-950 font-extrabold rounded-full border border-amber-400/50 flex items-center gap-1">
                ⭐ Pengurus: {citizen.officerRole || 'Amanah'}
              </span>
            )}
          </div>
          <div className="flex gap-2">
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-xs font-semibold shadow-sm transition-all"
            >
              <Printer className="w-3.5 h-3.5" />
              Cetak KTA
            </button>
          </div>
        </div>

        {/* The Card */}
        <div id="printable-receipt" className="p-6 sm:p-8 flex justify-center bg-slate-100">
          {side === 'front' ? (
            /* FRONT CARD */
            <div className={`w-full max-w-sm aspect-[1.586/1] ${citizen.isOfficer ? 'bg-gradient-to-br from-slate-900 via-emerald-950 to-amber-950 border-amber-400/70' : 'bg-gradient-to-br from-emerald-800 via-emerald-900 to-teal-950 border-emerald-500/40'} text-white rounded-2xl p-5 shadow-2xl relative overflow-hidden border-2 flex flex-col justify-between`}>
              {/* Card Watermark & Patterns */}
              <div className="absolute -right-12 -bottom-12 w-48 h-48 bg-emerald-600/20 rounded-full blur-2xl pointer-events-none" />
              <div className="absolute top-0 right-0 w-32 h-32 bg-amber-400/15 rounded-full blur-xl pointer-events-none" />

              {/* Card Header */}
              <div className="flex items-center justify-between border-b border-white/20 pb-3 relative z-10">
                <div className="flex items-center gap-2.5">
                  {settings.logoUrl ? (
                    <img 
                      src={getDirectImageUrl(settings.logoUrl)} 
                      alt={settings.shortName}
                      referrerPolicy="no-referrer"
                      className="w-10 h-10 object-contain bg-white rounded-xl p-0.5 shadow ring-1 ring-emerald-300/40"
                    />
                  ) : (
                    <div className="w-9 h-9 bg-emerald-500 text-slate-950 rounded-xl flex items-center justify-center font-black text-sm shadow">
                      RKM
                    </div>
                  )}
                  <div>
                    <h4 className="font-black text-xs uppercase tracking-wider text-emerald-200">
                      {settings.shortName}
                    </h4>
                    <p className="text-[9px] text-emerald-300 font-medium">{settings.village} - {settings.district}</p>
                  </div>
                </div>

                <div className="text-right">
                  {citizen.isOfficer ? (
                    <div className="flex flex-col items-end">
                      <span className="text-[8px] tracking-wider uppercase bg-amber-500/30 text-amber-200 font-extrabold px-2 py-0.5 rounded border border-amber-400/60 shadow-sm">
                        ⭐ PENGURUS TERPILIH
                      </span>
                      <span className="text-[7px] text-amber-300/90 font-mono mt-0.5">Periode 2024–2027</span>
                    </div>
                  ) : (
                    <span className="text-[8px] tracking-widest uppercase bg-amber-400/20 text-amber-300 font-bold px-2 py-0.5 rounded border border-amber-400/30">
                      KTA RESMI
                    </span>
                  )}
                </div>
              </div>

              {/* Card Middle Info */}
              <div className="my-2 relative z-10 flex items-center justify-between gap-3">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <p className="text-[9px] text-emerald-300 uppercase tracking-wider font-semibold">
                      {citizen.isOfficer ? 'Anggota & Pengurus Terpilih' : 'Kepala Keluarga'}
                    </p>
                    {citizen.ktaNumber && (
                      <span className="text-[8px] font-mono bg-white/10 px-1.5 py-0.2 rounded text-emerald-200 border border-white/10">
                        {citizen.ktaNumber}
                      </span>
                    )}
                  </div>
                  <h3 className="font-extrabold text-base sm:text-lg text-white leading-tight mt-0.5 drop-shadow-sm truncate">
                    {citizen.headOfFamily}
                  </h3>
                  {citizen.isOfficer && citizen.officerRole && (
                    <p className="text-[10px] font-bold text-amber-300 flex items-center gap-1 mt-0.5">
                      <span>Amanah Jabatan:</span>
                      <span className="bg-amber-400/20 px-1.5 py-0.2 rounded border border-amber-400/30">{citizen.officerRole}</span>
                    </p>
                  )}

                  <div className="grid grid-cols-2 gap-2 mt-2 text-[10px]">
                    <div>
                      <span className="text-emerald-400 block text-[8px] uppercase">Nomor KK</span>
                      <span className="font-mono font-bold tracking-tight">{citizen.noKK}</span>
                    </div>
                    <div>
                      <span className="text-emerald-400 block text-[8px] uppercase">Domisili / Blok</span>
                      <span className="font-bold">{citizen.block || 'Blok'} {citizen.houseNumber || ''} (RT {citizen.rt}/RW {citizen.rw})</span>
                    </div>
                  </div>
                </div>

                {citizen.avatar && (
                  <div className="shrink-0">
                    <img 
                      src={citizen.avatar} 
                      alt={citizen.headOfFamily} 
                      className={`w-14 h-14 object-cover rounded-xl border-2 ${citizen.isOfficer ? 'border-amber-400 shadow-amber-900/40' : 'border-white/40'} shadow-md`}
                    />
                  </div>
                )}
              </div>

              {/* Card Footer */}
              <div className="flex items-end justify-between border-t border-white/20 pt-2.5 relative z-10">
                <div className="text-[8px] text-emerald-300">
                  <span>Anggota Tercover: <strong>{activeMembersCount} Jiwa</strong></span>
                  <span className="block text-[7px] text-emerald-400/80">
                    {citizen.isOfficer 
                      ? `Status: ${citizen.officerDutyStatus || 'Aktif'} | Tanggal Bergabung: ${formatDateIndo(citizen.joinDate, false)}` 
                      : `Bergabung: ${formatDateIndo(citizen.joinDate, false)}`}
                  </span>
                </div>

                <div className="bg-white p-1 rounded-md shadow">
                  <img 
                    src={`https://api.qrserver.com/v1/create-qr-code/?size=48x48&data=${encodeURIComponent(citizen.isOfficer ? `KTA-PENGURUS-${citizen.ktaNumber || citizen.noKK}` : `KTA-RKM-${citizen.noKK}`)}`} 
                    alt="QR KTA" 
                    className="w-8 h-8"
                  />
                </div>
              </div>
            </div>
          ) : (
            /* BACK CARD (Family Members & Benefits) */
            <div className="w-full max-w-sm aspect-[1.586/1] bg-slate-900 text-white rounded-2xl p-5 shadow-2xl relative overflow-hidden border-2 border-slate-700 flex flex-col justify-between text-xs">
              <div>
                <div className="flex justify-between items-center pb-2 border-b border-slate-700">
                  <h4 className="font-bold text-[11px] text-emerald-400 uppercase tracking-wider">
                    Daftar Jiwa Tertanggung Santunan
                  </h4>
                  <span className="text-[9px] text-slate-400">{citizen.members.length} Jiwa Terdaftar</span>
                </div>

                <div className="mt-2 space-y-1 max-h-28 overflow-y-auto pr-1">
                  {citizen.members.map((m, idx) => (
                    <div key={m.id} className="flex items-center justify-between text-[10px] py-0.5 border-b border-slate-800">
                      <span className="text-slate-200 truncate max-w-[200px]">
                        {idx + 1}. {m.name}
                      </span>
                      <div className="flex items-center gap-1">
                        {m.socialCategory && m.socialCategory !== 'Umum' && (
                          <span className="text-[8px] px-1 bg-amber-950 text-amber-300 rounded border border-amber-800">
                            {m.socialCategory}
                          </span>
                        )}
                        <span className={`text-[9px] px-1.5 py-0.2 rounded ${m.status === 'Hidup' ? 'bg-emerald-950 text-emerald-300' : 'bg-rose-950 text-rose-300'}`}>
                          {m.relation}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {citizen.isOfficer && (
                <div className="my-1 py-1 px-2 bg-amber-500/10 rounded-lg border border-amber-500/20 text-[9px] text-amber-200 flex justify-between items-center">
                  <span>Satgas Pengurus: <strong>{citizen.officerRole}</strong></span>
                  <span className="font-semibold text-emerald-400">{citizen.officerDutyStatus || 'Aktif Siaga'}</span>
                </div>
              )}

              <div className="pt-2 border-t border-slate-800 flex justify-between items-center text-[8px] text-slate-400">
                <div>
                  <p>Layanan Darurat: <strong>{settings.contactCenter}</strong></p>
                  <p>Santunan Kematian: <strong>Rp {settings.deathBenefitAmount.toLocaleString('id-ID')}</strong> + Kain Kafan & Tim</p>
                </div>
                <div className="text-right font-bold text-emerald-400">
                  {settings.shortName}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3 bg-slate-50 border-t border-slate-200 flex justify-end no-print">
          <button
            onClick={closeKtaModal}
            className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-800 font-semibold text-xs rounded-xl transition-all"
          >
            Tutup
          </button>
        </div>

      </div>
    </div>
  );
};
