import React, { useState, useEffect } from 'react';
import { Download, Smartphone, X, CheckCircle, Share, PlusSquare } from 'lucide-react';

export const PwaInstallPrompt: React.FC = () => {
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isIos, setIsIos] = useState(false);
  const [isStandalone, setIsStandalone] = useState(false);
  const [showIosGuide, setShowIosGuide] = useState(false);
  const [showSuccessToast, setShowSuccessToast] = useState(false);

  useEffect(() => {
    // Check if already installed / running in standalone PWA mode
    const isRunningStandalone = window.matchMedia('(display-mode: standalone)').matches || 
      (window.navigator as any).standalone === true;
    setIsStandalone(isRunningStandalone);

    // Detect iOS devices
    const userAgent = window.navigator.userAgent.toLowerCase();
    const isIosDevice = /iphone|ipad|ipod/.test(userAgent);
    setIsIos(isIosDevice);

    // Capture beforeinstallprompt for Android / Chrome / Edge
    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);

    window.addEventListener('appinstalled', () => {
      setDeferredPrompt(null);
      setIsStandalone(true);
      setShowSuccessToast(true);
      setTimeout(() => setShowSuccessToast(false), 4000);
    });

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    };
  }, []);

  const handleInstallClick = async () => {
    if (isIos) {
      setShowIosGuide(true);
      return;
    }

    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === 'accepted') {
        setDeferredPrompt(null);
      }
    } else {
      // Fallback for browsers that support manual install or guidance
      setShowIosGuide(true);
    }
  };

  // If already running inside standalone app, do not show install prompt
  if (isStandalone) return null;

  return (
    <>
      {/* Install Button Trigger in Header */}
      <button
        type="button"
        onClick={handleInstallClick}
        className="flex items-center gap-1.5 px-3 py-1.5 bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-700 hover:to-teal-800 text-white rounded-xl text-xs font-bold shadow-xs transition-all cursor-pointer hover:shadow-sm transform active:scale-95 shrink-0"
        title="Pasang Aplikasi RKM MPP di Layar Utama HP / Komputer"
      >
        <Download className="w-3.5 h-3.5" />
        <span className="hidden sm:inline">Install Aplikasi</span>
        <span className="sm:hidden">App</span>
      </button>

      {/* iOS & Universal Install Guide Modal */}
      {showIosGuide && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center z-50 p-4 animate-fade-in">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full border border-slate-200 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-2xl bg-emerald-100 flex items-center justify-center text-emerald-700">
                  <Smartphone className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-sm text-slate-900">Install Aplikasi RKM MPP</h3>
                  <p className="text-xs text-slate-500">Bisa dibuka langsung tanpa file APK / App Store</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowIosGuide(false)}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-xl hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs text-slate-700">
              {isIos ? (
                <>
                  <p className="font-semibold text-slate-900">
                    Petunjuk pemasangan di iPhone / iPad (Safari):
                  </p>
                  <div className="space-y-2.5 bg-slate-50 p-3.5 rounded-2xl border border-slate-200/80">
                    <div className="flex items-start gap-2.5">
                      <div className="w-6 h-6 rounded-full bg-emerald-600 text-white font-bold flex items-center justify-center text-[11px] shrink-0 mt-0.5">
                        1
                      </div>
                      <p>
                        Tekan tombol <span className="font-bold inline-flex items-center gap-1 text-emerald-700 bg-emerald-50 px-1 rounded"><Share className="w-3 h-3" /> Bagikan (Share)</span> di bilah bawah browser Safari.
                      </p>
                    </div>
                    <div className="flex items-start gap-2.5">
                      <div className="w-6 h-6 rounded-full bg-emerald-600 text-white font-bold flex items-center justify-center text-[11px] shrink-0 mt-0.5">
                        2
                      </div>
                      <p>
                        Gulir ke bawah dan pilih menu <span className="font-bold inline-flex items-center gap-1 text-emerald-700 bg-emerald-50 px-1 rounded"><PlusSquare className="w-3 h-3" /> Tambah ke Layar Utama (Add to Home Screen)</span>.
                      </p>
                    </div>
                    <div className="flex items-start gap-2.5">
                      <div className="w-6 h-6 rounded-full bg-emerald-600 text-white font-bold flex items-center justify-center text-[11px] shrink-0 mt-0.5">
                        3
                      </div>
                      <p>
                        Tekan tombol <span className="font-bold text-slate-900">Tambah (Add)</span> di sudut kanan atas. Ikon RKM MPP siap digunakan dari layar HP Anda!
                      </p>
                    </div>
                  </div>
                </>
              ) : (
                <>
                  <p className="font-semibold text-slate-900">
                    Petunjuk pemasangan di Android / Chrome / Komputer:
                  </p>
                  <div className="space-y-2.5 bg-slate-50 p-3.5 rounded-2xl border border-slate-200/80">
                    <div className="flex items-start gap-2.5">
                      <div className="w-6 h-6 rounded-full bg-emerald-600 text-white font-bold flex items-center justify-center text-[11px] shrink-0 mt-0.5">
                        1
                      </div>
                      <p>
                        Tekan ikon titik tiga <span className="font-bold text-slate-900">⋮</span> di pojok kanan atas browser Chrome / browser HP Anda.
                      </p>
                    </div>
                    <div className="flex items-start gap-2.5">
                      <div className="w-6 h-6 rounded-full bg-emerald-600 text-white font-bold flex items-center justify-center text-[11px] shrink-0 mt-0.5">
                        2
                      </div>
                      <p>
                        Pilih menu <span className="font-bold text-emerald-700">"Install Aplikasi"</span> atau <span className="font-bold text-emerald-700">"Tambahkan ke Layar Utama"</span>.
                      </p>
                    </div>
                    <div className="flex items-start gap-2.5">
                      <div className="w-6 h-6 rounded-full bg-emerald-600 text-white font-bold flex items-center justify-center text-[11px] shrink-0 mt-0.5">
                        3
                      </div>
                      <p>
                        Konfirmasi pemasangan. Aplikasi RKM MPP akan terpasang otomatis dan dapat dibuka seperti aplikasi native.
                      </p>
                    </div>
                  </div>
                </>
              )}
            </div>

            <div className="pt-2 flex justify-end">
              <button
                type="button"
                onClick={() => setShowIosGuide(false)}
                className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold text-xs shadow-xs"
              >
                Saya Mengerti
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Success Toast */}
      {showSuccessToast && (
        <div className="fixed bottom-5 right-5 bg-slate-900 text-white px-4 py-3 rounded-2xl shadow-xl z-50 flex items-center gap-2.5 animate-bounce text-xs font-bold border border-slate-700">
          <CheckCircle className="w-4 h-4 text-emerald-400" />
          <span>Aplikasi RKM MPP Digital berhasil dipasang!</span>
        </div>
      )}
    </>
  );
};
