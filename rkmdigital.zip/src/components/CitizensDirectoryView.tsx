import React, { useState, useMemo } from 'react';
import { 
  Users, 
  Search, 
  Plus, 
  QrCode, 
  Edit, 
  Edit2, 
  Trash2, 
  UserPlus, 
  ShieldCheck, 
  Printer, 
  Phone, 
  MapPin, 
  Calendar, 
  AlertCircle, 
  Home, 
  Building, 
  BadgeCheck, 
  CheckCircle2, 
  X, 
  RefreshCw, 
  UserCheck, 
  HeartHandshake,
  UserX,
  Sparkles,
  Upload,
  Camera,
  ImageIcon,
  Download,
  FileText,
  MessageSquare,
  Send,
  Heart,
  ExternalLink,
  ShieldAlert,
  FileSpreadsheet,
  SlidersHorizontal,
  ArrowUpDown,
  ArrowUp,
  ArrowDown,
  Table,
  LayoutGrid,
  Award
} from 'lucide-react';
import { useRkm } from '../context/RkmContext';
import { 
  formatRupiah, 
  formatDateIndo, 
  BLOCK_OPTIONS, 
  CORE_RELATIONS, 
  EXTRA_RELATIONS, 
  getMemberCategory, 
  calculateCitizenMonthlyDues,
  getAvatarUrl,
  createWhatsAppUrl
} from '../utils/formatters';
import { 
  Citizen, 
  FamilyMember, 
  RelationType, 
  GenderType, 
  CommunityType,
  MemberCategory,
  MemberStatus,
  SocialCategoryType
} from '../types';
import { exportCitizensPdf, exportSingleCitizenFamilyPdf } from '../utils/pdfExport';
import { exportCitizensCsv } from '../utils/excelExport';
import { CitizensDuesTrendChart } from './CitizensDuesTrendChart';
import { CitizenWhatsAppModal } from './CitizenWhatsAppModal';
import { CitizenLocationMap } from './CitizenLocationMap';


export const CitizensDirectoryView: React.FC = () => {
  const { 
    currentUser,
    users,
    citizens, 
    deathNotices,
    addCitizen, 
    updateCitizen, 
    deleteCitizen, 
    addFamilyMember, 
    updateFamilyMember,
    deleteFamilyMember,
    openKtaModal, 
    currentRole,
    settings 
  } = useRkm();

  const isSuperAdminOrOfficer = currentRole !== 'warga';

  // Dynamic Territory Lists from Settings
  const blockOptions = settings.blockList && settings.blockList.length > 0 ? settings.blockList : BLOCK_OPTIONS;
  const rtOptions = settings.rtList && settings.rtList.length > 0 ? settings.rtList : ['01', '02', '03', '04', '05', '06', '07', '08'];
  const rwOptions = settings.rwList && settings.rwList.length > 0 ? settings.rwList : ['08'];
  const paguyubanOptions = settings.paguyubanList && settings.paguyubanList.length > 0 ? settings.paguyubanList : ['Paguyuban Warga Muslim Blok A', 'Paguyuban Warga Muslim Blok B', 'Paguyuban Warga Muslim Blok C', 'Paguyuban Warga Muslim Blok D'];

  // Registered Coordinators for downline mapping
  const coordinatorUsers = users.filter(u => u.role === 'koordinator' || u.role === 'petugas' || u.role === 'superadmin' || u.role === 'bendahara');

  // Filters & Selected State
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedRt, setSelectedRt] = useState<string>('all');
  const [selectedBlock, setSelectedBlock] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [selectedSocialCategory, setSelectedSocialCategory] = useState<string>('all');
  const [selectedOfficerFilter, setSelectedOfficerFilter] = useState<string>('all');
  const [sortBy, setSortBy] = useState<string>('name_asc');
  const [viewMode, setViewMode] = useState<'cards' | 'table'>('cards');
  const [filterCriticalArrearsOnly, setFilterCriticalArrearsOnly] = useState<boolean>(false);
  const [selectedCitizenId, setSelectedCitizenId] = useState<string>(citizens[0]?.id || '');

  const handleSortColumn = (col: 'name' | 'noKK' | 'block' | 'rt' | 'members' | 'status' | 'arrears' | 'join_date') => {
    if (sortBy === `${col}_asc`) {
      setSortBy(`${col}_desc`);
    } else {
      setSortBy(`${col}_asc`);
    }
  };
  
  // WhatsApp Gateway Modal State
  const [showWhatsAppModal, setShowWhatsAppModal] = useState(false);
  const [whatsAppCitizen, setWhatsAppCitizen] = useState<Citizen | null>(null);
  const [whatsAppInitialTab, setWhatsAppInitialTab] = useState<'reminder' | 'lelayu' | 'membership' | 'custom'>('reminder');

  const handleOpenWhatsAppModal = (citizen: Citizen, tab: 'reminder' | 'lelayu' | 'membership' | 'custom' = 'reminder') => {
    setWhatsAppCitizen(citizen);
    setWhatsAppInitialTab(tab);
    setShowWhatsAppModal(true);
  };

  // Notification Toast
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 4000);
  };

  // Modals state
  const [showAddCitizenModal, setShowAddCitizenModal] = useState(false);
  const [showEditCitizenModal, setShowEditCitizenModal] = useState(false);
  const [showAddMemberModal, setShowAddMemberModal] = useState(false);
  const [showEditMemberModal, setShowEditMemberModal] = useState(false);
  const [deleteCitizenConfirmTarget, setDeleteCitizenConfirmTarget] = useState<Citizen | null>(null);
  const [deleteMemberConfirmTarget, setDeleteMemberConfirmTarget] = useState<{
    memberId: string;
    name: string;
    relation: string;
    citizenId: string;
    headName: string;
  } | null>(null);

  // Add Citizen form state
  const [headOfFamily, setHeadOfFamily] = useState('');
  const [noKK, setNoKK] = useState('');
  const [nik, setNik] = useState('');
  const [phone, setPhone] = useState('');
  const [avatar, setAvatar] = useState('');
  const [block, setBlock] = useState('Blok A');
  const [houseNumber, setHouseNumber] = useState('No. 01');
  const [communityType, setCommunityType] = useState<CommunityType>('RT');
  const [paguyubanName, setPaguyubanName] = useState('Paguyuban Warga Muslim');
  const [addressDetail, setAddressDetail] = useState('');
  const [rt, setRt] = useState('01');
  const [rw, setRw] = useState('08');
  const [assignedCollectorId, setAssignedCollectorId] = useState('');
  const [status, setStatus] = useState<'Aktif' | 'Non-Aktif' | 'Pindah'>('Aktif');

  // Edit Citizen form state
  const [editCitizenId, setEditCitizenId] = useState('');
  const [editHeadOfFamily, setEditHeadOfFamily] = useState('');
  const [editNoKK, setEditNoKK] = useState('');
  const [editNik, setEditNik] = useState('');
  const [editPhone, setEditPhone] = useState('');
  const [editAvatar, setEditAvatar] = useState('');
  const [editBlock, setEditBlock] = useState('Blok A');
  const [editHouseNumber, setEditHouseNumber] = useState('No. 01');
  const [editCommunityType, setEditCommunityType] = useState<CommunityType>('RT');
  const [editPaguyubanName, setEditPaguyubanName] = useState('');
  const [editAddressDetail, setEditAddressDetail] = useState('');
  const [editRt, setEditRt] = useState('01');
  const [editRw, setEditRw] = useState('08');
  const [editAssignedCollectorId, setEditAssignedCollectorId] = useState('');
  const [editStatus, setEditStatus] = useState<'Aktif' | 'Non-Aktif' | 'Pindah'>('Aktif');
  const [editNotes, setEditNotes] = useState('');

  // Helper for computing unpaid months count (Jan-Aug 2026)
  const getCitizenUnpaidMonthsCount = (c: Citizen) => {
    let unpaid = 0;
    for (let i = 1; i <= 8; i++) {
      const mKey = `2026-${i.toString().padStart(2, '0')}`;
      if (!c.monthlyDues?.[mKey]?.paid) {
        unpaid++;
      }
    }
    return unpaid;
  };

  // Handle avatar photo selection & file conversion
  const handleAvatarFileChange = (e: React.ChangeEvent<HTMLInputElement>, isEdit: boolean) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 3 * 1024 * 1024) {
      showToast('Ukuran foto terlalu besar. Maksimal 3MB.');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const base64 = event.target?.result as string;
      if (isEdit) {
        setEditAvatar(base64);
      } else {
        setAvatar(base64);
      }
      showToast('Foto profil berhasil dimuat!');
    };
    reader.readAsDataURL(file);
  };

  // Add Family Member form state
  const [memberName, setMemberName] = useState('');
  const [memberNik, setMemberNik] = useState('');
  const [memberRelation, setMemberRelation] = useState<RelationType>('Istri');
  const [memberCategory, setMemberCategory] = useState<MemberCategory>('Inti');
  const [memberGender, setMemberGender] = useState<GenderType>('Perempuan');
  const [memberBirthDate, setMemberBirthDate] = useState('');
  const [memberStatus, setMemberStatus] = useState<MemberStatus>('Hidup');
  const [memberSocialCategory, setMemberSocialCategory] = useState<SocialCategoryType>('Umum');
  const [memberNotes, setMemberNotes] = useState('');

  // Edit / Replace Family Member form state
  const [editingMemberId, setEditingMemberId] = useState('');
  const [editMemberName, setEditMemberName] = useState('');
  const [editMemberNik, setEditMemberNik] = useState('');
  const [editMemberRelation, setEditMemberRelation] = useState<RelationType>('Anak');
  const [editMemberCategory, setEditMemberCategory] = useState<MemberCategory>('Inti');
  const [editMemberGender, setEditMemberGender] = useState<GenderType>('Laki-laki');
  const [editMemberBirthDate, setEditMemberBirthDate] = useState('');
  const [editMemberStatus, setEditMemberStatus] = useState<MemberStatus>('Hidup');
  const [editMemberSocialCategory, setEditMemberSocialCategory] = useState<SocialCategoryType>('Umum');
  const [editMemberNotes, setEditMemberNotes] = useState('');

  const baseRate = settings.baseDuesAmount || settings.duesAmount || 5000;
  const extraRate = settings.extraMemberDuesAmount || 3000;

  // Base list depending on role data isolation (downline & member privacy)
  const visibleCitizens = citizens.filter(c => {
    // 1. Warga isolation: only see their own family KK
    if (currentRole === 'warga') {
      if (currentUser?.noKK && c.noKK === currentUser.noKK) return true;
      if (currentUser?.name && (c.headOfFamily.toLowerCase().includes(currentUser.name.toLowerCase()) || currentUser.name.toLowerCase().includes(c.headOfFamily.toLowerCase()))) return true;
      return false;
    }
    // 2. Koordinator isolation: only see members under their direct assignment or assigned blocks
    if (currentRole === 'koordinator') {
      const isAssignedDirectly = c.assignedCollectorId === currentUser?.id;
      const isAssignedBlock = Boolean(currentUser?.assignedBlocks && currentUser.assignedBlocks.length > 0 && currentUser.assignedBlocks.includes(c.block || ''));
      // Fallback: If no assigned blocks yet, allow matching RT
      const isAssignedRt = (!currentUser?.assignedBlocks || currentUser.assignedBlocks.length === 0) && (!c.assignedCollectorId) && c.rt === currentUser?.rt;
      return isAssignedDirectly || isAssignedBlock || isAssignedRt;
    }
    // 3. Superadmin, ketua, bendahara, petugas, tim_jenazah can view all
    return true;
  });

  // Currently selected citizen object from visible citizens array
  const selectedCitizen = visibleCitizens.find(c => c.id === selectedCitizenId) || visibleCitizens[0] || null;

  // Total citizens with critical arrears (>3 unpaid months)
  const criticalArrearsCitizensCount = visibleCitizens.filter(c => getCitizenUnpaidMonthsCount(c) > 3 && c.status !== 'Pindah').length;

  // Filter citizens from visible list
  const filteredCitizens = visibleCitizens.filter(c => {
    const matchQuery = 
      c.headOfFamily.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.noKK.includes(searchQuery) ||
      c.nik.includes(searchQuery) ||
      (c.ktaNumber && c.ktaNumber.toLowerCase().includes(searchQuery.toLowerCase())) ||
      c.address.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (c.block && c.block.toLowerCase().includes(searchQuery.toLowerCase())) ||
      c.members.some(m => 
        m.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
        m.nik.includes(searchQuery) ||
        (m.socialCategory && m.socialCategory.toLowerCase().includes(searchQuery.toLowerCase()))
      );
    
    const matchRt = selectedRt === 'all' || c.rt === selectedRt;
    const matchBlock = selectedBlock === 'all' || c.block === selectedBlock;
    
    let matchStatus = true;
    if (selectedStatus === 'menunggak_kritis') {
      matchStatus = getCitizenUnpaidMonthsCount(c) > 3 && c.status !== 'Pindah';
    } else if (selectedStatus !== 'all') {
      matchStatus = c.status === selectedStatus;
    }

    const matchCriticalOnly = !filterCriticalArrearsOnly || (getCitizenUnpaidMonthsCount(c) > 3 && c.status !== 'Pindah');

    // Filter Kategori Khusus (Yatim, Piatu, Janda, Lansia, dll)
    const matchSocialCategory = selectedSocialCategory === 'all' ||
      c.members.some(m => m.socialCategory === selectedSocialCategory) ||
      (c.socialCategories && c.socialCategories.includes(selectedSocialCategory as any));

    // Filter Status Kepengurusan (Pengurus Terpilih / Anggota Biasa)
    const matchOfficerFilter = selectedOfficerFilter === 'all' ||
      (selectedOfficerFilter === 'officer_only' && c.isOfficer) ||
      (selectedOfficerFilter === 'regular_only' && !c.isOfficer);

    return matchQuery && matchRt && matchBlock && matchStatus && matchCriticalOnly && matchSocialCategory && matchOfficerFilter;
  });

  // Sorting logic based on sortBy selection
  const sortedAndFilteredCitizens = [...filteredCitizens].sort((a, b) => {
    switch (sortBy) {
      case 'name_desc':
        return b.headOfFamily.localeCompare(a.headOfFamily);
      case 'name_asc':
        return a.headOfFamily.localeCompare(b.headOfFamily);
      case 'noKK_desc':
        return b.noKK.localeCompare(a.noKK);
      case 'noKK_asc':
        return a.noKK.localeCompare(b.noKK);
      case 'block_desc':
        return ((b.block || '') + (b.houseNumber || '')).localeCompare((a.block || '') + (a.houseNumber || ''));
      case 'block_asc':
        return ((a.block || '') + (a.houseNumber || '')).localeCompare((b.block || '') + (b.houseNumber || ''));
      case 'rt_desc':
        return (b.rt || '').localeCompare(a.rt || '');
      case 'rt_asc':
        return (a.rt || '').localeCompare(b.rt || '');
      case 'status_desc':
      case 'status_inactive':
        if (a.status === b.status) return a.headOfFamily.localeCompare(b.headOfFamily);
        return a.status !== 'Aktif' ? -1 : 1;
      case 'status_asc':
      case 'status_active':
        if (a.status === b.status) return a.headOfFamily.localeCompare(b.headOfFamily);
        return a.status === 'Aktif' ? -1 : 1;
      case 'members_asc':
        return a.members.length - b.members.length;
      case 'members_desc':
        return b.members.length - a.members.length;
      case 'arrears_asc':
        return getCitizenUnpaidMonthsCount(a) - getCitizenUnpaidMonthsCount(b);
      case 'arrears_desc':
        return getCitizenUnpaidMonthsCount(b) - getCitizenUnpaidMonthsCount(a);
      case 'join_date_asc':
        return (a.joinDate || '').localeCompare(b.joinDate || '');
      case 'join_date_desc':
        return (b.joinDate || '').localeCompare(a.joinDate || '');
      default:
        return a.headOfFamily.localeCompare(b.headOfFamily);
    }
  });

  // Open Edit Citizen Modal
  const handleOpenEditCitizenModal = (cit: Citizen) => {
    setEditCitizenId(cit.id);
    setEditHeadOfFamily(cit.headOfFamily);
    setEditNoKK(cit.noKK);
    setEditNik(cit.nik);
    setEditPhone(cit.phone || '');
    setEditAvatar(cit.avatar || '');
    setEditBlock(cit.block || 'Blok A');
    setEditHouseNumber(cit.houseNumber || 'No. 01');
    setEditCommunityType(cit.communityType || 'RT');
    setEditPaguyubanName(cit.paguyubanName || 'Paguyuban Warga Muslim');
    setEditAddressDetail(cit.address || '');
    setEditRt(cit.rt || '01');
    setEditRw(cit.rw || '08');
    setEditAssignedCollectorId(cit.assignedCollectorId || '');
    setEditStatus(cit.status || 'Aktif');
    setEditNotes(cit.notes || '');
    setShowEditCitizenModal(true);
  };

  // Submit Edit Citizen
  const handleEditCitizenSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editHeadOfFamily.trim() || !editNoKK.trim() || !editNik.trim()) return;

    const fullAddr = editAddressDetail.trim()
      ? editAddressDetail
      : `${editBlock} ${editHouseNumber}, ${editCommunityType === 'RT' ? `RT ${editRt}/RW ${editRw}` : editPaguyubanName}`;

    const assignedCollector = coordinatorUsers.find(u => u.id === editAssignedCollectorId);

    updateCitizen(editCitizenId, {
      headOfFamily: editHeadOfFamily,
      noKK: editNoKK,
      nik: editNik,
      phone: editPhone,
      avatar: editAvatar,
      address: fullAddr,
      block: editBlock,
      houseNumber: editHouseNumber,
      communityType: editCommunityType,
      paguyubanName: editCommunityType === 'Paguyuban' ? editPaguyubanName : undefined,
      rt: editCommunityType === 'RT' ? editRt : '01',
      rw: editRw,
      assignedCollectorId: editAssignedCollectorId || undefined,
      assignedCollectorName: assignedCollector ? assignedCollector.name : undefined,
      status: editStatus,
      notes: editNotes
    });

    showToast(`Data KK Bpk. ${editHeadOfFamily} berhasil diperbarui!`);
    setShowEditCitizenModal(false);
  };

  // Submit Add Citizen
  const handleAddCitizenSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!headOfFamily.trim() || !noKK.trim() || !nik.trim()) return;

    const fullAddr = addressDetail.trim()
      ? `${block} ${houseNumber}, ${addressDetail}, ${communityType === 'RT' ? `RT ${rt}/RW ${rw}` : paguyubanName}`
      : `${block} ${houseNumber}, ${communityType === 'RT' ? `RT ${rt}/RW ${rw}` : paguyubanName}`;

    const initialMonths: Record<string, any> = {};
    for (let i = 1; i <= 12; i++) {
      const monthKey = `2026-${i.toString().padStart(2, '0')}`;
      initialMonths[monthKey] = { paid: false, amount: baseRate };
    }

    const assignedCollector = coordinatorUsers.find(u => u.id === assignedCollectorId);

    const newCit: Omit<Citizen, 'id'> = {
      headOfFamily,
      noKK,
      nik,
      phone: phone || '08123456789',
      avatar: avatar || undefined,
      address: fullAddr,
      block,
      houseNumber,
      communityType,
      paguyubanName: communityType === 'Paguyuban' ? paguyubanName : undefined,
      rt: communityType === 'RT' ? rt : '01',
      rw,
      assignedCollectorId: assignedCollectorId || undefined,
      assignedCollectorName: assignedCollector ? assignedCollector.name : undefined,
      joinDate: new Date().toISOString().split('T')[0],
      status,
      members: [
        {
          id: `m-${Date.now()}`,
          name: headOfFamily,
          nik,
          relation: 'Kepala Keluarga',
          gender: 'Laki-laki',
          status: 'Hidup',
          category: 'Inti'
        }
      ],
      monthlyDues: initialMonths,
      notes: `Warga ${block}. ${communityType === 'Paguyuban' ? paguyubanName : `RT ${rt}`}`
    };

    addCitizen(newCit);
    showToast(`Warga baru ${headOfFamily} berhasil didaftarkan!`);

    // Reset Form
    setHeadOfFamily('');
    setNoKK('');
    setNik('');
    setPhone('');
    setAvatar('');
    setAddressDetail('');
    setAssignedCollectorId('');
    setShowAddCitizenModal(false);
  };

  // Open Add Member Modal
  const handleOpenAddMemberModal = (cit?: Citizen) => {
    if (cit) setSelectedCitizenId(cit.id);
    setMemberName('');
    setMemberNik('');
    setMemberRelation('Istri');
    setMemberCategory('Inti');
    setMemberGender('Perempuan');
    setMemberBirthDate('');
    setMemberStatus('Hidup');
    setMemberSocialCategory('Umum');
    setMemberNotes('');
    setShowAddMemberModal(true);
  };

  // Submit Add Family Member
  const handleAddMemberSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCitizen || !memberName.trim() || !memberNik.trim()) return;

    addFamilyMember(selectedCitizen.id, {
      name: memberName,
      nik: memberNik,
      relation: memberRelation,
      gender: memberGender,
      birthDate: memberBirthDate,
      status: memberStatus,
      category: memberCategory,
      socialCategory: memberSocialCategory,
      notes: memberNotes
    });

    showToast(`Jiwa baru "${memberName}" (${memberRelation}${memberSocialCategory !== 'Umum' ? ` - ${memberSocialCategory}` : ''}) berhasil ditambahkan ke KK ${selectedCitizen.headOfFamily}!`);

    // Reset Form
    setMemberName('');
    setMemberNik('');
    setMemberSocialCategory('Umum');
    setShowAddMemberModal(false);
  };

  // Open Edit / Replace Member Modal
  const handleOpenEditMemberModal = (member: FamilyMember) => {
    setEditingMemberId(member.id);
    setEditMemberName(member.name);
    setEditMemberNik(member.nik);
    setEditMemberRelation(member.relation);
    setEditMemberCategory(member.category || getMemberCategory(member.relation));
    setEditMemberGender(member.gender);
    setEditMemberBirthDate(member.birthDate || '');
    setEditMemberStatus(member.status || 'Hidup');
    setEditMemberSocialCategory(member.socialCategory || 'Umum');
    setEditMemberNotes(member.notes || '');
    setShowEditMemberModal(true);
  };

  // Submit Edit / Replace Member
  const handleEditMemberSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCitizen || !editingMemberId || !editMemberName.trim() || !editMemberNik.trim()) return;

    updateFamilyMember(selectedCitizen.id, editingMemberId, {
      name: editMemberName,
      nik: editMemberNik,
      relation: editMemberRelation,
      category: editMemberCategory,
      gender: editMemberGender,
      birthDate: editMemberBirthDate,
      status: editMemberStatus,
      socialCategory: editMemberSocialCategory,
      notes: editMemberNotes
    });

    showToast(`Perubahan data jiwa "${editMemberName}" berhasil disimpan!`);
    setShowEditMemberModal(false);
  };

  // Quick Change Member Status (Hidup / Meninggal / Pindah)
  const handleQuickStatusChange = (memberId: string, nextStatus: MemberStatus) => {
    if (!selectedCitizen) return;
    const targetMember = selectedCitizen.members.find(m => m.id === memberId);
    if (!targetMember) return;

    updateFamilyMember(selectedCitizen.id, memberId, { status: nextStatus });
    showToast(`Status ${targetMember.name} diubah menjadi "${nextStatus}"`);
  };

  // Delete Member (Pengurangan Jiwa) - Trigger Custom Modal
  const handleDeleteMember = (memberId: string, name: string, relation: string) => {
    if (!selectedCitizen) return;
    setDeleteMemberConfirmTarget({
      memberId,
      name,
      relation,
      citizenId: selectedCitizen.id,
      headName: selectedCitizen.headOfFamily
    });
  };

  const confirmExecuteDeleteMember = () => {
    if (!deleteMemberConfirmTarget) return;
    const { memberId, name, citizenId } = deleteMemberConfirmTarget;
    deleteFamilyMember(citizenId, memberId);
    showToast(`Anggota jiwa "${name}" berhasil dihapus dari KK!`);
    setDeleteMemberConfirmTarget(null);
  };

  // Delete Citizen (Hapus Seluruh KK) - Trigger Custom Modal
  const handleDeleteCitizen = (cit: Citizen) => {
    setDeleteCitizenConfirmTarget(cit);
  };

  const confirmExecuteDeleteCitizen = () => {
    if (!deleteCitizenConfirmTarget) return;
    const cit = deleteCitizenConfirmTarget;
    deleteCitizen(cit.id);
    if (selectedCitizenId === cit.id) {
      setSelectedCitizenId(citizens.find(c => c.id !== cit.id)?.id || '');
    }
    showToast(`Data KK Bpk. ${cit.headOfFamily} berhasil dihapus.`);
    setDeleteCitizenConfirmTarget(null);
  };

  const selectedCitizenDues = selectedCitizen ? calculateCitizenMonthlyDues(selectedCitizen, baseRate, extraRate) : null;

  // Visual Summary Header Calculations
  const totalCitizensCount = citizens.length;
  const allMembers = useMemo(() => citizens.flatMap(c => c.members), [citizens]);
  const totalMembersCount = allMembers.length;

  const activeCitizensCount = citizens.filter(c => c.status === 'Aktif' || c.status === 'active').length;
  const inactiveCitizensCount = citizens.filter(c => c.status !== 'Aktif' && c.status !== 'active').length;
  const activeCitizensPercent = totalCitizensCount > 0 ? Math.round((activeCitizensCount / totalCitizensCount) * 100) : 0;

  const activeMembersCount = allMembers.filter(m => m.status === 'Hidup' || m.status === 'alive' || !m.status).length;
  const inactiveMembersCount = allMembers.filter(m => m.status === 'Meninggal' || m.status === 'Pindah' || m.status === 'deceased' || m.status === 'moved').length;
  const activeMembersPercent = totalMembersCount > 0 ? Math.round((activeMembersCount / totalMembersCount) * 100) : 0;

  const maleMembersCount = allMembers.filter(m => m.gender === 'Laki-laki' || m.gender === 'L').length;
  const femaleMembersCount = allMembers.filter(m => m.gender === 'Perempuan' || m.gender === 'P').length;
  const malePercent = totalMembersCount > 0 ? Math.round((maleMembersCount / totalMembersCount) * 100) : 0;
  const femalePercent = totalMembersCount > 0 ? 100 - malePercent : 0;

  return (
    <div className="space-y-6 pb-12 animate-fade-in">
      
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 flex items-center gap-3 px-5 py-3 bg-slate-900 text-white rounded-2xl shadow-2xl border border-emerald-500/40 animate-slide-up">
          <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
          <span className="text-xs sm:text-sm font-semibold">{toastMessage}</span>
          <button onClick={() => setToastMessage(null)} className="ml-2 text-slate-400 hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Header & Super Admin Notice */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5 flex-wrap">
            <span className="p-2.5 bg-emerald-100 text-emerald-800 rounded-xl">
              <Users className="w-6 h-6" />
            </span>
            <div>
              <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900">
                Data Master Warga & Jiwa Keluarga (KK)
              </h1>
              <div className="flex items-center gap-2 mt-0.5">
                <span className="text-xs bg-emerald-100 text-emerald-900 font-black px-2 py-0.5 rounded-md flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  Hak Akses: Super Admin
                </span>
                <span className="text-xs text-slate-500 font-medium hidden sm:inline">
                  • Total {citizens.length} KK terdaftar ({citizens.reduce((acc, c) => acc + c.members.length, 0)} Jiwa)
                </span>
              </div>
            </div>
          </div>
          <p className="text-xs sm:text-sm text-slate-600 mt-2 max-w-2xl">
            Super Admin berwenang mengelola data master: penambahan jiwa baru dalam KK, pengubahan/penggantian nama & identitas, penyesuaian hubungan inti/tambahan, perubahan status hidup/meninggal/pindah, dan pengurangan anggota jiwa.
          </p>
        </div>

        {isSuperAdminOrOfficer && (
          <div className="flex items-center gap-2 self-start md:self-auto flex-wrap">
            <button
              onClick={() => setShowAddCitizenModal(true)}
              className="flex items-center gap-2 px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 active:scale-98 text-white font-bold text-xs sm:text-sm rounded-xl shadow-md transition-all cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Tambah Warga / KK Baru</span>
            </button>
          </div>
        )}
      </div>

      {/* Visual Summary Header: Total citizens, active/inactive count, gender distribution */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Card 1: Total Warga (KK & Jiwa) */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 sm:p-5 border border-slate-200/80 dark:border-slate-800 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between gap-2">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
              Total Populasi Warga
            </span>
            <span className="p-2 bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400 rounded-xl">
              <Users className="w-4 h-4" />
            </span>
          </div>
          <div className="mt-3">
            <div className="flex items-baseline gap-2">
              <span className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white font-mono">
                {totalCitizensCount}
              </span>
              <span className="text-xs font-bold text-slate-600 dark:text-slate-300">KK Terdaftar</span>
              <span className="text-slate-300 dark:text-slate-700">•</span>
              <span className="text-lg sm:text-xl font-bold text-emerald-600 dark:text-emerald-400 font-mono">
                {totalMembersCount}
              </span>
              <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">Jiwa</span>
            </div>
            <div className="mt-2.5 flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400 pt-2 border-t border-slate-100 dark:border-slate-800/80">
              <span>Rata-rata Jiwa per KK:</span>
              <span className="font-bold text-slate-700 dark:text-slate-200 font-mono">
                {(totalMembersCount / (totalCitizensCount || 1)).toFixed(1)} Jiwa/KK
              </span>
            </div>
          </div>
        </div>

        {/* Card 2: Status Keaktifan (Active / Inactive) */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 sm:p-5 border border-slate-200/80 dark:border-slate-800 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between gap-2">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
              Status Keaktifan Warga
            </span>
            <span className="p-2 bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400 rounded-xl">
              <ShieldCheck className="w-4 h-4" />
            </span>
          </div>
          <div className="mt-3 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-emerald-700 dark:text-emerald-400 flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block" />
                Aktif: {activeCitizensCount} KK ({activeCitizensPercent}%)
              </span>
              <span className="font-semibold text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-slate-400 inline-block" />
                Non-Aktif: {inactiveCitizensCount} KK
              </span>
            </div>
            {/* Progress Bar */}
            <div className="h-2.5 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden flex">
              <div 
                style={{ width: `${activeCitizensPercent}%` }} 
                className="bg-emerald-500 h-full rounded-l-full transition-all duration-500" 
                title={`Warga Aktif: ${activeCitizensPercent}%`}
              />
              <div 
                style={{ width: `${100 - activeCitizensPercent}%` }} 
                className="bg-slate-300 dark:bg-slate-700 h-full rounded-r-full transition-all duration-500" 
                title={`Warga Non-Aktif / Pindah: ${100 - activeCitizensPercent}%`}
              />
            </div>
            <div className="flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400 pt-1">
              <span>{activeMembersCount} Jiwa Tercatat Hidup</span>
              <span>{inactiveMembersCount} Jiwa Wafat / Pindah</span>
            </div>
          </div>
        </div>

        {/* Card 3: Distribusi Gender (Laki-laki vs Perempuan) */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 sm:p-5 border border-slate-200/80 dark:border-slate-800 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between gap-2">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
              Distribusi Gender Jiwa
            </span>
            <div className="flex items-center gap-1">
              <span className="px-2 py-0.5 bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 text-[10px] font-bold rounded-md">
                L: {malePercent}%
              </span>
              <span className="px-2 py-0.5 bg-pink-50 dark:bg-pink-950/60 text-pink-700 dark:text-pink-300 text-[10px] font-bold rounded-md">
                P: {femalePercent}%
              </span>
            </div>
          </div>
          <div className="mt-3 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-blue-600 dark:text-blue-400 flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-blue-500 inline-block" />
                Laki-laki: {maleMembersCount} Jiwa
              </span>
              <span className="font-bold text-pink-600 dark:text-pink-400 flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-pink-500 inline-block" />
                Perempuan: {femaleMembersCount} Jiwa
              </span>
            </div>
            {/* Progress Bar */}
            <div className="h-2.5 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden flex">
              <div 
                style={{ width: `${malePercent}%` }} 
                className="bg-blue-500 h-full rounded-l-full transition-all duration-500" 
                title={`Laki-laki: ${malePercent}%`}
              />
              <div 
                style={{ width: `${femalePercent}%` }} 
                className="bg-pink-500 h-full rounded-r-full transition-all duration-500" 
                title={`Perempuan: ${femalePercent}%`}
              />
            </div>
            <div className="flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400 pt-1">
              <span>Rasio: {maleMembersCount}:{femaleMembersCount}</span>
              <span>Total: {totalMembersCount} Jiwa</span>
            </div>
          </div>
        </div>
      </div>

      {/* Visualisasi Grafik Tren Pembayaran Iuran Warga Bulanan */}
      <CitizensDuesTrendChart citizens={citizens} settings={settings} />

      {/* Search & Filters Toolbar */}
      <div className="bg-white dark:bg-slate-900 p-4 sm:p-5 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-3.5">
        {/* Row 1: Search & Primary Location/Status Filters */}
        <div className="flex flex-wrap items-center gap-2.5">
          <div className="relative flex-1 min-w-[240px]">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Cari kepala keluarga / NIK / No. KK / KTA / jiwa / Blok / kategori..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full h-10 pl-9 pr-3 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white placeholder:text-slate-400 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
            />
          </div>

          {/* Filter Blok */}
          <select
            value={selectedBlock}
            onChange={(e) => setSelectedBlock(e.target.value)}
            className="h-10 px-3 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl font-bold text-slate-700 dark:text-slate-200 cursor-pointer focus:outline-none focus:ring-2 focus:ring-emerald-500"
          >
            <option value="all">Semua Blok (A–Z)</option>
            {blockOptions.map(b => (
              <option key={b} value={b}>{b}</option>
            ))}
          </select>

          {/* Filter RT */}
          <select
            value={selectedRt}
            onChange={(e) => setSelectedRt(e.target.value)}
            className="h-10 px-3 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl font-semibold text-slate-700 dark:text-slate-200 cursor-pointer focus:outline-none focus:ring-2 focus:ring-emerald-500"
          >
            <option value="all">Semua RT</option>
            {rtOptions.map(r => (
              <option key={r} value={r}>RT {r}</option>
            ))}
          </select>

          {/* Filter Status Warga */}
          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="h-10 px-3 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl font-semibold text-slate-700 dark:text-slate-200 cursor-pointer focus:outline-none focus:ring-2 focus:ring-emerald-500"
          >
            <option value="all">Semua Status KK</option>
            <option value="Aktif">Status Aktif</option>
            <option value="Non-Aktif">Status Non-Aktif</option>
            <option value="Pindah">Status Pindah</option>
          </select>

          {/* Quick Filter: Tunggakan Kritis >3 Bulan */}
          <button
            onClick={() => setFilterCriticalArrearsOnly(!filterCriticalArrearsOnly)}
            className={`h-10 px-3.5 text-xs font-bold rounded-xl transition-all flex items-center gap-1.5 cursor-pointer border ${
              filterCriticalArrearsOnly
                ? 'bg-rose-600 text-white border-rose-600 shadow-sm'
                : 'bg-rose-50 dark:bg-rose-950/40 hover:bg-rose-100 dark:hover:bg-rose-900/60 text-rose-800 dark:text-rose-300 border-rose-200 dark:border-rose-800/60'
            }`}
            title="Filter hanya warga yang menunggak iuran >3 bulan berturut-turut"
          >
            <ShieldAlert className="w-3.5 h-3.5" />
            <span>Tunggakan &gt;3 Bln ({criticalArrearsCitizensCount})</span>
          </button>
        </div>

        {/* Row 2: Advanced Search (Kategori Khusus Yatim/Janda/dll, Kepengurusan, dan Sorting) */}
        <div className="flex flex-wrap items-center justify-between gap-2.5 pt-3 border-t border-slate-100 dark:border-slate-800">
          <div className="flex flex-wrap items-center gap-2">
            {/* Filter Kategori Khusus (Yatim, Piatu, Janda, Lansia, Disabilitas, Dhuafa) */}
            <div className="flex items-center gap-1">
              <span className="text-[11px] font-bold text-slate-500 dark:text-slate-400 hidden sm:inline">Kategori:</span>
              <select
                value={selectedSocialCategory}
                onChange={(e) => setSelectedSocialCategory(e.target.value)}
                className="h-9 px-2.5 text-xs bg-purple-50 dark:bg-purple-950/40 border border-purple-200 dark:border-purple-800/60 text-purple-900 dark:text-purple-300 rounded-xl font-bold cursor-pointer hover:bg-purple-100/70 dark:hover:bg-purple-900/40"
                title="Pencarian khusus anggota: Yatim, Piatu, Janda, Lansia, Disabilitas, Dhuafa"
              >
                <option value="all">🏷️ Semua Kategori (Termasuk Yatim/Janda/dll)</option>
                <option value="Yatim">👦 Anak Yatim</option>
                <option value="Piatu">👧 Anak Piatu</option>
                <option value="Yatim Piatu">👶 Yatim Piatu</option>
                <option value="Janda">👩 Ibu Janda</option>
                <option value="Duda">👨 Duda</option>
                <option value="Lansia">👴👵 Lanjut Usia (Lansia)</option>
                <option value="Disabilitas">♿ Penyandang Disabilitas</option>
                <option value="Dhuafa">🤲 Kaum Dhuafa</option>
              </select>
            </div>

            {/* Filter Kepengurusan Terpilih */}
            <div className="flex items-center gap-1">
              <span className="text-[11px] font-bold text-slate-500 dark:text-slate-400 hidden sm:inline">Jabatan:</span>
              <select
                value={selectedOfficerFilter}
                onChange={(e) => setSelectedOfficerFilter(e.target.value)}
                className="h-9 px-2.5 text-xs bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/60 text-amber-900 dark:text-amber-300 rounded-xl font-bold cursor-pointer hover:bg-amber-100/70 dark:hover:bg-amber-900/40"
              >
                <option value="all">⭐ Semua Warga & Pengurus</option>
                <option value="officer_only">⭐ Hanya Pengurus Terpilih</option>
                <option value="regular_only">👥 Anggota Biasa (Non-Pengurus)</option>
              </select>
            </div>

            {/* Sorting Dropdown */}
            <div className="flex items-center gap-1">
              <ArrowUpDown className="w-3.5 h-3.5 text-slate-400" />
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="h-9 px-2.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 rounded-xl font-semibold cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-700"
              >
                <option value="name_asc">Urutkan: Nama (A ke Z)</option>
                <option value="name_desc">Urutkan: Nama (Z ke A)</option>
                <option value="block_asc">Urutkan: Blok & No. Rumah</option>
                <option value="status_active">Urutkan: Status Aktif Dahulu</option>
                <option value="members_desc">Urutkan: Jumlah Jiwa Terbanyak</option>
                <option value="arrears_desc">Urutkan: Tunggakan Terbanyak</option>
                <option value="join_date_desc">Urutkan: Terdaftar Terbaru</option>
              </select>
            </div>
          </div>

          {/* Action Buttons: Unduh Excel, Unduh PDF, Print */}
          <div className="flex items-center gap-2 flex-wrap">
            {/* Export Excel / CSV */}
            <button
              onClick={() => {
                exportCitizensCsv(sortedAndFilteredCitizens, settings);
                showToast(`Data ${sortedAndFilteredCitizens.length} warga berhasil diexport ke file Excel/CSV.`);
              }}
              id="btn-export-excel-citizens"
              className="h-9 flex items-center gap-1.5 px-3.5 bg-emerald-50 dark:bg-emerald-950/40 hover:bg-emerald-100 dark:hover:bg-emerald-900/60 text-emerald-800 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-700/60 rounded-xl text-xs font-bold transition-all active:scale-95 cursor-pointer shadow-xs focus:outline-none focus:ring-2 focus:ring-emerald-500/40"
              title="Unduh Data Warga Lengkap dalam Format Excel / CSV"
              aria-label="Unduh Data Warga Lengkap dalam Format Excel / CSV"
            >
              <FileSpreadsheet className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
              <span>Unduh Excel / CSV</span>
            </button>

            {/* Download PDF Buku Induk Button */}
            <button
              onClick={() => {
                const filterParts = [];
                if (selectedBlock !== 'all') filterParts.push(`Blok ${selectedBlock}`);
                if (selectedRt !== 'all') filterParts.push(`RT ${selectedRt}`);
                if (selectedStatus !== 'all') filterParts.push(`Status ${selectedStatus}`);
                if (selectedSocialCategory !== 'all') filterParts.push(`Kategori ${selectedSocialCategory}`);
                if (selectedOfficerFilter === 'officer_only') filterParts.push('Pengurus Terpilih');
                const filterText = filterParts.join(' • ') || 'Seluruh Warga Terdaftar';
                exportCitizensPdf(sortedAndFilteredCitizens, settings, filterText);
                showToast(`Buku Induk PDF (${sortedAndFilteredCitizens.length} KK) berhasil diunduh.`);
              }}
              id="btn-download-pdf-citizens"
              className="h-9 flex items-center gap-1.5 px-3.5 bg-emerald-700 dark:bg-emerald-600 hover:bg-emerald-800 dark:hover:bg-emerald-500 text-white rounded-xl text-xs font-bold shadow-sm transition-all active:scale-95 cursor-pointer border border-emerald-600/40 dark:border-emerald-500/40 focus:outline-none focus:ring-2 focus:ring-emerald-500/40"
              title="Unduh Data Buku Induk Warga dalam Format PDF (A4 Landscape)"
              aria-label="Unduh Data Buku Induk Warga dalam Format PDF (A4 Landscape)"
            >
              <Download className="w-4 h-4" />
              <span>Unduh PDF</span>
            </button>

            <button
              onClick={() => window.print()}
              className="h-9 flex items-center gap-1.5 px-3.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold transition-all active:scale-95 cursor-pointer shadow-xs focus:outline-none focus:ring-2 focus:ring-slate-400/40"
              title="Cetak Daftar Warga"
              aria-label="Cetak Daftar Warga"
            >
              <Printer className="w-4 h-4 text-slate-500 dark:text-slate-400" />
              <span>Cetak</span>
            </button>

            {/* View Mode Toggle (Kartu / Tabel) */}
            <div className="flex items-center bg-slate-100 dark:bg-slate-800 p-0.5 rounded-xl border border-slate-200 dark:border-slate-700 ml-1">
              <button
                type="button"
                onClick={() => setViewMode('cards')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  viewMode === 'cards'
                    ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                    : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
                }`}
                title="Tampilan Kartu Warga"
              >
                <LayoutGrid className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Kartu</span>
              </button>
              <button
                type="button"
                onClick={() => setViewMode('table')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  viewMode === 'table'
                    ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                    : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
                }`}
                title="Tampilan Tabel Data Master dengan Sorting Kolom"
              >
                <Table className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Tabel</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {viewMode === 'table' ? (
        <div className="space-y-6">
          {/* Main Table Card */}
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-sm overflow-hidden">
            <div className="p-4 sm:p-5 border-b border-slate-100 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <h2 className="text-sm sm:text-base font-extrabold text-slate-900 dark:text-white">
                  Tabel Data Master Warga ({sortedAndFilteredCitizens.length} KK Terdaftar)
                </h2>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Klik header kolom bertanda panah untuk mengurutkan data (A-Z / Z-A / Angka). Klik baris atau tombol Rincian untuk mengelola data KK.
                </p>
              </div>
              {selectedCitizen && (
                <div className="text-xs px-3 py-1.5 bg-emerald-50 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 rounded-xl border border-emerald-200/60 dark:border-emerald-800/60 font-semibold self-start sm:self-auto">
                  KK Aktif: <strong>{selectedCitizen.headOfFamily}</strong> ({selectedCitizen.block || 'Blok'} {selectedCitizen.houseNumber || ''})
                </div>
              )}
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead>
                  <tr className="bg-slate-50 dark:bg-slate-800/80 text-slate-700 dark:text-slate-300 font-bold border-b border-slate-200 dark:border-slate-700">
                    <th className="p-3 text-center w-12">No</th>
                    <th 
                      onClick={() => handleSortColumn('name')}
                      className="p-3 cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-700/60 transition-colors select-none whitespace-nowrap"
                      title="Klik untuk mengurutkan nama kepala keluarga"
                    >
                      <div className="flex items-center gap-1.5">
                        <span>Kepala Keluarga</span>
                        {sortBy === 'name_asc' ? <ArrowUp className="w-3.5 h-3.5 text-emerald-600" /> : sortBy === 'name_desc' ? <ArrowDown className="w-3.5 h-3.5 text-emerald-600" /> : <ArrowUpDown className="w-3 h-3 text-slate-400 opacity-60" />}
                      </div>
                    </th>
                    <th 
                      onClick={() => handleSortColumn('noKK')}
                      className="p-3 cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-700/60 transition-colors select-none whitespace-nowrap"
                      title="Klik untuk mengurutkan No. KK"
                    >
                      <div className="flex items-center gap-1.5">
                        <span>No. KK / NIK</span>
                        {sortBy === 'noKK_asc' ? <ArrowUp className="w-3.5 h-3.5 text-emerald-600" /> : sortBy === 'noKK_desc' ? <ArrowDown className="w-3.5 h-3.5 text-emerald-600" /> : <ArrowUpDown className="w-3 h-3 text-slate-400 opacity-60" />}
                      </div>
                    </th>
                    <th 
                      onClick={() => handleSortColumn('block')}
                      className="p-3 cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-700/60 transition-colors select-none whitespace-nowrap"
                      title="Klik untuk mengurutkan Blok & Rumah"
                    >
                      <div className="flex items-center gap-1.5">
                        <span>Blok & No.</span>
                        {sortBy === 'block_asc' ? <ArrowUp className="w-3.5 h-3.5 text-emerald-600" /> : sortBy === 'block_desc' ? <ArrowDown className="w-3.5 h-3.5 text-emerald-600" /> : <ArrowUpDown className="w-3 h-3 text-slate-400 opacity-60" />}
                      </div>
                    </th>
                    <th 
                      onClick={() => handleSortColumn('rt')}
                      className="p-3 cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-700/60 transition-colors select-none whitespace-nowrap"
                      title="Klik untuk mengurutkan RT"
                    >
                      <div className="flex items-center gap-1.5">
                        <span>Wilayah (RT/RW)</span>
                        {sortBy === 'rt_asc' ? <ArrowUp className="w-3.5 h-3.5 text-emerald-600" /> : sortBy === 'rt_desc' ? <ArrowDown className="w-3.5 h-3.5 text-emerald-600" /> : <ArrowUpDown className="w-3 h-3 text-slate-400 opacity-60" />}
                      </div>
                    </th>
                    <th 
                      onClick={() => handleSortColumn('members')}
                      className="p-3 text-center cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-700/60 transition-colors select-none whitespace-nowrap"
                      title="Klik untuk mengurutkan Jumlah Jiwa"
                    >
                      <div className="flex items-center justify-center gap-1.5">
                        <span>Jiwa</span>
                        {sortBy === 'members_asc' ? <ArrowUp className="w-3.5 h-3.5 text-emerald-600" /> : sortBy === 'members_desc' ? <ArrowDown className="w-3.5 h-3.5 text-emerald-600" /> : <ArrowUpDown className="w-3 h-3 text-slate-400 opacity-60" />}
                      </div>
                    </th>
                    <th 
                      onClick={() => handleSortColumn('status')}
                      className="p-3 text-center cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-700/60 transition-colors select-none whitespace-nowrap"
                      title="Klik untuk mengurutkan Status KK"
                    >
                      <div className="flex items-center justify-center gap-1.5">
                        <span>Status</span>
                        {sortBy === 'status_asc' || sortBy === 'status_active' ? <ArrowUp className="w-3.5 h-3.5 text-emerald-600" /> : sortBy === 'status_desc' || sortBy === 'status_inactive' ? <ArrowDown className="w-3.5 h-3.5 text-emerald-600" /> : <ArrowUpDown className="w-3 h-3 text-slate-400 opacity-60" />}
                      </div>
                    </th>
                    <th 
                      onClick={() => handleSortColumn('arrears')}
                      className="p-3 text-center cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-700/60 transition-colors select-none whitespace-nowrap"
                      title="Klik untuk mengurutkan Tunggakan Iuran"
                    >
                      <div className="flex items-center justify-center gap-1.5">
                        <span>Tunggakan</span>
                        {sortBy === 'arrears_asc' ? <ArrowUp className="w-3.5 h-3.5 text-emerald-600" /> : sortBy === 'arrears_desc' ? <ArrowDown className="w-3.5 h-3.5 text-emerald-600" /> : <ArrowUpDown className="w-3 h-3 text-slate-400 opacity-60" />}
                      </div>
                    </th>
                    <th className="p-3 text-right whitespace-nowrap">Aksi / Kontrol</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {sortedAndFilteredCitizens.length === 0 ? (
                    <tr>
                      <td colSpan={9} className="p-8 text-center text-slate-400">
                        Tidak ada data warga yang cocok dengan kriteria filter saat ini.
                      </td>
                    </tr>
                  ) : (
                    sortedAndFilteredCitizens.map((c, index) => {
                      const isSelected = selectedCitizen?.id === c.id;
                      const unpaidMonths = getCitizenUnpaidMonthsCount(c);
                      const isCriticalArrears = unpaidMonths > 3 && c.status !== 'Pindah';
                      const liveCount = c.members.filter(m => m.status === 'Hidup').length;

                      return (
                        <tr 
                          key={c.id}
                          onClick={() => setSelectedCitizenId(c.id)}
                          className={`cursor-pointer transition-colors ${
                            isSelected 
                              ? 'bg-emerald-50/70 dark:bg-emerald-950/30 font-medium' 
                              : isCriticalArrears 
                              ? 'bg-rose-50/40 dark:bg-rose-950/20 hover:bg-rose-50/70' 
                              : 'hover:bg-slate-50/80 dark:hover:bg-slate-800/50'
                          }`}
                        >
                          <td className="p-3 text-center font-mono text-slate-400">{index + 1}</td>
                          <td className="p-3">
                            <div className="flex items-center gap-2.5">
                              <img
                                src={getAvatarUrl(c.headOfFamily, 'warga', c.avatar)}
                                alt={c.headOfFamily}
                                referrerPolicy="no-referrer"
                                className="w-8 h-8 rounded-xl object-cover shrink-0 ring-1 ring-slate-200 dark:ring-slate-700"
                              />
                              <div>
                                <div className="font-bold text-slate-900 dark:text-white flex items-center gap-1.5 flex-wrap">
                                  <span>{c.headOfFamily}</span>
                                  {c.isOfficer && (
                                    <span className="text-[9px] font-black px-1.5 py-0.2 bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 rounded">
                                      {c.officerRole || 'Pengurus'}
                                    </span>
                                  )}
                                </div>
                                <div className="text-[11px] text-slate-500 font-mono">
                                  {c.ktaNumber || c.phone || '-'}
                                </div>
                              </div>
                            </div>
                          </td>
                          <td className="p-3 font-mono">
                            <div className="font-semibold text-slate-800 dark:text-slate-200">{c.noKK}</div>
                            <div className="text-[10px] text-slate-500">{c.nik}</div>
                          </td>
                          <td className="p-3 whitespace-nowrap">
                            <span className="font-bold text-slate-800 dark:text-slate-200">{c.block || '-'}</span> {c.houseNumber || ''}
                          </td>
                          <td className="p-3 whitespace-nowrap text-slate-600 dark:text-slate-300">
                            {c.communityType === 'Paguyuban' ? (c.paguyubanName || 'Paguyuban') : `RT ${c.rt}/RW ${c.rw}`}
                          </td>
                          <td className="p-3 text-center whitespace-nowrap">
                            <span className="font-bold font-mono text-slate-800 dark:text-slate-200">{liveCount}</span>
                            <span className="text-slate-400 text-[10px]"> / {c.members.length}</span>
                          </td>
                          <td className="p-3 text-center whitespace-nowrap">
                            <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                              c.status === 'Aktif' 
                                ? 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300' 
                                : 'bg-rose-100 dark:bg-rose-950/60 text-rose-800 dark:text-rose-300'
                            }`}>
                              {c.status}
                            </span>
                          </td>
                          <td className="p-3 text-center whitespace-nowrap">
                            {isCriticalArrears ? (
                              <span className="text-[10px] font-black px-2 py-0.5 bg-rose-600 text-white rounded-full">
                                {unpaidMonths} Bln
                              </span>
                            ) : unpaidMonths > 0 ? (
                              <span className="text-[10px] font-bold px-2 py-0.5 bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 rounded-full">
                                {unpaidMonths} Bln
                              </span>
                            ) : (
                              <span className="text-[10px] font-bold px-2 py-0.5 bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 rounded-full">
                                Lunas
                              </span>
                            )}
                          </td>
                          <td className="p-3 text-right whitespace-nowrap" onClick={(e) => e.stopPropagation()}>
                            <div className="flex items-center justify-end gap-1.5">
                              <button
                                onClick={() => setSelectedCitizenId(c.id)}
                                className={`h-7 px-2.5 rounded-lg font-bold text-[11px] transition-all cursor-pointer ${
                                  isSelected
                                    ? 'bg-emerald-600 text-white shadow-xs'
                                    : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
                                }`}
                                title="Buka detail anggota keluarga"
                              >
                                {isSelected ? 'Terpilih' : 'Rincian'}
                              </button>
                              <button
                                onClick={() => handleOpenWhatsAppModal(c)}
                                className="h-7 w-7 flex items-center justify-center bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded-lg cursor-pointer"
                                title="Kirim Pesan WhatsApp"
                              >
                                <MessageSquare className="w-3.5 h-3.5" />
                              </button>
                              {isSuperAdminOrOfficer && (
                                <button
                                  onClick={() => handleOpenEditCitizenModal(c)}
                                  className="h-7 w-7 flex items-center justify-center bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-lg cursor-pointer"
                                  title="Edit Data Master KK"
                                >
                                  <Edit className="w-3.5 h-3.5" />
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Detailed Family Panel for Selected Citizen in Table Mode */}
          {selectedCitizen && (
            <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 p-5 sm:p-6 shadow-sm space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100 dark:border-slate-800">
                <div>
                  <span className="text-[10px] font-black text-emerald-700 dark:text-emerald-400 uppercase tracking-wider bg-emerald-100 dark:bg-emerald-950/60 px-2 py-0.5 rounded">
                    RINCIAN ANGGOTA KELUARGA (KK TERPILIH DARI TABEL)
                  </span>
                  <h3 className="text-lg font-black text-slate-900 dark:text-white mt-1">
                    Bpk. {selectedCitizen.headOfFamily} — No. KK: {selectedCitizen.noKK}
                  </h3>
                  <p className="text-xs text-slate-500">
                    {selectedCitizen.block} {selectedCitizen.houseNumber || ''} • RT {selectedCitizen.rt}/RW {selectedCitizen.rw} • Total {selectedCitizen.members.length} Jiwa
                  </p>
                </div>
                {isSuperAdminOrOfficer && (
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleOpenAddMemberModal(selectedCitizen)}
                      className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center gap-1 shadow-sm cursor-pointer"
                    >
                      <UserPlus className="w-3.5 h-3.5" />
                      <span>+ Tambah Jiwa Baru</span>
                    </button>
                    <button
                      onClick={() => handleOpenEditCitizenModal(selectedCitizen)}
                      className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold flex items-center gap-1 cursor-pointer"
                    >
                      <Edit className="w-3.5 h-3.5" />
                      <span>Edit KK</span>
                    </button>
                  </div>
                )}
              </div>

              {/* Members Table */}
              <div className="overflow-x-auto">
                <table className="w-full text-xs">
                  <thead>
                    <tr className="bg-slate-50 dark:bg-slate-800/80 text-slate-600 font-bold border-b border-slate-200 dark:border-slate-700">
                      <th className="p-2.5 text-center w-10">No</th>
                      <th className="p-2.5 text-left">Nama Jiwa</th>
                      <th className="p-2.5 text-left">NIK</th>
                      <th className="p-2.5 text-left">Hubungan</th>
                      <th className="p-2.5 text-center">Gender</th>
                      <th className="p-2.5 text-center">Status Jiwa</th>
                      <th className="p-2.5 text-center">Kategori</th>
                      <th className="p-2.5 text-right">Aksi</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {selectedCitizen.members.map((m, idx) => (
                      <tr key={m.id} className="hover:bg-slate-50/60 dark:hover:bg-slate-800/40">
                        <td className="p-2.5 text-center font-mono text-slate-400">{idx + 1}</td>
                        <td className="p-2.5 font-bold text-slate-900 dark:text-white">{m.name}</td>
                        <td className="p-2.5 font-mono text-slate-600 dark:text-slate-300">{m.nik}</td>
                        <td className="p-2.5">{m.relation}</td>
                        <td className="p-2.5 text-center">{m.gender}</td>
                        <td className="p-2.5 text-center">
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            m.status === 'Hidup' ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
                          }`}>
                            {m.status}
                          </span>
                        </td>
                        <td className="p-2.5 text-center">
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-100 text-slate-700">
                            {m.category || 'Inti'}
                          </span>
                        </td>
                        <td className="p-2.5 text-right">
                          {isSuperAdminOrOfficer && (
                            <div className="flex items-center justify-end gap-1">
                              <button
                                onClick={() => handleOpenEditMemberModal(m)}
                                className="p-1 hover:bg-slate-200 rounded text-slate-600 cursor-pointer"
                                title="Ubah data jiwa"
                              >
                                <Edit2 className="w-3.5 h-3.5" />
                              </button>
                              {m.relation !== 'Kepala Keluarga' && (
                                <button
                                  onClick={() => handleDeleteMember(m.id, m.name, m.relation)}
                                  className="p-1 hover:bg-rose-100 rounded text-rose-600 cursor-pointer"
                                  title="Hapus jiwa"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              )}
                            </div>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      ) : (
      /* 2-Columns: Left List of Citizens and Right Detail/Management Panel */
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: Citizens Card List (7 Cols) */}
        <div className="lg:col-span-7 space-y-3">
          <div className="flex items-center justify-between text-xs text-slate-500 font-bold px-1">
            <span>Daftar Kartu Keluarga ({sortedAndFilteredCitizens.length} KK Ditemukan)</span>
            <span>Pilih KK untuk rincian</span>
          </div>

          {sortedAndFilteredCitizens.length === 0 ? (
            <div className="p-12 text-center bg-white rounded-3xl border border-slate-200/80 text-slate-400">
              <Users className="w-12 h-12 mx-auto text-slate-300 mb-2" />
              <p className="font-bold text-slate-700">Tidak ada data warga yang cocok</p>
              <p className="text-xs text-slate-500 mt-1">Coba sesuaikan kata kunci pencarian, kategori sosial (yatim/janda), atau filter blok.</p>
            </div>
          ) : (
            sortedAndFilteredCitizens.map((c) => {
              const isSelected = selectedCitizen?.id === c.id;
              const liveMembers = c.members.filter(m => m.status === 'Hidup');
              const dues = calculateCitizenMonthlyDues(c, baseRate, extraRate);
              const unpaidMonths = getCitizenUnpaidMonthsCount(c);
              const isCriticalArrears = unpaidMonths > 3 && c.status !== 'Pindah';

              return (
                <div
                  key={c.id}
                  onClick={() => setSelectedCitizenId(c.id)}
                  className={`p-4 sm:p-5 rounded-2xl border transition-all cursor-pointer relative ${
                    isCriticalArrears
                      ? isSelected
                        ? 'bg-rose-50/70 dark:bg-rose-950/40 border-rose-500 shadow-md ring-2 ring-rose-500/30 border-l-8 border-l-rose-600'
                        : 'bg-white dark:bg-slate-900 border-rose-300 dark:border-rose-900/60 hover:border-rose-400 hover:shadow-sm border-l-8 border-l-rose-500'
                      : isSelected
                        ? 'bg-emerald-50/70 dark:bg-emerald-950/40 border-emerald-500 shadow-md ring-2 ring-emerald-500/30'
                        : 'bg-white dark:bg-slate-900 border-slate-200/80 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 hover:shadow-sm'
                  }`}
                >
                  <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                    <div className="flex items-start gap-3.5">
                      <img
                        src={getAvatarUrl(c.headOfFamily, 'warga', c.avatar)}
                        alt={c.headOfFamily}
                        referrerPolicy="no-referrer"
                        className={`w-12 h-12 rounded-2xl object-cover shrink-0 shadow-sm ring-2 ${
                          isCriticalArrears
                            ? 'ring-rose-400 bg-rose-50 dark:bg-rose-950'
                            : isSelected ? 'ring-emerald-500 bg-emerald-100 dark:bg-emerald-950' : 'ring-slate-200 dark:ring-slate-700 bg-slate-100 dark:bg-slate-800'
                        }`}
                      />
                      
                      <div className="space-y-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <h3 className="font-black text-sm sm:text-base text-slate-900 dark:text-white">
                            {c.headOfFamily}
                          </h3>
                          {c.block && (
                            <span className="text-[10px] font-black px-2 py-0.5 bg-emerald-100 dark:bg-emerald-950/60 text-emerald-900 dark:text-emerald-300 rounded border border-emerald-200/60 dark:border-emerald-800/60">
                              {c.block} {c.houseNumber || ''}
                            </span>
                          )}
                          <span className="text-[10px] font-bold px-2 py-0.5 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded border border-slate-200/60 dark:border-slate-700/60">
                            {c.communityType === 'Paguyuban' ? (c.paguyubanName || 'Paguyuban') : `RT ${c.rt}`}
                          </span>
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                            c.status === 'Aktif' 
                              ? 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 border border-emerald-200/60 dark:border-emerald-800/60' 
                              : 'bg-rose-100 dark:bg-rose-950/60 text-rose-800 dark:text-rose-300 border border-rose-200/60 dark:border-rose-900/60'
                          }`}>
                            {c.status}
                          </span>

                          {/* Badge Pengurus Terpilih */}
                          {c.isOfficer && (
                            <span className="text-[10px] font-black px-2 py-0.5 bg-amber-100 dark:bg-amber-950/60 text-amber-900 dark:text-amber-300 border border-amber-300 dark:border-amber-800/60 rounded flex items-center gap-1 shadow-xs">
                              <Award className="w-3 h-3 text-amber-600 dark:text-amber-400" />
                              <span>{c.officerRole || 'Pengurus Terpilih'}</span>
                            </span>
                          )}

                          {/* Badge No KTA */}
                          {c.ktaNumber && (
                            <span className="text-[9px] font-mono font-bold px-1.5 py-0.5 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded border border-slate-200 dark:border-slate-700">
                              {c.ktaNumber}
                            </span>
                          )}

                          {/* Indikator Merah Otomatis Jika Menunggak >3 Bulan */}
                          {isCriticalArrears && (
                            <span 
                              className="text-[10px] font-black px-2.5 py-0.5 bg-rose-600 text-white rounded-full flex items-center gap-1 shadow-xs animate-pulse"
                              title={`Peringatan: KK ini menunggak iuran kas selama ${unpaidMonths} bulan berturut-turut`}
                            >
                              <ShieldAlert className="w-3 h-3" />
                              <span>Menunggak {unpaidMonths} Bulan</span>
                            </span>
                          )}
                        </div>

                        <p className="text-xs text-slate-500 dark:text-slate-400 font-mono">
                          No. KK: <strong className="text-slate-700 dark:text-slate-200">{c.noKK}</strong> • NIK: {c.nik}
                        </p>
                        <p className="text-xs text-slate-600 dark:text-slate-300">
                          📍 {c.address}
                        </p>
                        <p className="text-[11px] text-slate-500 dark:text-slate-400">
                          📞 {c.phone || '-'}
                        </p>

                        {/* Social Categories Tags (Yatim, Piatu, Janda, Lansia, dll) */}
                        {(() => {
                          const specialMembers = c.members.filter(m => m.socialCategory && m.socialCategory !== 'Umum');
                          const familySocialCats = c.socialCategories || [];
                          if (specialMembers.length === 0 && familySocialCats.length === 0) return null;
                          return (
                            <div className="flex flex-wrap items-center gap-1.5 pt-1">
                              {familySocialCats.map(cat => (
                                <span key={cat} className="text-[9px] font-black px-2 py-0.5 bg-purple-100 dark:bg-purple-950/60 text-purple-900 dark:text-purple-300 border border-purple-200 dark:border-purple-800/60 rounded">
                                  🏷️ {cat}
                                </span>
                              ))}
                              {specialMembers.map(m => (
                                <span key={m.id} className="text-[9px] font-extrabold px-2 py-0.5 bg-indigo-50 dark:bg-indigo-950/60 text-indigo-800 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800/60 rounded">
                                  🏷️ {m.socialCategory}: {m.name}
                                </span>
                              ))}
                            </div>
                          );
                        })()}
                      </div>
                    </div>

                    {/* Right side stats and quick action buttons */}
                    <div className="flex sm:flex-col items-center sm:items-end justify-between gap-2 shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-100 dark:border-slate-800">
                      <div className="text-left sm:text-right">
                        <span className="text-xs bg-emerald-100 dark:bg-emerald-950/60 text-emerald-900 dark:text-emerald-300 font-bold px-2.5 py-1 rounded-full inline-block border border-emerald-200/60 dark:border-emerald-800/60">
                          {c.members.length} Jiwa ({dues.coreMembersCount} Inti{dues.extraMembersCount > 0 ? `, +${dues.extraMembersCount} Tambahan` : ''})
                        </span>
                        <span className="text-[11px] font-mono font-bold text-slate-800 dark:text-slate-200 mt-1 block">
                          Iuran: {formatRupiah(dues.totalMonthlyDues)}/bln
                        </span>
                      </div>

                      {/* Action buttons on card */}
                      <div className="flex items-center gap-1.5 mt-1">
                        {/* WhatsApp Personal Reminder / Death Notice Button */}
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleOpenWhatsAppModal(c, isCriticalArrears ? 'reminder' : 'custom');
                          }}
                          title="Kirim Pesan WhatsApp (Pengingat Iuran / Kabar Duka / Konfirmasi KTA)"
                          aria-label="Kirim Pesan WhatsApp"
                          className={`h-8 px-2.5 text-white text-xs font-bold rounded-xl flex items-center gap-1 shadow-xs transition-all active:scale-95 cursor-pointer ${
                            isCriticalArrears 
                              ? 'bg-rose-600 hover:bg-rose-700 ring-1 ring-rose-400' 
                              : 'bg-emerald-600 hover:bg-emerald-700'
                          }`}
                        >
                          <MessageSquare className="w-3.5 h-3.5" />
                          <span>WA</span>
                        </button>

                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            openKtaModal(c);
                          }}
                          title="Lihat KTA Digital"
                          aria-label="Lihat KTA Digital"
                          className="h-8 px-2.5 bg-slate-900 hover:bg-slate-800 dark:bg-slate-800 dark:hover:bg-slate-700 text-white text-xs font-bold rounded-xl flex items-center gap-1 shadow-sm transition-all active:scale-95 cursor-pointer border border-slate-700/50"
                        >
                          <QrCode className="w-3.5 h-3.5 text-emerald-400" />
                          <span>KTA</span>
                        </button>

                        {isSuperAdminOrOfficer && (
                          <>
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                handleOpenEditCitizenModal(c);
                              }}
                              title="Edit Data Master KK"
                              aria-label="Edit Data Master KK"
                              className="h-8 w-8 flex items-center justify-center text-slate-600 dark:text-slate-300 hover:text-emerald-700 dark:hover:text-emerald-300 bg-slate-50 dark:bg-slate-800/80 hover:bg-emerald-100/80 dark:hover:bg-emerald-900/60 rounded-xl border border-slate-200/80 dark:border-slate-700/80 hover:border-emerald-300 dark:hover:border-emerald-600/60 transition-all active:scale-90 cursor-pointer shadow-xs focus:outline-none focus:ring-2 focus:ring-emerald-500/40"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>

                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                handleOpenAddMemberModal(c);
                              }}
                              title="Tambah Jiwa ke KK Ini"
                              aria-label="Tambah Jiwa ke KK Ini"
                              className="h-8 w-8 flex items-center justify-center text-slate-600 dark:text-slate-300 hover:text-blue-700 dark:hover:text-blue-300 bg-slate-50 dark:bg-slate-800/80 hover:bg-blue-100/80 dark:hover:bg-blue-900/60 rounded-xl border border-slate-200/80 dark:border-slate-700/80 hover:border-blue-300 dark:hover:border-blue-600/60 transition-all active:scale-90 cursor-pointer shadow-xs focus:outline-none focus:ring-2 focus:ring-blue-500/40"
                            >
                              <UserPlus className="w-3.5 h-3.5" />
                            </button>

                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                handleDeleteCitizen(c);
                              }}
                              title="Hapus Seluruh Data KK"
                              aria-label="Hapus Seluruh Data KK"
                              className="h-8 w-8 flex items-center justify-center text-slate-400 dark:text-slate-500 hover:text-rose-600 dark:hover:text-rose-400 bg-slate-50 dark:bg-slate-800/80 hover:bg-rose-50 dark:hover:bg-rose-950/60 rounded-xl border border-slate-200/80 dark:border-slate-700/80 hover:border-rose-300 dark:hover:border-rose-700/60 transition-all active:scale-90 cursor-pointer shadow-xs focus:outline-none focus:ring-2 focus:ring-rose-500/40"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Right Column: Family Members Management & Edit Panel (5 Cols) */}
        <div className="lg:col-span-5">
          {selectedCitizen ? (
            <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 p-5 sm:p-6 shadow-sm space-y-4 sticky top-20">
              
              {/* Selected Citizen KK Header */}
              <div className="pb-4 border-b border-slate-100 dark:border-slate-800">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <span className="text-[10px] font-black text-emerald-700 dark:text-emerald-400 uppercase tracking-wider bg-emerald-100 dark:bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-200/60 dark:border-emerald-800/60">
                      MANAJEMEN ANGGOTA JIWA (KK)
                    </span>
                    <h2 className="font-black text-lg text-slate-900 dark:text-white mt-1">
                      {selectedCitizen.headOfFamily}
                    </h2>
                    <p className="text-xs text-slate-500 dark:text-slate-400 font-mono mt-0.5">
                      No. KK: <strong className="text-slate-700 dark:text-slate-200">{selectedCitizen.noKK}</strong>
                    </p>
                    <p className="text-xs text-slate-600 dark:text-slate-300 mt-0.5">
                      {selectedCitizen.block || 'Blok'} {selectedCitizen.houseNumber || ''} • {selectedCitizen.communityType === 'Paguyuban' ? selectedCitizen.paguyubanName : `RT ${selectedCitizen.rt}/RW ${selectedCitizen.rw}`}
                    </p>
                  </div>

                  {isSuperAdminOrOfficer && (
                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => handleOpenEditCitizenModal(selectedCitizen)}
                        title="Edit Data Master KK"
                        className="h-9 px-3 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-xl transition-all flex items-center gap-1 text-xs font-bold border border-slate-200/80 dark:border-slate-700/80 cursor-pointer"
                      >
                        <Edit className="w-3.5 h-3.5" />
                        <span className="hidden sm:inline">Edit KK</span>
                      </button>

                      <button
                        onClick={() => handleOpenAddMemberModal(selectedCitizen)}
                        className="h-9 px-3.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center gap-1 shadow-sm transition-all cursor-pointer"
                      >
                        <UserPlus className="w-3.5 h-3.5" />
                        <span>+ Jiwa</span>
                      </button>
                    </div>
                  )}
                </div>
              </div>

              {/* Members List with Full Super Admin Control */}
              <div className="space-y-3">
                <div className="flex items-center justify-between text-xs font-bold text-slate-600 dark:text-slate-300">
                  <span>Daftar Anggota Keluarga ({selectedCitizen.members.length} Jiwa)</span>
                  <span className="text-[11px] text-emerald-700 dark:text-emerald-400 font-semibold">Super Admin dapat merubah data</span>
                </div>

                <div className="space-y-2.5 max-h-[420px] overflow-y-auto pr-1">
                  {selectedCitizen.members.map((m, idx) => {
                    const isCore = (m.category === 'Inti') || (!m.category && (CORE_RELATIONS as readonly string[]).includes(m.relation)) || m.relation === 'Kepala Keluarga';
                    
                    return (
                      <div 
                        key={m.id} 
                        className={`p-3.5 rounded-2xl border transition-all text-xs ${
                          m.status === 'Meninggal' 
                            ? 'bg-slate-100/80 dark:bg-slate-800/40 border-slate-300 dark:border-slate-700 text-slate-500 dark:text-slate-400'
                            : m.status === 'Pindah'
                            ? 'bg-amber-50/60 dark:bg-amber-950/30 border-amber-200 dark:border-amber-900/60'
                            : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200/80 dark:border-slate-700/80 hover:bg-slate-100/50 dark:hover:bg-slate-800'
                        }`}
                      >
                        <div className="flex items-start justify-between gap-2">
                          <div className="space-y-1 flex-1 min-w-0">
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <span className="font-black text-slate-900 dark:text-white text-sm">
                                {idx + 1}. {m.name}
                              </span>
                              
                              <span className={`text-[9px] font-black px-2 py-0.5 rounded ${
                                isCore 
                                  ? 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-900 dark:text-emerald-300 border border-emerald-200/60 dark:border-emerald-800/60' 
                                  : 'bg-amber-100 dark:bg-amber-950/60 text-amber-900 dark:text-amber-300 border border-amber-200/60 dark:border-amber-800/60'
                              }`}>
                                {isCore ? 'Jiwa Inti' : 'Jiwa Tambahan (+Rp 3.000)'}
                              </span>

                              <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded-full ${
                                m.status === 'Hidup' 
                                  ? 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300' 
                                  : m.status === 'Meninggal'
                                  ? 'bg-rose-100 dark:bg-rose-950/60 text-rose-800 dark:text-rose-300'
                                  : 'bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300'
                              }`}>
                                {m.status}
                              </span>

                              {m.socialCategory && m.socialCategory !== 'Umum' && (
                                <span className="text-[9px] font-black px-2 py-0.5 rounded bg-purple-100 dark:bg-purple-950/60 text-purple-900 dark:text-purple-300 border border-purple-200 dark:border-purple-800/60">
                                  🏷️ {m.socialCategory}
                                </span>
                              )}
                            </div>

                            <div className="text-[11px] text-slate-600 dark:text-slate-300 font-mono">
                              NIK: <strong>{m.nik}</strong>
                            </div>

                            <div className="text-[11px] text-slate-600 dark:text-slate-300 flex items-center gap-2 flex-wrap">
                              <span><strong>Hubungan:</strong> {m.relation}</span>
                              <span>•</span>
                              <span><strong>Gender:</strong> {m.gender}</span>
                              {m.birthDate && (
                                <>
                                  <span>•</span>
                                  <span><strong>Lahir:</strong> {formatDateIndo(m.birthDate, false)}</span>
                                </>
                              )}
                            </div>

                            {m.notes && (
                              <div className="text-[10px] text-slate-500 dark:text-slate-400 italic">
                                Catatan: {m.notes}
                              </div>
                            )}
                          </div>

                          {/* Member Actions (Super Admin) */}
                          {isSuperAdminOrOfficer && (
                            <div className="flex flex-col items-end gap-1.5 shrink-0">
                              <div className="flex items-center gap-1">
                                <button
                                  onClick={() => handleOpenEditMemberModal(m)}
                                  title="Ganti / Edit Data Jiwa Ini"
                                  aria-label="Edit Data Jiwa"
                                  className="p-1.5 bg-white dark:bg-slate-800 hover:bg-emerald-50 dark:hover:bg-emerald-950/50 text-slate-700 dark:text-slate-200 hover:text-emerald-700 dark:hover:text-emerald-300 rounded-lg border border-slate-200 dark:border-slate-700 hover:border-emerald-300 dark:hover:border-emerald-600/60 shadow-xs transition-all active:scale-90 cursor-pointer"
                                >
                                  <Edit2 className="w-3.5 h-3.5" />
                                </button>

                                <button
                                  onClick={() => handleDeleteMember(m.id, m.name, m.relation)}
                                  title="Hapus / Kurangi Jiwa Ini"
                                  aria-label="Hapus Jiwa Ini"
                                  className="p-1.5 bg-white dark:bg-slate-800 hover:bg-rose-50 dark:hover:bg-rose-950/50 text-slate-400 dark:text-slate-500 hover:text-rose-600 dark:hover:text-rose-400 rounded-lg border border-slate-200 dark:border-slate-700 hover:border-rose-300 dark:hover:border-rose-700/60 shadow-xs transition-all active:scale-90 cursor-pointer"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </div>

                              {/* Quick status dropdown */}
                              <select
                                value={m.status}
                                onChange={(e) => handleQuickStatusChange(m.id, e.target.value as MemberStatus)}
                                className="text-[10px] py-0.5 px-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-md font-semibold text-slate-700 dark:text-slate-200 cursor-pointer"
                              >
                                <option value="Hidup">Hidup</option>
                                <option value="Meninggal">Meninggal</option>
                                <option value="Pindah">Pindah</option>
                              </select>
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Dues Calculation Breakdown */}
              <div className="p-4 bg-emerald-50/80 dark:bg-emerald-950/40 rounded-2xl border border-emerald-200/70 dark:border-emerald-800/60 text-xs space-y-2 text-emerald-950 dark:text-emerald-100">
                <div className="flex items-center justify-between font-bold">
                  <span>Kalkulasi Iuran Bulanan Resmi:</span>
                  <span className="font-mono text-base font-black text-emerald-800 dark:text-emerald-300">
                    {selectedCitizenDues ? formatRupiah(selectedCitizenDues.totalMonthlyDues) : formatRupiah(5000)} / bln
                  </span>
                </div>
                {selectedCitizenDues && (
                  <div className="text-[11px] text-emerald-800 dark:text-emerald-300 space-y-0.5">
                    <p>
                      • <strong>Pokok 1 Keluarga:</strong> {formatRupiah(selectedCitizenDues.baseFee)} (Mencakup KK & {selectedCitizenDues.coreMembersCount} Jiwa Inti)
                    </p>
                    {selectedCitizenDues.extraMembersCount > 0 ? (
                      <p>
                        • <strong>{selectedCitizenDues.extraMembersCount} Jiwa Tambahan:</strong> +{formatRupiah(selectedCitizenDues.totalExtraDues)} ({formatRupiah(extraRate)} / jiwa)
                      </p>
                    ) : (
                      <p className="text-emerald-700 dark:text-emerald-400 italic">• Tidak ada anggota tambahan dikenakan biaya ekstra.</p>
                    )}
                  </div>
                )}
                <div className="pt-2 border-t border-emerald-200/50 dark:border-emerald-800/50 flex items-center justify-between text-[11px] text-emerald-900 dark:text-emerald-200">
                  <span>Tgl Bergabung: {formatDateIndo(selectedCitizen.joinDate, false)}</span>
                  <span className="font-bold">
                    {Object.values(selectedCitizen.monthlyDues).filter(m => (m as any).paid).length} / 12 Bulan Lunas (2026)
                  </span>
                </div>
              </div>

              {/* Action Buttons: KTA, WhatsApp & PDF KK */}
              <div className="space-y-2 pt-1">
                <button
                  onClick={() => handleOpenWhatsAppModal(selectedCitizen, getCitizenUnpaidMonthsCount(selectedCitizen) > 3 ? 'reminder' : 'custom')}
                  id="btn-open-wa-gateway-detail"
                  className="w-full h-11 px-4 bg-emerald-600 hover:bg-emerald-700 active:scale-98 text-white text-xs font-bold rounded-2xl shadow-sm transition-all flex items-center justify-center gap-2 cursor-pointer border border-emerald-500/40"
                  title="Kirim Pesan WhatsApp Resmi ke Warga (Pengingat Iuran / Kabar Duka / Konfirmasi KTA)"
                >
                  <MessageSquare className="w-4 h-4 text-emerald-200" />
                  <span>Integrasi WhatsApp: Kirim Pengingat Iuran / Kabar Duka</span>
                </button>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <button
                    onClick={() => exportSingleCitizenFamilyPdf(selectedCitizen, settings)}
                    id="btn-download-pdf-family-doc"
                    className="h-11 px-3 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold rounded-2xl shadow transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-98 border border-emerald-600/40"
                    title="Unduh Dokumen Berkas Kartu Keluarga (PDF Resmi A4)"
                  >
                    <Download className="w-4 h-4 text-emerald-300" />
                    <span>Unduh Dokumen KK (PDF)</span>
                  </button>

                  <button
                    onClick={() => openKtaModal(selectedCitizen)}
                    id="btn-open-kta-card"
                    className="h-11 px-3 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-2xl shadow transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-98 border border-slate-700/50"
                  >
                    <QrCode className="w-4 h-4 text-emerald-400" />
                    <span>Buka KTA Digital</span>
                  </button>
                </div>
              </div>

              {/* Pemetaan Koordinat Lokasi Rumah Warga (OpenStreetMap) */}
              <CitizenLocationMap citizen={selectedCitizen} onNotify={showToast} />

            </div>
          ) : (
            <div className="bg-slate-50 rounded-3xl border border-dashed border-slate-300 p-12 text-center text-xs text-slate-400">
              <Users className="w-10 h-10 mx-auto text-slate-300 mb-2" />
              Pilih salah satu Kepala Keluarga di sebelah kiri untuk melihat & mengelola rincian anggota keluarga.
            </div>
          )}
        </div>

      </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 1: TAMBAH WARGA / KK BARU */}
      {/* ========================================================================= */}
      {showAddCitizenModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-sm animate-fade-in">
          <div className="bg-white rounded-3xl p-6 max-w-lg w-full shadow-2xl border border-slate-100 max-h-[90vh] overflow-y-auto">
            
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-emerald-100 text-emerald-800 rounded-xl">
                  <UserPlus className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-base text-slate-900">
                    Tambah Data Warga / KK Baru
                  </h3>
                  <p className="text-xs text-slate-500">Pendaftaran Kepala Keluarga dan pembuatan KK baru</p>
                </div>
              </div>
              <button
                onClick={() => setShowAddCitizenModal(false)}
                className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddCitizenSubmit} className="mt-4 space-y-3.5 text-xs">
              {/* Avatar Upload */}
              <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200">
                <label className="text-slate-700 font-bold block mb-2">Foto Profil / Avatar Kepala Keluarga (Opsional):</label>
                <div className="flex items-center gap-3.5">
                  <div className="relative shrink-0">
                    <img
                      src={getAvatarUrl(headOfFamily || 'Warga Baru', 'warga', avatar)}
                      alt="Avatar Preview"
                      className="w-14 h-14 rounded-2xl object-cover border-2 border-emerald-500 shadow-sm"
                    />
                    {avatar && (
                      <button
                        type="button"
                        onClick={() => setAvatar('')}
                        className="absolute -top-1.5 -right-1.5 p-1 bg-rose-600 text-white rounded-full hover:bg-rose-700 shadow"
                        title="Hapus Foto"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    )}
                  </div>
                  <div className="flex-1">
                    <label className="flex items-center justify-center gap-2 px-3 py-2 bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 rounded-xl cursor-pointer font-bold text-xs shadow-xs transition-colors">
                      <Upload className="w-4 h-4 text-emerald-600" />
                      <span>{avatar ? 'Ganti Foto Avatar' : 'Unggah Foto Avatar'}</span>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={(e) => handleAvatarFileChange(e, false)}
                        className="hidden"
                      />
                    </label>
                    <p className="text-[10px] text-slate-400 mt-1">Format JPG, PNG, WebP (Maks. 3MB)</p>
                  </div>
                </div>
              </div>

              <div>
                <label className="text-slate-700 font-bold block mb-1">Nama Lengkap Kepala Keluarga:</label>
                <input
                  type="text"
                  placeholder="Contoh: Bpk. Bambang Supriyadi"
                  value={headOfFamily}
                  onChange={(e) => setHeadOfFamily(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-bold text-slate-900 focus:ring-2 focus:ring-emerald-500"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-700 font-bold block mb-1">Nomor Kartu Keluarga (KK):</label>
                  <input
                    type="text"
                    maxLength={16}
                    placeholder="16 Digit No KK"
                    value={noKK}
                    onChange={(e) => setNoKK(e.target.value.replace(/\D/g, ''))}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-mono focus:ring-2 focus:ring-emerald-500"
                    required
                  />
                </div>

                <div>
                  <label className="text-slate-700 font-bold block mb-1">NIK Kepala Keluarga:</label>
                  <input
                    type="text"
                    maxLength={16}
                    placeholder="16 Digit NIK"
                    value={nik}
                    onChange={(e) => setNik(e.target.value.replace(/\D/g, ''))}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-mono focus:ring-2 focus:ring-emerald-500"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-700 font-bold block mb-1">No. Handphone (WhatsApp):</label>
                  <input
                    type="text"
                    placeholder="Contoh: 081234567890"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                {/* Blok selection */}
                <div>
                  <label className="text-slate-700 font-bold block mb-1">Pilihan Blok:</label>
                  <select
                    value={block}
                    onChange={(e) => setBlock(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-bold focus:ring-2 focus:ring-emerald-500"
                  >
                    {blockOptions.map(b => (
                      <option key={b} value={b}>{b}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-700 font-bold block mb-1">Nomor Rumah:</label>
                  <input
                    type="text"
                    placeholder="Contoh: No. 12"
                    value={houseNumber}
                    onChange={(e) => setHouseNumber(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="text-slate-700 font-bold block mb-1">Kelompok Komunitas:</label>
                  <select
                    value={communityType}
                    onChange={(e) => setCommunityType(e.target.value as CommunityType)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-bold focus:ring-2 focus:ring-emerald-500"
                  >
                    <option value="RT">Wilayah RT</option>
                    <option value="Paguyuban">Paguyuban</option>
                  </select>
                </div>
              </div>

              {communityType === 'RT' ? (
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-slate-700 font-bold block mb-1">Wilayah RT:</label>
                    <select
                      value={rt}
                      onChange={(e) => setRt(e.target.value)}
                      className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-semibold focus:ring-2 focus:ring-emerald-500"
                    >
                      {rtOptions.map(r => (
                        <option key={r} value={r}>RT {r}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="text-slate-700 font-bold block mb-1">Wilayah RW:</label>
                    <select
                      value={rw}
                      onChange={(e) => setRw(e.target.value)}
                      className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-semibold focus:ring-2 focus:ring-emerald-500"
                    >
                      {rwOptions.map(w => (
                        <option key={w} value={w}>RW {w}</option>
                      ))}
                    </select>
                  </div>
                </div>
              ) : (
                <div>
                  <label className="text-slate-700 font-bold block mb-1">Nama Paguyuban:</label>
                  <select
                    value={paguyubanName}
                    onChange={(e) => setPaguyubanName(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-bold focus:ring-2 focus:ring-emerald-500"
                  >
                    {paguyubanOptions.map(p => (
                      <option key={p} value={p}>{p}</option>
                    ))}
                  </select>
                </div>
              )}

              {/* Koordinator Pembayaran Penanggung Jawab (Downline) */}
              <div>
                <label className="text-slate-700 font-bold block mb-1">
                  Koordinator Penanggung Jawab (Downline):
                </label>
                <select
                  value={assignedCollectorId}
                  onChange={(e) => setAssignedCollectorId(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-semibold focus:ring-2 focus:ring-emerald-500 text-slate-800"
                >
                  <option value="">-- Otomatis Sesuai Blok / RT --</option>
                  {coordinatorUsers.map(u => (
                    <option key={u.id} value={u.id}>
                      {u.name} ({u.role.toUpperCase()} {u.assignedBlocks ? `- Blok ${u.assignedBlocks.join(',')}` : ''})
                    </option>
                  ))}
                </select>
                <p className="text-[10px] text-slate-400 mt-1">Koordinator ini yang berwenang menagih & mencatat iuran warga ini.</p>
              </div>

              <div>
                <label className="text-slate-700 font-bold block mb-1">Alamat Tambahan / Patokan (Opsional):</label>
                <input
                  type="text"
                  placeholder="Contoh: Dekat Pos Satpam Blok A"
                  value={addressDetail}
                  onChange={(e) => setAddressDetail(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddCitizenModal(false)}
                  className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow transition-all"
                >
                  Daftarkan Warga Baru
                </button>
              </div>
            </form>

          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 2: EDIT DATA MASTER KK & KEPALA KELUARGA (SUPER ADMIN) */}
      {/* ========================================================================= */}
      {showEditCitizenModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-sm animate-fade-in">
          <div className="bg-white rounded-3xl p-6 max-w-lg w-full shadow-2xl border border-slate-100 max-h-[90vh] overflow-y-auto">
            
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-emerald-100 text-emerald-800 rounded-xl">
                  <Edit className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-base text-slate-900">
                    Edit Data Master Kartu Keluarga (KK)
                  </h3>
                  <p className="text-xs text-slate-500">Perbarui identitas KK, alamat, blok, dan status warga</p>
                </div>
              </div>
              <button
                onClick={() => setShowEditCitizenModal(false)}
                className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleEditCitizenSubmit} className="mt-4 space-y-3.5 text-xs">
              {/* Avatar Photo Edit */}
              <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200">
                <label className="text-slate-700 font-bold block mb-2">Foto Profil / Avatar Kepala Keluarga:</label>
                <div className="flex items-center gap-3.5">
                  <div className="relative shrink-0">
                    <img
                      src={getAvatarUrl(editHeadOfFamily || 'Warga', 'warga', editAvatar)}
                      alt="Avatar Preview"
                      className="w-14 h-14 rounded-2xl object-cover border-2 border-emerald-500 shadow-sm"
                    />
                    {editAvatar && (
                      <button
                        type="button"
                        onClick={() => setEditAvatar('')}
                        className="absolute -top-1.5 -right-1.5 p-1 bg-rose-600 text-white rounded-full hover:bg-rose-700 shadow"
                        title="Hapus Foto Kustom"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    )}
                  </div>
                  <div className="flex-1">
                    <label className="flex items-center justify-center gap-2 px-3 py-2 bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 rounded-xl cursor-pointer font-bold text-xs shadow-xs transition-colors">
                      <Upload className="w-4 h-4 text-emerald-600" />
                      <span>{editAvatar ? 'Ganti Foto Avatar' : 'Unggah Foto Avatar Baru'}</span>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={(e) => handleAvatarFileChange(e, true)}
                        className="hidden"
                      />
                    </label>
                    <p className="text-[10px] text-slate-400 mt-1">Format JPG, PNG, WebP (Maks. 3MB)</p>
                  </div>
                </div>
              </div>

              <div>
                <label className="text-slate-700 font-bold block mb-1">Nama Kepala Keluarga:</label>
                <input
                  type="text"
                  value={editHeadOfFamily}
                  onChange={(e) => setEditHeadOfFamily(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-bold text-slate-900 focus:ring-2 focus:ring-emerald-500"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-700 font-bold block mb-1">Nomor Kartu Keluarga (No. KK):</label>
                  <input
                    type="text"
                    maxLength={16}
                    value={editNoKK}
                    onChange={(e) => setEditNoKK(e.target.value.replace(/\D/g, ''))}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-mono focus:ring-2 focus:ring-emerald-500"
                    required
                  />
                </div>

                <div>
                  <label className="text-slate-700 font-bold block mb-1">NIK Kepala Keluarga:</label>
                  <input
                    type="text"
                    maxLength={16}
                    value={editNik}
                    onChange={(e) => setEditNik(e.target.value.replace(/\D/g, ''))}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-mono focus:ring-2 focus:ring-emerald-500"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-700 font-bold block mb-1">No. Handphone (WhatsApp):</label>
                  <input
                    type="text"
                    value={editPhone}
                    onChange={(e) => setEditPhone(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="text-slate-700 font-bold block mb-1">Pilihan Blok:</label>
                  <select
                    value={editBlock}
                    onChange={(e) => setEditBlock(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-bold focus:ring-2 focus:ring-emerald-500"
                  >
                    {blockOptions.map(b => (
                      <option key={b} value={b}>{b}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-700 font-bold block mb-1">Nomor Rumah:</label>
                  <input
                    type="text"
                    value={editHouseNumber}
                    onChange={(e) => setEditHouseNumber(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="text-slate-700 font-bold block mb-1">Status Keaktifan KK:</label>
                  <select
                    value={editStatus}
                    onChange={(e) => setEditStatus(e.target.value as any)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-bold focus:ring-2 focus:ring-emerald-500"
                  >
                    <option value="Aktif">Aktif</option>
                    <option value="Non-Aktif">Non-Aktif</option>
                    <option value="Pindah">Pindah</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-700 font-bold block mb-1">Kelompok Komunitas:</label>
                  <select
                    value={editCommunityType}
                    onChange={(e) => setEditCommunityType(e.target.value as CommunityType)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-bold focus:ring-2 focus:ring-emerald-500"
                  >
                    <option value="RT">Wilayah RT</option>
                    <option value="Paguyuban">Paguyuban</option>
                  </select>
                </div>

                {editCommunityType === 'RT' ? (
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="text-slate-700 font-bold block mb-1">Wilayah RT:</label>
                      <select
                        value={editRt}
                        onChange={(e) => setEditRt(e.target.value)}
                        className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-semibold focus:ring-2 focus:ring-emerald-500"
                      >
                        {rtOptions.map(r => (
                          <option key={r} value={r}>RT {r}</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="text-slate-700 font-bold block mb-1">Wilayah RW:</label>
                      <select
                        value={editRw}
                        onChange={(e) => setEditRw(e.target.value)}
                        className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-semibold focus:ring-2 focus:ring-emerald-500"
                      >
                        {rwOptions.map(w => (
                          <option key={w} value={w}>RW {w}</option>
                        ))}
                      </select>
                    </div>
                  </div>
                ) : (
                  <div>
                    <label className="text-slate-700 font-bold block mb-1">Nama Paguyuban:</label>
                    <select
                      value={editPaguyubanName}
                      onChange={(e) => setEditPaguyubanName(e.target.value)}
                      className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-bold focus:ring-2 focus:ring-emerald-500"
                    >
                      {paguyubanOptions.map(p => (
                        <option key={p} value={p}>{p}</option>
                      ))}
                    </select>
                  </div>
                )}
              </div>

              {/* Koordinator Penanggung Jawab Edit */}
              <div>
                <label className="text-slate-700 font-bold block mb-1">
                  Koordinator Penanggung Jawab (Downline):
                </label>
                <select
                  value={editAssignedCollectorId}
                  onChange={(e) => setEditAssignedCollectorId(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-semibold focus:ring-2 focus:ring-emerald-500 text-slate-800"
                >
                  <option value="">-- Otomatis Sesuai Blok / RT --</option>
                  {coordinatorUsers.map(u => (
                    <option key={u.id} value={u.id}>
                      {u.name} ({u.role.toUpperCase()} {u.assignedBlocks ? `- Blok ${u.assignedBlocks.join(',')}` : ''})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-slate-700 font-bold block mb-1">Alamat Lengkap:</label>
                <input
                  type="text"
                  value={editAddressDetail}
                  onChange={(e) => setEditAddressDetail(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="text-slate-700 font-bold block mb-1">Catatan Khusus (Opsional):</label>
                <input
                  type="text"
                  placeholder="Catatan tambahan..."
                  value={editNotes}
                  onChange={(e) => setEditNotes(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowEditCitizenModal(false)}
                  className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow transition-all"
                >
                  Simpan Perubahan KK
                </button>
              </div>
            </form>

          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 3: PENAMBAHAN ANGGOTA JIWA DALAM SATU KK */}
      {/* ========================================================================= */}
      {showAddMemberModal && selectedCitizen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-sm animate-fade-in">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full shadow-2xl border border-slate-100 max-h-[90vh] overflow-y-auto">
            
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-emerald-100 text-emerald-800 rounded-xl">
                  <UserPlus className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-base text-slate-900">
                    Tambah Anggota Jiwa Baru
                  </h3>
                  <p className="text-xs text-slate-500">Penambahan jiwa ke KK Bpk. <strong>{selectedCitizen.headOfFamily}</strong></p>
                </div>
              </div>
              <button
                onClick={() => setShowAddMemberModal(false)}
                className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddMemberSubmit} className="mt-4 space-y-3.5 text-xs">
              <div>
                <label className="text-slate-700 font-bold block mb-1">Nama Lengkap Anggota Jiwa:</label>
                <input
                  type="text"
                  placeholder="Nama anggota keluarga baru"
                  value={memberName}
                  onChange={(e) => setMemberName(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-bold focus:ring-2 focus:ring-emerald-500"
                  required
                />
              </div>

              <div>
                <label className="text-slate-700 font-bold block mb-1">Nomor Induk Kependudukan (NIK):</label>
                <input
                  type="text"
                  maxLength={16}
                  placeholder="16 Digit NIK"
                  value={memberNik}
                  onChange={(e) => setMemberNik(e.target.value.replace(/\D/g, ''))}
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-mono focus:ring-2 focus:ring-emerald-500"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-700 font-bold block mb-1">Hubungan Keluarga:</label>
                  <select
                    value={memberRelation}
                    onChange={(e) => {
                      const rel = e.target.value as RelationType;
                      setMemberRelation(rel);
                      setMemberCategory(getMemberCategory(rel));
                    }}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-bold focus:ring-2 focus:ring-emerald-500"
                  >
                    <optgroup label="Anggota Inti (Termasuk Rp 5.000)">
                      <option value="Istri">Istri</option>
                      <option value="Suami">Suami</option>
                      <option value="Anak">Anak</option>
                      <option value="Orang Tua">Orang Tua (Ayah / Ibu)</option>
                      <option value="Mertua">Mertua (Ayah / Ibu Mertua)</option>
                    </optgroup>
                    <optgroup label="Anggota Tambahan (+Rp 3.000/bln)">
                      <option value="Adik">Adik</option>
                      <option value="Kakak">Kakak</option>
                      <option value="Saudara">Saudara / Famili</option>
                      <option value="Famili Lain">Famili Lain</option>
                    </optgroup>
                  </select>
                </div>

                <div>
                  <label className="text-slate-700 font-bold block mb-1">Kategori Jiwa:</label>
                  <select
                    value={memberCategory}
                    onChange={(e) => setMemberCategory(e.target.value as MemberCategory)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-bold focus:ring-2 focus:ring-emerald-500"
                  >
                    <option value="Inti">Jiwa Inti (Gratis / Termasuk Pokok)</option>
                    <option value="Tambahan">Jiwa Tambahan (+Rp 3.000/bln)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-700 font-bold block mb-1">Jenis Kelamin:</label>
                  <select
                    value={memberGender}
                    onChange={(e) => setMemberGender(e.target.value as GenderType)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-semibold focus:ring-2 focus:ring-emerald-500"
                  >
                    <option value="Laki-laki">Laki-laki</option>
                    <option value="Perempuan">Perempuan</option>
                  </select>
                </div>

                <div>
                  <label className="text-slate-700 font-bold block mb-1">Status Jiwa:</label>
                  <select
                    value={memberStatus}
                    onChange={(e) => setMemberStatus(e.target.value as MemberStatus)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-semibold focus:ring-2 focus:ring-emerald-500"
                  >
                    <option value="Hidup">Hidup</option>
                    <option value="Meninggal">Meninggal</option>
                    <option value="Pindah">Pindah</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-700 font-bold block mb-1">Tanggal Lahir (Opsional):</label>
                  <input
                    type="date"
                    value={memberBirthDate}
                    onChange={(e) => setMemberBirthDate(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="text-slate-700 font-bold block mb-1">Kategori Khusus:</label>
                  <select
                    value={memberSocialCategory}
                    onChange={(e) => setMemberSocialCategory(e.target.value as SocialCategoryType)}
                    className="w-full p-2.5 bg-purple-50 border border-purple-300 text-purple-900 rounded-xl font-bold focus:ring-2 focus:ring-purple-500"
                  >
                    <option value="Umum">Umum (Bukan Kategori Khusus)</option>
                    <option value="Yatim">👦 Anak Yatim</option>
                    <option value="Piatu">👧 Anak Piatu</option>
                    <option value="Yatim Piatu">👶 Yatim Piatu</option>
                    <option value="Janda">👩 Ibu Janda</option>
                    <option value="Duda">👨 Duda</option>
                    <option value="Lansia">👴👵 Lansia</option>
                    <option value="Disabilitas">♿ Penyandang Disabilitas</option>
                    <option value="Dhuafa">🤲 Kaum Dhuafa</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-slate-700 font-bold block mb-1">Catatan / Keterangan (Opsional):</label>
                <input
                  type="text"
                  placeholder="Keterangan tambahan..."
                  value={memberNotes}
                  onChange={(e) => setMemberNotes(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div className="p-3 bg-emerald-50 rounded-2xl text-[11px] text-emerald-900 space-y-1">
                <p className="font-bold">
                  Skema Iuran: {memberCategory === 'Inti' ? 'Anggota Inti (Termasuk paket Rp 5.000/bln)' : 'Anggota Tambahan (+Rp 3.000/bln ke iuran KK)'}
                </p>
                <p className="text-emerald-700">Total iuran bulanan KK akan otomatis terkalkulasi ulang setelah penambahan.</p>
              </div>

              <div className="pt-3 border-t border-slate-100 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddMemberModal(false)}
                  className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow transition-all"
                >
                  Simpan Jiwa Baru
                </button>
              </div>
            </form>

          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 4: EDIT / GANTI DATA ANGGOTA JIWA YANG ADA (SUPER ADMIN) */}
      {/* ========================================================================= */}
      {showEditMemberModal && selectedCitizen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-sm animate-fade-in">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full shadow-2xl border border-slate-100 max-h-[90vh] overflow-y-auto">
            
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-emerald-100 text-emerald-800 rounded-xl">
                  <Edit2 className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-base text-slate-900">
                    Edit / Ganti Data Jiwa
                  </h3>
                  <p className="text-xs text-slate-500">Perbarui identitas atau ganti anggota keluarga</p>
                </div>
              </div>
              <button
                onClick={() => setShowEditMemberModal(false)}
                className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleEditMemberSubmit} className="mt-4 space-y-3.5 text-xs">
              <div>
                <label className="text-slate-700 font-bold block mb-1">Nama Lengkap Anggota Jiwa:</label>
                <input
                  type="text"
                  value={editMemberName}
                  onChange={(e) => setEditMemberName(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-bold text-slate-900 focus:ring-2 focus:ring-emerald-500"
                  required
                />
              </div>

              <div>
                <label className="text-slate-700 font-bold block mb-1">Nomor Induk Kependudukan (NIK):</label>
                <input
                  type="text"
                  maxLength={16}
                  value={editMemberNik}
                  onChange={(e) => setEditMemberNik(e.target.value.replace(/\D/g, ''))}
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-mono focus:ring-2 focus:ring-emerald-500"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-700 font-bold block mb-1">Hubungan Keluarga:</label>
                  <select
                    value={editMemberRelation}
                    onChange={(e) => {
                      const rel = e.target.value as RelationType;
                      setEditMemberRelation(rel);
                      setEditMemberCategory(getMemberCategory(rel));
                    }}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-bold focus:ring-2 focus:ring-emerald-500"
                  >
                    <option value="Kepala Keluarga">Kepala Keluarga</option>
                    <optgroup label="Anggota Inti (Termasuk Rp 5.000)">
                      <option value="Istri">Istri</option>
                      <option value="Suami">Suami</option>
                      <option value="Anak">Anak</option>
                      <option value="Orang Tua">Orang Tua (Ayah / Ibu)</option>
                      <option value="Mertua">Mertua (Ayah / Ibu Mertua)</option>
                    </optgroup>
                    <optgroup label="Anggota Tambahan (+Rp 3.000/bln)">
                      <option value="Adik">Adik</option>
                      <option value="Kakak">Kakak</option>
                      <option value="Saudara">Saudara / Famili</option>
                      <option value="Famili Lain">Famili Lain</option>
                    </optgroup>
                  </select>
                </div>

                <div>
                  <label className="text-slate-700 font-bold block mb-1">Kategori Jiwa:</label>
                  <select
                    value={editMemberCategory}
                    onChange={(e) => setEditMemberCategory(e.target.value as MemberCategory)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-bold focus:ring-2 focus:ring-emerald-500"
                  >
                    <option value="Inti">Jiwa Inti (Gratis / Paket KK)</option>
                    <option value="Tambahan">Jiwa Tambahan (+Rp 3.000/bln)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-700 font-bold block mb-1">Jenis Kelamin:</label>
                  <select
                    value={editMemberGender}
                    onChange={(e) => setEditMemberGender(e.target.value as GenderType)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-semibold focus:ring-2 focus:ring-emerald-500"
                  >
                    <option value="Laki-laki">Laki-laki</option>
                    <option value="Perempuan">Perempuan</option>
                  </select>
                </div>

                <div>
                  <label className="text-slate-700 font-bold block mb-1">Status Keberadaan:</label>
                  <select
                    value={editMemberStatus}
                    onChange={(e) => setEditMemberStatus(e.target.value as MemberStatus)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-bold focus:ring-2 focus:ring-emerald-500"
                  >
                    <option value="Hidup">Hidup (Aktif)</option>
                    <option value="Meninggal">Meninggal (Alm/Almh)</option>
                    <option value="Pindah">Pindah Domisili</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-700 font-bold block mb-1">Tanggal Lahir (Opsional):</label>
                  <input
                    type="date"
                    value={editMemberBirthDate}
                    onChange={(e) => setEditMemberBirthDate(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="text-slate-700 font-bold block mb-1">Kategori Khusus:</label>
                  <select
                    value={editMemberSocialCategory}
                    onChange={(e) => setEditMemberSocialCategory(e.target.value as SocialCategoryType)}
                    className="w-full p-2.5 bg-purple-50 border border-purple-300 text-purple-900 rounded-xl font-bold focus:ring-2 focus:ring-purple-500"
                  >
                    <option value="Umum">Umum (Bukan Kategori Khusus)</option>
                    <option value="Yatim">👦 Anak Yatim</option>
                    <option value="Piatu">👧 Anak Piatu</option>
                    <option value="Yatim Piatu">👶 Yatim Piatu</option>
                    <option value="Janda">👩 Ibu Janda</option>
                    <option value="Duda">👨 Duda</option>
                    <option value="Lansia">👴👵 Lansia</option>
                    <option value="Disabilitas">♿ Penyandang Disabilitas</option>
                    <option value="Dhuafa">🤲 Kaum Dhuafa</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-slate-700 font-bold block mb-1">Catatan / Alasan Perubahan:</label>
                <input
                  type="text"
                  placeholder="Contoh: Koreksi NIK / Penggantian status..."
                  value={editMemberNotes}
                  onChange={(e) => setEditMemberNotes(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowEditMemberModal(false)}
                  className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow transition-all"
                >
                  Simpan Perubahan
                </button>
              </div>
            </form>

          </div>
        </div>
      )}

      {/* WhatsApp Official Message Gateway Modal */}
      {showWhatsAppModal && whatsAppCitizen && (
        <CitizenWhatsAppModal
          citizen={whatsAppCitizen}
          settings={settings}
          deathNotices={deathNotices}
          initialTab={whatsAppInitialTab}
          onClose={() => {
            setShowWhatsAppModal(false);
            setWhatsAppCitizen(null);
          }}
          onToast={showToast}
        />
      )}

      {/* Modal Konfirmasi Hapus KK (Super Admin) */}
      {deleteCitizenConfirmTarget && (
        <div 
          className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4 animate-fade-in"
          onClick={() => setDeleteCitizenConfirmTarget(null)}
        >
          <div 
            className="bg-white dark:bg-slate-900 rounded-3xl max-w-md w-full p-6 shadow-2xl border border-rose-200 dark:border-rose-900/60 space-y-4 animate-scale-up"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-rose-100 dark:bg-rose-950/80 text-rose-600 dark:text-rose-400 flex items-center justify-center shrink-0">
                <ShieldAlert className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base sm:text-lg font-black text-slate-900 dark:text-white">
                  Konfirmasi Hapus Data KK
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Tindakan ini permanen & tidak dapat dibatalkan
                </p>
              </div>
            </div>

            <div className="bg-rose-50/80 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-900/50 p-4 rounded-2xl space-y-2 text-xs">
              <div className="flex justify-between items-center text-slate-700 dark:text-slate-300">
                <span className="font-semibold text-slate-500 dark:text-slate-400">Kepala Keluarga:</span>
                <span className="font-extrabold text-slate-900 dark:text-white">{deleteCitizenConfirmTarget.headOfFamily}</span>
              </div>
              <div className="flex justify-between items-center text-slate-700 dark:text-slate-300">
                <span className="font-semibold text-slate-500 dark:text-slate-400">No. KK:</span>
                <span className="font-mono font-bold text-slate-800 dark:text-slate-200">{deleteCitizenConfirmTarget.noKK}</span>
              </div>
              <div className="flex justify-between items-center text-slate-700 dark:text-slate-300">
                <span className="font-semibold text-slate-500 dark:text-slate-400">Alamat:</span>
                <span className="font-semibold text-slate-800 dark:text-slate-200">{deleteCitizenConfirmTarget.block} {deleteCitizenConfirmTarget.houseNumber || ''}, RT {deleteCitizenConfirmTarget.rt}</span>
              </div>
              <div className="flex justify-between items-center text-slate-700 dark:text-slate-300">
                <span className="font-semibold text-slate-500 dark:text-slate-400">Total Anggota Jiwa:</span>
                <span className="font-bold text-rose-600 dark:text-rose-400 bg-rose-100 dark:bg-rose-950/80 px-2 py-0.5 rounded-md">
                  {deleteCitizenConfirmTarget.members.length} Jiwa
                </span>
              </div>
            </div>

            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              Seluruh riwayat jiwa keluarga dan data terkait kartu anggota ini akan dihapus dari basis data warga RKM.
            </p>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
              <button
                type="button"
                onClick={() => setDeleteCitizenConfirmTarget(null)}
                className="px-4 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 text-xs font-bold rounded-xl transition-all cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={confirmExecuteDeleteCitizen}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold rounded-xl shadow-md transition-all active:scale-95 cursor-pointer flex items-center gap-1.5"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Ya, Hapus Data KK</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal Konfirmasi Hapus Anggota Jiwa */}
      {deleteMemberConfirmTarget && (
        <div 
          className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4 animate-fade-in"
          onClick={() => setDeleteMemberConfirmTarget(null)}
        >
          <div 
            className="bg-white dark:bg-slate-900 rounded-3xl max-w-md w-full p-6 shadow-2xl border border-rose-200 dark:border-rose-900/60 space-y-4 animate-scale-up"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-rose-100 dark:bg-rose-950/80 text-rose-600 dark:text-rose-400 flex items-center justify-center shrink-0">
                <AlertCircle className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base sm:text-lg font-black text-slate-900 dark:text-white">
                  Konfirmasi Pengurangan Jiwa
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Hapus anggota jiwa dari Kartu Keluarga
                </p>
              </div>
            </div>

            <div className="bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 p-4 rounded-2xl space-y-2 text-xs">
              <div className="flex justify-between items-center">
                <span className="font-semibold text-slate-500 dark:text-slate-400">Nama Anggota:</span>
                <span className="font-extrabold text-slate-900 dark:text-white">{deleteMemberConfirmTarget.name}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="font-semibold text-slate-500 dark:text-slate-400">Hubungan:</span>
                <span className="font-bold text-slate-800 dark:text-slate-200 bg-slate-200 dark:bg-slate-700 px-2 py-0.5 rounded">
                  {deleteMemberConfirmTarget.relation}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="font-semibold text-slate-500 dark:text-slate-400">Dari KK:</span>
                <span className="font-semibold text-slate-800 dark:text-slate-200">{deleteMemberConfirmTarget.headName}</span>
              </div>
            </div>

            {deleteMemberConfirmTarget.relation === 'Kepala Keluarga' && (
              <div className="p-3 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/60 rounded-xl text-amber-800 dark:text-amber-300 text-xs font-semibold flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-amber-600 dark:text-amber-400" />
                <span>PERHATIAN: Anggota ini terdaftar sebagai Kepala Keluarga utama pada berkas KK.</span>
              </div>
            )}

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
              <button
                type="button"
                onClick={() => setDeleteMemberConfirmTarget(null)}
                className="px-4 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 text-xs font-bold rounded-xl transition-all cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={confirmExecuteDeleteMember}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold rounded-xl shadow-md transition-all active:scale-95 cursor-pointer flex items-center gap-1.5"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Ya, Hapus Jiwa Ini</span>
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
