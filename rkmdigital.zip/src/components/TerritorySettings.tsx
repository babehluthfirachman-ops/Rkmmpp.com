import React, { useState } from 'react';
import { 
  Map, 
  Plus, 
  Trash2, 
  Save, 
  CheckCircle2, 
  Home, 
  Layers, 
  Building,
  Compass,
  Sparkles,
  Edit2,
  X,
  Check,
  RotateCcw,
  AlertTriangle,
  AlertCircle,
  Info
} from 'lucide-react';
import { OrganizationSettings } from '../types';

interface TerritorySettingsProps {
  formState: OrganizationSettings;
  setFormState: React.Dispatch<React.SetStateAction<OrganizationSettings>>;
  onSave: () => void;
}

type EditCategory = 'rw' | 'rt' | 'paguyuban' | 'block' | null;

interface DeleteConfirmTarget {
  category: 'rw' | 'rt' | 'paguyuban' | 'block';
  categoryLabel: string;
  item: string;
}

export const TerritorySettings: React.FC<TerritorySettingsProps> = ({
  formState,
  setFormState,
  onSave
}) => {
  const [saved, setSaved] = useState(false);
  const [newRw, setNewRw] = useState('');
  const [newRt, setNewRt] = useState('');
  const [newPaguyuban, setNewPaguyuban] = useState('');
  const [newBlock, setNewBlock] = useState('');

  // Editing state
  const [editingCategory, setEditingCategory] = useState<EditCategory>(null);
  const [originalValue, setOriginalValue] = useState('');
  const [editValue, setEditValue] = useState('');

  // Deletion confirmation modal state
  const [deleteTarget, setDeleteTarget] = useState<DeleteConfirmTarget | null>(null);

  // Notification Toast state
  const [toastMsg, setToastMsg] = useState<{ text: string; type: 'success' | 'error' | 'info' } | null>(null);

  const showToast = (text: string, type: 'success' | 'error' | 'info' = 'info') => {
    setToastMsg({ text, type });
    setTimeout(() => setToastMsg(null), 3500);
  };

  const rwList = formState.rwList || ['RW 01', 'RW 02', 'RW 03', 'RW 05', 'RW 08', 'RW 12'];
  const rtList = formState.rtList || ['RT 01', 'RT 02', 'RT 03', 'RT 04', 'RT 05', 'RT 06', 'RT 07', 'RT 08', 'RT 09', 'RT 10', 'RT 11'];
  const paguyubanList = formState.paguyubanList || ['Paguyuban Graha Asri', 'Paguyuban Warga Muslim', 'Paguyuban Griya Parung', 'Paguyuban Sejahtera Mandiri'];
  const blockList = formState.blockList || ['Blok A', 'Blok B', 'Blok C', 'Blok D', 'Blok E', 'Blok F', 'Blok G', 'Blok H', 'Blok I', 'Blok J', 'Blok K', 'Blok L', 'Blok M', 'Blok N'];

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    onSave();
    setSaved(true);
    showToast('Seluruh data master wilayah berhasil disimpan ke database!', 'success');
    setTimeout(() => setSaved(false), 3000);
  };

  // Add RW
  const addRw = () => {
    const trimmed = newRw.trim();
    if (!trimmed) return;
    const formatted = trimmed.toUpperCase().startsWith('RW') ? trimmed.toUpperCase() : `RW ${trimmed.padStart(2, '0')}`;
    if (rwList.includes(formatted)) {
      showToast(`${formatted} sudah ada dalam daftar.`, 'error');
      return;
    }
    const updated = [...rwList, formatted];
    setFormState({ ...formState, rwList: updated });
    setNewRw('');
    showToast(`${formatted} berhasil ditambahkan ke master RW.`, 'success');
  };

  // Confirm delete handler
  const confirmExecuteDelete = () => {
    if (!deleteTarget) return;
    const { category, item } = deleteTarget;

    if (category === 'rw') {
      if (rwList.length <= 1) {
        showToast('Minimal harus ada 1 RW terdaftar.', 'error');
        setDeleteTarget(null);
        return;
      }
      const updated = rwList.filter(rw => rw !== item);
      setFormState({ ...formState, rwList: updated });
      showToast(`${item} berhasil dihapus dari master RW.`, 'success');
    } else if (category === 'rt') {
      if (rtList.length <= 1) {
        showToast('Minimal harus ada 1 RT terdaftar.', 'error');
        setDeleteTarget(null);
        return;
      }
      const updated = rtList.filter(rt => rt !== item);
      setFormState({ ...formState, rtList: updated });
      showToast(`${item} berhasil dihapus dari master RT.`, 'success');
    } else if (category === 'paguyuban') {
      if (paguyubanList.length <= 1) {
        showToast('Minimal harus ada 1 Paguyuban terdaftar.', 'error');
        setDeleteTarget(null);
        return;
      }
      const updated = paguyubanList.filter(p => p !== item);
      setFormState({ ...formState, paguyubanList: updated });
      showToast(`"${item}" berhasil dihapus dari master Paguyuban.`, 'success');
    } else if (category === 'block') {
      if (blockList.length <= 1) {
        showToast('Minimal harus ada 1 Blok terdaftar.', 'error');
        setDeleteTarget(null);
        return;
      }
      const updated = blockList.filter(b => b !== item);
      setFormState({ ...formState, blockList: updated });
      showToast(`${item} berhasil dihapus dari master Blok.`, 'success');
    }

    setDeleteTarget(null);
  };

  // Add RT
  const addRt = () => {
    const trimmed = newRt.trim();
    if (!trimmed) return;
    const formatted = trimmed.toUpperCase().startsWith('RT') ? trimmed.toUpperCase() : `RT ${trimmed.padStart(2, '0')}`;
    if (rtList.includes(formatted)) {
      showToast(`${formatted} sudah ada dalam daftar.`, 'error');
      return;
    }
    const updated = [...rtList, formatted].sort();
    setFormState({ ...formState, rtList: updated });
    setNewRt('');
    showToast(`${formatted} berhasil ditambahkan ke master RT.`, 'success');
  };

  // Add Paguyuban
  const addPaguyuban = () => {
    const trimmed = newPaguyuban.trim();
    if (!trimmed) return;
    if (paguyubanList.includes(trimmed)) {
      showToast(`${trimmed} sudah ada dalam daftar.`, 'error');
      return;
    }
    const updated = [...paguyubanList, trimmed];
    setFormState({ ...formState, paguyubanList: updated });
    setNewPaguyuban('');
    showToast(`"${trimmed}" berhasil ditambahkan ke master Paguyuban.`, 'success');
  };

  // Add Blok
  const addBlock = () => {
    const trimmed = newBlock.trim();
    if (!trimmed) return;
    const formatted = trimmed.toLowerCase().startsWith('blok') ? trimmed : `Blok ${trimmed.toUpperCase()}`;
    if (blockList.includes(formatted)) {
      showToast(`${formatted} sudah ada dalam daftar.`, 'error');
      return;
    }
    const updated = [...blockList, formatted];
    setFormState({ ...formState, blockList: updated });
    setNewBlock('');
    showToast(`${formatted} berhasil ditambahkan ke master Blok.`, 'success');
  };

  // Open Edit Dialog
  const handleOpenEdit = (category: EditCategory, val: string) => {
    setEditingCategory(category);
    setOriginalValue(val);
    setEditValue(val);
  };

  // Save Edit Item
  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = editValue.trim();
    if (!trimmed) return;

    if (editingCategory === 'rw') {
      const formatted = trimmed.toUpperCase().startsWith('RW') ? trimmed.toUpperCase() : `RW ${trimmed.padStart(2, '0')}`;
      const updated = rwList.map(item => item === originalValue ? formatted : item);
      setFormState({ ...formState, rwList: updated });
      showToast(`Master RW diperbarui ke ${formatted}.`, 'success');
    } else if (editingCategory === 'rt') {
      const formatted = trimmed.toUpperCase().startsWith('RT') ? trimmed.toUpperCase() : `RT ${trimmed.padStart(2, '0')}`;
      const updated = rtList.map(item => item === originalValue ? formatted : item);
      setFormState({ ...formState, rtList: updated });
      showToast(`Master RT diperbarui ke ${formatted}.`, 'success');
    } else if (editingCategory === 'paguyuban') {
      const updated = paguyubanList.map(item => item === originalValue ? trimmed : item);
      setFormState({ ...formState, paguyubanList: updated });
      showToast(`Master Paguyuban diperbarui ke "${trimmed}".`, 'success');
    } else if (editingCategory === 'block') {
      const formatted = trimmed.toLowerCase().startsWith('blok') ? trimmed : `Blok ${trimmed.toUpperCase()}`;
      const updated = blockList.map(item => item === originalValue ? formatted : item);
      setFormState({ ...formState, blockList: updated });
      showToast(`Master Blok diperbarui ke ${formatted}.`, 'success');
    }

    setEditingCategory(null);
    setOriginalValue('');
    setEditValue('');
  };

  // Quick Preset Handlers
  const loadPresetRW = () => {
    const preset = ['RW 01', 'RW 02', 'RW 03', 'RW 04', 'RW 05', 'RW 06', 'RW 07', 'RW 08', 'RW 09', 'RW 10', 'RW 11', 'RW 12'];
    setFormState({ ...formState, rwList: preset });
    showToast('Preset standar RW 01 s/d RW 12 berhasil dimuat.', 'info');
  };

  const loadPresetRT = () => {
    const preset = Array.from({ length: 15 }, (_, i) => `RT ${(i + 1).toString().padStart(2, '0')}`);
    setFormState({ ...formState, rtList: preset });
    showToast('Preset standar RT 01 s/d RT 15 berhasil dimuat.', 'info');
  };

  const loadPresetBlocks = () => {
    const preset = Array.from({ length: 26 }, (_, i) => `Blok ${String.fromCharCode(65 + i)}`);
    setFormState({ ...formState, blockList: preset });
    showToast('Preset alfabet Blok A s/d Blok Z berhasil dimuat.', 'info');
  };

  return (
    <form onSubmit={handleSave} className="space-y-6">
      {/* Toast Notification Banner */}
      {toastMsg && (
        <div className={`p-4 rounded-2xl flex items-center justify-between shadow-lg border transition-all animate-fade-in ${
          toastMsg.type === 'success' 
            ? 'bg-emerald-50 dark:bg-emerald-950/80 border-emerald-300 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200'
            : toastMsg.type === 'error'
            ? 'bg-rose-50 dark:bg-rose-950/80 border-rose-300 dark:border-rose-800 text-rose-900 dark:text-rose-200'
            : 'bg-indigo-50 dark:bg-indigo-950/80 border-indigo-300 dark:border-indigo-800 text-indigo-900 dark:text-indigo-200'
        }`}>
          <div className="flex items-center gap-2.5 text-xs font-bold">
            {toastMsg.type === 'success' && <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />}
            {toastMsg.type === 'error' && <AlertCircle className="w-4 h-4 text-rose-600 dark:text-rose-400 shrink-0" />}
            {toastMsg.type === 'info' && <Info className="w-4 h-4 text-indigo-600 dark:text-indigo-400 shrink-0" />}
            <span>{toastMsg.text}</span>
          </div>
          <button 
            type="button" 
            onClick={() => setToastMsg(null)}
            className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-7 border border-slate-200 dark:border-slate-800 shadow-sm space-y-6 transition-colors">
        
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-emerald-100 dark:bg-emerald-900/50 text-emerald-800 dark:text-emerald-300 rounded-2xl">
              <Map className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-extrabold text-base text-slate-900 dark:text-white">
                Master Data Wilayah & Penulisan Alamat
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Input, edit, dan hapus master RW, RT, Paguyuban Komunitas, dan Blok Perumahan untuk penugasan koordinator dan registrasi warga.
              </p>
            </div>
          </div>

          <button
            type="submit"
            className="flex items-center justify-center gap-2 px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white font-bold text-xs rounded-xl shadow-md transition-all self-start sm:self-auto cursor-pointer"
          >
            {saved ? (
              <>
                <CheckCircle2 className="w-4 h-4 text-emerald-200" />
                <span>Tersimpan!</span>
              </>
            ) : (
              <>
                <Save className="w-4 h-4" />
                <span>Simpan Semua Master Wilayah</span>
              </>
            )}
          </button>
        </div>

        {/* 4 Quadrants Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          
          {/* Section 1: Daftar Rukun Warga (RW) */}
          <div className="space-y-4 bg-slate-50/80 dark:bg-slate-800/60 p-5 rounded-2xl border border-slate-200 dark:border-slate-700/80 flex flex-col justify-between">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Compass className="w-4 h-4 text-teal-600 dark:text-teal-400" />
                  <h3 className="font-bold text-sm text-slate-800 dark:text-slate-100">Master Rukun Warga (RW) ({rwList.length} RW)</h3>
                </div>
                <button
                  type="button"
                  onClick={loadPresetRW}
                  className="text-[10px] bg-teal-100 dark:bg-teal-900/60 hover:bg-teal-200 dark:hover:bg-teal-800 text-teal-800 dark:text-teal-200 px-2.5 py-1 rounded-full font-bold transition-all cursor-pointer active:scale-95 border border-teal-200 dark:border-teal-700/60"
                  title="Klik untuk muat preset RW 01-12"
                >
                  Preset Standar
                </button>
              </div>

              {/* Add RW Input */}
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={newRw}
                  onChange={(e) => setNewRw(e.target.value)}
                  onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); addRw(); } }}
                  placeholder="Contoh: RW 08 atau 12"
                  className="flex-1 p-2.5 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl text-xs font-bold text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-teal-500 focus:outline-none"
                />
                <button
                  type="button"
                  onClick={addRw}
                  className="px-3.5 py-2.5 bg-teal-600 hover:bg-teal-700 active:scale-95 text-white font-bold text-xs rounded-xl shadow-xs flex items-center gap-1 cursor-pointer transition-all"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Tambah</span>
                </button>
              </div>

              {/* RW Chips List with Edit and Delete */}
              <div className="flex flex-wrap gap-2 pt-2 max-h-48 overflow-y-auto">
                {rwList.map(rw => (
                  <div
                    key={rw}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-white dark:bg-slate-900 border border-teal-200 dark:border-teal-800/80 rounded-xl shadow-xs text-xs font-bold text-teal-900 dark:text-teal-200 group transition-all hover:border-teal-400 dark:hover:border-teal-600"
                  >
                    <span>{rw}</span>
                    <div className="flex items-center gap-0.5 ml-1">
                      <button
                        type="button"
                        onClick={() => handleOpenEdit('rw', rw)}
                        aria-label={`Edit ${rw}`}
                        className="p-1 hover:bg-teal-50 dark:hover:bg-teal-950/60 text-slate-400 dark:text-slate-500 hover:text-teal-700 dark:hover:text-teal-300 rounded-md border border-transparent hover:border-teal-200 dark:hover:border-teal-800/60 transition-all active:scale-90 cursor-pointer"
                        title={`Edit ${rw}`}
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => setDeleteTarget({ category: 'rw', categoryLabel: 'Rukun Warga (RW)', item: rw })}
                        aria-label={`Hapus ${rw}`}
                        className="p-1 hover:bg-rose-50 dark:hover:bg-rose-950/60 text-slate-400 dark:text-slate-500 hover:text-rose-600 dark:hover:text-rose-400 rounded-md border border-transparent hover:border-rose-200 dark:hover:border-rose-800/60 transition-all active:scale-90 cursor-pointer"
                        title={`Hapus ${rw}`}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 pt-2 border-t border-slate-200/60 dark:border-slate-700/60">
              💡 RW digunakan sebagai induk pembagian wilayah administratif warga dan kuitansi resmi.
            </p>
          </div>

          {/* Section 2: Daftar Rukun Tetangga (RT) */}
          <div className="space-y-4 bg-slate-50/80 dark:bg-slate-800/60 p-5 rounded-2xl border border-slate-200 dark:border-slate-700/80 flex flex-col justify-between">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Home className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                  <h3 className="font-bold text-sm text-slate-800 dark:text-slate-100">Master Rukun Tetangga (RT) ({rtList.length} RT)</h3>
                </div>
                <button
                  type="button"
                  onClick={loadPresetRT}
                  className="text-[10px] bg-emerald-100 dark:bg-emerald-900/60 hover:bg-emerald-200 dark:hover:bg-emerald-800 text-emerald-800 dark:text-emerald-200 px-2.5 py-1 rounded-full font-bold transition-all cursor-pointer active:scale-95 border border-emerald-200 dark:border-emerald-700/60"
                  title="Klik untuk muat preset RT 01-15"
                >
                  Preset Standar
                </button>
              </div>

              {/* Add RT Input */}
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={newRt}
                  onChange={(e) => setNewRt(e.target.value)}
                  onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); addRt(); } }}
                  placeholder="Contoh: RT 12 atau 12"
                  className="flex-1 p-2.5 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl text-xs font-bold text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
                <button
                  type="button"
                  onClick={addRt}
                  className="px-3.5 py-2.5 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white font-bold text-xs rounded-xl shadow-xs flex items-center gap-1 cursor-pointer transition-all"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Tambah</span>
                </button>
              </div>

              {/* RT Chips List with Edit and Delete */}
              <div className="flex flex-wrap gap-2 pt-2 max-h-48 overflow-y-auto">
                {rtList.map(rt => (
                  <div
                    key={rt}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-white dark:bg-slate-900 border border-emerald-200 dark:border-emerald-800/80 rounded-xl shadow-xs text-xs font-bold text-emerald-900 dark:text-emerald-200 group transition-all hover:border-emerald-400 dark:hover:border-emerald-600"
                  >
                    <span>{rt.startsWith('RT') ? rt : `RT ${rt}`}</span>
                    <div className="flex items-center gap-0.5 ml-1">
                      <button
                        type="button"
                        onClick={() => handleOpenEdit('rt', rt)}
                        aria-label={`Edit ${rt}`}
                        className="p-1 hover:bg-emerald-50 dark:hover:bg-emerald-950/60 text-slate-400 dark:text-slate-500 hover:text-emerald-700 dark:hover:text-emerald-300 rounded-md border border-transparent hover:border-emerald-200 dark:hover:border-emerald-800/60 transition-all active:scale-90 cursor-pointer"
                        title={`Edit ${rt}`}
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => setDeleteTarget({ category: 'rt', categoryLabel: 'Rukun Tetangga (RT)', item: rt })}
                        aria-label={`Hapus ${rt}`}
                        className="p-1 hover:bg-rose-50 dark:hover:bg-rose-950/60 text-slate-400 dark:text-slate-500 hover:text-rose-600 dark:hover:text-rose-400 rounded-md border border-transparent hover:border-rose-200 dark:hover:border-rose-800/60 transition-all active:scale-90 cursor-pointer"
                        title={`Hapus ${rt}`}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 pt-2 border-t border-slate-200/60 dark:border-slate-700/60">
              💡 RT digunakan untuk penomoran wilayah warga tipe reguler RT dan ploting koordinator lapangan.
            </p>
          </div>

          {/* Section 3: Master Paguyuban / Komunitas Khusus */}
          <div className="space-y-4 bg-slate-50/80 dark:bg-slate-800/60 p-5 rounded-2xl border border-slate-200 dark:border-slate-700/80 flex flex-col justify-between">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Building className="w-4 h-4 text-amber-600 dark:text-amber-400" />
                  <h3 className="font-bold text-sm text-slate-800 dark:text-slate-100">Master Paguyuban ({paguyubanList.length} Paguyuban)</h3>
                </div>
                <span className="text-[10px] bg-amber-100 dark:bg-amber-900/60 text-amber-800 dark:text-amber-200 border border-amber-200 dark:border-amber-700/60 px-2.5 py-0.5 rounded-full font-bold">
                  Komunitas Khusus
                </span>
              </div>

              {/* Add Paguyuban Input */}
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={newPaguyuban}
                  onChange={(e) => setNewPaguyuban(e.target.value)}
                  onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); addPaguyuban(); } }}
                  placeholder="Contoh: Paguyuban Graha Asri"
                  className="flex-1 p-2.5 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl text-xs font-bold text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-amber-500 focus:outline-none"
                />
                <button
                  type="button"
                  onClick={addPaguyuban}
                  className="px-3.5 py-2.5 bg-amber-600 hover:bg-amber-700 active:scale-95 text-white font-bold text-xs rounded-xl shadow-xs flex items-center gap-1 cursor-pointer transition-all"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Tambah</span>
                </button>
              </div>

              {/* Paguyuban Chips List with Edit and Delete */}
              <div className="flex flex-wrap gap-2 pt-2 max-h-48 overflow-y-auto">
                {paguyubanList.map(paguyuban => (
                  <div
                    key={paguyuban}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-white dark:bg-slate-900 border border-amber-200 dark:border-amber-800/80 rounded-xl shadow-xs text-xs font-bold text-amber-900 dark:text-amber-200 group transition-all hover:border-amber-400 dark:hover:border-amber-600"
                  >
                    <span>{paguyuban}</span>
                    <div className="flex items-center gap-0.5 ml-1">
                      <button
                        type="button"
                        onClick={() => handleOpenEdit('paguyuban', paguyuban)}
                        aria-label={`Edit ${paguyuban}`}
                        className="p-1 hover:bg-amber-50 dark:hover:bg-amber-950/60 text-slate-400 dark:text-slate-500 hover:text-amber-700 dark:hover:text-amber-300 rounded-md border border-transparent hover:border-amber-200 dark:hover:border-amber-800/60 transition-all active:scale-90 cursor-pointer"
                        title={`Edit ${paguyuban}`}
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => setDeleteTarget({ category: 'paguyuban', categoryLabel: 'Paguyuban Khusus', item: paguyuban })}
                        aria-label={`Hapus ${paguyuban}`}
                        className="p-1 hover:bg-rose-50 dark:hover:bg-rose-950/60 text-slate-400 dark:text-slate-500 hover:text-rose-600 dark:hover:text-rose-400 rounded-md border border-transparent hover:border-rose-200 dark:hover:border-rose-800/60 transition-all active:scale-90 cursor-pointer"
                        title={`Hapus ${paguyuban}`}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 pt-2 border-t border-slate-200/60 dark:border-slate-700/60">
              💡 Digunakan apabila anggota terdaftar dalam entitas paguyuban mandiri di luar penomoran RT baku.
            </p>
          </div>

          {/* Section 4: Master Blok Perumahan */}
          <div className="space-y-4 bg-slate-50/80 dark:bg-slate-800/60 p-5 rounded-2xl border border-slate-200 dark:border-slate-700/80 flex flex-col justify-between">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Layers className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                  <h3 className="font-bold text-sm text-slate-800 dark:text-slate-100">Master Blok Perumahan ({blockList.length} Blok)</h3>
                </div>
                <button
                  type="button"
                  onClick={loadPresetBlocks}
                  className="text-[10px] bg-indigo-100 dark:bg-indigo-900/60 hover:bg-indigo-200 dark:hover:bg-indigo-800 text-indigo-800 dark:text-indigo-200 px-2.5 py-1 rounded-full font-bold transition-all cursor-pointer active:scale-95 border border-indigo-200 dark:border-indigo-700/60"
                  title="Klik untuk muat preset Blok A - Z"
                >
                  Preset Blok A-Z
                </button>
              </div>

              {/* Add Block Input */}
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={newBlock}
                  onChange={(e) => setNewBlock(e.target.value)}
                  onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); addBlock(); } }}
                  placeholder="Contoh: Blok O atau O"
                  className="flex-1 p-2.5 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl text-xs font-bold text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                />
                <button
                  type="button"
                  onClick={addBlock}
                  className="px-3.5 py-2.5 bg-indigo-600 hover:bg-indigo-700 active:scale-95 text-white font-bold text-xs rounded-xl shadow-xs flex items-center gap-1 cursor-pointer transition-all"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Tambah</span>
                </button>
              </div>

              {/* Block Chips List with Edit and Delete */}
              <div className="flex flex-wrap gap-2 pt-2 max-h-48 overflow-y-auto">
                {blockList.map(block => (
                  <div
                    key={block}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-white dark:bg-slate-900 border border-indigo-200 dark:border-indigo-800/80 rounded-xl shadow-xs text-xs font-bold text-indigo-900 dark:text-indigo-200 group transition-all hover:border-indigo-400 dark:hover:border-indigo-600"
                  >
                    <span>{block}</span>
                    <div className="flex items-center gap-0.5 ml-1">
                      <button
                        type="button"
                        onClick={() => handleOpenEdit('block', block)}
                        aria-label={`Edit ${block}`}
                        className="p-1 hover:bg-indigo-50 dark:hover:bg-indigo-950/60 text-slate-400 dark:text-slate-500 hover:text-indigo-700 dark:hover:text-indigo-300 rounded-md border border-transparent hover:border-indigo-200 dark:hover:border-indigo-800/60 transition-all active:scale-90 cursor-pointer"
                        title={`Edit ${block}`}
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => setDeleteTarget({ category: 'block', categoryLabel: 'Blok Perumahan', item: block })}
                        aria-label={`Hapus ${block}`}
                        className="p-1 hover:bg-rose-50 dark:hover:bg-rose-950/60 text-slate-400 dark:text-slate-500 hover:text-rose-600 dark:hover:text-rose-400 rounded-md border border-transparent hover:border-rose-200 dark:hover:border-rose-800/60 transition-all active:scale-90 cursor-pointer"
                        title={`Hapus ${block}`}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 pt-2 border-t border-slate-200/60 dark:border-slate-700/60">
              💡 Blok perumahan digunakan untuk penugasan koordinator dan pemetaan denah rumah anggota secara acak.
            </p>
          </div>

        </div>

      </div>

      {/* Modern Deletion Confirmation Modal Dialog */}
      {deleteTarget && (
        <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center z-50 p-4 animate-fade-in">
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 max-w-sm w-full border border-slate-200 dark:border-slate-800 shadow-2xl space-y-4 text-center animate-scale-in">
            <div className="w-12 h-12 rounded-2xl bg-rose-100 dark:bg-rose-950/80 text-rose-600 dark:text-rose-400 flex items-center justify-center mx-auto border border-rose-200 dark:border-rose-800">
              <Trash2 className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-extrabold text-base text-slate-900 dark:text-white">
                Hapus {deleteTarget.item}?
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                Apakah Anda yakin ingin menghapus <strong>{deleteTarget.item}</strong> dari master {deleteTarget.categoryLabel}?
              </p>
            </div>

            <div className="flex gap-2.5 pt-2">
              <button
                type="button"
                onClick={() => setDeleteTarget(null)}
                className="flex-1 py-2.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-bold text-xs rounded-xl transition-all cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={confirmExecuteDelete}
                className="flex-1 py-2.5 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs rounded-xl shadow-md transition-all active:scale-95 cursor-pointer flex items-center justify-center gap-1.5"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Ya, Hapus</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Edit Modal Dialog */}
      {editingCategory && (
        <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center z-50 p-4 animate-fade-in">
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 max-w-md w-full border border-slate-200 dark:border-slate-800 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <Edit2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                <h3 className="font-extrabold text-sm text-slate-900 dark:text-white">
                  Ubah Nama {editingCategory === 'rw' ? 'Rukun Warga (RW)' : editingCategory === 'rt' ? 'Rukun Tetangga (RT)' : editingCategory === 'paguyuban' ? 'Paguyuban' : 'Blok Perumahan'}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setEditingCategory(null)}
                className="p-1.5 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3">
              <div>
                <label className="text-xs font-bold text-slate-600 dark:text-slate-300 block mb-1">Nama / Nomor Baru:</label>
                <input
                  type="text"
                  value={editValue}
                  onChange={(e) => setEditValue(e.target.value)}
                  autoFocus
                  className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-sm font-bold text-slate-900 dark:text-white focus:bg-white dark:focus:bg-slate-900 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>
              <div className="text-[11px] text-slate-500 dark:text-slate-400">
                Nilai sebelumnya: <span className="font-bold text-slate-700 dark:text-slate-200">{originalValue}</span>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
              <button
                type="button"
                onClick={() => setEditingCategory(null)}
                className="px-4 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 text-xs font-bold rounded-xl cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleSaveEdit}
                className="flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white text-xs font-bold rounded-xl shadow-xs cursor-pointer"
              >
                <Check className="w-3.5 h-3.5" />
                <span>Simpan Perubahan</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </form>
  );
};

