import React, { useState } from 'react';
import { X, Check, Search, CreditCard, User, AlertCircle, Sparkles, MessageSquare, Printer, QrCode } from 'lucide-react';
import { useRkm } from '../context/RkmContext';
import { formatRupiah, calculateCitizenMonthlyDues, getMonthNameFromKey, createWhatsAppUrl } from '../utils/formatters';
import { Citizen } from '../types';

interface QuickDuesModalProps {
  isOpen: boolean;
  onClose: () => void;
  preselectedCitizen?: Citizen | null;
}

export const QuickDuesModal: React.FC<QuickDuesModalProps> = ({ isOpen, onClose, preselectedCitizen }) => {
  const { citizens, settings, processPayment, openReceiptModal, currentUser, currentRole } = useRkm();
  
  // Role data isolation
  const visibleCitizens = citizens.filter(c => {
    if (currentRole === 'warga') {
      if (currentUser?.noKK && c.noKK === currentUser.noKK) return true;
      if (currentUser?.name && (c.headOfFamily.toLowerCase().includes(currentUser.name.toLowerCase()) || currentUser.name.toLowerCase().includes(c.headOfFamily.toLowerCase()))) return true;
      return false;
    }
    if (currentRole === 'koordinator') {
      const isAssignedDirectly = c.assignedCollectorId === currentUser?.id;
      const isAssignedBlock = Boolean(currentUser?.assignedBlocks && currentUser.assignedBlocks.length > 0 && currentUser.assignedBlocks.includes(c.block || ''));
      const isAssignedRt = (!currentUser?.assignedBlocks || currentUser.assignedBlocks.length === 0) && (!c.assignedCollectorId) && c.rt === currentUser?.rt;
      return isAssignedDirectly || isAssignedBlock || isAssignedRt;
    }
    return true;
  });

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCitizenId, setSelectedCitizenId] = useState<string>(preselectedCitizen?.id || visibleCitizens[0]?.id || '');
  const [selectedMonths, setSelectedMonths] = useState<string[]>(['2026-08']);
  const [infaqAmount, setInfaqAmount] = useState<number>(0);
  const [paymentMethod, setPaymentMethod] = useState<'Tunai' | 'Transfer Bank' | 'QRIS' | 'Kolektif'>('Tunai');
  const [collector, setCollector] = useState<string>(currentUser?.name || 'Petugas Kolektor RKM');
  const [isSuccess, setIsSuccess] = useState(false);
  const [lastReceiptNo, setLastReceiptNo] = useState<string>('');

  if (!isOpen) return null;

  const currentCitizen = visibleCitizens.find(c => c.id === selectedCitizenId) || preselectedCitizen || visibleCitizens[0];

  const filteredCitizens = searchQuery
    ? visibleCitizens.filter(c => 
        c.headOfFamily.toLowerCase().includes(searchQuery.toLowerCase()) ||
        c.noKK.includes(searchQuery) ||
        (c.block && c.block.toLowerCase().includes(searchQuery.toLowerCase())) ||
        (c.address && c.address.toLowerCase().includes(searchQuery.toLowerCase()))
      )
    : visibleCitizens.slice(0, 10);

  const baseRate = settings.baseDuesAmount || settings.duesAmount || 5000;
  const extraRate = settings.extraMemberDuesAmount || 3000;
  const citizenDuesInfo = currentCitizen ? calculateCitizenMonthlyDues(currentCitizen, baseRate, extraRate) : null;
  const ratePerMonth = citizenDuesInfo?.totalMonthlyDues || baseRate;

  const totalDues = selectedMonths.length * ratePerMonth;
  const grandTotal = totalDues + (Number(infaqAmount) || 0);

  const availableMonths = [
    '2026-01', '2026-02', '2026-03', '2026-04',
    '2026-05', '2026-06', '2026-07', '2026-08',
    '2026-09', '2026-10', '2026-11', '2026-12'
  ];

  const toggleMonth = (mKey: string) => {
    setSelectedMonths(prev => 
      prev.includes(mKey) ? prev.filter(m => m !== mKey) : [...prev, mKey].sort()
    );
  };

  const handleSelectAllUnpaid = () => {
    if (!currentCitizen) return;
    const unpaid = availableMonths.filter(m => !currentCitizen.monthlyDues[m]?.paid);
    setSelectedMonths(unpaid);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentCitizen || selectedMonths.length === 0) return;

    const receiptNo = processPayment({
      noKK: currentCitizen.noKK,
      months: selectedMonths,
      infaqAmount: Number(infaqAmount) || 0,
      paymentMethod,
      collector
    });

    if (receiptNo) {
      setLastReceiptNo(receiptNo);
      setIsSuccess(true);
    }
  };

  const handleSendWhatsApp = () => {
    if (!currentCitizen) return;
    const monthsText = selectedMonths.map(m => getMonthNameFromKey(m)).join(', ');
    const message = `*KUITANSI PEMBAYARAN IURAN RKM MPP*\n` +
      `----------------------------------------\n` +
      `No. Kuitansi: *${lastReceiptNo}*\n` +
      `Nama KK: *${currentCitizen.headOfFamily}*\n` +
      `No. KK: ${currentCitizen.noKK}\n` +
      `Alamat: ${currentCitizen.address} (RT ${currentCitizen.rt}/RW ${currentCitizen.rw})\n` +
      `----------------------------------------\n` +
      `Bulan Dibayar: ${monthsText}\n` +
      `Iuran RKM: ${formatRupiah(totalDues)}\n` +
      (infaqAmount > 0 ? `Infaq Sukarela: ${formatRupiah(infaqAmount)}\n` : '') +
      `*TOTAL DIBAYAR: ${formatRupiah(grandTotal)}*\n` +
      `Metode: ${paymentMethod}\n` +
      `Penerima: ${collector}\n` +
      `----------------------------------------\n` +
      `_Alhamdulillah, terima kasih atas partisipasi Anda mendukung paguyuban Rukun Kematian Metro Parung Panjang (MPP)._`;

    window.open(createWhatsAppUrl(currentCitizen.phone, message), '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-2xl overflow-hidden animate-fade-in my-8">
        
        {/* Header */}
        <div className="bg-slate-900 text-white p-5 flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-600 flex items-center justify-center text-white shadow-lg shadow-emerald-950/50">
              <CreditCard className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">Kasir Cepat: Catat Setoran Iuran</h2>
              <p className="text-xs text-slate-400">Aturan AD/ART RKM MPP Periode 2024–2027</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {isSuccess ? (
          <div className="p-8 text-center space-y-5">
            <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-2xl flex items-center justify-center mx-auto shadow-inner">
              <Check className="w-8 h-8 stroke-[3]" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-slate-900">Pembayaran Berhasil Dicatat!</h3>
              <p className="text-xs text-slate-600 mt-1">
                Kuitansi digital No. <strong>{lastReceiptNo}</strong> telah diterbitkan dan saldo kas telah terupdate.
              </p>
            </div>

            <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 text-left text-xs space-y-2">
              <div className="flex justify-between">
                <span className="text-slate-500">Warga / No. KK:</span>
                <span className="font-bold text-slate-800">{currentCitizen?.headOfFamily} ({currentCitizen?.noKK})</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Jumlah Bulan:</span>
                <span className="font-bold text-emerald-700">{selectedMonths.length} Bulan</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Total Nominal:</span>
                <span className="font-black text-slate-900 text-sm">{formatRupiah(grandTotal)}</span>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-3 pt-2">
              <button
                onClick={handleSendWhatsApp}
                className="flex-1 py-3 px-4 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold text-xs flex items-center justify-center gap-2 shadow-md transition-all"
              >
                <MessageSquare className="w-4 h-4" />
                <span>Kirim Kuitansi via WhatsApp</span>
              </button>
              <button
                onClick={() => {
                  if (currentCitizen) {
                    openReceiptModal({
                      receiptNo: lastReceiptNo,
                      citizen: currentCitizen,
                      monthsPaid: selectedMonths,
                      duesAmount: totalDues,
                      infaqAmount: Number(infaqAmount) || 0,
                      totalAmount: grandTotal,
                      date: new Date().toISOString().split('T')[0],
                      paymentMethod,
                      collector
                    });
                  }
                  onClose();
                }}
                className="py-3 px-4 bg-slate-800 hover:bg-slate-700 text-white rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-all"
              >
                <Printer className="w-4 h-4" />
                <span>Cetak Bukti Kuitansi</span>
              </button>
            </div>
            
            <button
              onClick={() => {
                setIsSuccess(false);
                setSelectedMonths(['2026-08']);
                setInfaqAmount(0);
              }}
              className="text-xs text-slate-500 hover:text-slate-800 underline block mx-auto pt-2"
            >
              Catat Pembayaran Lainnya
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-6 space-y-5">
            {/* Step 1: Pilih Warga */}
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                1. Pilih Anggota / Kepala Keluarga (KK)
              </label>
              
              <div className="relative mb-2">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Cari Nama, No. KK, atau Blok..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-emerald-500 outline-none"
                />
              </div>

              <select
                value={selectedCitizenId}
                onChange={(e) => {
                  setSelectedCitizenId(e.target.value);
                  setSelectedMonths(['2026-08']);
                }}
                className="w-full px-3 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-bold text-slate-800 focus:ring-2 focus:ring-emerald-500 outline-none"
              >
                {filteredCitizens.map(c => (
                  <option key={c.id} value={c.id}>
                    {c.headOfFamily} — No. KK: {c.noKK} | {c.block ? `Blok ${c.block}` : `RT ${c.rt}`} ({c.members.length} Jiwa)
                  </option>
                ))}
              </select>

              {currentCitizen && citizenDuesInfo && (
                <div className="mt-2 p-3 bg-emerald-50/70 border border-emerald-200 rounded-xl text-xs text-emerald-900 flex items-center justify-between">
                  <div>
                    <span className="font-bold">{currentCitizen.headOfFamily}</span> ({currentCitizen.address})
                    <p className="text-[11px] text-emerald-700 mt-0.5">
                      {citizenDuesInfo.coreMembersCount} Jiwa Inti (Rp 5.000) + {citizenDuesInfo.extraMembersCount} Tambahan (+ {formatRupiah(citizenDuesInfo.totalExtraDues)})
                    </p>
                  </div>
                  <div className="text-right">
                    <span className="text-[10px] text-slate-500 block uppercase font-bold">Tarif / Bulan</span>
                    <span className="font-extrabold text-emerald-700 text-sm">{formatRupiah(ratePerMonth)}</span>
                  </div>
                </div>
              )}
            </div>

            {/* Step 2: Pilih Bulan Tagihan */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                  2. Pilih Bulan Iuran (Tahun 2026)
                </label>
                <button
                  type="button"
                  onClick={handleSelectAllUnpaid}
                  className="text-[11px] text-emerald-600 font-bold hover:underline"
                >
                  Pilih Semua yang Belum Lunas
                </button>
              </div>

              <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
                {availableMonths.map(mKey => {
                  const isPaid = currentCitizen?.monthlyDues[mKey]?.paid;
                  const isSelected = selectedMonths.includes(mKey);

                  return (
                    <button
                      type="button"
                      key={mKey}
                      disabled={isPaid}
                      onClick={() => toggleMonth(mKey)}
                      className={`p-2.5 rounded-xl text-xs font-semibold border transition-all text-center relative ${
                        isPaid
                          ? 'bg-slate-100 text-slate-400 border-slate-200 cursor-not-allowed line-through'
                          : isSelected
                          ? 'bg-emerald-600 text-white border-emerald-600 shadow-md shadow-emerald-950/20'
                          : 'bg-white text-slate-700 border-slate-200 hover:border-emerald-400'
                      }`}
                    >
                      <span>{getMonthNameFromKey(mKey)}</span>
                      {isPaid && <span className="block text-[9px] font-normal text-emerald-600 no-underline font-mono">LUNAS</span>}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Step 3: Infaq & Metode Bayar */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Infaq / Sedekah Sukarela (Rp)
                </label>
                <input
                  type="number"
                  min="0"
                  step="5000"
                  value={infaqAmount || ''}
                  onChange={(e) => setInfaqAmount(Number(e.target.value) || 0)}
                  placeholder="0"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-bold focus:ring-2 focus:ring-emerald-500 outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Metode Pembayaran
                </label>
                <select
                  value={paymentMethod}
                  onChange={(e) => setPaymentMethod(e.target.value as any)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-bold focus:ring-2 focus:ring-emerald-500 outline-none"
                >
                  <option value="Tunai">Tunai (Cash ke Kolektor)</option>
                  <option value="Transfer Bank">Transfer Bank BSI / BCA</option>
                  <option value="QRIS">QRIS Standar Indonesia</option>
                  <option value="Kolektif">Kolektif Pengurus RT</option>
                </select>
              </div>
            </div>

            {/* Total Ringkasan */}
            <div className="p-4 bg-slate-900 text-white rounded-2xl flex items-center justify-between">
              <div>
                <span className="text-xs text-slate-400 block">Total Tagihan ({selectedMonths.length} Bulan + Infaq)</span>
                <span className="text-lg font-black text-emerald-400">{formatRupiah(grandTotal)}</span>
              </div>
              <button
                type="submit"
                disabled={selectedMonths.length === 0}
                className={`py-2.5 px-6 rounded-xl text-xs font-extrabold shadow-lg transition-all ${
                  selectedMonths.length === 0
                    ? 'bg-slate-700 text-slate-400 cursor-not-allowed'
                    : 'bg-emerald-600 hover:bg-emerald-500 text-white active:scale-95 shadow-emerald-950/40'
                }`}
              >
                Konfirmasi Setoran
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
