import React, { useState, useMemo } from 'react';
import { 
  BookOpen, 
  Plus, 
  Minus, 
  TrendingUp, 
  TrendingDown, 
  Wallet, 
  Filter, 
  Printer, 
  Download, 
  Search, 
  CheckCircle2, 
  ArrowUpRight, 
  ArrowDownRight, 
  Calendar, 
  ShieldCheck,
  FileText,
  Trash2,
  Check,
  Building2,
  Eye,
  X,
  RotateCcw,
  Activity,
  History,
  ShieldAlert,
  UserCheck,
  FileSpreadsheet,
  ArrowUp,
  ArrowDown,
  ArrowUpDown
} from 'lucide-react';
import { useRkm } from '../context/RkmContext';
import { formatRupiah, formatDateIndo, formatDateTimeIndo, getDirectImageUrl, getMonthNameFromKey, MONTH_NAMES } from '../utils/formatters';
import { Transaction, TransactionType } from '../types';
import { exportCashbookPdf } from '../utils/pdfExport';
import { exportCashbookCsv } from '../utils/excelExport';

export const CashbookView: React.FC = () => {
  const { 
    transactions, 
    addTransaction, 
    deleteTransaction, 
    currentUser, 
    currentRole, 
    settings,
    auditLogs
  } = useRkm();

  const [activeCashbookTab, setActiveCashbookTab] = useState<'ledger' | 'audit_logs'>('ledger');
  const [searchQuery, setSearchQuery] = useState('');
  const [logSearchQuery, setLogSearchQuery] = useState('');
  const [logActionFilter, setLogActionFilter] = useState<string>('all');
  const [filterType, setFilterType] = useState<'all' | 'in' | 'out'>('all');
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [filterMonth, setFilterMonth] = useState<string>('all');
  const [showAddModal, setShowAddModal] = useState(false);
  const [showPrintPreview, setShowPrintPreview] = useState(false);
  const [txToDelete, setTxToDelete] = useState<Transaction | null>(null);

  // Column-based table sorting state
  const [sortColumn, setSortColumn] = useState<string>('date');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('desc');

  const handleSortColumn = (col: string) => {
    if (sortColumn === col) {
      setSortDirection(prev => prev === 'asc' ? 'desc' : 'asc');
    } else {
      setSortColumn(col);
      setSortDirection(col === 'date' || col === 'amount' ? 'desc' : 'asc');
    }
  };

  // New Transaction Form State
  const [newTxType, setNewTxType] = useState<TransactionType>('in');
  const [newTxCategory, setNewTxCategory] = useState<any>('Iuran Wajib');
  const [newTxAmount, setNewTxAmount] = useState<number | ''>('');
  const [newTxDate, setNewTxDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [newTxDescription, setNewTxDescription] = useState<string>('');
  const [newTxRecipientOrPayer, setNewTxRecipientOrPayer] = useState<string>('');
  const [newTxMethod, setNewTxMethod] = useState<string>('Tunai');

  // Extract unique month-year list from transactions
  const availableMonths = useMemo(() => {
    const monthsSet = new Set<string>();
    // Always include current month
    const currentMonthKey = new Date().toISOString().slice(0, 7);
    monthsSet.add(currentMonthKey);
    
    transactions.forEach(t => {
      if (t.date && t.date.length >= 7) {
        monthsSet.add(t.date.slice(0, 7));
      }
    });
    return Array.from(monthsSet).sort().reverse();
  }, [transactions]);

  // Starting balance before selected month (if month filter active)
  const initialBalanceBeforeMonth = useMemo(() => {
    if (filterMonth === 'all') return 0;
    const startOfCurrentMonth = `${filterMonth}-01`;
    return transactions
      .filter(t => t.date < startOfCurrentMonth)
      .reduce((acc, t) => acc + (t.type === 'in' ? t.amount : -t.amount), 0);
  }, [transactions, filterMonth]);

  // Filter transactions based on search, type, category, and month
  const filteredTx = useMemo(() => {
    return transactions.filter(t => {
      const matchQuery = 
        t.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        t.recipientOrPayer.toLowerCase().includes(searchQuery.toLowerCase()) ||
        t.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (t.receiptNo && t.receiptNo.toLowerCase().includes(searchQuery.toLowerCase()));

      const matchType = filterType === 'all' || t.type === filterType;
      const matchCat = filterCategory === 'all' || t.category === filterCategory;
      const matchMonth = filterMonth === 'all' || t.date.startsWith(filterMonth);

      return matchQuery && matchType && matchCat && matchMonth;
    });
  }, [transactions, searchQuery, filterType, filterCategory, filterMonth]);

  // Calculate overall totals
  const totalIn = transactions.filter(t => t.type === 'in').reduce((acc, t) => acc + t.amount, 0);
  const totalOut = transactions.filter(t => t.type === 'out').reduce((acc, t) => acc + t.amount, 0);
  const totalBalance = totalIn - totalOut;

  // Filtered Totals (for current filtered view / monthly summary)
  const filteredIn = filteredTx.filter(t => t.type === 'in').reduce((acc, t) => acc + t.amount, 0);
  const filteredOut = filteredTx.filter(t => t.type === 'out').reduce((acc, t) => acc + t.amount, 0);
  const filteredBalance = filterMonth === 'all' 
    ? (filteredIn - filteredOut)
    : (initialBalanceBeforeMonth + filteredIn - filteredOut);

  // Categories list
  const inCategories = ['Iuran Wajib', 'Infaq / Sedekah', 'Donasi / Hibah', 'Lainnya'];
  const outCategories = [
    'Santunan Kematian', 
    'Perlengkapan Kain Kafan', 
    'Gali Kubur / TPU', 
    'Operasional Ambulance', 
    'Perawatan Aset & Tenda', 
    'Konsumsi Takziah', 
    'Lainnya'
  ];

  // Sort filtered transactions based on active column and direction
  const sortedTx = useMemo(() => {
    return [...filteredTx].sort((a, b) => {
      let comparison = 0;
      switch (sortColumn) {
        case 'date':
          comparison = new Date(a.date).getTime() - new Date(b.date).getTime();
          break;
        case 'receiptNo':
          comparison = (a.receiptNo || '').localeCompare(b.receiptNo || '');
          break;
        case 'category':
          comparison = (a.category || '').localeCompare(b.category || '');
          break;
        case 'description':
          comparison = (a.description || '').localeCompare(b.description || '');
          break;
        case 'recipientOrPayer':
          comparison = (a.recipientOrPayer || '').localeCompare(b.recipientOrPayer || '');
          break;
        case 'method':
          comparison = (a.paymentMethod || '').localeCompare(b.paymentMethod || '');
          break;
        case 'amount':
          comparison = a.amount - b.amount;
          break;
        default:
          comparison = new Date(a.date).getTime() - new Date(b.date).getTime();
      }
      return sortDirection === 'asc' ? comparison : -comparison;
    });
  }, [filteredTx, sortColumn, sortDirection]);

  // Triggers browser print dialog
  const handlePrint = () => {
    window.print();
  };

  // Triggers browser print dialog specifically for Monthly Financial Report
  const handlePrintMonthlyReport = (targetMonth?: string) => {
    const selectedM = targetMonth || (filterMonth !== 'all' ? filterMonth : new Date().toISOString().slice(0, 7));
    setFilterMonth(selectedM);
    setTimeout(() => {
      window.print();
    }, 150);
  };

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTxAmount || !newTxDescription.trim() || !newTxRecipientOrPayer.trim()) return;

    const receiptNo = `RKM-${newTxType === 'in' ? 'IN' : 'OUT'}-${new Date().getFullYear()}${Math.floor(1000 + Math.random() * 9000)}`;

    addTransaction({
      type: newTxType,
      category: newTxCategory,
      amount: Number(newTxAmount),
      date: newTxDate,
      description: newTxDescription,
      recipientOrPayer: newTxRecipientOrPayer,
      paymentMethod: newTxMethod,
      verifiedBy: currentUser?.name || settings.treasurerName,
      receiptNo
    });

    // Reset Form
    setNewTxAmount('');
    setNewTxDescription('');
    setNewTxRecipientOrPayer('');
    setShowAddModal(false);
  };

  // Compute running balance for printed table sorted chronologically
  const sortedForPrint = useMemo(() => {
    return [...filteredTx].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  }, [filteredTx]);

  let runningBal = filterMonth !== 'all' ? initialBalanceBeforeMonth : 0;
  const printRows = sortedForPrint.map((tx, idx) => {
    if (tx.type === 'in') {
      runningBal += tx.amount;
    } else {
      runningBal -= tx.amount;
    }
    return {
      ...tx,
      no: idx + 1,
      runningBalance: runningBal
    };
  });

  const periodTitle = filterMonth !== 'all' 
    ? `Bulan ${getMonthNameFromKey(filterMonth)}`
    : 'Semua Periode Transaksi';

  return (
    <div className="space-y-6 pb-12 animate-fade-in">
      
      {/* Header - Hidden on Print */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200/80 dark:border-slate-800 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4 no-print">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400 rounded-xl">
              <BookOpen className="w-5 h-5" />
            </span>
            <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white">Buku Kas & Transparansi Keuangan</h1>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Laporan mutasi kas masuk, pengeluaran santunan jenazah, dan rekapitulasi keuangan bulanan berformat A4.
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center gap-2.5 self-start md:self-auto">
          {/* Excel / CSV Export Button */}
          <button
            onClick={() => {
              const periodTitle = filterMonth !== 'all' ? getMonthNameFromKey(filterMonth) : 'Semua Periode';
              exportCashbookCsv(filteredTx, settings, periodTitle);
            }}
            id="btn-export-excel-cashbook"
            className="h-10 flex items-center gap-2 px-3.5 bg-emerald-50 dark:bg-emerald-950/40 hover:bg-emerald-100 dark:hover:bg-emerald-900/60 text-emerald-900 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-700/60 font-bold text-xs rounded-xl shadow-xs transition-all active:scale-95 cursor-pointer"
            title="Unduh Laporan Mutasi Kas dalam Format Excel / CSV"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-700 dark:text-emerald-400" />
            <span>Unduh Excel / CSV</span>
          </button>

          {/* Print Monthly Financial Report Button */}
          <button
            onClick={() => handlePrintMonthlyReport()}
            id="btn-print-monthly-financial-report"
            className="h-10 flex items-center gap-2 px-4 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs rounded-xl shadow-md transition-all active:scale-95 cursor-pointer border border-emerald-600/50"
            title="Cetak Laporan Keuangan Bulanan Resmi dengan Kop Organisasi & Rentang Tanggal (Format Cetak / PDF)"
          >
            <Printer className="w-4 h-4 text-emerald-200" />
            <span>Print Laporan Bulanan</span>
          </button>

          {/* Print Button (Primary) */}
          <button
            onClick={handlePrint}
            id="btn-print-cashbook-header"
            className="h-10 flex items-center gap-2 px-4 bg-slate-900 dark:bg-slate-800 hover:bg-slate-800 dark:hover:bg-slate-700 text-white font-bold text-xs rounded-xl shadow-md transition-all active:scale-95 cursor-pointer border border-slate-800 dark:border-slate-700"
            title="Cetak Buku Kas / Ekspor PDF Format A4"
          >
            <Printer className="w-4 h-4 text-emerald-400" />
            <span>Print Rekap Kas (A4)</span>
          </button>

          {/* Print Preview Button */}
          <button
            onClick={() => setShowPrintPreview(true)}
            className="h-10 flex items-center gap-1.5 px-3.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 font-bold text-xs rounded-xl transition-all active:scale-95 cursor-pointer border border-slate-200 dark:border-slate-700"
            title="Pratinjau Tampilan Cetak A4"
          >
            <Eye className="w-4 h-4 text-slate-500 dark:text-slate-400" />
            <span>Pratinjau</span>
          </button>

          {currentRole !== 'warga' && (
            <button
              onClick={() => setShowAddModal(true)}
              className="h-10 flex items-center gap-2 px-4 sm:px-5 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white font-bold text-xs rounded-xl shadow-md transition-all cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Catat Transaksi Baru</span>
            </button>
          )}
        </div>
      </div>

      {/* Role-Specific Sub-Tab for Bendahara and Super Admin */}
      {(currentRole === 'superadmin' || currentRole === 'bendahara') && (
        <div className="flex items-center gap-2 p-1.5 bg-slate-100 dark:bg-slate-800/80 rounded-2xl w-fit border border-slate-200 dark:border-slate-700 no-print">
          <button
            onClick={() => setActiveCashbookTab('ledger')}
            className={`flex items-center gap-2 px-4 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer ${
              activeCashbookTab === 'ledger'
                ? 'bg-white dark:bg-slate-900 text-emerald-800 dark:text-emerald-400 shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <BookOpen className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
            <span>Buku Kas & Mutasi</span>
            <span className="px-2 py-0.5 rounded-full text-[10px] bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 font-black border border-emerald-200/60 dark:border-emerald-800/60">
              {transactions.length}
            </span>
          </button>

          <button
            onClick={() => setActiveCashbookTab('audit_logs')}
            className={`flex items-center gap-2 px-4 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer ${
              activeCashbookTab === 'audit_logs'
                ? 'bg-slate-900 dark:bg-slate-950 text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <Activity className="w-4 h-4 text-amber-400" />
            <span>Log Aktivitas & Audit Kas</span>
            <span className="px-2 py-0.5 rounded-full text-[10px] bg-amber-500/20 text-amber-300 font-black">
              {auditLogs.filter(l => l.action.startsWith('KAS_') || l.action.startsWith('IURAN_')).length || auditLogs.length}
            </span>
          </button>
        </div>
      )}

      {/* VIEW 1: REGULAR CASHBOOK MUTATIONS */}
      {activeCashbookTab === 'ledger' ? (
        <>
          {/* Balance Summary Header Cards - Hidden on Print */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 no-print">
            <div className="bg-gradient-to-br from-slate-900 to-emerald-950 text-white p-5 rounded-2xl border border-emerald-900/60 shadow-md">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider">
                  {filterMonth !== 'all' ? `Saldo Akhir (${getMonthNameFromKey(filterMonth)})` : 'Saldo Kas Keseluruhan'}
                </span>
                <Wallet className="w-5 h-5 text-emerald-400" />
              </div>
              <div className="text-2xl sm:text-3xl font-black font-mono mt-2 text-white">
                {formatRupiah(filterMonth !== 'all' ? filteredBalance : totalBalance)}
              </div>
              <p className="text-[11px] text-slate-300 mt-1 flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span>Tersimpan di Rekening BSI & Kas Tunai</span>
              </p>
            </div>

            <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-sm">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">
                  {filterMonth !== 'all' ? `Pemasukan Bulan Ini` : 'Total Kas Masuk'}
                </span>
                <TrendingUp className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
              </div>
              <div className="text-2xl sm:text-3xl font-black font-mono mt-2 text-emerald-700 dark:text-emerald-400">
                +{formatRupiah(filteredIn)}
              </div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
                Iuran warga, infaq donatur & sedekah
              </p>
            </div>

            <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-sm">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">
                  {filterMonth !== 'all' ? `Pengeluaran Bulan Ini` : 'Total Pengeluaran'}
                </span>
                <TrendingDown className="w-5 h-5 text-rose-600 dark:text-rose-400" />
              </div>
              <div className="text-2xl sm:text-3xl font-black font-mono mt-2 text-rose-700 dark:text-rose-400">
                -{formatRupiah(filteredOut)}
              </div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
                Santunan kematian, kain kafan & makam
              </p>
            </div>
          </div>

      {/* Filter and Search Bar - Hidden on Print */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-sm flex flex-wrap items-center justify-between gap-3 no-print">
        <div className="flex flex-wrap items-center gap-2 flex-1 min-w-[280px]">
          {/* Search Input */}
          <div className="relative flex-1 min-w-[200px]">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Cari transaksi / keterangan / nama / No. Kuitansi..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full h-10 pl-9 pr-3 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white placeholder:text-slate-400 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
            />
          </div>

          {/* Month Period Filter for Monthly Summaries */}
          <div className="flex items-center gap-1.5">
            <Calendar className="w-4 h-4 text-slate-400" />
            <select
              value={filterMonth}
              onChange={(e) => setFilterMonth(e.target.value)}
              className="h-10 px-3 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl font-bold text-slate-800 dark:text-slate-200 cursor-pointer focus:outline-none focus:ring-2 focus:ring-emerald-500"
              title="Pilih Bulan Rekapitulasi"
            >
              <option value="all">🗓️ Semua Bulan / Periode</option>
              {availableMonths.map(mKey => (
                <option key={mKey} value={mKey}>
                  {getMonthNameFromKey(mKey)}
                </option>
              ))}
            </select>
          </div>

          {/* Type Filter */}
          <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value as any)}
            className="h-10 px-3 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl font-semibold text-slate-700 dark:text-slate-200 cursor-pointer focus:outline-none focus:ring-2 focus:ring-emerald-500"
          >
            <option value="all">Semua Tipe</option>
            <option value="in">Kas Masuk (Pemasukan)</option>
            <option value="out">Kas Keluar (Pengeluaran)</option>
          </select>

          {/* Category Filter */}
          <select
            value={filterCategory}
            onChange={(e) => setFilterCategory(e.target.value)}
            className="h-10 px-3 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl font-semibold text-slate-700 dark:text-slate-200 cursor-pointer focus:outline-none focus:ring-2 focus:ring-emerald-500"
          >
            <option value="all">Semua Kategori</option>
            {[...inCategories, ...outCategories].filter((v, i, a) => a.indexOf(v) === i).map(cat => (
              <option key={cat} value={cat}>{cat}</option>
            ))}
          </select>

          {/* Reset Filters */}
          {(searchQuery || filterType !== 'all' || filterCategory !== 'all' || filterMonth !== 'all') && (
            <button
              onClick={() => {
                setSearchQuery('');
                setFilterType('all');
                setFilterCategory('all');
                setFilterMonth('all');
              }}
              className="h-10 px-3 text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-all cursor-pointer border border-slate-200 dark:border-slate-700"
              title="Reset Semua Filter"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          )}
        </div>

        <div className="flex items-center gap-2">
          {/* Monthly Report Print Button in Toolbar */}
          <button
            onClick={() => handlePrintMonthlyReport()}
            id="btn-print-monthly-toolbar"
            className="h-10 flex items-center gap-2 px-3.5 bg-emerald-800 hover:bg-emerald-900 text-white rounded-xl text-xs font-bold shadow-sm transition-all active:scale-95 cursor-pointer border border-emerald-700"
            title="Cetak Laporan Keuangan Bulanan Resmi (A4)"
          >
            <Printer className="w-4 h-4 text-emerald-300" />
            <span className="hidden sm:inline">Print Lap. Bulanan</span>
            <span className="sm:hidden">Lap. Bulanan</span>
          </button>

          {/* Download PDF Button */}
          <button
            onClick={() => exportCashbookPdf(filteredTx, settings, filterMonth, initialBalanceBeforeMonth)}
            id="btn-download-pdf-cashbook"
            className="h-10 flex items-center gap-2 px-4 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-bold shadow-sm transition-all active:scale-95 cursor-pointer border border-emerald-600/40"
            title="Unduh Berkas Rekapitulasi Kas dalam Format PDF (A4)"
          >
            <Download className="w-4 h-4" />
            <span>Unduh PDF</span>
          </button>

          {/* Secondary Print Button in Toolbar */}
          <button
            onClick={handlePrint}
            id="btn-print-cashbook-toolbar"
            className="h-10 flex items-center gap-2 px-4 bg-slate-800 hover:bg-slate-700 dark:bg-slate-800 dark:hover:bg-slate-700 text-white rounded-xl text-xs font-bold shadow-sm transition-all active:scale-95 cursor-pointer border border-slate-700"
            title="Cetak Laporan Rekapitulasi Kas (A4)"
          >
            <Printer className="w-4 h-4" />
            <span>Print Rekap (A4)</span>
          </button>
        </div>
      </div>

      {/* Screen Interactive Table - Hidden on Print */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-sm overflow-hidden no-print">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-900 dark:bg-slate-950 text-white font-bold">
                <th 
                  onClick={() => handleSortColumn('date')}
                  className="p-3.5 cursor-pointer hover:bg-slate-800 transition-colors select-none"
                  title="Klik untuk mengurutkan berdasarkan Tanggal"
                >
                  <div className="flex items-center gap-1.5">
                    <span>Tanggal</span>
                    {sortColumn === 'date' ? (
                      sortDirection === 'asc' ? <ArrowUp className="w-3.5 h-3.5 text-emerald-400" /> : <ArrowDown className="w-3.5 h-3.5 text-emerald-400" />
                    ) : (
                      <ArrowUpDown className="w-3 h-3 text-slate-400 opacity-60" />
                    )}
                  </div>
                </th>
                <th 
                  onClick={() => handleSortColumn('receiptNo')}
                  className="p-3.5 cursor-pointer hover:bg-slate-800 transition-colors select-none"
                  title="Klik untuk mengurutkan berdasarkan No. Bukti"
                >
                  <div className="flex items-center gap-1.5">
                    <span>No. Bukti</span>
                    {sortColumn === 'receiptNo' ? (
                      sortDirection === 'asc' ? <ArrowUp className="w-3.5 h-3.5 text-emerald-400" /> : <ArrowDown className="w-3.5 h-3.5 text-emerald-400" />
                    ) : (
                      <ArrowUpDown className="w-3 h-3 text-slate-400 opacity-60" />
                    )}
                  </div>
                </th>
                <th 
                  onClick={() => handleSortColumn('category')}
                  className="p-3.5 cursor-pointer hover:bg-slate-800 transition-colors select-none"
                  title="Klik untuk mengurutkan berdasarkan Kategori / Keterangan"
                >
                  <div className="flex items-center gap-1.5">
                    <span>Kategori & Keterangan</span>
                    {sortColumn === 'category' ? (
                      sortDirection === 'asc' ? <ArrowUp className="w-3.5 h-3.5 text-emerald-400" /> : <ArrowDown className="w-3.5 h-3.5 text-emerald-400" />
                    ) : (
                      <ArrowUpDown className="w-3 h-3 text-slate-400 opacity-60" />
                    )}
                  </div>
                </th>
                <th 
                  onClick={() => handleSortColumn('recipientOrPayer')}
                  className="p-3.5 cursor-pointer hover:bg-slate-800 transition-colors select-none"
                  title="Klik untuk mengurutkan berdasarkan Pihak Terkait"
                >
                  <div className="flex items-center gap-1.5">
                    <span>Pihak Terkait</span>
                    {sortColumn === 'recipientOrPayer' ? (
                      sortDirection === 'asc' ? <ArrowUp className="w-3.5 h-3.5 text-emerald-400" /> : <ArrowDown className="w-3.5 h-3.5 text-emerald-400" />
                    ) : (
                      <ArrowUpDown className="w-3 h-3 text-slate-400 opacity-60" />
                    )}
                  </div>
                </th>
                <th 
                  onClick={() => handleSortColumn('method')}
                  className="p-3.5 cursor-pointer hover:bg-slate-800 transition-colors select-none"
                  title="Klik untuk mengurutkan berdasarkan Metode Pembayaran"
                >
                  <div className="flex items-center gap-1.5">
                    <span>Metode</span>
                    {sortColumn === 'method' ? (
                      sortDirection === 'asc' ? <ArrowUp className="w-3.5 h-3.5 text-emerald-400" /> : <ArrowDown className="w-3.5 h-3.5 text-emerald-400" />
                    ) : (
                      <ArrowUpDown className="w-3 h-3 text-slate-400 opacity-60" />
                    )}
                  </div>
                </th>
                <th 
                  onClick={() => handleSortColumn('amount')}
                  className="p-3.5 text-right cursor-pointer hover:bg-slate-800 transition-colors select-none"
                  title="Klik untuk mengurutkan berdasarkan Nominal"
                >
                  <div className="flex items-center justify-end gap-1.5">
                    <span>Nominal</span>
                    {sortColumn === 'amount' ? (
                      sortDirection === 'asc' ? <ArrowUp className="w-3.5 h-3.5 text-emerald-400" /> : <ArrowDown className="w-3.5 h-3.5 text-emerald-400" />
                    ) : (
                      <ArrowUpDown className="w-3 h-3 text-slate-400 opacity-60" />
                    )}
                  </div>
                </th>
                {currentRole === 'bendahara' && <th className="p-3.5 text-center">Aksi</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {sortedTx.map((tx) => {
                const isIncome = tx.type === 'in';
                return (
                  <tr key={tx.id} className="hover:bg-slate-50/80 dark:hover:bg-slate-800/60 transition-colors">
                    <td className="p-3.5 font-medium text-slate-600 dark:text-slate-300 whitespace-nowrap">
                      {formatDateIndo(tx.date, false)}
                    </td>
                    <td className="p-3.5 font-mono text-[11px] text-slate-500 dark:text-slate-400 font-bold">
                      {tx.receiptNo || '-'}
                    </td>
                    <td className="p-3.5 max-w-xs sm:max-w-md">
                      <span className={`inline-block text-[10px] font-bold px-2 py-0.5 rounded-md mb-1 ${
                        isIncome 
                          ? 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 border border-emerald-200/60 dark:border-emerald-800/60' 
                          : 'bg-rose-100 dark:bg-rose-950/60 text-rose-800 dark:text-rose-300 border border-rose-200/60 dark:border-rose-900/60'
                      }`}>
                        {tx.category}
                      </span>
                      <p className="font-semibold text-slate-900 dark:text-white line-clamp-2">
                        {tx.description}
                      </p>
                    </td>
                    <td className="p-3.5 font-medium text-slate-700 dark:text-slate-200">
                      {tx.recipientOrPayer}
                    </td>
                    <td className="p-3.5">
                      <span className="text-[10px] px-2 py-0.5 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded font-semibold border border-slate-200/60 dark:border-slate-700/60">
                        {tx.paymentMethod}
                      </span>
                    </td>
                    <td className="p-3.5 text-right whitespace-nowrap font-mono font-black text-sm">
                      <span className={isIncome ? 'text-emerald-700 dark:text-emerald-400' : 'text-rose-700 dark:text-rose-400'}>
                        {isIncome ? '+' : '-'}{formatRupiah(tx.amount)}
                      </span>
                    </td>
                    {currentRole === 'bendahara' && (
                      <td className="p-3.5 text-center">
                        <button
                          onClick={() => setTxToDelete(tx)}
                          className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 dark:hover:text-rose-400 rounded-lg transition-colors cursor-pointer"
                          title="Hapus Transaksi"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    )}
                  </tr>
                );
              })}

              {filteredTx.length === 0 && (
                <tr>
                  <td colSpan={7} className="p-8 text-center text-slate-400 dark:text-slate-500">
                    Tidak ada catatan transaksi yang sesuai dengan filter periode.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Table Footer Summary */}
        <div className="p-4 bg-slate-50 dark:bg-slate-850/60 border-t border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-600 dark:text-slate-400 gap-2">
          <span>
            Menampilkan {filteredTx.length} mutasi {filterMonth !== 'all' ? `(${getMonthNameFromKey(filterMonth)})` : `dari ${transactions.length} total`}
          </span>
          <div className="flex flex-wrap gap-4 font-mono font-bold">
            {filterMonth !== 'all' && (
              <span className="text-slate-600 dark:text-slate-400">Saldo Awal: {formatRupiah(initialBalanceBeforeMonth)}</span>
            )}
            <span className="text-emerald-700 dark:text-emerald-400">Masuk: +{formatRupiah(filteredIn)}</span>
            <span className="text-rose-700 dark:text-rose-400">Keluar: -{formatRupiah(filteredOut)}</span>
            <span className="text-slate-900 dark:text-white">Saldo Akhir: {formatRupiah(filteredBalance)}</span>
          </div>
        </div>
      </div>
      </>
      ) : (
        /* VIEW 2: FINANCIAL AUDIT TRAIL & LOG AKTIVITAS KAS */
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-sm overflow-hidden space-y-4 p-5 sm:p-6 animate-fade-in no-print">
          
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100 dark:border-slate-800">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-amber-100 dark:bg-amber-950/60 text-amber-900 dark:text-amber-300 rounded-2xl">
                <Activity className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="font-extrabold text-base text-slate-900 dark:text-white">
                    Log Aktivitas & Audit Perubahan Transaksi Kas
                  </h2>
                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-amber-100 dark:bg-amber-950/60 text-amber-900 dark:text-amber-300 border border-amber-200 dark:border-amber-800/60">
                    Khusus Bendahara & Super Admin
                  </span>
                </div>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Mencatat otomatis setiap transaksi masuk, pengeluaran santunan, penerimaan kasir, penghapusan, dan penyesuaian saldo.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-slate-500 dark:text-slate-400">
                Total Rekaman: <strong className="text-slate-900 dark:text-white font-mono">{auditLogs.length}</strong>
              </span>
            </div>
          </div>

          {/* Filter Bar for Audit Logs */}
          <div className="flex flex-wrap items-center gap-3 pt-1">
            <div className="relative flex-1 min-w-[240px]">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Cari log: nama pengurus / keterangan / kwitansi / nominal..."
                value={logSearchQuery}
                onChange={(e) => setLogSearchQuery(e.target.value)}
                className="w-full h-10 pl-9 pr-3 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white placeholder:text-slate-400 focus:ring-2 focus:ring-amber-500 focus:outline-none"
              />
            </div>

            <div className="flex items-center gap-2">
              <Filter className="w-4 h-4 text-slate-400" />
              <select
                value={logActionFilter}
                onChange={(e) => setLogActionFilter(e.target.value)}
                className="h-10 px-3 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl font-bold text-slate-800 dark:text-slate-200 cursor-pointer focus:outline-none focus:ring-2 focus:ring-amber-500"
              >
                <option value="all">🔍 Semua Jenis Aksi</option>
                <option value="KAS_MASUK">💰 Kas Masuk</option>
                <option value="KAS_KELUAR">💸 Kas Keluar / Santunan</option>
                <option value="IURAN_DITERIMA">🧾 Kwitansi Iuran</option>
                <option value="KAS_DIHAPUS">⚠️ Kas Dihapus</option>
                <option value="AUTO_AGING_RUN">⚡ Auto-Aging Status</option>
              </select>
            </div>
          </div>

          {/* Audit Logs Table */}
          <div className="overflow-x-auto border border-slate-200/80 dark:border-slate-800 rounded-2xl">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-50/90 dark:bg-slate-950 text-slate-600 dark:text-slate-400 font-bold border-b border-slate-200 dark:border-slate-800 uppercase text-[10px] tracking-wider">
                  <th className="p-3.5 w-36">Waktu & Tanggal</th>
                  <th className="p-3.5 w-44">Operator / Pengurus</th>
                  <th className="p-3.5 w-32 text-center">Jenis Aksi</th>
                  <th className="p-3.5">Rincian Perubahan & Nominal Transaksi</th>
                  <th className="p-3.5 w-40 text-right">Terminal & Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {auditLogs
                  .filter(l => {
                    const matchSearch = 
                      l.details.toLowerCase().includes(logSearchQuery.toLowerCase()) ||
                      l.userName.toLowerCase().includes(logSearchQuery.toLowerCase()) ||
                      l.action.toLowerCase().includes(logSearchQuery.toLowerCase());
                    const matchAction = logActionFilter === 'all' || l.action === logActionFilter;
                    return matchSearch && matchAction;
                  })
                  .map((log) => {
                    const isMasuk = log.action === 'KAS_MASUK' || log.action === 'IURAN_DITERIMA';
                    const isKeluar = log.action === 'KAS_KELUAR';
                    const isHapus = log.action === 'KAS_DIHAPUS';
                    const isAging = log.action === 'AUTO_AGING_RUN';

                    return (
                      <tr key={log.id} className="hover:bg-slate-50/70 dark:hover:bg-slate-800/60 transition-colors">
                        <td className="p-3.5 font-mono text-[11px] text-slate-500 dark:text-slate-400 whitespace-nowrap">
                          {log.timestamp}
                        </td>
                        <td className="p-3.5 whitespace-nowrap">
                          <div className="font-bold text-slate-900 dark:text-white text-xs">{log.userName}</div>
                          <div className="text-[10px] text-slate-500 dark:text-slate-400 uppercase font-semibold">
                            Role: {log.userRole}
                          </div>
                        </td>
                        <td className="p-3.5 text-center whitespace-nowrap">
                          <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-black ${
                            isMasuk 
                              ? 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 border border-emerald-200/60 dark:border-emerald-800/60' 
                              : isKeluar 
                              ? 'bg-rose-100 dark:bg-rose-950/60 text-rose-800 dark:text-rose-300 border border-rose-200/60 dark:border-rose-900/60' 
                              : isHapus 
                              ? 'bg-amber-100 dark:bg-amber-950/60 text-amber-900 dark:text-amber-300 font-bold border border-amber-200/60 dark:border-amber-800/60' 
                              : isAging
                              ? 'bg-blue-100 dark:bg-blue-950/60 text-blue-800 dark:text-blue-300 border border-blue-200/60 dark:border-blue-800/60'
                              : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200/60 dark:border-slate-700/60'
                          }`}>
                            {log.action}
                          </span>
                        </td>
                        <td className="p-3.5 text-slate-700 dark:text-slate-300 font-medium text-xs leading-relaxed">
                          {log.details}
                        </td>
                        <td className="p-3.5 text-right whitespace-nowrap">
                          <div className="text-[11px] font-mono text-slate-500 dark:text-slate-400">{log.ipAddress}</div>
                          <span className={`inline-flex items-center gap-1 text-[10px] font-bold ${
                            log.status === 'Success' ? 'text-emerald-700 dark:text-emerald-400' : 'text-amber-700 dark:text-amber-400'
                          }`}>
                            <span className={`w-1.5 h-1.5 rounded-full ${
                              log.status === 'Success' ? 'bg-emerald-600' : 'bg-amber-600'
                            }`} />
                            {log.status}
                          </span>
                        </td>
                      </tr>
                    );
                  })}

                {auditLogs.length === 0 && (
                  <tr>
                    <td colSpan={5} className="p-8 text-center text-slate-400 dark:text-slate-500">
                      Belum ada catatan aktivitas transaksi keuangan.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          <div className="p-4 bg-slate-50 dark:bg-slate-850/60 rounded-2xl border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 text-xs flex flex-col sm:flex-row items-center justify-between gap-3">
            <span>
              💡 <strong>Prinsip Akuntabilitas:</strong> Setiap mutasi kas, kwitansi iuran, atau penghapusan transaksi akan tersimpan permanen dalam audit trail demi menjaga transparansi dana umat.
            </span>
            <button
              onClick={() => setLogSearchQuery('')}
              className="text-amber-800 dark:text-amber-400 hover:underline font-bold text-xs shrink-0 cursor-pointer"
            >
              Reset Filter
            </button>
          </div>

        </div>
      )}

      {/* ========================================================================= */}
      {/* OFFICIAL A4 PRINTABLE DOCUMENT LAYOUT (Active on Print & Print Preview) */}
      {/* ========================================================================= */}
      <div id="printable-cashbook" className="hidden print:block bg-white text-black font-serif">
        
        {/* KOP SURAT RESMI RKM MPP */}
        <div className="border-b-[3px] border-black pb-2 mb-4">
          <div className="flex items-center gap-4">
            {settings.logoUrl ? (
              <img 
                src={getDirectImageUrl(settings.logoUrl)} 
                alt="Logo RKM"
                className="w-20 h-20 object-contain"
              />
            ) : (
              <div className="w-16 h-16 border-2 border-black rounded-lg flex items-center justify-center font-bold text-xs text-center">
                RKM MPP
              </div>
            )}
            
            <div className="flex-1 text-center font-serif">
              <h2 className="text-xl font-bold tracking-wide uppercase">
                {settings.orgName} ({settings.shortName})
              </h2>
              <p className="text-sm font-bold tracking-wider">
                PAGUYUBAN RUKUN KEMATIAN MUSLIM PERUMAHAN MADANI PARUNGPANJANG
              </p>
              <p className="text-xs mt-0.5">
                Sekretariat: {settings.rtRw}, {settings.village}, {settings.district}, {settings.regency} {settings.postalCode ? `- ${settings.postalCode}` : ''}
              </p>
              <p className="text-[11px] text-gray-700">
                Email: {settings.email} | Kontak Siaga: {settings.contactCenter}
              </p>
            </div>
          </div>
          <div className="border-b border-black mt-1.5" />
        </div>

        {/* JUDUL LAPORAN */}
        <div className="text-center my-3 font-sans">
          <h3 className="text-base font-extrabold uppercase underline tracking-wider">
            {filterMonth !== 'all' ? `LAPORAN REKAPITULASI KEUANGAN BULANAN - ${getMonthNameFromKey(filterMonth).toUpperCase()}` : 'LAPORAN BUKU KAS & MUTASI KEUANGAN PAGUYUBAN'}
          </h3>
          <p className="text-xs text-gray-700 mt-1">
            Periode: <strong>{periodTitle} {filterCategory !== 'all' ? `(${filterCategory})` : ''} ({filterType === 'in' ? 'Pemasukan Saja' : filterType === 'out' ? 'Pengeluaran Saja' : 'Pemasukan & Pengeluaran'})</strong>
            {' • '}Dicetak Tanggal: <strong>{formatDateIndo(new Date().toISOString().split('T')[0])}</strong>
          </p>
        </div>

        {/* RINGKASAN SALDO KAS KOTAK RESMI */}
        <div className={`grid ${filterMonth !== 'all' ? 'grid-cols-4' : 'grid-cols-3'} gap-2 my-3 text-xs font-sans`}>
          {filterMonth !== 'all' && (
            <div className="p-2 border border-black rounded bg-slate-50">
              <span className="text-[9px] text-gray-600 uppercase font-bold block">Saldo Awal Bulan</span>
              <span className="text-xs sm:text-sm font-bold text-slate-800 font-mono">{formatRupiah(initialBalanceBeforeMonth)}</span>
            </div>
          )}
          <div className="p-2 border border-black rounded bg-slate-50">
            <span className="text-[9px] text-gray-600 uppercase font-bold block">Total Kas Masuk (Penerimaan)</span>
            <span className="text-xs sm:text-sm font-bold text-black font-mono">+{formatRupiah(filteredIn)}</span>
          </div>
          <div className="p-2 border border-black rounded bg-slate-50">
            <span className="text-[9px] text-gray-600 uppercase font-bold block">Total Kas Keluar (Pengeluaran)</span>
            <span className="text-xs sm:text-sm font-bold text-black font-mono">-{formatRupiah(filteredOut)}</span>
          </div>
          <div className="p-2 border-2 border-black rounded bg-slate-100 font-bold">
            <span className="text-[9px] text-gray-800 uppercase font-bold block">Saldo Akhir Terverifikasi</span>
            <span className="text-xs sm:text-sm font-bold text-black font-mono">{formatRupiah(filteredBalance)}</span>
          </div>
        </div>

        {/* TABEL MUTASI KAS A4 */}
        <table className="a4-print-table my-3 font-sans">
          <thead>
            <tr>
              <th className="text-center w-8">No</th>
              <th className="w-20 text-center">Tanggal</th>
              <th className="w-24 text-center">No. Bukti</th>
              <th>Keterangan / Uraian Transaksi</th>
              <th className="w-28">Pihak Terkait</th>
              <th className="w-24 text-right">Masuk (Rp)</th>
              <th className="w-24 text-right">Keluar (Rp)</th>
              <th className="w-24 text-right">Saldo (Rp)</th>
            </tr>
          </thead>
          <tbody>
            {/* Initial Balance Row for Monthly Report */}
            {filterMonth !== 'all' && (
              <tr className="bg-slate-50 font-semibold italic">
                <td className="text-center">-</td>
                <td className="text-center">{filterMonth}-01</td>
                <td className="text-center font-mono text-[10px]">-</td>
                <td colSpan={2}>
                  Saldo Awal Kas Bulan {getMonthNameFromKey(filterMonth)}
                </td>
                <td className="text-right font-mono">-</td>
                <td className="text-right font-mono">-</td>
                <td className="text-right font-mono font-bold text-slate-900">
                  {formatRupiah(initialBalanceBeforeMonth)}
                </td>
              </tr>
            )}

            {printRows.map((row) => (
              <tr key={row.id} className="a4-page-break">
                <td className="text-center font-mono">{row.no}</td>
                <td className="text-center whitespace-nowrap">{formatDateIndo(row.date, false)}</td>
                <td className="text-center font-mono text-[10px]">{row.receiptNo || '-'}</td>
                <td>
                  <span className="font-semibold block">{row.description}</span>
                  <span className="text-[9px] text-gray-600 italic">[{row.category} - {row.paymentMethod}]</span>
                </td>
                <td>{row.recipientOrPayer}</td>
                <td className="text-right font-mono font-medium">
                  {row.type === 'in' ? formatRupiah(row.amount) : '-'}
                </td>
                <td className="text-right font-mono font-medium">
                  {row.type === 'out' ? formatRupiah(row.amount) : '-'}
                </td>
                <td className="text-right font-mono font-bold">
                  {formatRupiah(row.runningBalance)}
                </td>
              </tr>
            ))}

            {printRows.length === 0 && (
              <tr>
                <td colSpan={8} className="p-4 text-center text-gray-500 italic">
                  Tidak ada catatan mutasi transaksi pada periode {periodTitle}.
                </td>
              </tr>
            )}
          </tbody>
          <tfoot>
            <tr className="font-bold bg-slate-100 text-black">
              <td colSpan={5} className="text-right uppercase p-2">JUMLAH TOTAL</td>
              <td className="text-right font-mono p-2">{formatRupiah(filteredIn)}</td>
              <td className="text-right font-mono p-2">{formatRupiah(filteredOut)}</td>
              <td className="text-right font-mono p-2">{formatRupiah(filteredBalance)}</td>
            </tr>
          </tfoot>
        </table>

        {/* LEMBAR PENGESAHAN TANDA TANGAN */}
        <div className="mt-8 pt-4 a4-page-break font-sans text-xs">
          <div className="text-right mb-4 pr-6">
            <p>Parungpanjang, {formatDateIndo(new Date().toISOString().split('T')[0])}</p>
          </div>

          <div className="grid grid-cols-3 gap-4 text-center">
            <div>
              <p className="font-semibold text-gray-700 mb-16">Mengetahui,<br /><strong>Ketua RKM MPP</strong></p>
              <p className="font-bold text-slate-900 uppercase underline">{settings.chairmanName}</p>
              <p className="text-[10px] text-gray-600">Ketua Pengurus</p>
            </div>

            <div>
              <p className="font-semibold text-gray-700 mb-16">Memverifikasi,<br /><strong>Sekretaris RKM</strong></p>
              <p className="font-bold text-slate-900 uppercase underline">{settings.secretaryName}</p>
              <p className="text-[10px] text-gray-600">Sekretaris Pengurus</p>
            </div>

            <div>
              <p className="font-semibold text-gray-700 mb-16">Dibuat Oleh,<br /><strong>Bendahara Kas</strong></p>
              <p className="font-bold text-slate-900 uppercase underline">{settings.treasurerName}</p>
              <p className="text-[10px] text-gray-600">Bendahara Pengurus</p>
            </div>
          </div>

          <div className="mt-8 text-center text-[9px] text-gray-500 border-t border-gray-300 pt-2">
            Dokumen ini dihasilkan secara otomatis dari Sistem Digitalisasi Kas Rukun Kematian Muslim (RKM MPP) berlandaskan AD/ART 2024–2027.
          </div>
        </div>

      </div>

      {/* Print Preview Modal - Screen Dialog */}
      {showPrintPreview && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in no-print">
          <div className="bg-white rounded-3xl max-w-4xl w-full shadow-2xl border border-slate-200 max-h-[92vh] flex flex-col overflow-hidden">
            
            {/* Modal Header */}
            <div className="p-4 sm:p-5 bg-slate-900 text-white flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-emerald-500/20 text-emerald-400 rounded-xl">
                  <Printer className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-sm sm:text-base">
                    Pratinjau Cetak Laporan Kas A4
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    Periode: {periodTitle} • {printRows.length} Baris Transaksi
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    setShowPrintPreview(false);
                    setTimeout(() => window.print(), 100);
                  }}
                  className="flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow-md transition-all active:scale-98"
                >
                  <Printer className="w-4 h-4" />
                  <span>Cetak / Ekspor PDF Sekarang</span>
                </button>

                <button
                  onClick={() => setShowPrintPreview(false)}
                  className="p-2 text-slate-400 hover:text-white rounded-xl transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Modal Body - Paper Simulation */}
            <div className="p-6 overflow-y-auto bg-slate-100/80 flex-1">
              <div className="bg-white p-8 rounded-xl shadow border border-slate-200 max-w-3xl mx-auto text-black font-serif text-xs">
                
                {/* Header in Preview */}
                <div className="border-b-[2.5px] border-black pb-2 mb-4">
                  <div className="flex items-center gap-4">
                    {settings.logoUrl ? (
                      <img 
                        src={getDirectImageUrl(settings.logoUrl)} 
                        alt="Logo RKM"
                        className="w-16 h-16 object-contain"
                      />
                    ) : (
                      <div className="w-14 h-14 border-2 border-black rounded-lg flex items-center justify-center font-bold text-[10px] text-center">
                        RKM MPP
                      </div>
                    )}
                    
                    <div className="flex-1 text-center font-serif">
                      <h2 className="text-base font-bold tracking-wide uppercase">
                        {settings.orgName} ({settings.shortName})
                      </h2>
                      <p className="text-xs font-bold tracking-wider">
                        PAGUYUBAN RUKUN KEMATIAN MUSLIM PERUMAHAN MADANI PARUNGPANJANG
                      </p>
                      <p className="text-[10px] mt-0.5">
                        Sekretariat: {settings.rtRw}, {settings.village}, {settings.district}, {settings.regency}
                      </p>
                      <p className="text-[9px] text-gray-700">
                        Email: {settings.email} | Kontak Siaga: {settings.contactCenter}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Title in Preview */}
                <div className="text-center my-3 font-sans">
                  <h3 className="text-sm font-extrabold uppercase underline tracking-wider">
                    {filterMonth !== 'all' ? `LAPORAN REKAPITULASI KEUANGAN BULANAN - ${getMonthNameFromKey(filterMonth).toUpperCase()}` : 'LAPORAN BUKU KAS & MUTASI KEUANGAN PAGUYUBAN'}
                  </h3>
                  <p className="text-[10px] text-gray-700 mt-0.5">
                    Periode: <strong>{periodTitle}</strong> • Dicetak Tanggal: <strong>{formatDateIndo(new Date().toISOString().split('T')[0])}</strong>
                  </p>
                </div>

                {/* Balance Cards in Preview */}
                <div className={`grid ${filterMonth !== 'all' ? 'grid-cols-4' : 'grid-cols-3'} gap-2 my-3 text-[11px] font-sans`}>
                  {filterMonth !== 'all' && (
                    <div className="p-2 border border-black rounded bg-slate-50">
                      <span className="text-[8px] text-gray-600 uppercase font-bold block">Saldo Awal</span>
                      <span className="text-xs font-bold font-mono">{formatRupiah(initialBalanceBeforeMonth)}</span>
                    </div>
                  )}
                  <div className="p-2 border border-black rounded bg-slate-50">
                    <span className="text-[8px] text-gray-600 uppercase font-bold block">Total Masuk</span>
                    <span className="text-xs font-bold font-mono">+{formatRupiah(filteredIn)}</span>
                  </div>
                  <div className="p-2 border border-black rounded bg-slate-50">
                    <span className="text-[8px] text-gray-600 uppercase font-bold block">Total Keluar</span>
                    <span className="text-xs font-bold font-mono">-{formatRupiah(filteredOut)}</span>
                  </div>
                  <div className="p-2 border-2 border-black rounded bg-slate-100 font-bold">
                    <span className="text-[8px] text-gray-800 uppercase font-bold block">Saldo Akhir</span>
                    <span className="text-xs font-bold font-mono">{formatRupiah(filteredBalance)}</span>
                  </div>
                </div>

                {/* Table in Preview */}
                <table className="a4-print-table my-3 font-sans">
                  <thead>
                    <tr>
                      <th className="text-center w-6">No</th>
                      <th className="w-16 text-center">Tanggal</th>
                      <th className="w-20 text-center">No. Bukti</th>
                      <th>Keterangan</th>
                      <th className="w-24">Pihak</th>
                      <th className="w-20 text-right">Masuk</th>
                      <th className="w-20 text-right">Keluar</th>
                      <th className="w-20 text-right">Saldo</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filterMonth !== 'all' && (
                      <tr className="bg-slate-50 font-semibold italic text-[9.5px]">
                        <td className="text-center">-</td>
                        <td className="text-center">{filterMonth}-01</td>
                        <td className="text-center">-</td>
                        <td colSpan={2}>Saldo Awal Kas {getMonthNameFromKey(filterMonth)}</td>
                        <td className="text-right">-</td>
                        <td className="text-right">-</td>
                        <td className="text-right font-mono font-bold">{formatRupiah(initialBalanceBeforeMonth)}</td>
                      </tr>
                    )}
                    {printRows.map((row) => (
                      <tr key={row.id} className="text-[9.5px]">
                        <td className="text-center font-mono">{row.no}</td>
                        <td className="text-center whitespace-nowrap">{formatDateIndo(row.date, false)}</td>
                        <td className="text-center font-mono text-[9px]">{row.receiptNo || '-'}</td>
                        <td>{row.description}</td>
                        <td>{row.recipientOrPayer}</td>
                        <td className="text-right font-mono">{row.type === 'in' ? formatRupiah(row.amount) : '-'}</td>
                        <td className="text-right font-mono">{row.type === 'out' ? formatRupiah(row.amount) : '-'}</td>
                        <td className="text-right font-mono font-bold">{formatRupiah(row.runningBalance)}</td>
                      </tr>
                    ))}
                  </tbody>
                  <tfoot>
                    <tr className="font-bold bg-slate-100 text-black text-[10px]">
                      <td colSpan={5} className="text-right uppercase p-1.5">JUMLAH TOTAL</td>
                      <td className="text-right font-mono p-1.5">{formatRupiah(filteredIn)}</td>
                      <td className="text-right font-mono p-1.5">{formatRupiah(filteredOut)}</td>
                      <td className="text-right font-mono p-1.5">{formatRupiah(filteredBalance)}</td>
                    </tr>
                  </tfoot>
                </table>

                {/* Signatures in Preview */}
                <div className="mt-6 pt-2 font-sans text-[10px]">
                  <div className="text-right mb-3 pr-4">
                    <p>Parungpanjang, {formatDateIndo(new Date().toISOString().split('T')[0])}</p>
                  </div>
                  <div className="grid grid-cols-3 gap-2 text-center">
                    <div>
                      <p className="font-semibold text-gray-700 mb-10">Mengetahui,<br /><strong>Ketua RKM MPP</strong></p>
                      <p className="font-bold text-slate-900 uppercase underline">{settings.chairmanName}</p>
                    </div>
                    <div>
                      <p className="font-semibold text-gray-700 mb-10">Memverifikasi,<br /><strong>Sekretaris RKM</strong></p>
                      <p className="font-bold text-slate-900 uppercase underline">{settings.secretaryName}</p>
                    </div>
                    <div>
                      <p className="font-semibold text-gray-700 mb-10">Dibuat Oleh,<br /><strong>Bendahara Kas</strong></p>
                      <p className="font-bold text-slate-900 uppercase underline">{settings.treasurerName}</p>
                    </div>
                  </div>
                </div>

              </div>
            </div>

            {/* Modal Footer */}
            <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-xs">
              <span className="text-slate-500">
                Gunakan pengaturan cetak browser: <strong>Ukuran Kertas A4</strong> dan <strong>Background Graphics: On</strong>.
              </span>
              <div className="flex gap-2">
                <button
                  onClick={() => setShowPrintPreview(false)}
                  className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold rounded-xl"
                >
                  Tutup Pratinjau
                </button>
                <button
                  onClick={() => {
                    setShowPrintPreview(false);
                    setTimeout(() => window.print(), 100);
                  }}
                  className="px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-xl flex items-center gap-2 shadow"
                >
                  <Printer className="w-4 h-4 text-emerald-400" />
                  <span>Buka Dialog Print</span>
                </button>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* Record Transaction Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-sm animate-fade-in no-print">
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 max-w-lg w-full shadow-2xl border border-slate-100 dark:border-slate-800 max-h-[90vh] overflow-y-auto">
            
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="font-extrabold text-base text-slate-900 dark:text-white">
                Catat Transaksi Kas Baru
              </h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-lg cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleAddSubmit} className="mt-4 space-y-4 text-xs">
              
              {/* Type Switcher */}
              <div>
                <label className="text-slate-700 dark:text-slate-300 font-bold block mb-1.5">Jenis Transaksi:</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setNewTxType('in');
                      setNewTxCategory('Iuran Wajib');
                    }}
                    className={`h-10 px-3 rounded-xl font-bold border transition-all flex items-center justify-center gap-2 cursor-pointer ${
                      newTxType === 'in'
                        ? 'bg-emerald-600 text-white border-emerald-700 shadow-sm'
                        : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-300 dark:border-slate-700'
                    }`}
                  >
                    <ArrowDownRight className="w-4 h-4" />
                    <span>Kas Masuk</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setNewTxType('out');
                      setNewTxCategory('Santunan Kematian');
                    }}
                    className={`h-10 px-3 rounded-xl font-bold border transition-all flex items-center justify-center gap-2 cursor-pointer ${
                      newTxType === 'out'
                        ? 'bg-rose-600 text-white border-rose-700 shadow-sm'
                        : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-300 dark:border-slate-700'
                    }`}
                  >
                    <ArrowUpRight className="w-4 h-4" />
                    <span>Kas Keluar</span>
                  </button>
                </div>
              </div>

              {/* Category */}
              <div>
                <label className="text-slate-700 dark:text-slate-300 font-bold block mb-1">Kategori:</label>
                <select
                  value={newTxCategory}
                  onChange={(e) => setNewTxCategory(e.target.value as any)}
                  className="w-full h-10 px-3 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl font-semibold text-slate-800 dark:text-slate-200 cursor-pointer focus:outline-none focus:ring-2 focus:ring-emerald-500"
                >
                  {(newTxType === 'in' ? inCategories : outCategories).map(c => (
                    <option key={c} value={c}>{c}</option>
                  ))}
                </select>
              </div>

              {/* Nominal & Tanggal */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-700 dark:text-slate-300 font-bold block mb-1">Nominal (Rp):</label>
                  <input
                    type="number"
                    placeholder="Contoh: 500000"
                    value={newTxAmount}
                    onChange={(e) => setNewTxAmount(Number(e.target.value) || '')}
                    className="w-full h-10 px-3 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl font-mono font-bold text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    required
                  />
                </div>

                <div>
                  <label className="text-slate-700 dark:text-slate-300 font-bold block mb-1">Tanggal Transaksi:</label>
                  <input
                    type="date"
                    value={newTxDate}
                    onChange={(e) => setNewTxDate(e.target.value)}
                    className="w-full h-10 px-3 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl font-semibold text-slate-800 dark:text-slate-200 cursor-pointer focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    required
                  />
                </div>
              </div>

              {/* Pihak Terkait (Penyetor / Penerima) */}
              <div>
                <label className="text-slate-700 dark:text-slate-300 font-bold block mb-1">
                  {newTxType === 'in' ? 'Diterima Dari (Penyetor / Donatur):' : 'Diserahkan Kepada (Penerima Santunan / Toko):'}
                </label>
                <input
                  type="text"
                  placeholder="Nama orang / keluarga / toko / instansi"
                  value={newTxRecipientOrPayer}
                  onChange={(e) => setNewTxRecipientOrPayer(e.target.value)}
                  className="w-full h-10 px-3 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl font-semibold text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  required
                />
              </div>

              {/* Keterangan */}
              <div>
                <label className="text-slate-700 dark:text-slate-300 font-bold block mb-1">Keterangan / Rincian:</label>
                <textarea
                  rows={2}
                  placeholder="Penjelasan detail transaksi..."
                  value={newTxDescription}
                  onChange={(e) => setNewTxDescription(e.target.value)}
                  className="w-full p-3 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  required
                />
              </div>

              {/* Metode Pembayaran */}
              <div>
                <label className="text-slate-700 dark:text-slate-300 font-bold block mb-1">Metode:</label>
                <select
                  value={newTxMethod}
                  onChange={(e) => setNewTxMethod(e.target.value)}
                  className="w-full h-10 px-3 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl font-semibold text-slate-800 dark:text-slate-200 cursor-pointer focus:outline-none focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="Tunai">Kas Tunai</option>
                  <option value="Transfer BSI">Transfer Bank BSI</option>
                  <option value="Transfer BCA">Transfer Bank BCA</option>
                  <option value="QRIS">QRIS Merchant</option>
                </select>
              </div>

              <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex gap-2 justify-end">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="h-10 px-4 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-bold rounded-xl cursor-pointer transition-colors"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="h-10 px-6 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow transition-all cursor-pointer"
                >
                  Simpan Transaksi Kas
                </button>
              </div>

            </form>

          </div>
        </div>
      )}

      {/* Custom Modal Konfirmasi Hapus Transaksi Kas */}
      {txToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-sm animate-fade-in no-print">
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 max-w-md w-full shadow-2xl border border-slate-100 dark:border-slate-800 text-center">
            <div className="w-12 h-12 rounded-2xl bg-rose-100 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 flex items-center justify-center mx-auto mb-4">
              <Trash2 className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-extrabold text-slate-900 dark:text-white">
              Hapus Transaksi Kas?
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-2">
              Apakah Anda yakin ingin menghapus catatan mutasi kas berikut:
            </p>
            <div className="my-3 p-3 bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-200/80 dark:border-slate-700 text-left">
              <p className="font-bold text-xs text-slate-900 dark:text-white line-clamp-2">{txToDelete.description}</p>
              <p className="text-[11px] font-mono font-bold mt-1 text-emerald-600 dark:text-emerald-400">
                {txToDelete.type === 'in' ? '+' : '-'}{formatRupiah(txToDelete.amount)} • {formatDateIndo(txToDelete.date, false)}
              </p>
            </div>
            <p className="text-[11px] text-amber-600 dark:text-amber-400 font-semibold mb-4">
              Tindakan ini akan mempengaruhi saldo kas dan tercatat otomatis di Log Audit.
            </p>
            <div className="flex gap-2.5">
              <button
                onClick={() => setTxToDelete(null)}
                className="flex-1 h-10 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 font-bold rounded-xl text-xs transition-all cursor-pointer"
              >
                Batal
              </button>
              <button
                onClick={() => {
                  deleteTransaction(txToDelete.id);
                  setTxToDelete(null);
                }}
                className="flex-1 h-10 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-xl text-xs shadow-md transition-all cursor-pointer"
              >
                Ya, Hapus Transaksi
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};

