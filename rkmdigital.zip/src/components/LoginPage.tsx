import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Lock, 
  User, 
  Users, 
  ArrowRight, 
  CheckCircle2, 
  AlertCircle, 
  KeyRound, 
  Eye, 
  EyeOff, 
  ExternalLink
} from 'lucide-react';
import { useRkm } from '../context/RkmContext';
import { getDirectImageUrl } from '../utils/formatters';

interface LoginPageProps {
  onSuccess?: () => void;
  onBackToHome?: () => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({ onSuccess, onBackToHome }) => {
  const { login, settings } = useRkm();

  const [activeTab, setActiveTab] = useState<'pengurus' | 'warga'>('pengurus');
  
  // Officer form state
  const [officerUsername, setOfficerUsername] = useState('');
  const [officerPassword, setOfficerPassword] = useState('');
  const [showOfficerPassword, setShowOfficerPassword] = useState(false);
  
  // Citizen form state
  const [citizenIdentifier, setCitizenIdentifier] = useState('');
  const [citizenPin, setCitizenPin] = useState('');
  const [showCitizenPin, setShowCitizenPin] = useState(false);

  // Status state
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  // Handle Officer Login
  const handleOfficerLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setLoading(true);

    setTimeout(() => {
      const cleanUser = officerUsername.trim();
      const success = login(cleanUser);
      setLoading(false);
      if (success) {
        setSuccessMsg('✓ Berhasil masuk ke Panel Pengurus RKM!');
        if (onSuccess) onSuccess();
      } else {
        setErrorMsg('Username atau kata sandi pengurus tidak sesuai. Silakan periksa kembali kredensial Anda.');
      }
    }, 300);
  };

  // Handle Citizen Login
  const handleCitizenLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setLoading(true);

    setTimeout(() => {
      const cleanId = citizenIdentifier.trim();
      const success = login(cleanId, 'warga');
      setLoading(false);
      if (success) {
        setSuccessMsg('✓ Selamat datang di Portal Mandiri Warga!');
        if (onSuccess) onSuccess();
      } else {
        setErrorMsg('Nomor KK, NIK, atau No. HP tidak ditemukan di database warga. Pastikan data KK Anda telah terdaftar.');
      }
    }, 300);
  };

  return (
    <div className="min-h-[80vh] flex flex-col justify-center items-center py-6 px-4 sm:px-6">
      
      {/* Back to Home Button */}
      {onBackToHome && (
        <div className="w-full max-w-md mb-4 flex justify-start">
          <button
            type="button"
            onClick={onBackToHome}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white hover:bg-slate-100 text-slate-600 hover:text-slate-900 border border-slate-200 text-xs font-bold shadow-2xs transition-all cursor-pointer"
          >
            <span>← Kembali ke Beranda</span>
          </button>
        </div>
      )}

      {/* Header Identitas Sederhana & Elegan */}
      <div className="w-full max-w-md text-center mb-6">
        {settings.logoUrl && (
          <div className="flex justify-center mb-3">
            <img 
              src={getDirectImageUrl(settings.logoUrl)} 
              alt={settings.orgName}
              referrerPolicy="no-referrer"
              className="w-16 h-16 object-contain rounded-2xl bg-white p-1.5 shadow-md border border-slate-200"
            />
          </div>
        )}

        <h1 className="text-2xl font-black text-slate-900 tracking-tight">
          {settings.orgName}
        </h1>
        <p className="text-xs text-slate-500 font-medium mt-1">
          Sistem Informasi Kas & Fardhu Kifayah • {settings.village}
        </p>
      </div>

      {/* Main Login Card */}
      <div className="w-full max-w-md bg-white rounded-3xl border border-slate-200/90 shadow-xl overflow-hidden">
        
        {/* Tab Switcher: Pengurus vs Warga */}
        <div className="grid grid-cols-2 p-1.5 bg-slate-100/90 border-b border-slate-200/80 gap-1.5">
          <button
            type="button"
            onClick={() => {
              setActiveTab('pengurus');
              setErrorMsg(null);
            }}
            className={`flex items-center justify-center gap-2 py-2.5 rounded-2xl font-bold text-xs transition-all ${
              activeTab === 'pengurus'
                ? 'bg-white text-slate-900 shadow-sm border border-slate-200'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            <ShieldCheck className={`w-4 h-4 ${activeTab === 'pengurus' ? 'text-emerald-600' : 'text-slate-400'}`} />
            <span>Pengurus / Admin</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setActiveTab('warga');
              setErrorMsg(null);
            }}
            className={`flex items-center justify-center gap-2 py-2.5 rounded-2xl font-bold text-xs transition-all ${
              activeTab === 'warga'
                ? 'bg-white text-slate-900 shadow-sm border border-slate-200'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            <Users className={`w-4 h-4 ${activeTab === 'warga' ? 'text-emerald-600' : 'text-slate-400'}`} />
            <span>Portal Warga (KK)</span>
          </button>
        </div>

        <div className="p-6 space-y-4">
          
          {/* Status Message */}
          {errorMsg && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs font-semibold text-rose-800 flex items-start gap-2 animate-fade-in">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <div className="flex-1">{errorMsg}</div>
            </div>
          )}

          {successMsg && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs font-semibold text-emerald-900 flex items-center gap-2 animate-fade-in">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <div>{successMsg}</div>
            </div>
          )}

          {/* FORM 1: PENGURUS & ADMIN */}
          {activeTab === 'pengurus' && (
            <form onSubmit={handleOfficerLogin} className="space-y-3.5">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Username Pengurus:
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400">
                    <User className="w-4 h-4" />
                  </span>
                  <input
                    type="text"
                    value={officerUsername}
                    onChange={(e) => setOfficerUsername(e.target.value)}
                    placeholder="admin / bendahara / ketua / petugas"
                    className="w-full pl-9 pr-3 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold text-slate-900 focus:bg-white focus:ring-2 focus:ring-emerald-500"
                    required
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-bold text-slate-700">
                    Kata Sandi:
                  </label>
                  <a
                    href={`https://wa.me/${settings.waAdmin}?text=Halo%20Admin%20RKM,%20saya%20lupa%20kata%20sandi.`}
                    target="_blank"
                    rel="noreferrer"
                    className="text-[11px] text-emerald-700 font-semibold hover:underline"
                  >
                    Bantuan Login?
                  </a>
                </div>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400">
                    <Lock className="w-4 h-4" />
                  </span>
                  <input
                    type={showOfficerPassword ? 'text' : 'password'}
                    value={officerPassword}
                    onChange={(e) => setOfficerPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pl-9 pr-9 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-mono font-semibold text-slate-900 focus:bg-white focus:ring-2 focus:ring-emerald-500"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowOfficerPassword(!showOfficerPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                  >
                    {showOfficerPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-extrabold text-xs rounded-xl shadow transition-all flex items-center justify-center gap-2 mt-2 cursor-pointer"
              >
                <span>{loading ? 'Memeriksa Kredensial...' : 'Masuk Aplikasi'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          )}

          {/* FORM 2: PORTAL MANDIRI WARGA */}
          {activeTab === 'warga' && (
            <form onSubmit={handleCitizenLogin} className="space-y-3.5">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Nomor KK / NIK / No. HP Warga:
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400">
                    <Users className="w-4 h-4" />
                  </span>
                  <input
                    type="text"
                    value={citizenIdentifier}
                    onChange={(e) => setCitizenIdentifier(e.target.value)}
                    placeholder="Contoh: 3201082501890001"
                    className="w-full pl-9 pr-3 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-mono font-bold text-slate-900 focus:bg-white focus:ring-2 focus:ring-emerald-500"
                    required
                  />
                </div>
                <p className="text-[10px] text-slate-400 mt-1">
                  Masukkan Nomor KK atau No. HP yang terdaftar di RT/RW.
                </p>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-bold text-slate-700">
                    PIN Keamanan (Default: 123456):
                  </label>
                  <span className="text-[11px] text-slate-400">6 Digit</span>
                </div>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400">
                    <KeyRound className="w-4 h-4" />
                  </span>
                  <input
                    type={showCitizenPin ? 'text' : 'password'}
                    value={citizenPin}
                    onChange={(e) => setCitizenPin(e.target.value)}
                    placeholder="123456"
                    className="w-full pl-9 pr-9 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-mono font-bold text-slate-900 focus:bg-white focus:ring-2 focus:ring-emerald-500"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowCitizenPin(!showCitizenPin)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                  >
                    {showCitizenPin ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-extrabold text-xs rounded-xl shadow transition-all flex items-center justify-center gap-2 mt-2 cursor-pointer"
              >
                <span>{loading ? 'Mencari Data KK...' : 'Buka Portal Mandiri Warga'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          )}


        </div>

        {/* Footer Card */}
        <div className="bg-slate-50 px-6 py-3 border-t border-slate-200/80 flex items-center justify-between text-[11px] text-slate-500">
          <span>{settings.shortName} • Versi 2.5</span>
          <a
            href="https://drive.google.com/file/d/1itGAXcxzcn0Wg9uqoHnc1fniJzUJKX83/view?usp=sharing"
            target="_blank"
            rel="noreferrer"
            className="text-emerald-700 font-bold hover:underline inline-flex items-center gap-1"
          >
            <span>AD/ART PDF</span>
            <ExternalLink className="w-3 h-3" />
          </a>
        </div>

      </div>

    </div>
  );
};
