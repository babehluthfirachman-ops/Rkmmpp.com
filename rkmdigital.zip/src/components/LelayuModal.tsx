import React, { useState } from 'react';
import { 
  X, 
  Share2, 
  Printer, 
  Copy, 
  CheckCircle2, 
  Clock, 
  MapPin, 
  Phone, 
  HeartHandshake, 
  ShieldAlert,
  Truck,
  Layers,
  Sparkles
} from 'lucide-react';
import { useRkm } from '../context/RkmContext';
import { DeathNotice } from '../types';
import { formatRupiah, createWhatsAppUrl, getDirectImageUrl } from '../utils/formatters';

export const LelayuModal: React.FC = () => {
  const { selectedLelayu, closeLelayuModal, settings } = useRkm();
  const [copied, setCopied] = useState(false);

  if (!selectedLelayu) return null;

  const dn: DeathNotice = selectedLelayu;

  // Build WhatsApp Broadcast text for community groups
  const waBroadcastText = 
`*BERITA DUKA CITA (LELAYU)*
*${settings.orgName.toUpperCase()}*
────────────────────────────
_Inna lillahi wa inna ilaihi raji'un_
(إِنَّا لِلَّٰهِ وَإِنَّا إِلَيْهِ رَاجِعُونَ)

Telah berpulang ke Rahmatullah, saudara/i kita yang tercinta:

*Nama Almarhum/ah:*
*${dn.deceasedName} bin/binti ${dn.binBinti}*
• *Usia:* ${dn.age} Tahun
• *Alamat:* ${dn.address} (RT ${dn.rt} / RW ${dn.rw})

*INFORMASI PEMAKAMAN:*
• *Waktu Wafat:* ${dn.passAwayTime}
• *Tempat Wafat:* ${dn.passAwayLocation}
• *Sholat Jenazah:* ${dn.funeralTime}
• *Lokasi Sholat:* ${dn.mosqueName}
• *Pemakaman:* ${dn.cemeteryName}

*KONTAK KELUARGA / SHOHIBUL MUSHIBAH:*
• ${dn.contactPerson} (${dn.contactPhone})

*PELAYANAN RKM MASJID METRO PARUNG PANJANG:*
${dn.shroudsProvided ? '✓ Perlengkapan Kain Kafan & Tim Pemulasaraan Lengkap\n' : ''}${dn.ambulanceProvided ? '✓ Mobil Ambulance Jenazah Siaga\n' : ''}${dn.graveDiggerAssigned ? '✓ Koordinasi Penggalian Makam TPU\n' : ''}✓ Uang Santunan Duka: ${formatRupiah(dn.rkmAssistanceAmount)}

Semoga Almarhum/ah diampuni segala dosa-dosanya, diterima seluruh amal ibadahnya, dan diberikan tempat terbaik di sisi Allah SWT. Serta keluarga yang ditinggalkan diberikan ketabahan dan keikhlasan. Aamiin ya Rabbal 'Alamin.

_Pengurus RKM Masjid Metro Parung Panjang_
*Pusat Bantuan 24 Jam:* ${settings.contactCenter}`;

  const handleCopy = () => {
    navigator.clipboard.writeText(waBroadcastText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleShareWA = () => {
    const url = `https://api.whatsapp.com/send?text=${encodeURIComponent(waBroadcastText)}`;
    window.open(url, '_blank');
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/75 backdrop-blur-sm animate-fade-in overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-slate-100 overflow-hidden my-8">
        
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-slate-900 text-white no-print">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-emerald-500/20 text-emerald-400 rounded-lg">
              <HeartHandshake className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base text-white">Lelayu / Berita Duka Warga</h3>
              <p className="text-xs text-slate-400">Pengumuman & Koordinasi Pemulasaraan Jenazah</p>
            </div>
          </div>

          <button
            onClick={closeLelayuModal}
            className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Action Toolbar */}
        <div className="grid grid-cols-3 gap-3 p-4 bg-emerald-50 border-b border-emerald-100 no-print">
          <button
            onClick={handleShareWA}
            className="flex items-center justify-center gap-2 py-2.5 px-3 bg-emerald-600 hover:bg-emerald-700 active:scale-98 text-white font-semibold text-xs sm:text-sm rounded-xl shadow-sm transition-all"
          >
            <Share2 className="w-4 h-4" />
            <span>Bagikan ke WA Grup</span>
          </button>

          <button
            onClick={handlePrint}
            className="flex items-center justify-center gap-2 py-2.5 px-3 bg-white hover:bg-slate-100 active:scale-98 text-slate-700 border border-slate-300 font-semibold text-xs sm:text-sm rounded-xl shadow-sm transition-all"
          >
            <Printer className="w-4 h-4 text-emerald-600" />
            <span>Cetak Pengumuman</span>
          </button>

          <button
            onClick={handleCopy}
            className="flex items-center justify-center gap-2 py-2.5 px-3 bg-white hover:bg-slate-100 active:scale-98 text-slate-700 border border-slate-300 font-semibold text-xs sm:text-sm rounded-xl shadow-sm transition-all"
          >
            {copied ? (
              <>
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span className="text-emerald-700">Tersalin!</span>
              </>
            ) : (
              <>
                <Copy className="w-4 h-4 text-slate-500" />
                <span>Salin Teks Broadcast</span>
              </>
            )}
          </button>
        </div>

        {/* Official Lelayu Sheet Body */}
        <div id="printable-receipt" className="p-6 sm:p-8 bg-white">
          <div className="border-2 border-slate-800 rounded-xl p-6 relative bg-slate-50/50">
            
            {/* Arabic Header & Institution Logo */}
            <div className="text-center pb-4 border-b border-slate-300">
              {settings.logoUrl && (
                <div className="flex justify-center mb-2">
                  <img 
                    src={getDirectImageUrl(settings.logoUrl)} 
                    alt={settings.orgName}
                    referrerPolicy="no-referrer"
                    className="w-14 h-14 object-contain rounded-xl bg-white p-1 shadow-sm border border-slate-200"
                  />
                </div>
              )}
              <div className="text-2xl sm:text-3xl font-arabic text-slate-900 my-1 font-bold">
                إِنَّا لِلَّٰهِ وَإِنَّا إِلَيْهِ رَاجِعُونَ
              </div>
              <p className="text-xs italic text-slate-600">
                "Sesungguhnya kami adalah kepunyaan Allah dan kepada-Nya lah kami kembali."
              </p>
              
              <div className="mt-3 inline-block px-3 py-1 bg-slate-900 text-white text-[11px] font-bold tracking-widest uppercase rounded">
                BERITA DUKA CITA (LELAYU)
              </div>
              <p className="text-xs text-emerald-800 font-bold mt-1 uppercase">{settings.orgName}</p>
            </div>

            {/* Deceased Info Banner */}
            <div className="my-6 text-center bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
              <p className="text-xs uppercase tracking-wider text-slate-500 font-semibold">Telah Berpulang ke Rahmatullah:</p>
              <h2 className="text-xl sm:text-2xl font-black text-slate-900 mt-1">
                {dn.deceasedName} <span className="text-base font-medium text-slate-600">bin/binti {dn.binBinti}</span>
              </h2>
              <div className="flex items-center justify-center gap-4 mt-2 text-xs text-slate-600">
                <span>Usia: <strong>{dn.age} Tahun</strong></span>
                <span>•</span>
                <span>Jenis Kelamin: <strong>{dn.gender}</strong></span>
              </div>
              <div className="mt-2 text-xs font-medium text-slate-700 bg-slate-100 py-1.5 px-3 rounded-lg inline-block">
                Alamat Duka: {dn.address}
              </div>
            </div>

            {/* Schedule & Funeral Details */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs mb-5">
              <div className="p-3.5 bg-white rounded-xl border border-slate-200">
                <div className="flex items-center gap-2 font-bold text-slate-900 mb-2">
                  <Clock className="w-4 h-4 text-emerald-700" />
                  <span>Waktu & Sholat Jenazah</span>
                </div>
                <p className="text-slate-600 mb-1"><strong>Wafat:</strong> {dn.passAwayTime}</p>
                <p className="text-slate-600 mb-1"><strong>Lokasi Wafat:</strong> {dn.passAwayLocation}</p>
                <p className="text-slate-900 font-semibold"><strong>Sholat:</strong> {dn.funeralTime}</p>
                <p className="text-emerald-800 font-medium">di {dn.mosqueName}</p>
              </div>

              <div className="p-3.5 bg-white rounded-xl border border-slate-200">
                <div className="flex items-center gap-2 font-bold text-slate-900 mb-2">
                  <MapPin className="w-4 h-4 text-emerald-700" />
                  <span>Lokasi Pemakaman & Kontak</span>
                </div>
                <p className="text-slate-900 font-semibold mb-1"><strong>TPU / Makam:</strong> {dn.cemeteryName}</p>
                <p className="text-slate-600 mb-1"><strong>Shohibul Mushibah:</strong> {dn.contactPerson}</p>
                <p className="text-slate-600"><strong>No. Kontak/WA:</strong> {dn.contactPhone}</p>
              </div>
            </div>

            {/* RKM Services Assistance Card */}
            <div className="p-4 bg-emerald-50 rounded-xl border border-emerald-200 text-xs">
              <h4 className="font-bold text-emerald-950 flex items-center gap-2 mb-2">
                <ShieldAlert className="w-4 h-4 text-emerald-700" />
                Layanan & Santunan Kematian yang Telah Disiapkan RKM:
              </h4>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px] text-emerald-900">
                <div className="bg-white p-2 rounded-lg border border-emerald-100 text-center">
                  <span className="block font-bold">1 Set Kafan</span>
                  <span className="text-[10px] text-emerald-700">Tersedia Lengkap</span>
                </div>
                <div className="bg-white p-2 rounded-lg border border-emerald-100 text-center">
                  <span className="block font-bold">Pemulasaraan</span>
                  <span className="text-[10px] text-emerald-700">Tim Mandi Siaga</span>
                </div>
                <div className="bg-white p-2 rounded-lg border border-emerald-100 text-center">
                  <span className="block font-bold">Mobil Jenazah</span>
                  <span className="text-[10px] text-emerald-700">Ambulance Siap</span>
                </div>
                <div className="bg-white p-2 rounded-lg border border-emerald-100 text-center">
                  <span className="block font-bold">Santunan Duka</span>
                  <span className="text-[10px] text-emerald-700 font-bold">{formatRupiah(dn.rkmAssistanceAmount)}</span>
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="mt-5 pt-3 border-t border-slate-300 flex items-center justify-between text-[11px] text-slate-500">
              <span>Pengurus RKM Masjid Metro Parung Panjang</span>
              <span>Pusat Informasi 24 Jam: {settings.contactCenter}</span>
            </div>

          </div>
        </div>

        {/* Bottom bar */}
        <div className="px-6 py-3 bg-slate-50 border-t border-slate-200 flex justify-end no-print">
          <button
            onClick={closeLelayuModal}
            className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-800 font-semibold text-xs rounded-xl transition-all"
          >
            Tutup
          </button>
        </div>

      </div>
    </div>
  );
};
