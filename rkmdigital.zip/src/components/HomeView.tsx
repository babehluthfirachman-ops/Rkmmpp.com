import React, { useState } from 'react';
import { 
  HeartHandshake, 
  ShieldCheck, 
  LogIn, 
  Phone, 
  AlertTriangle, 
  CheckCircle2, 
  Search, 
  Users, 
  CreditCard, 
  Package, 
  ScrollText, 
  Clock, 
  MapPin, 
  ArrowRight, 
  Sparkles, 
  FileText, 
  BookOpen, 
  Activity, 
  UserCheck, 
  Calendar,
  Send,
  ExternalLink,
  ChevronRight,
  Info,
  Layers,
  Award,
  Truck,
  Newspaper,
  User,
  X,
  Lock,
  MessageSquare
} from 'lucide-react';
import { useRkm } from '../context/RkmContext';
import { formatRupiah, getDirectImageUrl, getAvatarUrl } from '../utils/formatters';
import { Citizen } from '../types';
import { PwaInstallPrompt } from './PwaInstallPrompt';

interface HomeViewProps {
  onNavigateToLogin: () => void;
  onNavigateToTab: (tab: string) => void;
  onOpenReportDeath: () => void;
  onOpenQuickDues: () => void;
}

export const HomeView: React.FC<HomeViewProps> = ({
  onNavigateToLogin,
  onNavigateToTab,
  onOpenReportDeath,
  onOpenQuickDues
}) => {
  const { 
    settings, 
    citizens, 
    currentUser, 
    deathNotices, 
    officers,
    openLelayuModal, 
    openKtaModal,
    openProfileModal,
    addFeedback
  } = useRkm();

  const [searchQuery, setSearchQuery] = useState('');
  const [searchResult, setSearchResult] = useState<Citizen | null>(null);
  const [searched, setSearched] = useState(false);
  const [showLoginRequiredModal, setShowLoginRequiredModal] = useState(false);

  // Feedback form state
  const [fbName, setFbName] = useState('');
  const [fbNoKK, setFbNoKK] = useState('');
  const [fbPhone, setFbPhone] = useState('');
  const [fbCategory, setFbCategory] = useState<'Saran' | 'Pertanyaan' | 'Keluhan' | 'Ucapan Terima Kasih'>('Saran');
  const [fbMessage, setFbMessage] = useState('');
  const [fbSuccess, setFbSuccess] = useState(false);

  const activeDeaths = deathNotices.filter(d => d.status === 'Aktif');
  const baseDues = settings.baseDuesAmount || settings.duesAmount || 5000;
  const extraDues = settings.extraMemberDuesAmount || 3000;
  const activeCitizensCount = citizens.filter(c => c.status === 'Aktif').length;
  const totalLives = citizens.reduce((sum, c) => sum + (c.members?.filter(m => m.status === 'Hidup').length || 1), 0);

  // Handle Lapor Duka: must be logged in first!
  const handleLaporDukaClick = () => {
    if (!currentUser) {
      setShowLoginRequiredModal(true);
    } else {
      onOpenReportDeath();
    }
  };

  // Handle public fast search for citizen status
  const handleSearchCitizen = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;

    const query = searchQuery.toLowerCase().trim();
    const found = citizens.find(c => 
      c.noKK.includes(query) || 
      c.headOfFamily.toLowerCase().includes(query) || 
      c.nik.includes(query) ||
      (c.phone && c.phone.includes(query))
    );

    setSearchResult(found || null);
    setSearched(true);
  };

  // Handle send feedback
  const handleSendFeedback = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fbName || !fbMessage) return;

    addFeedback({
      citizenName: fbName,
      noKK: fbNoKK || '-',
      phone: fbPhone || '-',
      category: fbCategory,
      message: fbMessage,
      createdAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
      status: 'Baru'
    });

    setFbSuccess(true);
    setFbName('');
    setFbNoKK('');
    setFbPhone('');
    setFbMessage('');
    setTimeout(() => setFbSuccess(false), 4000);
  };

  // List of official news / updates
  const NEWS_ITEMS = [
    {
      id: 'news-1',
      title: 'Pemberlakuan Anggaran Dasar & Anggaran Rumah Tangga (AD/ART) Periode 2024–2027',
      date: '15 Januari 2024',
      category: 'Ketetapan Musyawarah Warga',
      summary: 'Dokumen AD/ART RKM Perumahan Metro Parung Panjang telah disahkan bersama pengurus DKM Al-Muhajirin dan seluruh perwakilan warga RT 01 s/d RT 11. Mengatur rincian iuran, hak fardhu kifayah, santunan, dan tata kelola transparan.',
      icon: BookOpen,
      tagColor: 'bg-emerald-100 text-emerald-800 border-emerald-200'
    },
    {
      id: 'news-2',
      title: 'Kesiapsiagaan Posko Satgas Duka & Ambulans Jenazah Siaga 24 Jam',
      date: '12 Agustus 2026',
      category: 'Operasional Layanan',
      summary: 'Tim pemulasaraan ikhwan & akhwat serta armada ambulans RKM selalu siap melayani panggilan darurat warga. Hubungi hotline posko 24 jam untuk respon cepat tanpa dipungut biaya bagi anggota aktif.',
      icon: Truck,
      tagColor: 'bg-rose-100 text-rose-800 border-rose-200'
    },
    {
      id: 'news-3',
      title: 'Digitalisasi Kuitansi Otomatis WhatsApp & KTA Digital Berbasis Barcode',
      date: '20 Agustus 2026',
      category: 'Inovasi Sistem',
      summary: 'Warga kini menerima bukti setor kuitansi berformat resmi via WhatsApp secara instan setiap pembayaran tercatat. KTA digital dapat diakses mandiri kapan saja.',
      icon: Sparkles,
      tagColor: 'bg-blue-100 text-blue-800 border-blue-200'
    },
    {
      id: 'news-4',
      title: 'Perawatan Logistik Tenda, Kursi Takziah & Perlengkapan Pemakaman di Posko',
      date: '25 Agustus 2026',
      category: 'Logistik & Aset',
      summary: 'Inventaris 100 kursi plastik, 2 set tenda duka, keranda stenlis, kain penutup, dan perlengkapan mandi jenazah telah selesai diinspeksi dalam kondisi prima untuk kebutuhan takziah warga.',
      icon: Package,
      tagColor: 'bg-purple-100 text-purple-800 border-purple-200'
    }
  ];

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 flex flex-col selection:bg-emerald-500 selection:text-white">
      
      {/* ─────────────────────────────────────────────────────────────
          1. TOP NAVIGATION HEADER (Portal News & Information)
          ───────────────────────────────────────────────────────────── */}
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between gap-4">
          
          {/* Logo & Brand */}
          <div className="flex items-center gap-3.5">
            {settings.logoUrl ? (
              <img 
                src={getDirectImageUrl(settings.logoUrl)} 
                alt={settings.orgName}
                referrerPolicy="no-referrer"
                className="w-11 h-11 rounded-2xl object-cover border border-emerald-500/30 shadow-sm bg-white p-0.5"
              />
            ) : (
              <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-emerald-700 to-emerald-500 flex items-center justify-center text-white shadow-md shadow-emerald-700/20">
                <HeartHandshake className="w-6 h-6" />
              </div>
            )}
            <div>
              <div className="flex items-center gap-2">
                <span className="font-black text-slate-900 text-base sm:text-lg tracking-tight leading-none">
                  {settings.orgName || 'PERUMAHAN METRO PARUNG PANJANG'}
                </span>
                <span className="hidden sm:inline-block text-[10px] font-black uppercase tracking-wider bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full border border-emerald-300/60">
                  AD/ART 2024–2027
                </span>
              </div>
              <p className="text-[11px] text-slate-500 font-medium truncate max-w-[200px] sm:max-w-xs mt-0.5">
                {settings.village || 'Perumahan Metro Parung Panjang, Parungpanjang, Bogor'}
              </p>
            </div>
          </div>

          {/* Center Navigation Links (Desktop) */}
          <nav className="hidden lg:flex items-center gap-6 text-xs font-bold text-slate-600">
            <a href="#berita" className="hover:text-emerald-600 transition-colors">
              Berita & Maklumat
            </a>
            <a href="#pengurus" className="hover:text-emerald-600 transition-colors">
              Susunan Pengurus
            </a>
            <a href="#layanan" className="hover:text-emerald-600 transition-colors">
              Layanan Duka
            </a>
            <a href="#iuran" className="hover:text-emerald-600 transition-colors">
              Ketentuan Iuran
            </a>
            <a href="#cek-warga" className="hover:text-emerald-600 transition-colors">
              Cek Status Warga
            </a>
            <button 
              onClick={() => onNavigateToTab('ad-art')} 
              className="hover:text-emerald-600 transition-colors cursor-pointer"
            >
              AD/ART 2024–2027
            </button>
          </nav>

          {/* Right Header Action: PWA + Login Button / Profile */}
          <div className="flex items-center gap-2.5 sm:gap-3">
            <PwaInstallPrompt />

            {currentUser ? (
              <div className="flex items-center gap-2">
                <button
                  onClick={() => openProfileModal()}
                  className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs border border-slate-200 transition-all cursor-pointer"
                  title="Buka Profil & Ubah Password"
                >
                  <img
                    src={getAvatarUrl(currentUser.name, currentUser.role, currentUser.avatar)}
                    alt={currentUser.name}
                    className="w-5 h-5 rounded-full object-cover border border-slate-300"
                  />
                  <span className="hidden sm:inline">{currentUser.name}</span>
                </button>

                <button
                  onClick={() => onNavigateToTab('iuran')}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md shadow-emerald-700/20 transition-all active:scale-[0.98] cursor-pointer"
                >
                  <span>Buka Sistem</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            ) : (
              <button
                id="btn-header-login"
                onClick={onNavigateToLogin}
                className="flex items-center gap-2 px-4 sm:px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-black text-xs sm:text-sm shadow-md shadow-emerald-600/25 transition-all transform active:scale-[0.98] cursor-pointer"
              >
                <LogIn className="w-4 h-4" />
                <span>Masuk / Login</span>
              </button>
            )}
          </div>
        </div>
      </header>

      {/* ─────────────────────────────────────────────────────────────
          2. EMERGENCY RUNNING ALERT (If active death notice)
          ───────────────────────────────────────────────────────────── */}
      {activeDeaths.length > 0 && (
        <div className="bg-gradient-to-r from-rose-900 via-rose-800 to-slate-900 text-white p-3.5 shadow-md border-b border-rose-700/60 animate-fade-in">
          <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2.5">
              <span className="p-1.5 bg-rose-600 rounded-xl text-white animate-pulse">
                <AlertTriangle className="w-4 h-4" />
              </span>
              <div>
                <span className="font-extrabold text-rose-200 uppercase tracking-wider text-[10px] block">
                  BERITA DUKA CITA (LELAYU AKTIF):
                </span>
                <span className="font-bold text-white text-sm">
                  Inna lillahi wa inna ilaihi raji'un — Telah wafat Alm/Almh. <strong>{activeDeaths[0].deceasedName}</strong> ({activeDeaths[0].binBinti})
                </span>
              </div>
            </div>

            <button
              onClick={() => openLelayuModal(activeDeaths[0])}
              className="px-3.5 py-1.5 bg-white text-rose-900 hover:bg-rose-50 rounded-xl text-xs font-black shadow transition-all self-end sm:self-center flex items-center gap-1.5 cursor-pointer"
            >
              <span>Lihat Maklumat & Doa</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* ─────────────────────────────────────────────────────────────
          3. HERO PORTAL BERITA & INFORMASI RKM MPP
          ───────────────────────────────────────────────────────────── */}
      <section className="relative overflow-hidden bg-gradient-to-b from-emerald-950 via-slate-900 to-slate-950 text-white py-14 sm:py-20 px-4 sm:px-6 lg:px-8 border-b border-slate-800">
        <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#10b981_1px,transparent_1px)] [background-size:20px_20px] pointer-events-none" />
        
        <div className="relative max-w-5xl mx-auto text-center space-y-6">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-500/20 border border-emerald-400/30 text-emerald-300 text-xs font-extrabold shadow-inner">
            <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
            <span>Portal Berita & Informasi Resmi Pelayanan Duka Cita</span>
          </div>

          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black tracking-tight leading-tight text-white max-w-4xl mx-auto">
            Rukun Kematian Muslim <br className="hidden sm:inline" />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-teal-300 to-cyan-300">
              {settings.orgName || 'PERUMAHAN METRO PARUNG PANJANG'}
            </span>
          </h1>

          <p className="text-sm sm:text-base text-slate-300 max-w-2xl mx-auto leading-relaxed font-normal">
            Pusat informasi gotong royong warga muslim dalam menunaikan kewajiban fardhu kifayah secara tertib, cepat, ikhlas, dan transparan berlandaskan <strong>AD/ART RKM MPP Periode 2024–2027</strong>.
          </p>

          {/* Action Buttons (Lapor Duka checks authentication) */}
          <div className="pt-4 flex flex-wrap items-center justify-center gap-3 sm:gap-4">
            <button
              onClick={handleLaporDukaClick}
              className="px-5 py-3.5 bg-rose-600 hover:bg-rose-500 text-white font-bold text-sm rounded-2xl border border-rose-500/60 shadow-lg shadow-rose-900/30 flex items-center gap-2 transition-all cursor-pointer"
            >
              <Phone className="w-4 h-4 text-rose-200 animate-bounce" />
              <span>Lapor Duka Siaga 24 Jam</span>
            </button>

            <a
              href="#cek-warga"
              className="px-5 py-3.5 bg-slate-800/90 hover:bg-slate-700 text-slate-200 font-bold text-sm rounded-2xl border border-slate-700 flex items-center gap-2 transition-all"
            >
              <Search className="w-4 h-4 text-emerald-400" />
              <span>Cek Status Warga</span>
            </a>

            <button
              onClick={() => onNavigateToTab('ad-art')}
              className="px-5 py-3.5 bg-emerald-800/60 hover:bg-emerald-800 text-emerald-200 font-bold text-sm rounded-2xl border border-emerald-600/50 flex items-center gap-2 transition-all cursor-pointer"
            >
              <BookOpen className="w-4 h-4" />
              <span>Dokumen AD/ART</span>
            </button>

            {!currentUser && (
              <button
                onClick={onNavigateToLogin}
                className="px-5 py-3.5 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-slate-950 font-black text-sm rounded-2xl shadow-lg shadow-emerald-500/25 flex items-center gap-2 transition-all cursor-pointer"
              >
                <LogIn className="w-4 h-4 text-slate-950" />
                <span>Masuk Akun</span>
              </button>
            )}
          </div>

          {/* Live Informational Statistics (Without Cash Figures) */}
          <div className="pt-8 grid grid-cols-2 sm:grid-cols-4 gap-3 max-w-4xl mx-auto text-left">
            <div className="p-3.5 bg-slate-800/80 rounded-2xl border border-slate-700/80">
              <span className="text-[10px] font-bold uppercase text-slate-400 block">Warga Terdaftar</span>
              <span className="text-xl font-black text-emerald-400">{activeCitizensCount} KK Aktif</span>
              <span className="text-[10px] text-slate-400 block mt-0.5">{totalLives} Jiwa Tertanggung</span>
            </div>

            <div className="p-3.5 bg-slate-800/80 rounded-2xl border border-slate-700/80">
              <span className="text-[10px] font-bold uppercase text-slate-400 block">Iuran Pokok KK</span>
              <span className="text-xl font-black text-teal-300">{formatRupiah(baseDues)}</span>
              <span className="text-[10px] text-slate-400 block mt-0.5">/ KK / Bulan</span>
            </div>

            <div className="p-3.5 bg-slate-800/80 rounded-2xl border border-slate-700/80">
              <span className="text-[10px] font-bold uppercase text-slate-400 block">Satgas Siaga</span>
              <span className="text-xl font-black text-emerald-300">24 Jam Penuh</span>
              <span className="text-[10px] text-slate-400 block mt-0.5">Ambulans & Amil Siap</span>
            </div>

            <div className="p-3.5 bg-slate-800/80 rounded-2xl border border-slate-700/80">
              <span className="text-[10px] font-bold uppercase text-slate-400 block">Landasan Hukum</span>
              <span className="text-xl font-black text-amber-300">AD/ART Resmi</span>
              <span className="text-[10px] text-slate-400 block mt-0.5">SK DKM Al-Muhajirin</span>
            </div>
          </div>
        </div>
      </section>

      {/* ─────────────────────────────────────────────────────────────
          4. BERITA TERKINI & MAKLUMAT RESMI RKM MPP
          ───────────────────────────────────────────────────────────── */}
      <section id="berita" className="py-14 sm:py-18 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto w-full">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
          <div>
            <span className="text-xs font-extrabold text-emerald-600 uppercase tracking-wider bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
              Portal Berita & Informasi
            </span>
            <h2 className="text-2xl sm:text-3xl font-black text-slate-900 mt-2">
              Kabar & Maklumat Terkini RKM
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 mt-1">
              Informasi kegiatan, pengumuman resmi, dan perkembangan layanan duka di Perumahan Metro Parung Panjang.
            </p>
          </div>

          <button
            onClick={() => onNavigateToTab('ad-art')}
            className="text-xs font-bold text-emerald-700 hover:text-emerald-800 flex items-center gap-1 self-start sm:self-auto cursor-pointer"
          >
            <span>Lihat Ketentuan AD/ART</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {NEWS_ITEMS.map((item) => {
            const Icon = item.icon;
            return (
              <div 
                key={item.id}
                className="bg-white p-6 rounded-3xl border border-slate-200/90 shadow-sm hover:shadow-md transition-all flex flex-col justify-between space-y-4"
              >
                <div className="space-y-2.5">
                  <div className="flex items-center justify-between gap-2">
                    <span className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full border ${item.tagColor}`}>
                      {item.category}
                    </span>
                    <span className="text-[11px] text-slate-400 font-medium flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5" />
                      <span>{item.date}</span>
                    </span>
                  </div>

                  <h3 className="font-extrabold text-slate-900 text-base leading-snug">
                    {item.title}
                  </h3>

                  <p className="text-xs text-slate-600 leading-relaxed">
                    {item.summary}
                  </p>
                </div>

                <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs">
                  <span className="text-[11px] font-bold text-slate-500 flex items-center gap-1.5">
                    <Icon className="w-4 h-4 text-emerald-600" />
                    <span>RKM Metro Parung Panjang</span>
                  </span>
                  <span className="text-emerald-700 font-bold flex items-center gap-1">
                    <span>Terverifikasi</span>
                    <CheckCircle2 className="w-3.5 h-3.5" />
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* ─────────────────────────────────────────────────────────────
          5. SUSUNAN PENGURUS DARI AD/ART RKM
          ───────────────────────────────────────────────────────────── */}
      <section id="pengurus" className="py-14 sm:py-18 bg-slate-100/80 border-y border-slate-200 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto w-full space-y-8">
          <div className="text-center max-w-2xl mx-auto">
            <span className="text-xs font-extrabold text-emerald-600 uppercase tracking-wider bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
              Struktur Organisasi AD/ART
            </span>
            <h2 className="text-2xl sm:text-3xl font-black text-slate-900 mt-2">
              Susunan Pengurus & Satgas Duka 2024–2027
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 mt-1">
              Pengurus dan satgas lapangan yang bertugas melayani warga Perumahan Metro Parung Panjang sesuai ketetapan AD/ART.
            </p>
          </div>

          {officers.length === 0 ? (
            <div className="bg-white/80 rounded-3xl p-8 border border-slate-200/80 text-center space-y-2 max-w-md mx-auto shadow-xs">
              <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-700 flex items-center justify-center mx-auto">
                <Users className="w-6 h-6" />
              </div>
              <h4 className="font-bold text-sm text-slate-800">Belum Ada Data Pengurus</h4>
              <p className="text-xs text-slate-500">
                Daftar struktur kepengurusan dan satgas pelayanan dapat ditambahkan melalui menu Pengaturan Pengurus oleh Super Admin.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {officers.map((officer) => (
                <div 
                  key={officer.id}
                  className="bg-white p-5 rounded-3xl border border-slate-200/90 shadow-sm hover:shadow-md transition-all flex flex-col items-center text-center space-y-3"
                >
                  <div className="w-20 h-20 rounded-2xl overflow-hidden border-2 border-emerald-500/40 shadow bg-slate-100 shrink-0">
                    <img
                      src={getDirectImageUrl(officer.photo || 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&auto=format&fit=crop&q=80')}
                      alt={officer.name}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                    />
                  </div>

                  <div className="space-y-1 w-full min-w-0">
                    <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200 inline-block truncate max-w-full">
                      {officer.role}
                    </span>
                    <h3 className="font-extrabold text-slate-900 text-sm truncate">
                      {officer.name}
                    </h3>
                    <p className="text-xs text-slate-500 font-mono flex items-center justify-center gap-1">
                      <Phone className="w-3 h-3 text-emerald-600" />
                      <span>{officer.phone}</span>
                    </p>
                  </div>

                  <div className="w-full pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
                    <span>Wilayah:</span>
                    <span className="font-bold text-slate-700">{officer.rtAssigned?.join(', ') || 'Semua RT'}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* ─────────────────────────────────────────────────────────────
          6. PILAR LAYANAN FARDHU KIFAYAH & ALUR 24 JAM
          ───────────────────────────────────────────────────────────── */}
      <section id="layanan" className="py-14 sm:py-18 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto w-full">
        <div className="text-center max-w-2xl mx-auto mb-10">
          <span className="text-xs font-extrabold text-emerald-600 uppercase tracking-wider bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
            Pelayanan Fardhu Kifayah
          </span>
          <h2 className="text-2xl sm:text-3xl font-black text-slate-900 mt-2">
            Layanan Terpadu & SOP Penanganan Jenazah
          </h2>
          <p className="text-xs sm:text-sm text-slate-600 mt-2">
            Ketika musibah duka cita terjadi, RKM MPP hadir mendampingi keluarga ahli musibah mulai dari awal hingga tuntas.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          
          {/* Card 1: Pemulasaraan Lengkap */}
          <div className="bg-white p-6 rounded-3xl border border-slate-200/90 shadow-sm hover:shadow-md transition-shadow space-y-3">
            <div className="w-12 h-12 rounded-2xl bg-emerald-100 text-emerald-700 flex items-center justify-center">
              <HeartHandshake className="w-6 h-6" />
            </div>
            <h3 className="font-extrabold text-slate-900 text-base">Pemulasaraan Jenazah Lengkap</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Pelayanan memandikan, mengkafani (dengan kain kafan mori berkualitas, kapas, sabun, bidara, kapur barus, dan wewangian), serta menyalatkan jenazah secara syar'i.
            </p>
            <div className="pt-2 text-[11px] font-bold text-emerald-700 flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4" />
              <span>Disediakan gratis untuk warga anggota aktif</span>
            </div>
          </div>

          {/* Card 2: Tim Rois & Amil Terlatih */}
          <div className="bg-white p-6 rounded-3xl border border-slate-200/90 shadow-sm hover:shadow-md transition-shadow space-y-3">
            <div className="w-12 h-12 rounded-2xl bg-teal-100 text-teal-700 flex items-center justify-center">
              <UserCheck className="w-6 h-6" />
            </div>
            <h3 className="font-extrabold text-slate-900 text-base">Tim Rois & Amil Pemakaman</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Pendampingan ustadz / rois terpercaya untuk talqin, bimbingan keluarga ahli bait, memimpin shalat jenazah, hingga pembacaan doa talqin di pemakaman.
            </p>
            <div className="pt-2 text-[11px] font-bold text-teal-700 flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4" />
              <span>Sesuai tuntunan sunnah Rasulullah SAW</span>
            </div>
          </div>

          {/* Card 3: Transportasi & Keranda Jenazah */}
          <div className="bg-white p-6 rounded-3xl border border-slate-200/90 shadow-sm hover:shadow-md transition-shadow space-y-3">
            <div className="w-12 h-12 rounded-2xl bg-cyan-100 text-cyan-700 flex items-center justify-center">
              <Truck className="w-6 h-6" />
            </div>
            <h3 className="font-extrabold text-slate-900 text-base">Ambulans & Keranda Jenazah</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Penyediaan keranda stenlis khusus jenazah, kain penutup keranda, tenda pemandian, dan koordinasi mobil ambulans siaga pengantaran jenazah ke TPU.
            </p>
            <div className="pt-2 text-[11px] font-bold text-cyan-700 flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4" />
              <span>Inventaris lengkap siaga di posko</span>
            </div>
          </div>

          {/* Card 4: Santunan Uang Duka */}
          <div className="bg-white p-6 rounded-3xl border border-slate-200/90 shadow-sm hover:shadow-md transition-shadow space-y-3">
            <div className="w-12 h-12 rounded-2xl bg-amber-100 text-amber-700 flex items-center justify-center">
              <Award className="w-6 h-6" />
            </div>
            <h3 className="font-extrabold text-slate-900 text-base">Santunan Duka Cita Tunai</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Penyaluran santunan uang duka tunai ({formatRupiah(settings.deathBenefitAmount || 3000000)}) langsung kepada ahli waris untuk membantu biaya pemakaman dan operasional.
            </p>
            <div className="pt-2 text-[11px] font-bold text-amber-700 flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4" />
              <span>Hak santunan sesuai ketetapan AD/ART</span>
            </div>
          </div>

          {/* Card 5: Kuitansi WhatsApp & KTA Digital */}
          <div className="bg-white p-6 rounded-3xl border border-slate-200/90 shadow-sm hover:shadow-md transition-shadow space-y-3">
            <div className="w-12 h-12 rounded-2xl bg-indigo-100 text-indigo-700 flex items-center justify-center">
              <Send className="w-6 h-6" />
            </div>
            <h3 className="font-extrabold text-slate-900 text-base">Kuitansi WhatsApp & KTA Digital</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Setiap pembayaran iuran langsung terbit bukti kuitansi digital otomatis ber-barcode via WhatsApp, serta kartu KTA digital untuk seluruh anggota KK.
            </p>
            <div className="pt-2 text-[11px] font-bold text-indigo-700 flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4" />
              <span>Transparansi mutlak real-time</span>
            </div>
          </div>

          {/* Card 6: Logistik Tenda & Kursi Takziah */}
          <div className="bg-white p-6 rounded-3xl border border-slate-200/90 shadow-sm hover:shadow-md transition-shadow space-y-3">
            <div className="w-12 h-12 rounded-2xl bg-purple-100 text-purple-700 flex items-center justify-center">
              <Layers className="w-6 h-6" />
            </div>
            <h3 className="font-extrabold text-slate-900 text-base">Logistik & Perlengkapan Takziah</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Peminjaman tenda duka, kursi tamu pelayat, sound system pengeras suara, tikar, bendera lelayu kuning, dan papan pengumuman lelayu resmi.
            </p>
            <div className="pt-2 text-[11px] font-bold text-purple-700 flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4" />
              <span>Dukungan logistik penuh di rumah duka</span>
            </div>
          </div>

        </div>

        {/* 5-Step Emergency Workflow */}
        <div className="mt-12 bg-emerald-950 text-white rounded-3xl p-6 sm:p-8 border border-emerald-800/80 shadow-xl">
          <div className="max-w-2xl mx-auto text-center mb-6">
            <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-400 bg-emerald-900/60 px-3 py-1 rounded-full border border-emerald-700">
              Alur Tanggap Darurat 24 Jam
            </span>
            <h3 className="text-xl sm:text-2xl font-black mt-2">
              Prosedur Penanganan Musibah Kematian
            </h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 text-xs">
            <div className="p-3.5 bg-slate-900/80 rounded-2xl border border-emerald-800/60">
              <span className="w-6 h-6 rounded-full bg-emerald-600 text-white font-black text-xs flex items-center justify-center mb-2">1</span>
              <h4 className="font-extrabold text-white">Lapor Posko</h4>
              <p className="text-slate-400 text-[11px] mt-1">Keluarga/RT lapor ke hotline posko 24 jam atau melalui tombol Lapor Duka.</p>
            </div>

            <div className="p-3.5 bg-slate-900/80 rounded-2xl border border-emerald-800/60">
              <span className="w-6 h-6 rounded-full bg-emerald-600 text-white font-black text-xs flex items-center justify-center mb-2">2</span>
              <h4 className="font-extrabold text-white">Satgas Meluncur</h4>
              <p className="text-slate-400 text-[11px] mt-1">Tim pemulasaraan, kain kafan, dan keranda diberangkatkan ke rumah duka.</p>
            </div>

            <div className="p-3.5 bg-slate-900/80 rounded-2xl border border-emerald-800/60">
              <span className="w-6 h-6 rounded-full bg-emerald-600 text-white font-black text-xs flex items-center justify-center mb-2">3</span>
              <h4 className="font-extrabold text-white">Pemulasaraan</h4>
              <p className="text-slate-400 text-[11px] mt-1">Proses memandikan, mengkafani, dan menyalatkan jenazah dipimpin rois.</p>
            </div>

            <div className="p-3.5 bg-slate-900/80 rounded-2xl border border-emerald-800/60">
              <span className="w-6 h-6 rounded-full bg-emerald-600 text-white font-black text-xs flex items-center justify-center mb-2">4</span>
              <h4 className="font-extrabold text-white">Pengantaran TPU</h4>
              <p className="text-slate-400 text-[11px] mt-1">Ambulans mengantar jenazah ke TPU Giri Mulya / TPU pilihan keluarga.</p>
            </div>

            <div className="p-3.5 bg-slate-900/80 rounded-2xl border border-emerald-800/60">
              <span className="w-6 h-6 rounded-full bg-emerald-600 text-white font-black text-xs flex items-center justify-center mb-2">5</span>
              <h4 className="font-extrabold text-white">Santunan Duka</h4>
              <p className="text-slate-400 text-[11px] mt-1">Pemberian santunan tunai & kuitansi santunan diserahkan ke ahli waris.</p>
            </div>
          </div>
        </div>
      </section>

      {/* ─────────────────────────────────────────────────────────────
          7. CEK CEPAT STATUS WARGA (Lookup KK / NIK)
          ───────────────────────────────────────────────────────────── */}
      <section id="cek-warga" className="py-14 bg-slate-100/90 border-y border-slate-200 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <div className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200/90 shadow-lg space-y-6">
            
            <div className="text-center max-w-xl mx-auto">
              <div className="w-12 h-12 rounded-2xl bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto mb-3">
                <Search className="w-6 h-6" />
              </div>
              <h2 className="text-2xl font-black text-slate-900">
                Cek Status Keanggotaan Warga
              </h2>
              <p className="text-xs sm:text-sm text-slate-500 mt-1">
                Masukkan <strong>Nomor KK</strong> atau <strong>Nama Kepala Keluarga</strong> untuk mengecek status keaktifan Anda di {settings.orgName}.
              </p>
            </div>

            {/* Search Input Form */}
            <form onSubmit={handleSearchCitizen} className="max-w-xl mx-auto flex flex-col sm:flex-row gap-2.5">
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
                <input
                  type="text"
                  placeholder="Contoh: 3201... atau Nama Kepala Keluarga..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-300 rounded-2xl text-xs sm:text-sm font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white transition-all"
                />
              </div>
              <button
                type="submit"
                className="px-6 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs sm:text-sm rounded-2xl shadow-md transition-all shrink-0 cursor-pointer"
              >
                Cari Data Warga
              </button>
            </form>

            {/* Search Results Display */}
            {searched && (
              <div className="pt-2 animate-fade-in">
                {searchResult ? (
                  <div className="p-5 rounded-2xl bg-emerald-50/80 border border-emerald-200 text-slate-800 space-y-3">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-emerald-200/80">
                      <div className="flex items-center gap-3">
                        <img
                          src={getAvatarUrl(searchResult.headOfFamily, 'warga', searchResult.avatar)}
                          alt={searchResult.headOfFamily}
                          className="w-12 h-12 rounded-xl object-cover border border-emerald-500 bg-white"
                        />
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-extrabold text-slate-900 text-base">
                              {searchResult.headOfFamily}
                            </span>
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-emerald-600 text-white">
                              {searchResult.status}
                            </span>
                          </div>
                          <p className="text-xs text-slate-600 font-mono mt-0.5">
                            No. KK: {searchResult.noKK}
                          </p>
                        </div>
                      </div>

                      <div className="text-right sm:self-center">
                        <span className="text-[10px] font-bold text-slate-500 uppercase block">Wilayah / Blok</span>
                        <span className="text-xs font-bold text-slate-800">
                          {searchResult.block} {searchResult.houseNumber} ({searchResult.communityType === 'RT' ? `RT ${searchResult.rt}/RW ${searchResult.rw}` : searchResult.paguyubanName})
                        </span>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-xs">
                      <div className="p-2.5 bg-white rounded-xl border border-emerald-100">
                        <span className="text-[10px] text-slate-400 block font-bold">Jumlah Anggota Jiwa</span>
                        <span className="font-extrabold text-slate-800">{searchResult.members?.length || 1} Jiwa Terdaftar</span>
                      </div>
                      <div className="p-2.5 bg-white rounded-xl border border-emerald-100">
                        <span className="text-[10px] text-slate-400 block font-bold">Koordinator Lapangan</span>
                        <span className="font-extrabold text-slate-800">{searchResult.assignedCollectorName || `Koordinator ${searchResult.block || 'Blok'}`}</span>
                      </div>
                      <div className="p-2.5 bg-white rounded-xl border border-emerald-100">
                        <span className="text-[10px] text-slate-400 block font-bold">Kartu Digital</span>
                        <button
                          type="button"
                          onClick={() => openKtaModal(searchResult)}
                          className="font-extrabold text-emerald-700 hover:text-emerald-900 underline flex items-center gap-1 cursor-pointer"
                        >
                          <span>Lihat KTA Digital</span>
                          <ExternalLink className="w-3 h-3" />
                        </button>
                      </div>
                    </div>

                    <div className="pt-2 flex justify-end">
                      <button
                        onClick={onNavigateToLogin}
                        className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow flex items-center gap-1.5 cursor-pointer"
                      >
                        <span>Masuk untuk Riwayat & Pembayaran Lengkap</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="p-5 rounded-2xl bg-amber-50 border border-amber-200 text-center space-y-2">
                    <p className="text-xs sm:text-sm font-bold text-amber-900">
                      Data tidak ditemukan dengan kata kunci: <em>"{searchQuery}"</em>
                    </p>
                    <p className="text-xs text-amber-700">
                      Pastikan nomor KK atau nama sesuai. Jika Anda warga baru yang belum terdaftar, silakan hubungi Koordinator RT/Blok atau Pengurus RKM.
                    </p>
                  </div>
                )}
              </div>
            )}

          </div>
        </div>
      </section>

      {/* ─────────────────────────────────────────────────────────────
          8. KETENTUAN IURAN KAS DUKA & STRUKTUR TARIF
          ───────────────────────────────────────────────────────────── */}
      <section id="iuran" className="py-14 sm:py-18 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto w-full">
        <div className="text-center max-w-2xl mx-auto mb-10">
          <span className="text-xs font-extrabold text-emerald-600 uppercase tracking-wider bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
            Transparansi Finansial
          </span>
          <h2 className="text-2xl sm:text-3xl font-black text-slate-900 mt-2">
            Ketentuan Iuran Kas Duka RKM (AD/ART)
          </h2>
          <p className="text-xs sm:text-sm text-slate-600 mt-2">
            Iuran dikelola secara amanah, dicatat transparan dalam buku kas terbuka, dan dipertanggungjawabkan dalam Laporan 4-Bulanan.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
          
          {/* Box 1: Iuran Pokok */}
          <div className="bg-white p-6 rounded-3xl border-2 border-emerald-500/80 shadow-md space-y-4 relative overflow-hidden">
            <div className="absolute top-0 right-0 bg-emerald-500 text-white font-black text-[10px] uppercase tracking-wider px-3 py-1 rounded-bl-xl">
              Iuran Pokok KK
            </div>
            
            <div>
              <span className="text-xs font-bold text-slate-500 uppercase block">Kepala Keluarga & Anggota Inti</span>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="text-3xl sm:text-4xl font-black text-emerald-700">{formatRupiah(baseDues)}</span>
                <span className="text-xs text-slate-500 font-bold">/ KK / Bulan</span>
              </div>
            </div>

            <ul className="space-y-2 text-xs text-slate-600 border-t border-slate-100 pt-3">
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span>Mencakup Kepala Keluarga, Istri, dan Anak-anak kandung dalam 1 Kartu Keluarga (KK).</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span>Mendapatkan hak pemulasaraan jenazah penuh & kain kafan lengkap.</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span>Kuitansi pembayaran digital langsung via WhatsApp.</span>
              </li>
            </ul>
          </div>

          {/* Box 2: Anggota Tambahan */}
          <div className="bg-white p-6 rounded-3xl border border-slate-200/90 shadow-sm space-y-4 relative">
            <div className="bg-slate-100 text-slate-700 font-black text-[10px] uppercase tracking-wider px-3 py-1 rounded-full w-fit">
              Anggota Tambahan
            </div>
            
            <div>
              <span className="text-xs font-bold text-slate-500 uppercase block">Famili / Orang Tua / Kerabat Tinggal Serumah</span>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="text-3xl sm:text-4xl font-black text-slate-800">{formatRupiah(extraDues)}</span>
                <span className="text-xs text-slate-500 font-bold">/ Jiwa / Bulan</span>
              </div>
            </div>

            <ul className="space-y-2 text-xs text-slate-600 border-t border-slate-100 pt-3">
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span>Untuk orang tua, mertua, famili lain yang tinggal serumah tapi terdaftar sebagai anggota tambahan.</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span>Mendapatkan hak pemulasaraan jenazah & santunan setara anggota inti.</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span>Didaftarkan secara resmi ke database RKM oleh kepala keluarga.</span>
              </li>
            </ul>
          </div>

        </div>

        {/* Payment Methods */}
        <div className="mt-8 p-6 bg-slate-100 rounded-3xl border border-slate-200 max-w-4xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-600 text-white flex items-center justify-center shrink-0">
              <CreditCard className="w-5 h-5" />
            </div>
            <div>
              <span className="font-extrabold text-slate-900 block text-sm">Metode Pembayaran Iuran Fleksibel</span>
              <p className="text-slate-600 text-xs">
                Bayar tunai melalui Koordinator RT/Blok masing-masing, Transfer Bank BSI (7192837465), BCA (8400192837), atau Scan QRIS Kas RKM.
              </p>
            </div>
          </div>

          <button
            onClick={onNavigateToLogin}
            className="px-4 py-2.5 bg-white hover:bg-slate-50 text-slate-900 border border-slate-300 font-bold rounded-xl shadow-2xs shrink-0 flex items-center gap-1.5 transition-all cursor-pointer"
          >
            <span>Bayar Iuran via Portal</span>
            <ChevronRight className="w-4 h-4 text-emerald-600" />
          </button>
        </div>
      </section>

      {/* ─────────────────────────────────────────────────────────────
          9. FORM ASPIRASI & PESAN WARGA
          ───────────────────────────────────────────────────────────── */}
      <section className="py-14 bg-white border-t border-slate-200 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <div className="space-y-4">
            <span className="text-xs font-extrabold text-emerald-600 uppercase tracking-wider bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
              Suara & Aspirasi Warga
            </span>
            <h2 className="text-2xl sm:text-3xl font-black text-slate-900 leading-tight">
              Sampaikan Saran, Pertanyaan, atau Masukan ke Pengurus
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
              Pengurus RKM Perumahan Metro Parung Panjang terbuka menerima saran dan kritik membangun dari seluruh warga demi penyempurnaan layanan fardhu kifayah.
            </p>

            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2 text-xs text-slate-700">
              <div className="flex items-center gap-2 font-bold text-slate-900">
                <Phone className="w-4 h-4 text-emerald-600" />
                <span>Kontak Sekretariat & Hotline:</span>
              </div>
              <p className="font-mono text-emerald-700 font-bold">{settings.contactCenter}</p>
              <p className="text-[11px] text-slate-500">Email: {settings.email} • Sekretariat: {settings.rtRw}</p>
            </div>
          </div>

          <div className="bg-slate-50 p-6 rounded-3xl border border-slate-200/90 shadow-sm space-y-4">
            <h3 className="font-extrabold text-slate-900 text-sm flex items-center gap-2">
              <MessageSquare className="w-4 h-4 text-emerald-600" />
              <span>Formulir Pesan & Aspirasi</span>
            </h3>

            <form onSubmit={handleSendFeedback} className="space-y-3 text-xs">
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">Nama Lengkap</label>
                <input
                  type="text"
                  required
                  value={fbName}
                  onChange={(e) => setFbName(e.target.value)}
                  placeholder="Contoh: Bpk. Bambang"
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">No. WhatsApp / HP</label>
                  <input
                    type="tel"
                    value={fbPhone}
                    onChange={(e) => setFbPhone(e.target.value)}
                    placeholder="0812..."
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">Kategori</label>
                  <select
                    value={fbCategory}
                    onChange={(e: any) => setFbCategory(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  >
                    <option value="Saran">Saran</option>
                    <option value="Pertanyaan">Pertanyaan</option>
                    <option value="Keluhan">Keluhan</option>
                    <option value="Ucapan Terima Kasih">Ucapan Terima Kasih</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">Pesan / Masukan</label>
                <textarea
                  required
                  rows={3}
                  value={fbMessage}
                  onChange={(e) => setFbMessage(e.target.value)}
                  placeholder="Tuliskan saran atau masukan Anda..."
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              {fbSuccess && (
                <div className="p-2.5 bg-emerald-100 text-emerald-800 rounded-xl font-bold flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>Terima kasih! Pesan Anda telah terkirim ke pengurus RKM.</span>
                </div>
              )}

              <button
                type="submit"
                className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Kirim Pesan ke Pengurus</span>
              </button>
            </form>
          </div>
        </div>
      </section>

      {/* ─────────────────────────────────────────────────────────────
          10. PUBLIC FOOTER
          ───────────────────────────────────────────────────────────── */}
      <footer className="bg-slate-950 text-slate-400 border-t border-slate-800 py-10 px-4 sm:px-6 lg:px-8 text-xs mt-auto">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6 text-center md:text-left">
          <div>
            <div className="flex items-center justify-center md:justify-start gap-2.5 text-white font-extrabold text-sm">
              <div className="w-7 h-7 rounded-xl bg-emerald-600 flex items-center justify-center text-white">
                <HeartHandshake className="w-4 h-4" />
              </div>
              <span>{settings.orgName || 'PERUMAHAN METRO PARUNG PANJANG'}</span>
              <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded-full border border-emerald-500/30 font-bold">
                AD/ART 2024–2027
              </span>
            </div>
            <p className="text-slate-400 text-xs mt-1.5 max-w-md">
              Sistem Digitalisasi Kas Rukun Kematian, Transparansi Dana Duka, Kuitansi WhatsApp & Layanan Pemulasaraan Jenazah Terpadu.
            </p>
          </div>

          <div className="flex flex-col md:items-end text-xs space-y-2">
            <div className="flex items-center gap-2 text-slate-300">
              <Phone className="w-4 h-4 text-emerald-400" />
              <span>Satgas Siaga 24 Jam: <strong>{settings.contactCenter}</strong></span>
            </div>
            <div className="flex items-center gap-3 text-slate-400">
              <button 
                onClick={() => onNavigateToTab('ad-art')} 
                className="hover:text-emerald-400 hover:underline font-bold text-emerald-400 cursor-pointer"
              >
                Dokumen AD/ART
              </button>
              <span>•</span>
              <button 
                onClick={onNavigateToLogin} 
                className="hover:text-emerald-400 hover:underline text-slate-300 font-bold cursor-pointer"
              >
                Masuk / Login
              </button>
            </div>
            <p className="text-slate-500 text-[11px]">
              © 2024–2027 {settings.orgName} • Amanah & Fardhu Kifayah
            </p>
          </div>
        </div>
      </footer>

      {/* ─────────────────────────────────────────────────────────────
          11. MODAL: LOGIN REQUIRED FOR LAPOR DUKA 24 JAM
          ───────────────────────────────────────────────────────────── */}
      {showLoginRequiredModal && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white w-full max-w-md rounded-3xl shadow-2xl border border-slate-200 p-6 text-center space-y-4">
            <div className="w-14 h-14 rounded-2xl bg-rose-100 text-rose-700 flex items-center justify-center mx-auto shadow-inner">
              <Lock className="w-7 h-7" />
            </div>

            <div>
              <h3 className="text-lg font-black text-slate-900">
                Masuk / Login Akun Terlebih Dahulu
              </h3>
              <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                Demi verifikasi validitas pelapor, nomor kontak keluarga, dan data kepesertaan almarhum/ah, pelaporan musibah duka cita 24 jam harus melalui akun warga atau satgas terdaftar.
              </p>
            </div>

            <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200 text-left text-xs space-y-1.5">
              <div className="flex items-center gap-1.5 text-emerald-800 font-bold">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                <span>Warga cukup login dengan No. KK & PIN/Password</span>
              </div>
              <div className="flex items-center gap-1.5 text-emerald-800 font-bold">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                <span>Satgas & Pengurus login dengan username terdaftar</span>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowLoginRequiredModal(false)}
                className="w-full sm:w-1/2 py-2.5 bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold text-xs rounded-xl transition-colors cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowLoginRequiredModal(false);
                  onNavigateToLogin();
                }}
                className="w-full sm:w-1/2 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-md transition-all cursor-pointer flex items-center justify-center gap-1.5"
              >
                <LogIn className="w-4 h-4" />
                <span>Masuk Sekarang</span>
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
