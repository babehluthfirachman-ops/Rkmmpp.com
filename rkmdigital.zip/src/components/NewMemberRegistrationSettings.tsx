import React, { useState } from 'react';
import { 
  UserPlus, 
  Users, 
  CreditCard, 
  CheckCircle2, 
  AlertCircle, 
  Plus, 
  Trash2, 
  QrCode, 
  Printer, 
  Download, 
  Upload, 
  ShieldCheck, 
  FileSpreadsheet, 
  Calendar, 
  MapPin, 
  Phone, 
  Mail, 
  KeyRound, 
  Sparkles,
  Receipt,
  FileText,
  BadgeCheck,
  Building,
  Home,
  Info,
  HelpCircle
} from 'lucide-react';
import { useRkm } from '../context/RkmContext';
import { 
  Citizen, 
  FamilyMember, 
  RelationType, 
  GenderType, 
  MemberStatus,
  MemberCategory,
  CommunityType
} from '../types';
import { 
  formatRupiah, 
  formatDateIndo, 
  BLOCK_OPTIONS, 
  CORE_RELATIONS, 
  EXTRA_RELATIONS, 
  getMemberCategory, 
  calculateCitizenMonthlyDues,
  getAvatarUrl
} from '../utils/formatters';

interface NewFamilyMemberDraft {
  name: string;
  nik: string;
  relation: RelationType;
  gender: GenderType;
  birthDate: string;
  category: MemberCategory;
}

export const NewMemberRegistrationSettings: React.FC = () => {
  const { 
    citizens, 
    addCitizen, 
    settings, 
    users,
    registerUser, 
    addTransaction, 
    openKtaModal 
  } = useRkm();

  const blockOptions = settings.blockList && settings.blockList.length > 0 ? settings.blockList : BLOCK_OPTIONS;
  const rtOptions = settings.rtList && settings.rtList.length > 0 ? settings.rtList : ['01', '02', '03', '04', '05', '06', '07', '08'];
  const rwOptions = settings.rwList && settings.rwList.length > 0 ? settings.rwList : ['08'];
  const paguyubanOptions = settings.paguyubanList && settings.paguyubanList.length > 0 ? settings.paguyubanList : ['Paguyuban Warga Muslim Blok A', 'Paguyuban Warga Muslim Blok B', 'Paguyuban Warga Muslim Blok C', 'Paguyuban Warga Muslim Blok D'];

  const coordinatorUsers = users.filter(u => u.role === 'koordinator' || u.role === 'petugas' || u.role === 'superadmin');

  const [activeSubView, setActiveSubView] = useState<'form' | 'import' | 'print_form'>('form');
  const [successResult, setSuccessResult] = useState<Citizen | null>(null);

  // Form Step
  const [step, setStep] = useState<number>(1);

  // Step 1: Head of Family & KK Data
  const [noKK, setNoKK] = useState('');
  const [nik, setNik] = useState('');
  const [headOfFamily, setHeadOfFamily] = useState('');
  const [phone, setPhone] = useState('08');
  const [avatar, setAvatar] = useState('');
  const [assignedCollectorId, setAssignedCollectorId] = useState('');
  
  // New Block & Community Type fields
  const [block, setBlock] = useState<string>('Blok A');
  const [houseNumber, setHouseNumber] = useState<string>('No. 10');
  const [communityType, setCommunityType] = useState<CommunityType>('RT');
  const [rt, setRt] = useState('01');
  const [rw, setRw] = useState('08');
  const [paguyubanName, setPaguyubanName] = useState('Paguyuban Warga Muslim Blok A');
  const [addressDetail, setAddressDetail] = useState('');
  const [residenceStatus, setResidenceStatus] = useState<'Warga Tetap (Pemilik)' | 'Warga Kontrak / Sewa' | 'Pindahan Baru'>('Warga Tetap (Pemilik)');
  const [joinDate, setJoinDate] = useState(new Date().toISOString().split('T')[0]);

  // Handle avatar upload
  const handleAvatarUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 3 * 1024 * 1024) {
      alert('Ukuran foto terlalu besar. Maksimal 3MB.');
      return;
    }
    const reader = new FileReader();
    reader.onload = (event) => {
      setAvatar(event.target?.result as string);
    };
    reader.readAsDataURL(file);
  };

  // Step 2: Family Members (Anggota Jiwa Inti & Tambahan)
  const [members, setMembers] = useState<NewFamilyMemberDraft[]>([]);
  const [tempMemberName, setTempMemberName] = useState('');
  const [tempMemberNik, setTempMemberNik] = useState('');
  const [tempMemberRelation, setTempMemberRelation] = useState<RelationType>('Istri');
  const [tempMemberGender, setTempMemberGender] = useState<GenderType>('Perempuan');
  const [tempMemberBirthDate, setTempMemberBirthDate] = useState('1995-01-01');

  // Step 3: Dues & Initial Payment
  const regFeeBase = settings.registrationFee || 50000;
  const baseDuesRate = settings.baseDuesAmount || settings.duesAmount || 5000;
  const extraMemberRate = settings.extraMemberDuesAmount || 3000;

  const [payRegistrationFee, setPayRegistrationFee] = useState(true);
  const [regFeeAmount, setRegFeeAmount] = useState(regFeeBase);
  const [payInitialDues, setPayInitialDues] = useState(true);
  const [initialDuesMonths, setInitialDuesMonths] = useState<number>(1);
  const [paymentMethod, setPaymentMethod] = useState<'Tunai' | 'Transfer Bank' | 'QRIS'>('Tunai');
  const [collectorName, setCollectorName] = useState('Petugas Lapangan');
  const [infaqInitial, setInfaqInitial] = useState(0);

  // Step 4: Automation Options
  const [createCitizenAccount, setCreateCitizenAccount] = useState(true);
  const [sendWaWelcome, setSendWaWelcome] = useState(true);

  // CSV Import State
  const [csvText, setCsvText] = useState('');
  const [importStatus, setImportStatus] = useState<string | null>(null);

  // Categorize drafts count
  const coreMembersDraftCount = members.filter(m => m.category === 'Inti').length;
  const extraMembersDraftCount = members.filter(m => m.category === 'Tambahan').length;
  
  // Total Family monthly dues: Base (5.000 for Head + Inti) + Extra (3.000 * extraCount)
  const calculatedMonthlyDues = baseDuesRate + (extraMembersDraftCount * extraMemberRate);

  // Derived category for the selected relation in the draft input
  const currentDraftCategory = getMemberCategory(tempMemberRelation);

  // Add Family Member to Draft
  const handleAddMemberDraft = (e: React.FormEvent) => {
    e.preventDefault();
    if (!tempMemberName.trim() || !tempMemberNik.trim()) {
      alert('Mohon isi nama anggota dan NIK anggota.');
      return;
    }

    if (tempMemberNik.length !== 16) {
      alert('NIK harus berupa 16 digit angka.');
      return;
    }

    // Check duplicate NIK in members or head
    if (tempMemberNik === nik || members.some(m => m.nik === tempMemberNik)) {
      alert('NIK ini sudah dimasukkan!');
      return;
    }

    const cat = getMemberCategory(tempMemberRelation);

    setMembers([
      ...members,
      {
        name: tempMemberName,
        nik: tempMemberNik,
        relation: tempMemberRelation,
        gender: tempMemberGender,
        birthDate: tempMemberBirthDate,
        category: cat
      }
    ]);

    // Reset Temp fields
    setTempMemberName('');
    setTempMemberNik('');
    setTempMemberRelation('Anak');
    setTempMemberGender('Laki-laki');
  };

  const handleRemoveMemberDraft = (index: number) => {
    setMembers(members.filter((_, i) => i !== index));
  };

  // Submit Full Registration
  const handleSubmitRegistration = (e: React.FormEvent) => {
    e.preventDefault();

    if (!noKK.trim() || noKK.length !== 16) {
      alert('Nomor Kartu Keluarga (No. KK) harus 16 digit angka.');
      return;
    }

    if (!nik.trim() || nik.length !== 16) {
      alert('NIK Kepala Keluarga harus 16 digit angka.');
      return;
    }

    if (!headOfFamily.trim()) {
      alert('Nama Kepala Keluarga wajib diisi.');
      return;
    }

    // Check duplicate KK
    if (citizens.some(c => c.noKK === noKK)) {
      alert(`Warga dengan No. KK ${noKK} sudah terdaftar sebelumnya!`);
      return;
    }

    // Prepare Monthly Dues Object for 2026 with accurately calculated rate
    const initialMonths: Record<string, any> = {};
    const dateStr = new Date().toISOString().split('T')[0];

    for (let i = 1; i <= 12; i++) {
      const monthKey = `2026-${i.toString().padStart(2, '0')}`;
      if (payInitialDues && i <= initialDuesMonths) {
        initialMonths[monthKey] = {
          paid: true,
          paidAt: dateStr,
          receiptNo: `RKM-REG-${Date.now().toString().slice(-6)}`,
          amount: calculatedMonthlyDues,
          paymentMethod: paymentMethod,
          collector: collectorName
        };
      } else {
        initialMonths[monthKey] = {
          paid: false,
          amount: calculatedMonthlyDues
        };
      }
    }

    // Assemble Family Members (Head + Extra Members)
    const allMembers: FamilyMember[] = [
      {
        id: `m-${Date.now()}-head`,
        name: headOfFamily,
        nik: nik,
        relation: 'Kepala Keluarga',
        gender: 'Laki-laki',
        status: 'Hidup',
        category: 'Inti'
      },
      ...members.map((m, idx) => ({
        id: `m-${Date.now()}-${idx}`,
        name: m.name,
        nik: m.nik,
        relation: m.relation,
        gender: m.gender,
        birthDate: m.birthDate,
        status: 'Hidup' as MemberStatus,
        category: m.category
      }))
    ];

    // Build structured address string
    const fullAddress = addressDetail.trim() 
      ? `${block} ${houseNumber}, ${addressDetail}, ${communityType === 'RT' ? `RT ${rt}/RW ${rw}` : paguyubanName}`
      : `${block} ${houseNumber}, ${communityType === 'RT' ? `RT ${rt}/RW ${rw}` : paguyubanName}`;

    const selectedCoordinator = coordinatorUsers.find(u => u.id === assignedCollectorId);

    const newCitizenData: Omit<Citizen, 'id'> = {
      noKK,
      headOfFamily,
      nik,
      phone: phone || '08123456789',
      avatar: avatar || undefined,
      assignedCollectorId: assignedCollectorId || undefined,
      assignedCollectorName: selectedCoordinator?.name || undefined,
      address: fullAddress,
      block,
      houseNumber,
      communityType,
      paguyubanName: communityType === 'Paguyuban' ? paguyubanName : undefined,
      rt,
      rw,
      joinDate,
      status: 'Aktif',
      members: allMembers,
      monthlyDues: initialMonths,
      notes: `Status: ${residenceStatus}. ${communityType === 'Paguyuban' ? `Paguyuban: ${paguyubanName}` : `Wilayah RT ${rt}`}. ${extraMembersDraftCount} Jiwa Tambahan.`
    };

    // 1. Add Citizen to Database
    addCitizen(newCitizenData);

    // 2. Add Transaction if Initial Payment made
    const initialRegistrationPaid = payRegistrationFee ? regFeeAmount : 0;
    const initialDuesPaid = payInitialDues ? initialDuesMonths * calculatedMonthlyDues : 0;
    const totalInitialPay = initialRegistrationPaid + initialDuesPaid + (infaqInitial || 0);

    if (totalInitialPay > 0) {
      addTransaction({
        type: 'in',
        category: payRegistrationFee ? 'Donasi / Hibah' : 'Iuran Wajib',
        amount: totalInitialPay,
        date: joinDate,
        description: `Pendaftaran Warga Baru (${formatRupiah(initialRegistrationPaid)}) & Iuran Awal ${initialDuesMonths} Bulan (${formatRupiah(initialDuesPaid)}) - ${headOfFamily} (${block} ${communityType === 'RT' ? `RT ${rt}` : paguyubanName})`,
        recipientOrPayer: headOfFamily,
        noKK: noKK,
        receiptNo: `RKM-REG-${Date.now().toString().slice(-6)}`,
        paymentMethod: paymentMethod,
        verifiedBy: collectorName
      });
    }

    // 3. Create Citizen Login Account if enabled
    if (createCitizenAccount) {
      registerUser({
        username: noKK,
        name: headOfFamily,
        role: 'warga',
        phone: phone,
        password: noKK.slice(-6), // Default PIN = last 6 digits of KK
        status: 'Aktif',
        noKK: noKK,
        avatar: avatar || undefined,
        rt: rt,
        rw: rw,
        title: 'Kepala Keluarga'
      });
    }

    const createdCitizen: Citizen = {
      ...newCitizenData,
      id: `cit-${Date.now()}`
    };

    setSuccessResult(createdCitizen);
  };

  const handleResetForm = () => {
    setSuccessResult(null);
    setStep(1);
    setNoKK('');
    setNik('');
    setHeadOfFamily('');
    setPhone('08');
    setBlock('Blok A');
    setHouseNumber('No. 10');
    setCommunityType('RT');
    setPaguyubanName('Paguyuban Warga Muslim');
    setAddressDetail('');
    setRt('01');
    setMembers([]);
    setPayRegistrationFee(true);
    setRegFeeAmount(regFeeBase);
    setPayInitialDues(true);
    setInitialDuesMonths(1);
    setInfaqInitial(0);
  };

  // Quick Template CSV Import
  const handleImportSampleCsv = () => {
    const sample = `No KK,Kepala Keluarga,NIK,No HP,Blok,No Rumah,RT/Paguyuban,Nama RT atau Paguyuban\n3201082501900088,H. Mochammad Ilyas,3201081503880005,081299887766,Blok C,No. 08,RT,04\n3201082004920099,Drs. Hendra Gunawan,3201081208850007,085611223344,Blok E,No. 15,Paguyuban,Paguyuban Warga Muslim`;
    setCsvText(sample);
  };

  const handleProcessCsvImport = () => {
    if (!csvText.trim()) {
      alert('Silakan masukkan atau tempel teks data CSV terlebih dahulu.');
      return;
    }

    const lines = csvText.trim().split('\n');
    let successCount = 0;

    lines.forEach((line, idx) => {
      if (idx === 0 && (line.includes('No KK') || line.includes('Kepala Keluarga'))) {
        return; // Skip header row
      }

      const cols = line.split(',').map(c => c.trim());
      if (cols.length >= 4) {
        const importKK = cols[0];
        const importName = cols[1];
        const importNik = cols[2];
        const importPhone = cols[3] || '08123456789';
        const importBlock = cols[4] || 'Blok A';
        const importHouseNo = cols[5] || 'No. 01';
        const importCommType: CommunityType = (cols[6] && cols[6].toLowerCase().includes('paguyuban')) ? 'Paguyuban' : 'RT';
        const importCommVal = cols[7] || (importCommType === 'RT' ? '01' : 'Paguyuban Warga');

        if (importKK && importName && !citizens.some(c => c.noKK === importKK)) {
          const initialMonths: Record<string, any> = {};
          for (let i = 1; i <= 12; i++) {
            initialMonths[`2026-${i.toString().padStart(2, '0')}`] = { paid: false, amount: baseDuesRate };
          }

          addCitizen({
            noKK: importKK,
            headOfFamily: importName,
            nik: importNik || `${importKK.slice(0, 6)}0000000001`,
            phone: importPhone,
            address: `${importBlock} ${importHouseNo}, ${importCommType === 'RT' ? `RT ${importCommVal}/RW 08` : importCommVal}`,
            block: importBlock,
            houseNumber: importHouseNo,
            communityType: importCommType,
            paguyubanName: importCommType === 'Paguyuban' ? importCommVal : undefined,
            rt: importCommType === 'RT' ? importCommVal : '01',
            rw: '08',
            joinDate: new Date().toISOString().split('T')[0],
            status: 'Aktif',
            members: [
              {
                id: `m-${Date.now()}-${idx}`,
                name: importName,
                nik: importNik || `${importKK.slice(0, 6)}0000000001`,
                relation: 'Kepala Keluarga',
                gender: 'Laki-laki',
                status: 'Hidup',
                category: 'Inti'
              }
            ],
            monthlyDues: initialMonths,
            notes: 'Diimpor massal via CSV'
          });

          // Also create citizen user account
          registerUser({
            username: importKK,
            name: importName,
            role: 'warga',
            phone: importPhone,
            password: importKK.slice(-6),
            status: 'Aktif',
            noKK: importKK,
            rt: importCommType === 'RT' ? importCommVal : '01',
            rw: '08',
            title: 'Kepala Keluarga'
          });

          successCount++;
        }
      }
    });

    setImportStatus(`Berhasil mengimpor ${successCount} data keluarga (KK) warga baru.`);
    setCsvText('');
  };

  return (
    <div className="space-y-6 pb-12 animate-fade-in">
      
      {/* Header */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 bg-emerald-100 text-emerald-700 rounded-xl">
              <UserPlus className="w-5 h-5" />
            </span>
            <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900">
              Formulir & Pendaftaran Anggota Baru
            </h1>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Pendaftaran warga, pemilihan Blok (A–Z), RT / Paguyuban, pengelompokan anggota jiwa (Inti & Tambahan), serta perhitungan iuran resmi.
          </p>
        </div>

        {/* Tab Sub-View Switcher */}
        <div className="flex items-center gap-2 self-start md:self-auto bg-slate-100 p-1 rounded-2xl border border-slate-200">
          <button
            type="button"
            onClick={() => setActiveSubView('form')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
              activeSubView === 'form'
                ? 'bg-white text-emerald-800 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Formulir Pendaftaran
          </button>

          <button
            type="button"
            onClick={() => setActiveSubView('import')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
              activeSubView === 'import'
                ? 'bg-white text-emerald-800 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Impor CSV Massal
          </button>

          <button
            type="button"
            onClick={() => setActiveSubView('print_form')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
              activeSubView === 'print_form'
                ? 'bg-white text-emerald-800 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Blangko Fisik Cetak
          </button>
        </div>
      </div>

      {/* VIEW 1: INTERACTIVE MULTI-STEP REGISTRATION FORM */}
      {activeSubView === 'form' && (
        <div className="space-y-6">

          {/* Quick Rules Banner */}
          <div className="bg-gradient-to-r from-emerald-900 via-teal-900 to-slate-900 text-white rounded-3xl p-5 shadow-sm border border-emerald-800/40">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-0.5 bg-emerald-500/20 border border-emerald-400/40 text-emerald-300 text-[10px] font-black rounded-full uppercase tracking-wider">
                    Ketentuan Iuran & Jiwa AD/ART RKM
                  </span>
                </div>
                <h3 className="text-base sm:text-lg font-black text-white">
                  Ketentuan Biaya & Kategori Keanggotaan
                </h3>
              </div>
              
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 w-full sm:w-auto text-xs font-sans">
                <div className="bg-white/10 backdrop-blur-sm p-2.5 rounded-xl border border-white/10">
                  <span className="text-[10px] text-emerald-300 block font-semibold">Pendaftaran Anggota Baru:</span>
                  <span className="font-extrabold text-white text-sm">{formatRupiah(regFeeBase)}</span>
                  <span className="text-[10px] text-slate-300 block">Satu kali saat daftar</span>
                </div>
                <div className="bg-white/10 backdrop-blur-sm p-2.5 rounded-xl border border-white/10">
                  <span className="text-[10px] text-emerald-300 block font-semibold">1 Keluarga & Anggota Inti:</span>
                  <span className="font-extrabold text-white text-sm">{formatRupiah(baseDuesRate)} / bln</span>
                  <span className="text-[10px] text-slate-300 block">KK, Suami/Istri, Anak, Ortu, Mertua</span>
                </div>
                <div className="bg-white/10 backdrop-blur-sm p-2.5 rounded-xl border border-white/10">
                  <span className="text-[10px] text-amber-300 block font-semibold">Anggota Tambahan Jiwa:</span>
                  <span className="font-extrabold text-amber-200 text-sm">+{formatRupiah(extraMemberRate)} / jiwa / bln</span>
                  <span className="text-[10px] text-slate-300 block">Adik, Kakak, Saudara / Famili</span>
                </div>
              </div>
            </div>
          </div>

          {successResult ? (
            /* SUCCESS CONFIRMATION & ACTIONS */
            <div className="bg-white rounded-3xl p-8 border border-emerald-200 shadow-md text-center space-y-6 max-w-2xl mx-auto animate-scale-up">
              <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-inner">
                <CheckCircle2 className="w-10 h-10" />
              </div>

              <div>
                <span className="px-3 py-1 bg-emerald-50 text-emerald-800 text-xs font-bold rounded-full border border-emerald-200">
                  Pendaftaran Berhasil & Terverifikasi
                </span>
                <h3 className="text-2xl font-black text-slate-900 mt-2">
                  {successResult.headOfFamily}
                </h3>
                <p className="text-xs sm:text-sm text-slate-500 font-mono mt-1">
                  Nomor KK: {successResult.noKK} | {successResult.block} {successResult.houseNumber} | {successResult.communityType === 'RT' ? `RT ${successResult.rt} / RW ${successResult.rw}` : successResult.paguyubanName}
                </p>
                <div className="mt-3 inline-flex items-center gap-2 px-3 py-1 bg-slate-100 rounded-xl text-xs font-bold text-slate-700">
                  <span>Iuran Bulanan Resmi:</span>
                  <span className="text-emerald-700 font-mono font-black">
                    {formatRupiah(calculatedMonthlyDues)} / bulan
                  </span>
                  <span className="text-[10px] text-slate-500 font-normal">
                    ({members.length + 1} Jiwa: {coreMembersDraftCount + 1} Inti, {extraMembersDraftCount} Tambahan)
                  </span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => openKtaModal(successResult)}
                  className="px-4 py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-2xl text-xs flex items-center justify-center gap-2 shadow-md transition-all"
                >
                  <QrCode className="w-4 h-4" />
                  <span>Buka KTA Digital & Barcode</span>
                </button>

                <a
                  href={`https://wa.me/${successResult.phone.replace(/\D/g, '')}?text=${encodeURIComponent(
                    `*SELAMAT BERGABUNG DI RKM MPP DIGITAL*\n\nAssalamu'alaikum Bpk/Ibu *${successResult.headOfFamily}*.\nKeluarga Anda telah resmi terdaftar sebagai anggota Paguyuban Rukun Kematian Muslim (${settings.orgName}).\n\n📌 No. KK: *${successResult.noKK}*\n📌 Domisili: *${successResult.block} ${successResult.houseNumber}* (${successResult.communityType === 'RT' ? `RT ${successResult.rt}/RW ${successResult.rw}` : successResult.paguyubanName})\n📌 Iuran Bulanan: *${formatRupiah(calculatedMonthlyDues)}/bulan* (${members.length + 1} jiwa terdaftar)\n📌 Status: *Aktif & Berhak Mendapatkan Pelayanan Santunan*\n\nTerima kasih atas partisipasi dan kepedulian sosial Anda.`
                  )}`}
                  target="_blank"
                  rel="noreferrer"
                  className="px-4 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-2xl text-xs flex items-center justify-center gap-2 shadow-md transition-all"
                >
                  <Phone className="w-4 h-4" />
                  <span>Kirim Sambutan via WhatsApp</span>
                </a>
              </div>

              <button
                type="button"
                onClick={handleResetForm}
                className="text-xs font-bold text-slate-500 hover:text-slate-800 hover:underline pt-2 block mx-auto"
              >
                + Daftarkan Anggota Warga Lainnya
              </button>
            </div>
          ) : (
            /* MULTI-STEP REGISTRATION FORM */
            <form onSubmit={handleSubmitRegistration} className="space-y-6">
              
              {/* Stepper Header */}
              <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-sm">
                <div className="flex items-center justify-between max-w-xl mx-auto">
                  {[
                    { s: 1, label: '1. Identitas KK, Blok & RT/Paguyuban' },
                    { s: 2, label: '2. Anggota Jiwa (Inti & Tambahan)' },
                    { s: 3, label: '3. Rincian Iuran & Simpan' }
                  ].map((st) => (
                    <button
                      key={st.s}
                      type="button"
                      onClick={() => setStep(st.s)}
                      className={`flex items-center gap-2 text-xs font-extrabold pb-2 border-b-2 transition-all ${
                        step === st.s
                          ? 'border-emerald-600 text-emerald-700'
                          : 'border-transparent text-slate-400 hover:text-slate-600'
                      }`}
                    >
                      <span className={`w-6 h-6 rounded-full flex items-center justify-center text-[11px] ${
                        step === st.s ? 'bg-emerald-600 text-white' : 'bg-slate-100 text-slate-500'
                      }`}>
                        {st.s}
                      </span>
                      <span className="hidden sm:inline">{st.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* STEP 1: DATA KEPALA KELUARGA, BLOK & RT / PAGUYUBAN */}
              {step === 1 && (
                <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/80 shadow-sm space-y-6 animate-fade-in">
                  <div className="flex items-center gap-2.5 pb-4 border-b border-slate-100">
                    <span className="p-2 bg-emerald-100 text-emerald-700 rounded-xl">
                      <Users className="w-5 h-5" />
                    </span>
                    <div>
                      <h3 className="font-extrabold text-slate-900 text-base">Identitas Kartu Keluarga, Blok & Wilayah</h3>
                      <p className="text-xs text-slate-500">Unggah foto avatar, tentukan nomor KK, NIK, blok domisili dan koordinator pembayaran.</p>
                    </div>
                  </div>

                  {/* Avatar Upload */}
                  <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 flex flex-col sm:flex-row items-center gap-4">
                    <div className="relative shrink-0">
                      <img
                        src={getAvatarUrl(headOfFamily || 'Warga Baru', 'warga', avatar)}
                        alt="Avatar Preview"
                        className="w-16 h-16 rounded-2xl object-cover border-2 border-emerald-500 shadow-sm"
                      />
                      {avatar && (
                        <button
                          type="button"
                          onClick={() => setAvatar('')}
                          className="absolute -top-2 -right-2 p-1 bg-rose-600 text-white rounded-full hover:bg-rose-700 shadow"
                          title="Hapus Foto"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                    <div className="flex-1 text-center sm:text-left">
                      <span className="text-xs font-bold text-slate-800 block mb-1">
                        Foto Profil / Avatar Kepala Keluarga (Opsional)
                      </span>
                      <p className="text-[11px] text-slate-500 mb-2">
                        Foto akan terpasang di Kartu KTA Digital, tanda pengenal portal, serta database warga.
                      </p>
                      <label className="inline-flex items-center gap-2 px-3.5 py-2 bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 rounded-xl cursor-pointer font-bold text-xs shadow-xs transition-colors">
                        <Upload className="w-4 h-4 text-emerald-600" />
                        <span>{avatar ? 'Ganti Foto Avatar' : 'Unggah Foto Avatar'}</span>
                        <input
                          type="file"
                          accept="image/*"
                          onChange={handleAvatarUpload}
                          className="hidden"
                        />
                      </label>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        Nomor Kartu Keluarga (No. KK 16 Digit) <span className="text-rose-500">*</span>
                      </label>
                      <input
                        type="text"
                        maxLength={16}
                        required
                        placeholder="320108xxxxxxxxxx"
                        value={noKK}
                        onChange={(e) => setNoKK(e.target.value.replace(/\D/g, ''))}
                        className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono font-bold focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                      />
                      <p className="text-[10px] text-slate-400 mt-1">Digunakan sebagai Username login portal warga</p>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        NIK Kepala Keluarga (16 Digit) <span className="text-rose-500">*</span>
                      </label>
                      <input
                        type="text"
                        maxLength={16}
                        required
                        placeholder="320108xxxxxxxxxx"
                        value={nik}
                        onChange={(e) => setNik(e.target.value.replace(/\D/g, ''))}
                        className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono font-bold focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        Nama Lengkap Kepala Keluarga <span className="text-rose-500">*</span>
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="Contoh: Bpk. H. Ahmad Sudirman"
                        value={headOfFamily}
                        onChange={(e) => setHeadOfFamily(e.target.value)}
                        className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        Nomor WhatsApp / HP Aktif <span className="text-rose-500">*</span>
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="081234567890"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                      />
                    </div>
                  </div>

                  {/* BLOK & RT / PAGUYUBAN SELECTION */}
                  <div className="p-4 bg-emerald-50/60 rounded-2xl border border-emerald-200/80 space-y-4">
                    <div className="flex items-center gap-2">
                      <Home className="w-4 h-4 text-emerald-700" />
                      <h4 className="font-extrabold text-xs text-emerald-950 uppercase tracking-wide">
                        Pilihan Blok Rumah & Komunitas (RT / Paguyuban)
                      </h4>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                      {/* Pilihan Blok */}
                      <div>
                        <label className="block text-xs font-bold text-slate-800 mb-1">
                          Blok Rumah <span className="text-rose-500">*</span>
                        </label>
                        <select
                          value={block}
                          onChange={(e) => setBlock(e.target.value)}
                          className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-xs font-black text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                        >
                          {blockOptions.map((opt) => (
                            <option key={opt} value={opt}>
                              {opt}
                            </option>
                          ))}
                        </select>
                      </div>

                      {/* Nomor Rumah */}
                      <div>
                        <label className="block text-xs font-bold text-slate-800 mb-1">
                          Nomor Rumah
                        </label>
                        <input
                          type="text"
                          placeholder="Contoh: No. 12"
                          value={houseNumber}
                          onChange={(e) => setHouseNumber(e.target.value)}
                          className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-xs font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                        />
                      </div>

                      {/* Pilihan RT atau Paguyuban */}
                      <div>
                        <label className="block text-xs font-bold text-slate-800 mb-1">
                          Kelompok Komunitas <span className="text-rose-500">*</span>
                        </label>
                        <div className="grid grid-cols-2 gap-2">
                          <button
                            type="button"
                            onClick={() => setCommunityType('RT')}
                            className={`py-2 px-3 rounded-xl text-xs font-extrabold border transition-all ${
                              communityType === 'RT'
                                ? 'bg-emerald-600 text-white border-emerald-700 shadow-sm'
                                : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
                            }`}
                          >
                            Wilayah RT
                          </button>
                          <button
                            type="button"
                            onClick={() => setCommunityType('Paguyuban')}
                            className={`py-2 px-3 rounded-xl text-xs font-extrabold border transition-all ${
                              communityType === 'Paguyuban'
                                ? 'bg-emerald-600 text-white border-emerald-700 shadow-sm'
                                : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
                            }`}
                          >
                            Paguyuban
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* Conditional input based on RT or Paguyuban */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
                      {communityType === 'RT' ? (
                        <div className="grid grid-cols-2 gap-2">
                          <div>
                            <label className="block text-xs font-bold text-slate-800 mb-1">
                              Nomor RT:
                            </label>
                            <select
                              value={rt}
                              onChange={(e) => setRt(e.target.value)}
                              className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-xs font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                            >
                              {rtOptions.map(r => (
                                <option key={r} value={r}>RT {r}</option>
                              ))}
                            </select>
                          </div>
                          <div>
                            <label className="block text-xs font-bold text-slate-800 mb-1">
                              Nomor RW:
                            </label>
                            <select
                              value={rw}
                              onChange={(e) => setRw(e.target.value)}
                              className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-xs font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                            >
                              {rwOptions.map(w => (
                                <option key={w} value={w}>RW {w}</option>
                              ))}
                            </select>
                          </div>
                        </div>
                      ) : (
                        <div>
                          <label className="block text-xs font-bold text-slate-800 mb-1">
                            Nama Paguyuban / Komunitas Warga:
                          </label>
                          <select
                            value={paguyubanName}
                            onChange={(e) => setPaguyubanName(e.target.value)}
                            className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-xs font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                          >
                            {paguyubanOptions.map(p => (
                              <option key={p} value={p}>{p}</option>
                            ))}
                          </select>
                        </div>
                      )}

                      <div>
                        <label className="block text-xs font-bold text-slate-800 mb-1">
                          Detail Alamat Tambahan (Opsional)
                        </label>
                        <input
                          type="text"
                          placeholder="Contoh: Depan Taman Utama / Samping Pos Satpam"
                          value={addressDetail}
                          onChange={(e) => setAddressDetail(e.target.value)}
                          className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Koordinator Penanggung Jawab (Downline) */}
                  <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200">
                    <label className="block text-xs font-bold text-slate-800 mb-1">
                      Koordinator Penanggung Jawab Penagihan (Downline)
                    </label>
                    <select
                      value={assignedCollectorId}
                      onChange={(e) => setAssignedCollectorId(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-xs font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    >
                      <option value="">-- Otomatis Sesuai Blok / RT --</option>
                      {coordinatorUsers.map(u => (
                        <option key={u.id} value={u.id}>
                          {u.name} ({u.role.toUpperCase()} {u.assignedBlocks ? `- Blok ${u.assignedBlocks.join(',')}` : ''})
                        </option>
                      ))}
                    </select>
                    <p className="text-[10px] text-slate-500 mt-1">
                      Petugas koordinator yang membawahi anggota ini. Hanya koordinator yang ditugaskan yang dapat melihat dan menagih iuran warga ini.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        Status Kepemilikan Rumah / Domisili
                      </label>
                      <select
                        value={residenceStatus}
                        onChange={(e) => setResidenceStatus(e.target.value as any)}
                        className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                      >
                        <option value="Warga Tetap (Pemilik)">Warga Tetap (Pemilik Rumah)</option>
                        <option value="Warga Kontrak / Sewa">Warga Kontrak / Sewa</option>
                        <option value="Pindahan Baru">Warga Pindahan Baru</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        Tanggal Terdaftar Bergabung
                      </label>
                      <input
                        type="date"
                        value={joinDate}
                        onChange={(e) => setJoinDate(e.target.value)}
                        className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                      />
                    </div>
                  </div>

                  <div className="flex justify-end pt-4 border-t border-slate-100">
                    <button
                      type="button"
                      onClick={() => {
                        if (!noKK || !nik || !headOfFamily) {
                          alert('Lengkapi No KK, NIK, dan Nama Kepala Keluarga terlebih dahulu.');
                          return;
                        }
                        setStep(2);
                      }}
                      className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs shadow-md shadow-emerald-900/20 transition-all"
                    >
                      Lanjut ke Anggota Jiwa Keluarga →
                    </button>
                  </div>
                </div>
              )}

              {/* STEP 2: ANGGOTA JIWA (INTI & TAMBAHAN) */}
              {step === 2 && (
                <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/80 shadow-sm space-y-6 animate-fade-in">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-4 border-b border-slate-100">
                    <div className="flex items-center gap-2.5">
                      <span className="p-2 bg-indigo-100 text-indigo-700 rounded-xl">
                        <Users className="w-5 h-5" />
                      </span>
                      <div>
                        <h3 className="font-extrabold text-slate-900 text-base">Anggota Jiwa Terdaftar</h3>
                        <p className="text-xs text-slate-500">
                          Kepala Keluarga ({headOfFamily}) + {members.length} Jiwa Anggota
                        </p>
                      </div>
                    </div>

                    {/* Dynamic fee badge */}
                    <div className="px-3.5 py-1.5 bg-slate-900 text-white rounded-xl text-xs font-mono font-bold flex items-center gap-2">
                      <span className="text-slate-300">Estimasi Iuran:</span>
                      <span className="text-emerald-400 font-black">{formatRupiah(calculatedMonthlyDues)}/bln</span>
                    </div>
                  </div>

                  {/* Kategori Guide Card */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <div className="p-3.5 bg-emerald-50/80 rounded-2xl border border-emerald-200 text-xs space-y-1">
                      <div className="flex items-center gap-1.5 font-extrabold text-emerald-900">
                        <span className="w-2 h-2 rounded-full bg-emerald-600"></span>
                        <span>Anggota Inti Jiwa (Termasuk Iuran Rp 5.000 / KK)</span>
                      </div>
                      <p className="text-[11px] text-emerald-800">
                        Orang tua, anak, istri/suami, atau mertua dari Kepala Keluarga. Iuran bulanan sudah tercakup dalam iuran pokok keluarga.
                      </p>
                    </div>

                    <div className="p-3.5 bg-amber-50/80 rounded-2xl border border-amber-200 text-xs space-y-1">
                      <div className="flex items-center gap-1.5 font-extrabold text-amber-900">
                        <span className="w-2 h-2 rounded-full bg-amber-600"></span>
                        <span>Anggota Tambahan Jiwa (+Rp 3.000 / jiwa / bulan)</span>
                      </div>
                      <p className="text-[11px] text-amber-800">
                        Adik, kakak, saudara, atau famili lain yang tinggal bersama. Dikenakan iuran tambahan Rp 3.000 / jiwa per bulan.
                      </p>
                    </div>
                  </div>

                  {/* Form Add Member Inline */}
                  <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200/80 space-y-3">
                    <h4 className="font-bold text-xs text-slate-800 flex items-center gap-1.5">
                      <Plus className="w-3.5 h-3.5 text-emerald-600" />
                      <span>Tambah Anggota Jiwa Keluarga</span>
                    </h4>

                    <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                      <div>
                        <label className="block text-[11px] font-bold text-slate-600 mb-1">Nama Anggota</label>
                        <input
                          type="text"
                          placeholder="Nama lengkap"
                          value={tempMemberName}
                          onChange={(e) => setTempMemberName(e.target.value)}
                          className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-emerald-500"
                        />
                      </div>

                      <div>
                        <label className="block text-[11px] font-bold text-slate-600 mb-1">NIK (16 Digit)</label>
                        <input
                          type="text"
                          maxLength={16}
                          placeholder="320108xxxxxxxxxx"
                          value={tempMemberNik}
                          onChange={(e) => setTempMemberNik(e.target.value.replace(/\D/g, ''))}
                          className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-mono focus:outline-none focus:ring-2 focus:ring-emerald-500"
                        />
                      </div>

                      <div>
                        <label className="block text-[11px] font-bold text-slate-600 mb-1">Hubungan Keluarga</label>
                        <select
                          value={tempMemberRelation}
                          onChange={(e) => setTempMemberRelation(e.target.value as any)}
                          className="w-full px-2.5 py-2 bg-white border border-slate-200 rounded-xl text-xs font-bold text-slate-700"
                        >
                          <optgroup label="Anggota Inti (Termasuk Rp 5.000)">
                            <option value="Istri">Istri</option>
                            <option value="Suami">Suami</option>
                            <option value="Anak">Anak</option>
                            <option value="Orang Tua">Orang Tua (Ayah / Ibu)</option>
                            <option value="Mertua">Mertua (Ayah / Ibu Mertua)</option>
                          </optgroup>
                          <optgroup label="Anggota Tambahan (+Rp 3.000/bln)">
                            <option value="Adik">Adik</option>
                            <option value="Kakak">Kakak</option>
                            <option value="Saudara">Saudara / Famili Lain</option>
                          </optgroup>
                        </select>
                      </div>

                      <div className="flex items-end gap-2">
                        <div className="flex-1">
                          <label className="block text-[11px] font-bold text-slate-600 mb-1">Jenis Kelamin</label>
                          <select
                            value={tempMemberGender}
                            onChange={(e) => setTempMemberGender(e.target.value as any)}
                            className="w-full px-2.5 py-2 bg-white border border-slate-200 rounded-xl text-xs font-semibold text-slate-700"
                          >
                            <option value="Laki-laki">Laki-laki</option>
                            <option value="Perempuan">Perempuan</option>
                          </select>
                        </div>

                        <button
                          type="button"
                          onClick={handleAddMemberDraft}
                          className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs shadow-xs h-[38px]"
                        >
                          + Tambah
                        </button>
                      </div>
                    </div>

                    {/* Preview category tag for the current selected relation */}
                    <div className="flex items-center gap-2 text-[11px] text-slate-500 pt-1">
                      <span>Status Hubungan Terpilih:</span>
                      <span className={`px-2 py-0.5 rounded font-bold ${
                        currentDraftCategory === 'Inti' 
                          ? 'bg-emerald-100 text-emerald-800' 
                          : 'bg-amber-100 text-amber-900'
                      }`}>
                        {currentDraftCategory === 'Inti' ? 'Anggota Inti (Termasuk Rp 5.000)' : 'Anggota Tambahan (+Rp 3.000 / bulan)'}
                      </span>
                    </div>
                  </div>

                  {/* List of Added Members */}
                  <div className="space-y-2">
                    {/* Head of Family Row (Read-only) */}
                    <div className="p-3 bg-emerald-50/60 rounded-xl border border-emerald-200/80 flex items-center justify-between text-xs">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-extrabold text-slate-900">{headOfFamily}</span>
                          <span className="px-2 py-0.5 bg-emerald-200 text-emerald-900 rounded-md text-[10px] font-black">
                            Kepala Keluarga (Jiwa Inti)
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-500 font-mono mt-0.5">NIK: {nik}</p>
                      </div>
                      <BadgeCheck className="w-5 h-5 text-emerald-600" />
                    </div>

                    {/* Additional Family Members */}
                    {members.map((m, idx) => {
                      const isInti = m.category === 'Inti';
                      return (
                        <div key={idx} className="p-3 bg-slate-50 rounded-xl border border-slate-200/70 flex items-center justify-between text-xs">
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="font-extrabold text-slate-900">{m.name}</span>
                              <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${
                                isInti ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-900'
                              }`}>
                                {m.relation} • {isInti ? 'Jiwa Inti' : 'Jiwa Tambahan (+Rp 3.000)'}
                              </span>
                            </div>
                            <p className="text-[11px] text-slate-500 font-mono mt-0.5">
                              NIK: {m.nik} • {m.gender}
                            </p>
                          </div>
                          <button
                            type="button"
                            onClick={() => handleRemoveMemberDraft(idx)}
                            className="text-slate-400 hover:text-rose-600 p-1"
                            title="Hapus"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      );
                    })}
                  </div>

                  {/* Summary of members count and monthly fee calculation */}
                  <div className="p-4 bg-slate-100 rounded-2xl border border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
                    <div>
                      <p className="font-extrabold text-slate-800">
                        Rincian Jiwa: 1 Kepala Keluarga + {coreMembersDraftCount} Jiwa Inti + {extraMembersDraftCount} Jiwa Tambahan
                      </p>
                      <p className="text-[11px] text-slate-500 mt-0.5">
                        Pokok ({formatRupiah(baseDuesRate)}) + Jiwa Tambahan ({extraMembersDraftCount} × {formatRupiah(extraMemberRate)} = {formatRupiah(extraMembersDraftCount * extraMemberRate)})
                      </p>
                    </div>

                    <div className="text-right">
                      <span className="text-[10px] text-slate-500 uppercase font-bold block">Iuran Rutin Keluarga</span>
                      <span className="text-base font-black text-emerald-700 font-mono">
                        {formatRupiah(calculatedMonthlyDues)} / bulan
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-4 border-t border-slate-100">
                    <button
                      type="button"
                      onClick={() => setStep(1)}
                      className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs"
                    >
                      ← Kembali ke Data KK
                    </button>
                    <button
                      type="button"
                      onClick={() => setStep(3)}
                      className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs shadow-md shadow-emerald-900/20 transition-all"
                    >
                      Lanjut ke Iuran & Verifikasi →
                    </button>
                  </div>
                </div>
              )}

              {/* STEP 3: RINCIAN IURAN, UANG PANGKAL & SIMPAN */}
              {step === 3 && (
                <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/80 shadow-sm space-y-6 animate-fade-in">
                  <div className="flex items-center gap-2.5 pb-4 border-b border-slate-100">
                    <span className="p-2 bg-emerald-100 text-emerald-700 rounded-xl">
                      <CreditCard className="w-5 h-5" />
                    </span>
                    <div>
                      <h3 className="font-extrabold text-slate-900 text-base">Pembayaran Pendaftaran & Iuran Awal</h3>
                      <p className="text-xs text-slate-500">Biaya pendaftaran anggota baru Rp 50.000 dan iuran bulanan keluarga terhitung</p>
                    </div>
                  </div>

                  {/* Calculation Breakdown Card */}
                  <div className="p-5 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
                    <h4 className="font-extrabold text-xs text-slate-900 uppercase tracking-wide">
                      Rincian Biaya & Iuran Anggota Baru
                    </h4>
                    
                    <div className="space-y-2 text-xs divide-y divide-slate-200/60 font-sans">
                      <div className="flex items-center justify-between pt-1">
                        <span className="text-slate-600">1. Biaya Pendaftaran Anggota Baru (1x seumur hidup):</span>
                        <span className="font-mono font-bold text-slate-900">{formatRupiah(regFeeAmount)}</span>
                      </div>
                      <div className="flex items-center justify-between pt-2">
                        <span className="text-slate-600">2. Iuran Pokok Keluarga (Kepala Keluarga & Jiwa Inti):</span>
                        <span className="font-mono font-bold text-slate-900">{formatRupiah(baseDuesRate)} / bulan</span>
                      </div>
                      <div className="flex items-center justify-between pt-2">
                        <span className="text-slate-600">3. Iuran Jiwa Tambahan ({extraMembersDraftCount} Jiwa @ {formatRupiah(extraMemberRate)}):</span>
                        <span className="font-mono font-bold text-slate-900">+{formatRupiah(extraMembersDraftCount * extraMemberRate)} / bulan</span>
                      </div>
                      <div className="flex items-center justify-between pt-2 font-bold text-emerald-800 bg-emerald-50/60 p-2 rounded-lg">
                        <span>Total Iuran Bulanan Keluarga ({headOfFamily}):</span>
                        <span className="font-mono font-black text-sm">{formatRupiah(calculatedMonthlyDues)} / bulan</span>
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {/* Registration Fee */}
                    <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200/80 space-y-2">
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={payRegistrationFee}
                          onChange={(e) => setPayRegistrationFee(e.target.checked)}
                          className="w-4 h-4 text-emerald-600 rounded border-slate-300 focus:ring-emerald-500"
                        />
                        <span className="text-xs font-bold text-slate-800">
                          Bayar Uang Pendaftaran Anggota Baru
                        </span>
                      </label>
                      {payRegistrationFee && (
                        <div className="pt-2">
                          <input
                            type="number"
                            value={regFeeAmount}
                            onChange={(e) => setRegFeeAmount(Number(e.target.value))}
                            className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-bold text-slate-900"
                          />
                          <p className="text-[10px] text-slate-400 mt-1">Standar AD/ART: Rp 50.000 (Satu kali)</p>
                        </div>
                      )}
                    </div>

                    {/* Initial Dues */}
                    <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200/80 space-y-2">
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={payInitialDues}
                          onChange={(e) => setPayInitialDues(e.target.checked)}
                          className="w-4 h-4 text-emerald-600 rounded border-slate-300 focus:ring-emerald-500"
                        />
                        <span className="text-xs font-bold text-slate-800">
                          Bayar Iuran Bulanan Langsung
                        </span>
                      </label>
                      {payInitialDues && (
                        <div className="pt-2">
                          <select
                            value={initialDuesMonths}
                            onChange={(e) => setInitialDuesMonths(Number(e.target.value))}
                            className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-bold text-slate-900"
                          >
                            <option value={1}>1 Bulan Pertama ({formatRupiah(calculatedMonthlyDues)})</option>
                            <option value={3}>3 Bulan Sekaligus ({formatRupiah(calculatedMonthlyDues * 3)})</option>
                            <option value={6}>6 Bulan Sekaligus ({formatRupiah(calculatedMonthlyDues * 6)})</option>
                            <option value={12}>1 Tahun Penuh 2026 ({formatRupiah(calculatedMonthlyDues * 12)})</option>
                          </select>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Payment Method & Collector */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        Metode Pembayaran
                      </label>
                      <select
                        value={paymentMethod}
                        onChange={(e) => setPaymentMethod(e.target.value as any)}
                        className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800"
                      >
                        <option value="Tunai">💵 Tunai (Langsung ke Petugas)</option>
                        <option value="Transfer Bank">🏦 Transfer Bank (BSI / Mandiri / BCA)</option>
                        <option value="QRIS">📱 QRIS Masjid Metro Parung Panjang</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        Petugas Penerima / Verifikator
                      </label>
                      <input
                        type="text"
                        value={collectorName}
                        onChange={(e) => setCollectorName(e.target.value)}
                        className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium"
                      />
                    </div>
                  </div>

                  {/* Automation Toggles */}
                  <div className="p-4 bg-indigo-50/70 rounded-2xl border border-indigo-100 space-y-3">
                    <h4 className="font-extrabold text-xs text-indigo-950 flex items-center gap-1.5">
                      <Sparkles className="w-4 h-4 text-indigo-600" />
                      <span>Otomatisasi Sistem & Layanan Digital</span>
                    </h4>

                    <label className="flex items-center gap-2.5 cursor-pointer text-xs font-bold text-indigo-900">
                      <input
                        type="checkbox"
                        checked={createCitizenAccount}
                        onChange={(e) => setCreateCitizenAccount(e.target.checked)}
                        className="w-4 h-4 text-indigo-600 rounded border-slate-300"
                      />
                      <span>
                        Buatkan Akun Login Portal Warga (Username: No. KK, PIN default: 6 digit terakhir KK)
                      </span>
                    </label>

                    <label className="flex items-center gap-2.5 cursor-pointer text-xs font-bold text-indigo-900">
                      <input
                        type="checkbox"
                        checked={sendWaWelcome}
                        onChange={(e) => setSendWaWelcome(e.target.checked)}
                        className="w-4 h-4 text-indigo-600 rounded border-slate-300"
                      />
                      <span>
                        Siapkan Template Pesan Sambutan & Kuitansi Digital Resmi via WhatsApp
                      </span>
                    </label>
                  </div>

                  {/* Total Calculation */}
                  <div className="p-5 bg-emerald-950 text-white rounded-2xl flex items-center justify-between">
                    <div>
                      <p className="text-xs text-emerald-300">Total Setoran Awal Diterima:</p>
                      <h4 className="text-2xl font-black text-white font-mono">
                        {formatRupiah(
                          (payRegistrationFee ? regFeeAmount : 0) +
                          (payInitialDues ? initialDuesMonths * calculatedMonthlyDues : 0)
                        )}
                      </h4>
                      <p className="text-[11px] text-emerald-300/80 mt-0.5">
                        {payRegistrationFee ? `Pendaftaran ${formatRupiah(regFeeAmount)}` : ''} 
                        {payRegistrationFee && payInitialDues ? ' + ' : ''}
                        {payInitialDues ? `Iuran ${initialDuesMonths} bln (${formatRupiah(initialDuesMonths * calculatedMonthlyDues)})` : ''}
                      </p>
                    </div>
                    <span className="px-3 py-1 bg-emerald-800 text-emerald-200 text-xs font-bold rounded-lg">
                      {paymentMethod}
                    </span>
                  </div>

                  <div className="flex items-center justify-between pt-4 border-t border-slate-100">
                    <button
                      type="button"
                      onClick={() => setStep(2)}
                      className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs"
                    >
                      ← Kembali ke Anggota Jiwa
                    </button>
                    <button
                      type="submit"
                      className="px-7 py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold rounded-2xl text-xs shadow-lg shadow-emerald-900/30 transition-all hover:scale-[1.02]"
                    >
                      ✓ Simpan & Daftarkan Warga Resmi
                    </button>
                  </div>
                </div>
              )}

            </form>
          )}
        </div>
      )}

      {/* VIEW 2: CSV BATCH IMPORT */}
      {activeSubView === 'import' && (
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/80 shadow-sm space-y-6">
          <div className="flex items-center justify-between pb-4 border-b border-slate-100">
            <div className="flex items-center gap-2.5">
              <span className="p-2 bg-emerald-100 text-emerald-700 rounded-xl">
                <FileSpreadsheet className="w-5 h-5" />
              </span>
              <div>
                <h3 className="font-extrabold text-slate-900 text-base">Impor Data Warga Massal (Format CSV / Excel)</h3>
                <p className="text-xs text-slate-500">Tambah puluhan data KK dan anggota sekaligus dengan kolom Blok & RT/Paguyuban</p>
              </div>
            </div>

            <button
              type="button"
              onClick={handleImportSampleCsv}
              className="px-3.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs flex items-center gap-1.5 transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Muat Contoh Format CSV</span>
            </button>
          </div>

          {importStatus && (
            <div className="p-4 bg-emerald-50 text-emerald-900 border border-emerald-200 rounded-2xl text-xs font-semibold">
              {importStatus}
            </div>
          )}

          <div className="space-y-2">
            <label className="block text-xs font-bold text-slate-700">
              Tempelkan (Paste) Teks CSV di Bawah Ini:
            </label>
            <textarea
              rows={8}
              value={csvText}
              onChange={(e) => setCsvText(e.target.value)}
              placeholder="No KK,Kepala Keluarga,NIK,No HP,Blok,No Rumah,RT/Paguyuban,Nama RT atau Paguyuban&#10;3201082501900088,H. Mochammad Ilyas,3201081503880005,081299887766,Blok C,No. 08,RT,04"
              className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl font-mono text-xs focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
            <p className="text-[11px] text-slate-500">
              Format kolom wajib: <code>No KK, Kepala Keluarga, NIK, No HP, Blok (A-Z), No Rumah, RT/Paguyuban, Nama RT/Paguyuban</code>
            </p>
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t border-slate-100">
            <button
              type="button"
              onClick={() => setCsvText('')}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs"
            >
              Bersihkan
            </button>
            <button
              type="button"
              onClick={handleProcessCsvImport}
              className="px-6 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs shadow-md"
            >
              Proses Impor Data Warga
            </button>
          </div>
        </div>
      )}

      {/* VIEW 3: PRINT BLANK FORM */}
      {activeSubView === 'print_form' && (
        <div className="bg-white rounded-3xl p-8 border border-slate-200/80 shadow-sm space-y-6">
          <div className="flex items-center justify-between pb-4 border-b border-slate-200 print:hidden">
            <div>
              <h3 className="font-extrabold text-slate-900 text-base">Formulir Pendaftaran Fisik (Kertas Blangko A4)</h3>
              <p className="text-xs text-slate-500">Dapat dicetak untuk formulir pendaftaran warga offline oleh Ketua RT / Pengurus Paguyuban</p>
            </div>
            <button
              type="button"
              onClick={() => window.print()}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl shadow flex items-center gap-1.5"
            >
              <Printer className="w-4 h-4" />
              <span>Cetak Formulir Ini</span>
            </button>
          </div>

          {/* Printable Blank Form */}
          <div className="border border-slate-900 p-6 font-serif text-xs space-y-4 text-slate-900">
            <div className="text-center border-b-2 border-slate-900 pb-3 space-y-0.5">
              <h4 className="font-bold text-sm tracking-wider uppercase">PAGUYUBAN RUKUN KEMATIAN MUSLIM (RKM)</h4>
              <h3 className="font-black text-base uppercase">{settings.orgName}</h3>
              <p className="text-[11px] font-sans">FORMULIR PENDAFTARAN ANGGOTA & KELUARGA BARU</p>
            </div>

            <div className="space-y-3 font-sans pt-2">
              <div className="grid grid-cols-2 gap-4">
                <div>1. Nomor Kartu Keluarga (KK) : ............................................................</div>
                <div>2. NIK Kepala Keluarga : ............................................................</div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>3. Nama Kepala Keluarga : ............................................................</div>
                <div>4. Nomor HP / WhatsApp : ............................................................</div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>5. Pilihan Blok Rumah : <strong>Blok [   ]</strong>  No. ....................</div>
                <div>6. Kelompok : [  ] RT .......... / RW 08    [  ] Paguyuban: ....................</div>
              </div>
              <div>7. Status Tempat Tinggal : [  ] Rumah Sendiri / Tetap    [  ] Kontrak / Sewa</div>
              <div className="p-2 bg-slate-100 text-[10px] rounded border border-slate-300">
                <strong>Ketentuan Biaya:</strong> Uang Pendaftaran Anggota Baru: Rp 50.000 (1x) | Iuran 1 Keluarga (Kepala + Jiwa Inti: Orang Tua, Istri/Suami, Anak, Mertua): Rp 5.000/bulan | Anggota Tambahan (Adik, Kakak, Saudara): Rp 3.000/jiwa/bulan.
              </div>
            </div>

            <div className="font-sans pt-3">
              <p className="font-bold mb-1">Daftar Anggota Jiwa Keluarga Terdaftar:</p>
              <table className="w-full border-collapse border border-slate-900 text-[11px]">
                <thead>
                  <tr className="bg-slate-100">
                    <th className="border border-slate-900 p-1 w-8">No</th>
                    <th className="border border-slate-900 p-1 text-left">Nama Lengkap</th>
                    <th className="border border-slate-900 p-1 text-left">NIK</th>
                    <th className="border border-slate-900 p-1 text-left">Hubungan Keluarga</th>
                    <th className="border border-slate-900 p-1 text-left">Kategori Jiwa (Inti / Tambahan)</th>
                    <th className="border border-slate-900 p-1 text-left">Tgl Lahir / Usia</th>
                  </tr>
                </thead>
                <tbody>
                  {[1, 2, 3, 4, 5, 6].map(i => (
                    <tr key={i} className="h-7">
                      <td className="border border-slate-900 text-center">{i}</td>
                      <td className="border border-slate-900"></td>
                      <td className="border border-slate-900"></td>
                      <td className="border border-slate-900"></td>
                      <td className="border border-slate-900"></td>
                      <td className="border border-slate-900"></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="grid grid-cols-2 gap-4 pt-6 font-sans text-center text-xs">
              <div>
                <p>Mengetahui,</p>
                <p className="font-bold mt-1">Ketua RT / Pengurus Paguyuban</p>
                <div className="h-14"></div>
                <p>( .................................................... )</p>
              </div>
              <div>
                <p>Parungpanjang, ................................ 2026</p>
                <p className="font-bold mt-1">Kepala Keluarga Pendaftar</p>
                <div className="h-14"></div>
                <p>( .................................................... )</p>
              </div>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
