import React, { useState, useMemo } from 'react';
import { 
  Calendar, 
  Clock, 
  UserCheck, 
  Plus, 
  Phone, 
  MessageSquare, 
  Trash2, 
  Edit3, 
  CheckCircle2, 
  AlertCircle, 
  Printer, 
  Download, 
  ShieldAlert, 
  Ambulance, 
  Users, 
  FileText,
  Search,
  Filter,
  Check,
  X
} from 'lucide-react';
import { useRkm } from '../context/RkmContext';
import { DutySchedule, Officer } from '../types';
import { formatDateIndo, createWhatsAppUrl } from '../utils/formatters';

interface DutyScheduleManagerProps {
  onNotify?: (msg: string) => void;
}

export const DutyScheduleManager: React.FC<DutyScheduleManagerProps> = ({ onNotify }) => {
  const { 
    dutySchedules, 
    addDutySchedule, 
    updateDutySchedule, 
    deleteDutySchedule, 
    officers, 
    users, 
    settings,
    currentRole 
  } = useRkm();

  const isSuperAdminOrOfficer = ['superadmin', 'ketua', 'bendahara', 'petugas'].includes(currentRole);

  const [filterPeriod, setFilterPeriod] = useState<'all' | 'today' | 'upcoming'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingDuty, setEditingDuty] = useState<DutySchedule | null>(null);

  // Form states for Add/Edit Duty Schedule
  const todayStr = new Date().toISOString().split('T')[0];
  const [dutyDate, setDutyDate] = useState(todayStr);
  const [dayName, setDayName] = useState(() => {
    const days = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
    return days[new Date().getDay()];
  });
  const [shiftType, setShiftType] = useState<DutySchedule['shiftType']>('Siaga 24 Jam');
  const [coordinatorName, setCoordinatorName] = useState('Supriyanto (Kang Asep)');
  const [coordinatorPhone, setCoordinatorPhone] = useState('085712349988');
  const [selectedOfficerNames, setSelectedOfficerNames] = useState<string[]>(['Ust. Syihabuddin']);
  const [ambulanceDriverName, setAmbulanceDriverName] = useState('Bpk. Ridwan');
  const [ambulanceDriverPhone, setAmbulanceDriverPhone] = useState('081298765401');
  const [graveDiggerName, setGraveDiggerName] = useState('Pak Sukardi & Tim TPU');
  const [graveDiggerPhone, setGraveDiggerPhone] = useState('081399887766');
  const [dutyStatus, setDutyStatus] = useState<DutySchedule['status']>('Siaga');
  const [dutyNotes, setDutyNotes] = useState('');

  // Handle date change and automatically calculate day name
  const handleDateChange = (newDate: string) => {
    setDutyDate(newDate);
    if (newDate) {
      const days = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
      const d = new Date(newDate);
      if (!isNaN(d.getTime())) {
        setDayName(days[d.getDay()]);
      }
    }
  };

  // Open add modal
  const handleOpenAddModal = () => {
    setEditingDuty(null);
    setDutyDate(new Date().toISOString().split('T')[0]);
    const days = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
    setDayName(days[new Date().getDay()]);
    setShiftType('Siaga 24 Jam');
    setCoordinatorName('Supriyanto (Kang Asep)');
    setCoordinatorPhone('085712349988');
    setSelectedOfficerNames(['Ust. Syihabuddin', 'Supriyanto (Kang Asep)']);
    setAmbulanceDriverName('Bpk. Ridwan');
    setAmbulanceDriverPhone('081298765401');
    setGraveDiggerName('Pak Sukardi & Tim TPU');
    setGraveDiggerPhone('081399887766');
    setDutyStatus('Siaga');
    setDutyNotes('Piket posko siaga duka fardhu kifayah 24 jam.');
    setShowAddModal(true);
  };

  // Open edit modal
  const handleOpenEditModal = (duty: DutySchedule) => {
    setEditingDuty(duty);
    setDutyDate(duty.date);
    setDayName(duty.dayName);
    setShiftType(duty.shiftType);
    setCoordinatorName(duty.coordinatorName);
    setCoordinatorPhone(duty.coordinatorPhone);
    setSelectedOfficerNames(duty.assignedOfficerNames || []);
    setAmbulanceDriverName(duty.ambulanceDriverName || '');
    setAmbulanceDriverPhone(duty.ambulanceDriverPhone || '');
    setGraveDiggerName(duty.graveDiggerName || '');
    setGraveDiggerPhone(duty.graveDiggerPhone || '');
    setDutyStatus(duty.status);
    setDutyNotes(duty.notes || '');
    setShowAddModal(true);
  };

  // Handle save (Add or Update)
  const handleSaveDuty = (e: React.FormEvent) => {
    e.preventDefault();
    if (!dutyDate || !coordinatorName.trim()) return;

    if (editingDuty) {
      updateDutySchedule(editingDuty.id, {
        date: dutyDate,
        dayName,
        shiftType,
        coordinatorName,
        coordinatorPhone,
        assignedOfficerNames: selectedOfficerNames,
        ambulanceDriverName,
        ambulanceDriverPhone,
        graveDiggerName,
        graveDiggerPhone,
        status: dutyStatus,
        notes: dutyNotes
      });
      if (onNotify) onNotify('Jadwal piket petugas berhasil diperbarui');
    } else {
      addDutySchedule({
        date: dutyDate,
        dayName,
        shiftType,
        assignedOfficerIds: [],
        assignedOfficerNames: selectedOfficerNames,
        coordinatorName,
        coordinatorPhone,
        ambulanceDriverName,
        ambulanceDriverPhone,
        graveDiggerName,
        graveDiggerPhone,
        status: dutyStatus,
        notes: dutyNotes
      });
      if (onNotify) onNotify('Jadwal piket baru berhasil ditambahkan');
    }
    setShowAddModal(false);
  };

  // Filtered schedules
  const filteredSchedules = useMemo(() => {
    return dutySchedules
      .filter(s => {
        if (filterPeriod === 'today') {
          return s.date === todayStr;
        }
        if (filterPeriod === 'upcoming') {
          return s.date >= todayStr;
        }
        return true;
      })
      .filter(s => {
        if (!searchQuery.trim()) return true;
        const q = searchQuery.toLowerCase();
        return (
          s.coordinatorName.toLowerCase().includes(q) ||
          s.dayName.toLowerCase().includes(q) ||
          s.date.includes(q) ||
          s.shiftType.toLowerCase().includes(q) ||
          s.assignedOfficerNames.some(name => name.toLowerCase().includes(q))
        );
      })
      .sort((a, b) => a.date.localeCompare(b.date));
  }, [dutySchedules, filterPeriod, searchQuery, todayStr]);

  // Today's active duty
  const todaySchedule = useMemo(() => {
    return dutySchedules.find(s => s.date === todayStr) || null;
  }, [dutySchedules, todayStr]);

  // WhatsApp quick text to Duty Officer
  const sendWhatsAppToCoordinator = (duty: DutySchedule) => {
    const text = 
`*PANGGILAN TUGAS PIKET SATGAS RKM MPP*
Halo Bpk/Ustadz *${duty.coordinatorName}*,
Kami mengonfirmasi jadwal tugas piket Satgas Rukun Kematian Muslim pada:
📅 *Hari/Tanggal:* ${duty.dayName}, ${formatDateIndo(duty.date)}
⏰ *Shift:* ${duty.shiftType}
👥 *Tim Bertugas:* ${duty.assignedOfficerNames.join(', ')}
🚑 *Armada Ambulans:* ${duty.ambulanceDriverName || 'Siaga'} (${duty.ambulanceDriverPhone || '-'})
🪦 *Tim Makam TPU:* ${duty.graveDiggerName || 'Siaga'}
📝 *Catatan:* ${duty.notes || 'Siaga 24 jam melayani warga berduka'}

Posko Layanan: Masjid Metro Parung Panjang
Mohon konfirmasi kesiapsiagaan. Terima kasih.`;

    const url = createWhatsAppUrl(duty.coordinatorPhone, text);
    window.open(url, '_blank');
  };

  return (
    <div className="space-y-6">
      {/* Banner: Today's On-Duty Satgas Highlight */}
      <div className="bg-gradient-to-br from-slate-900 via-emerald-950 to-slate-900 text-white rounded-3xl p-6 sm:p-7 shadow-lg border border-emerald-800/40 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-5 relative z-10">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="px-3 py-1 bg-emerald-500 text-slate-950 rounded-full text-xs font-black uppercase tracking-wider flex items-center gap-1.5 shadow-sm">
                <span className="w-2 h-2 rounded-full bg-slate-950 animate-pulse" />
                Satgas Piket Hari Ini
              </span>
              <span className="text-xs text-emerald-300 font-medium">
                {formatDateIndo(todayStr)}
              </span>
            </div>

            {todaySchedule ? (
              <div>
                <h3 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
                  <span>{todaySchedule.coordinatorName}</span>
                  <span className="text-xs bg-white/20 text-emerald-200 px-2.5 py-0.5 rounded-lg font-bold">
                    Koordinator Piket
                  </span>
                </h3>
                <p className="text-xs text-slate-300 mt-1 max-w-xl">
                  Shift: <strong>{todaySchedule.shiftType}</strong> • Tim Siaga: <strong>{todaySchedule.assignedOfficerNames.join(', ')}</strong>
                </p>
                <div className="flex flex-wrap items-center gap-3 mt-3 text-xs text-slate-200">
                  <span className="flex items-center gap-1.5 bg-white/10 px-3 py-1 rounded-xl">
                    <Ambulance className="w-3.5 h-3.5 text-emerald-400" />
                    Supir: {todaySchedule.ambulanceDriverName || 'Siaga'}
                  </span>
                  <span className="flex items-center gap-1.5 bg-white/10 px-3 py-1 rounded-xl">
                    <UserCheck className="w-3.5 h-3.5 text-amber-400" />
                    Tim TPU: {todaySchedule.graveDiggerName || 'Siaga TPU Parung Panjang'}
                  </span>
                </div>
              </div>
            ) : (
              <div>
                <h3 className="text-xl font-bold text-slate-200">
                  Belum Ada Petugas Terjadwal Hari Ini
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  Tetapkan giliran piket harian untuk memastikan tim pemulasaraan & ambulans siaga 24 jam.
                </p>
              </div>
            )}
          </div>

          <div className="flex items-center gap-2 self-start md:self-auto shrink-0 flex-wrap">
            {todaySchedule && (
              <button
                onClick={() => sendWhatsAppToCoordinator(todaySchedule)}
                className="flex items-center gap-2 px-4 py-2.5 bg-emerald-500 hover:bg-emerald-400 active:scale-95 text-slate-950 font-bold text-xs rounded-xl shadow-md transition-all cursor-pointer"
                title="Hubungi Koordinator Piket via WhatsApp"
              >
                <MessageSquare className="w-4 h-4" />
                <span>Hubungi Satgas Hari Ini</span>
              </button>
            )}

            {isSuperAdminOrOfficer && (
              <button
                onClick={handleOpenAddModal}
                className="flex items-center gap-2 px-4 py-2.5 bg-white/15 hover:bg-white/25 active:scale-95 text-white font-bold text-xs rounded-xl border border-white/20 transition-all cursor-pointer"
              >
                <Plus className="w-4 h-4 text-emerald-400" />
                <span>Tambah Jadwal Piket</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Toolbar & Filters */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-sm flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-2.5 flex-1 min-w-[260px]">
          {/* Search */}
          <div className="relative flex-1 min-w-[200px]">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Cari nama petugas / koordinator / hari..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none"
            />
          </div>

          {/* Period Filter Tabs */}
          <div className="flex items-center bg-slate-100 p-1 rounded-xl gap-1">
            <button
              onClick={() => setFilterPeriod('all')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                filterPeriod === 'all'
                  ? 'bg-white text-emerald-900 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Semua Jadwal ({dutySchedules.length})
            </button>
            <button
              onClick={() => setFilterPeriod('today')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                filterPeriod === 'today'
                  ? 'bg-white text-emerald-900 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Hari Ini
            </button>
            <button
              onClick={() => setFilterPeriod('upcoming')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                filterPeriod === 'upcoming'
                  ? 'bg-white text-emerald-900 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Mendatang
            </button>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => window.print()}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold transition-all cursor-pointer"
            title="Cetak Jadwal Piket Satgas (Siap Tempel di Posko)"
          >
            <Printer className="w-4 h-4" />
            <span>Cetak Jadwal Roster</span>
          </button>
        </div>
      </div>

      {/* Grid of Duty Schedules */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredSchedules.length === 0 ? (
          <div className="col-span-full p-12 text-center bg-white rounded-3xl border border-slate-200/80 text-slate-400">
            <Calendar className="w-12 h-12 mx-auto text-slate-300 mb-2" />
            <p className="font-bold text-slate-700">Tidak ada jadwal piket yang cocok</p>
            <p className="text-xs text-slate-500 mt-1">Gunakan tombol "Tambah Jadwal Piket" untuk menambahkan roster giliran tugas baru.</p>
          </div>
        ) : (
          filteredSchedules.map((duty) => {
            const isToday = duty.date === todayStr;
            return (
              <div
                key={duty.id}
                className={`bg-white rounded-3xl border p-5 shadow-sm hover:shadow-md transition-all flex flex-col justify-between relative ${
                  isToday
                    ? 'border-emerald-500 ring-2 ring-emerald-500/20 bg-emerald-50/20'
                    : 'border-slate-200/80'
                }`}
              >
                {/* Header Tag */}
                <div>
                  <div className="flex items-start justify-between gap-2 mb-3">
                    <div>
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className={`text-[10px] font-black px-2.5 py-0.5 rounded-full uppercase ${
                          isToday
                            ? 'bg-emerald-600 text-white'
                            : 'bg-slate-100 text-slate-700'
                        }`}>
                          {duty.dayName}, {formatDateIndo(duty.date)}
                        </span>
                        {isToday && (
                          <span className="text-[10px] font-black px-2 py-0.5 bg-rose-100 text-rose-800 rounded-full animate-pulse">
                            HARI INI
                          </span>
                        )}
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                          duty.status === 'Siaga' ? 'bg-amber-100 text-amber-800' :
                          duty.status === 'Bertugas' ? 'bg-blue-100 text-blue-800' : 'bg-slate-100 text-slate-600'
                        }`}>
                          {duty.status}
                        </span>
                      </div>

                      <h4 className="text-base font-black text-slate-900 mt-2 flex items-center gap-1.5">
                        <UserCheck className="w-4 h-4 text-emerald-700" />
                        {duty.coordinatorName}
                      </h4>
                      <p className="text-[11px] text-slate-500">
                        Shift: <strong>{duty.shiftType}</strong>
                      </p>
                    </div>

                    {isSuperAdminOrOfficer && (
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => handleOpenEditModal(duty)}
                          title="Edit Jadwal"
                          className="p-1.5 text-slate-400 hover:text-emerald-700 hover:bg-emerald-50 rounded-lg transition-colors cursor-pointer"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => {
                            if (window.confirm(`Hapus jadwal piket untuk tanggal ${duty.date}?`)) {
                              deleteDutySchedule(duty.id);
                            }
                          }}
                          title="Hapus Jadwal"
                          className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    )}
                  </div>

                  {/* Details Card */}
                  <div className="space-y-2 text-xs text-slate-600 bg-slate-50 p-3.5 rounded-2xl border border-slate-100 mb-3">
                    <div>
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                        Anggota Satgas Siaga:
                      </span>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {duty.assignedOfficerNames.map((name, i) => (
                          <span key={i} className="text-[11px] font-bold bg-white text-slate-800 px-2 py-0.5 rounded-md border border-slate-200">
                            {name}
                          </span>
                        ))}
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-200/60 text-[11px]">
                      <div>
                        <span className="text-slate-400 text-[10px] block">🚑 Driver Ambulans:</span>
                        <span className="font-bold text-slate-800">{duty.ambulanceDriverName || 'Siaga'}</span>
                      </div>
                      <div>
                        <span className="text-slate-400 text-[10px] block">🪦 Petugas TPU:</span>
                        <span className="font-bold text-slate-800">{duty.graveDiggerName || 'Siaga TPU'}</span>
                      </div>
                    </div>

                    {duty.notes && (
                      <p className="text-[11px] text-slate-500 italic pt-1 border-t border-slate-200/60">
                        💬 "{duty.notes}"
                      </p>
                    )}
                  </div>
                </div>

                {/* Card Actions */}
                <div className="pt-2 border-t border-slate-100 flex items-center justify-between gap-2">
                  <span className="text-[11px] text-slate-500 font-mono">
                    📞 {duty.coordinatorPhone || '-'}
                  </span>

                  <button
                    onClick={() => sendWhatsAppToCoordinator(duty)}
                    className="flex items-center gap-1 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white text-xs font-bold rounded-xl shadow-xs transition-all cursor-pointer"
                    title="Kirim Notifikasi Tugas via WhatsApp"
                  >
                    <MessageSquare className="w-3.5 h-3.5" />
                    <span>WhatsApp</span>
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Add / Edit Duty Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-100 my-8">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <span className="p-2 bg-emerald-100 text-emerald-800 rounded-xl">
                  <Calendar className="w-5 h-5" />
                </span>
                <div>
                  <h3 className="font-black text-slate-900 text-base">
                    {editingDuty ? 'Edit Jadwal Piket Satgas' : 'Tambah Jadwal Piket Satgas'}
                  </h3>
                  <p className="text-xs text-slate-500">Penetapan giliran tugas posko siaga duka 24 jam</p>
                </div>
              </div>
              <button
                onClick={() => setShowAddModal(false)}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-xl"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveDuty} className="mt-4 space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    Tanggal Piket *
                  </label>
                  <input
                    type="date"
                    required
                    value={dutyDate}
                    onChange={(e) => handleDateChange(e.target.value)}
                    className="w-full text-xs p-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none font-bold text-slate-800"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    Hari
                  </label>
                  <input
                    type="text"
                    value={dayName}
                    onChange={(e) => setDayName(e.target.value)}
                    className="w-full text-xs p-2.5 bg-slate-100 border border-slate-200 rounded-xl font-bold text-slate-700"
                    placeholder="Contoh: Rabu"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  Shift Tugas
                </label>
                <select
                  value={shiftType}
                  onChange={(e) => setShiftType(e.target.value as any)}
                  className="w-full text-xs p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-bold text-slate-800 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                >
                  <option value="Siaga 24 Jam">Siaga 24 Jam (Standby)</option>
                  <option value="Pagi (08:00 - 16:00)">Pagi (08:00 - 16:00 WIB)</option>
                  <option value="Malam (16:00 - 08:00)">Malam (16:00 - 08:00 WIB)</option>
                  <option value="Khusus Pemakaman">Khusus Pemakaman & Fardhu Kifayah</option>
                </select>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    Koordinator Lapangan *
                  </label>
                  <input
                    type="text"
                    required
                    value={coordinatorName}
                    onChange={(e) => setCoordinatorName(e.target.value)}
                    className="w-full text-xs p-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none font-bold"
                    placeholder="Nama Koordinator"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    No. WhatsApp Koordinator
                  </label>
                  <input
                    type="text"
                    value={coordinatorPhone}
                    onChange={(e) => setCoordinatorPhone(e.target.value)}
                    className="w-full text-xs p-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none font-mono"
                    placeholder="08xxxxxxxxxx"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  Anggota Tim Satgas yang Bertugas (Pisahkan koma)
                </label>
                <input
                  type="text"
                  value={selectedOfficerNames.join(', ')}
                  onChange={(e) => setSelectedOfficerNames(e.target.value.split(',').map(s => s.trim()).filter(Boolean))}
                  className="w-full text-xs p-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none font-semibold"
                  placeholder="Contoh: Ust. Syihabuddin, Kang Asep, H. Suherman"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    Supir Ambulans
                  </label>
                  <input
                    type="text"
                    value={ambulanceDriverName}
                    onChange={(e) => setAmbulanceDriverName(e.target.value)}
                    className="w-full text-xs p-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                    placeholder="Nama Supir"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    No. HP Supir
                  </label>
                  <input
                    type="text"
                    value={ambulanceDriverPhone}
                    onChange={(e) => setAmbulanceDriverPhone(e.target.value)}
                    className="w-full text-xs p-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none font-mono"
                    placeholder="08xxxxxxxxxx"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    Tim Penggali Makam TPU
                  </label>
                  <input
                    type="text"
                    value={graveDiggerName}
                    onChange={(e) => setGraveDiggerName(e.target.value)}
                    className="w-full text-xs p-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                    placeholder="Nama Kontak TPU"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    Status Piket
                  </label>
                  <select
                    value={dutyStatus}
                    onChange={(e) => setDutyStatus(e.target.value as any)}
                    className="w-full text-xs p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-bold text-slate-800 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  >
                    <option value="Siaga">Siaga (Ready)</option>
                    <option value="Bertugas">Sedang Bertugas</option>
                    <option value="Selesai">Selesai</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  Catatan / Instruksi Khusus
                </label>
                <textarea
                  rows={2}
                  value={dutyNotes}
                  onChange={(e) => setDutyNotes(e.target.value)}
                  className="w-full text-xs p-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  placeholder="Contoh: Pastikan genset dan kunci gudang keranda dibawa koordinator..."
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white text-xs font-bold rounded-xl shadow-md transition-all"
                >
                  {editingDuty ? 'Simpan Perubahan' : 'Tetapkan Jadwal Piket'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
