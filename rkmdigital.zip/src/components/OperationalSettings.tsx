import React, { useState } from 'react';
import { 
  Truck, 
  MapPin, 
  Phone, 
  Save, 
  CheckCircle2, 
  Clock, 
  ShieldCheck, 
  User, 
  Compass, 
  AlertCircle,
  Car,
  Plus,
  Trash2,
  Edit2,
  X,
  Check,
  Star,
  Activity,
  MessageSquare
} from 'lucide-react';
import { OrganizationSettings, CemeteryItem, AmbulanceFleetItem } from '../types';

interface OperationalSettingsProps {
  formState: OrganizationSettings;
  setFormState: React.Dispatch<React.SetStateAction<OrganizationSettings>>;
  onSave: () => void;
}

export const OperationalSettings: React.FC<OperationalSettingsProps> = ({
  formState,
  setFormState,
  onSave
}) => {
  const [saved, setSaved] = useState(false);

  // Modal / Form state for Cemetery TPU
  const [showAddCemetery, setShowAddCemetery] = useState(false);
  const [editingCemeteryId, setEditingCemeteryId] = useState<string | null>(null);
  const [cemeteryForm, setCemeteryForm] = useState<Partial<CemeteryItem>>({
    name: '',
    location: '',
    contactPerson: '',
    phone: '',
    notes: '',
    isPrimary: false
  });

  // Modal / Form state for Ambulance / Driver
  const [showAddFleet, setShowAddFleet] = useState(false);
  const [editingFleetId, setEditingFleetId] = useState<string | null>(null);
  const [fleetForm, setFleetForm] = useState<Partial<AmbulanceFleetItem>>({
    plateNumber: '',
    vehicleModel: '',
    driverName: '',
    driverPhone: '',
    status: 'Siaga 24 Jam',
    isPrimary: false
  });

  // Default initial lists if not present
  const cemeteryList: CemeteryItem[] = formState.cemeteryList || [
    {
      id: 'tpu-1',
      name: formState.cemeteryName || 'TPU Desa Gerowong (Makam Utama RKM)',
      location: formState.cemeteryLocation || 'Jl. Raya Salimah, Desa Gerowong, Parungpanjang, Bogor',
      contactPerson: 'Bpk. Endang (Juru Kunci / Kuncen TPU)',
      phone: '0813-8877-6655',
      isPrimary: true,
      notes: 'Makam rujukan utama warga Muslim Metro Parung Panjang'
    },
    {
      id: 'tpu-2',
      name: 'TPU Giri Mulya Parung Panjang',
      location: 'Kecamatan Parung Panjang, Kab. Bogor',
      contactPerson: 'Bpk. Saripudin (Pengelola TPU)',
      phone: '0857-1122-3344',
      isPrimary: false,
      notes: 'TPU alternatif cadangan'
    }
  ];

  const ambulanceList: AmbulanceFleetItem[] = formState.ambulanceFleetList || [
    {
      id: 'amb-1',
      plateNumber: formState.ambulancePlate || 'F 1982 MPP',
      vehicleModel: 'Suzuki APV GX Ambulans Jenazah RKM',
      driverName: formState.ambulanceDriver1?.split('(')[0]?.trim() || 'Bpk. Herman Suherman',
      driverPhone: formState.ambulanceDriver1?.match(/\((.*?)\)/)?.[1] || '0812-8822-1100',
      status: 'Siaga 24 Jam',
      isPrimary: true
    },
    {
      id: 'amb-2',
      plateNumber: 'B 2024 RKM',
      vehicleModel: 'Daihatsu Gran Max Ambulans Siaga Warga',
      driverName: formState.ambulanceDriver2?.split('(')[0]?.trim() || 'Bpk. Ruslan Effendi',
      driverPhone: formState.ambulanceDriver2?.match(/\((.*?)\)/)?.[1] || '0813-7711-2233',
      status: 'Siaga 24 Jam',
      isPrimary: false
    }
  ];

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    onSave();
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  // TPU Handlers
  const handleOpenAddCemetery = () => {
    setEditingCemeteryId(null);
    setCemeteryForm({
      name: '',
      location: '',
      contactPerson: '',
      phone: '',
      notes: '',
      isPrimary: cemeteryList.length === 0
    });
    setShowAddCemetery(true);
  };

  const handleOpenEditCemetery = (item: CemeteryItem) => {
    setEditingCemeteryId(item.id);
    setCemeteryForm({ ...item });
    setShowAddCemetery(true);
  };

  const handleSaveCemetery = (e: React.FormEvent) => {
    e.preventDefault();
    if (!cemeteryForm.name?.trim() || !cemeteryForm.location?.trim()) {
      alert('Nama dan lokasi TPU wajib diisi!');
      return;
    }

    let updated: CemeteryItem[];
    if (editingCemeteryId) {
      updated = cemeteryList.map(item => {
        if (item.id === editingCemeteryId) {
          return {
            ...item,
            ...cemeteryForm,
            name: cemeteryForm.name!.trim(),
            location: cemeteryForm.location!.trim()
          } as CemeteryItem;
        }
        return cemeteryForm.isPrimary ? { ...item, isPrimary: false } : item;
      });
    } else {
      const newItem: CemeteryItem = {
        id: `tpu-${Date.now()}`,
        name: cemeteryForm.name.trim(),
        location: cemeteryForm.location.trim(),
        contactPerson: cemeteryForm.contactPerson || '',
        phone: cemeteryForm.phone || '',
        notes: cemeteryForm.notes || '',
        isPrimary: Boolean(cemeteryForm.isPrimary) || cemeteryList.length === 0
      };
      updated = cemeteryForm.isPrimary 
        ? [...cemeteryList.map(c => ({ ...c, isPrimary: false })), newItem]
        : [...cemeteryList, newItem];
    }

    const primary = updated.find(c => c.isPrimary) || updated[0];
    setFormState({
      ...formState,
      cemeteryList: updated,
      cemeteryName: primary?.name || '',
      cemeteryLocation: primary?.location || ''
    });

    setShowAddCemetery(false);
    setEditingCemeteryId(null);
  };

  const handleDeleteCemetery = (id: string) => {
    if (cemeteryList.length <= 1) {
      alert('Minimal harus ada 1 TPU rujukan terdaftar.');
      return;
    }
    if (confirm('Hapus lokasi TPU ini dari daftar rujukan?')) {
      const updated = cemeteryList.filter(c => c.id !== id);
      if (!updated.some(c => c.isPrimary) && updated.length > 0) {
        updated[0].isPrimary = true;
      }
      const primary = updated.find(c => c.isPrimary) || updated[0];
      setFormState({
        ...formState,
        cemeteryList: updated,
        cemeteryName: primary?.name || '',
        cemeteryLocation: primary?.location || ''
      });
    }
  };

  const handleSetPrimaryCemetery = (id: string) => {
    const updated = cemeteryList.map(c => ({
      ...c,
      isPrimary: c.id === id
    }));
    const primary = updated.find(c => c.id === id);
    setFormState({
      ...formState,
      cemeteryList: updated,
      cemeteryName: primary?.name || '',
      cemeteryLocation: primary?.location || ''
    });
  };

  // Fleet Handlers
  const handleOpenAddFleet = () => {
    setEditingFleetId(null);
    setFleetForm({
      plateNumber: '',
      vehicleModel: 'Ambulans Jenazah Siaga',
      driverName: '',
      driverPhone: '',
      status: 'Siaga 24 Jam',
      isPrimary: ambulanceList.length === 0
    });
    setShowAddFleet(true);
  };

  const handleOpenEditFleet = (item: AmbulanceFleetItem) => {
    setEditingFleetId(item.id);
    setFleetForm({ ...item });
    setShowAddFleet(true);
  };

  const handleSaveFleet = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fleetForm.plateNumber?.trim() || !fleetForm.driverName?.trim()) {
      alert('Plat nomor dan nama driver wajib diisi!');
      return;
    }

    let updated: AmbulanceFleetItem[];
    if (editingFleetId) {
      updated = ambulanceList.map(item => {
        if (item.id === editingFleetId) {
          return {
            ...item,
            ...fleetForm,
            plateNumber: fleetForm.plateNumber!.trim().toUpperCase(),
            driverName: fleetForm.driverName!.trim()
          } as AmbulanceFleetItem;
        }
        return fleetForm.isPrimary ? { ...item, isPrimary: false } : item;
      });
    } else {
      const newItem: AmbulanceFleetItem = {
        id: `amb-${Date.now()}`,
        plateNumber: fleetForm.plateNumber.trim().toUpperCase(),
        vehicleModel: fleetForm.vehicleModel || 'Ambulans Jenazah Siaga',
        driverName: fleetForm.driverName.trim(),
        driverPhone: fleetForm.driverPhone || '',
        status: fleetForm.status || 'Siaga 24 Jam',
        isPrimary: Boolean(fleetForm.isPrimary) || ambulanceList.length === 0
      };
      updated = fleetForm.isPrimary 
        ? [...ambulanceList.map(a => ({ ...a, isPrimary: false })), newItem]
        : [...ambulanceList, newItem];
    }

    const primary = updated.find(a => a.isPrimary) || updated[0];
    const secondary = updated.find(a => !a.isPrimary) || updated[1];

    setFormState({
      ...formState,
      ambulanceFleetList: updated,
      ambulancePlate: primary?.plateNumber || '',
      ambulanceDriver1: primary ? `${primary.driverName} (${primary.driverPhone})` : '',
      ambulanceDriver2: secondary ? `${secondary.driverName} (${secondary.driverPhone})` : ''
    });

    setShowAddFleet(false);
    setEditingFleetId(null);
  };

  const handleDeleteFleet = (id: string) => {
    if (ambulanceList.length <= 1) {
      alert('Minimal harus ada 1 unit ambulans / driver terdaftar.');
      return;
    }
    if (confirm('Hapus armada / driver ini?')) {
      const updated = ambulanceList.filter(a => a.id !== id);
      if (!updated.some(a => a.isPrimary) && updated.length > 0) {
        updated[0].isPrimary = true;
      }
      const primary = updated.find(a => a.isPrimary) || updated[0];
      const secondary = updated.find(a => !a.isPrimary) || updated[1];
      setFormState({
        ...formState,
        ambulanceFleetList: updated,
        ambulancePlate: primary?.plateNumber || '',
        ambulanceDriver1: primary ? `${primary.driverName} (${primary.driverPhone})` : '',
        ambulanceDriver2: secondary ? `${secondary.driverName} (${secondary.driverPhone})` : ''
      });
    }
  };

  const handleSetPrimaryFleet = (id: string) => {
    const updated = ambulanceList.map(a => ({
      ...a,
      isPrimary: a.id === id
    }));
    const primary = updated.find(a => a.id === id);
    const secondary = updated.find(a => a.id !== id);
    setFormState({
      ...formState,
      ambulanceFleetList: updated,
      ambulancePlate: primary?.plateNumber || '',
      ambulanceDriver1: primary ? `${primary.driverName} (${primary.driverPhone})` : '',
      ambulanceDriver2: secondary ? `${secondary.driverName} (${secondary.driverPhone})` : ''
    });
  };

  return (
    <form onSubmit={handleSave} className="space-y-6">
      <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200 shadow-sm space-y-6">
        
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-emerald-100 text-emerald-800 rounded-2xl">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-extrabold text-base text-slate-900">
                Pengaturan Operasional Ambulans, Driver & Pemakaman TPU
              </h2>
              <p className="text-xs text-slate-500">
                Konfigurasi armada siaga 24 jam, driver penanggung jawab, dan lokasi pemakaman rujukan resmi RKM MPP.
              </p>
            </div>
          </div>

          <button
            type="submit"
            className="flex items-center justify-center gap-2 px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white font-bold text-xs rounded-xl shadow-md transition-all self-start sm:self-auto cursor-pointer"
          >
            {saved ? (
              <>
                <CheckCircle2 className="w-4 h-4 text-emerald-200" />
                <span>Tersimpan!</span>
              </>
            ) : (
              <>
                <Save className="w-4 h-4" />
                <span>Simpan Pengaturan Operasional</span>
              </>
            )}
          </button>
        </div>

        {/* Section 1: Armada Mobil Ambulans & Driver */}
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-slate-100">
            <div className="flex items-center gap-2 text-sm font-bold text-slate-800">
              <Car className="w-4 h-4 text-emerald-600" />
              <span>Daftar Armada Ambulans & Driver Siaga ({ambulanceList.length} Unit)</span>
            </div>

            <button
              type="button"
              onClick={handleOpenAddFleet}
              className="flex items-center gap-1.5 px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-xs cursor-pointer self-start sm:self-auto"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Tambah Armada / Driver</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {ambulanceList.map((fleet) => (
              <div 
                key={fleet.id}
                className={`p-4 rounded-2xl border transition-all flex flex-col justify-between ${
                  fleet.isPrimary 
                    ? 'bg-emerald-50/70 border-emerald-300 shadow-xs' 
                    : 'bg-slate-50/80 border-slate-200'
                }`}
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-sm font-black bg-slate-900 text-white px-2.5 py-1 rounded-lg">
                        {fleet.plateNumber}
                      </span>
                      {fleet.isPrimary && (
                        <span className="px-2 py-0.5 bg-emerald-600 text-white text-[10px] font-bold rounded-full flex items-center gap-1">
                          <Star className="w-3 h-3 fill-current" />
                          Utama
                        </span>
                      )}
                    </div>

                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                      fleet.status === 'Siaga 24 Jam' 
                        ? 'bg-emerald-100 text-emerald-800' 
                        : fleet.status === 'Dalam Tugas' 
                        ? 'bg-blue-100 text-blue-800' 
                        : 'bg-amber-100 text-amber-800'
                    }`}>
                      {fleet.status}
                    </span>
                  </div>

                  <div className="text-xs font-bold text-slate-800">
                    {fleet.vehicleModel}
                  </div>

                  <div className="pt-2 border-t border-slate-200/60 text-xs space-y-1">
                    <div className="flex items-center gap-1.5 text-slate-700">
                      <User className="w-3.5 h-3.5 text-slate-400" />
                      <span>Driver: <strong className="text-slate-900">{fleet.driverName}</strong></span>
                    </div>
                    {fleet.driverPhone && (
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-1.5 text-slate-600 font-mono text-[11px]">
                          <Phone className="w-3.5 h-3.5 text-emerald-600" />
                          <span>{fleet.driverPhone}</span>
                        </div>
                        <a
                          href={`https://wa.me/${fleet.driverPhone.replace(/[^0-9]/g, '')}`}
                          target="_blank"
                          rel="noreferrer"
                          className="text-[10px] text-emerald-700 hover:text-emerald-800 font-bold flex items-center gap-1 bg-white px-2 py-0.5 rounded-md border border-emerald-200"
                        >
                          <MessageSquare className="w-3 h-3" />
                          <span>Chat WA</span>
                        </a>
                      </div>
                    )}
                  </div>
                </div>

                <div className="flex items-center justify-between pt-3 mt-3 border-t border-slate-200/60 text-xs">
                  <div>
                    {!fleet.isPrimary && (
                      <button
                        type="button"
                        onClick={() => handleSetPrimaryFleet(fleet.id)}
                        className="text-[11px] text-slate-500 hover:text-emerald-700 font-semibold cursor-pointer"
                      >
                        Jadikan Utama
                      </button>
                    )}
                  </div>

                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => handleOpenEditFleet(fleet)}
                      className="p-1.5 hover:bg-slate-200/70 text-slate-600 rounded-lg transition-colors cursor-pointer"
                      title="Edit Armada"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => handleDeleteFleet(fleet.id)}
                      className="p-1.5 hover:bg-rose-100 text-rose-600 rounded-lg transition-colors cursor-pointer"
                      title="Hapus Armada"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Section 2: Tempat Pemakaman Umum (TPU) Rujukan */}
        <div className="space-y-4 pt-4 border-t border-slate-100">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-slate-100">
            <div className="flex items-center gap-2 text-sm font-bold text-slate-800">
              <MapPin className="w-4 h-4 text-emerald-600" />
              <span>Lokasi TPU Rujukan Resmi Paguyuban ({cemeteryList.length} Lokasi)</span>
            </div>

            <button
              type="button"
              onClick={handleOpenAddCemetery}
              className="flex items-center gap-1.5 px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-xs cursor-pointer self-start sm:self-auto"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Tambah Lokasi TPU</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {cemeteryList.map((cemetery) => (
              <div 
                key={cemetery.id}
                className={`p-4 rounded-2xl border transition-all flex flex-col justify-between ${
                  cemetery.isPrimary 
                    ? 'bg-teal-50/70 border-teal-300 shadow-xs' 
                    : 'bg-slate-50/80 border-slate-200'
                }`}
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-extrabold text-xs text-slate-900 flex items-center gap-1.5">
                      <MapPin className="w-3.5 h-3.5 text-teal-600" />
                      {cemetery.name}
                    </span>
                    {cemetery.isPrimary ? (
                      <span className="px-2 py-0.5 bg-teal-600 text-white text-[10px] font-bold rounded-full flex items-center gap-1">
                        <Star className="w-3 h-3 fill-current" />
                        Rujukan Utama
                      </span>
                    ) : (
                      <span className="text-[10px] text-slate-400 font-semibold">Alternatif</span>
                    )}
                  </div>

                  <p className="text-xs text-slate-600">
                    {cemetery.location}
                  </p>

                  {(cemetery.contactPerson || cemetery.phone) && (
                    <div className="pt-2 border-t border-slate-200/60 text-[11px] space-y-1 text-slate-600">
                      {cemetery.contactPerson && (
                        <div>Kontak / Kuncen: <strong className="text-slate-800">{cemetery.contactPerson}</strong></div>
                      )}
                      {cemetery.phone && (
                        <div className="font-mono font-bold text-teal-800">{cemetery.phone}</div>
                      )}
                    </div>
                  )}
                </div>

                <div className="flex items-center justify-between pt-3 mt-3 border-t border-slate-200/60 text-xs">
                  <div>
                    {!cemetery.isPrimary && (
                      <button
                        type="button"
                        onClick={() => handleSetPrimaryCemetery(cemetery.id)}
                        className="text-[11px] text-slate-500 hover:text-teal-700 font-semibold cursor-pointer"
                      >
                        Jadikan Rujukan Utama
                      </button>
                    )}
                  </div>

                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => handleOpenEditCemetery(cemetery)}
                      className="p-1.5 hover:bg-slate-200/70 text-slate-600 rounded-lg transition-colors cursor-pointer"
                      title="Edit TPU"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => handleDeleteCemetery(cemetery.id)}
                      className="p-1.5 hover:bg-rose-100 text-rose-600 rounded-lg transition-colors cursor-pointer"
                      title="Hapus TPU"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Section 3: Standar Pelayanan & SOP Siaga 24 Jam */}
        <div className="p-4 bg-emerald-50/60 rounded-2xl border border-emerald-100 space-y-3">
          <div className="flex items-center gap-2 text-xs font-bold text-emerald-950">
            <Clock className="w-4 h-4 text-emerald-600" />
            <span>Ketentuan Standar Respons Tim Satgas (Sesuai AD/ART):</span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-[11px] text-emerald-900">
            <div className="p-3 bg-white rounded-xl border border-emerald-200/80">
              <span className="font-bold block text-emerald-800 mb-0.5">⏱ Respon Laporan:</span>
              <span>Maksimal 15 menit setelah laporan diterima via Call Center / WhatsApp.</span>
            </div>
            <div className="p-3 bg-white rounded-xl border border-emerald-200/80">
              <span className="font-bold block text-emerald-800 mb-0.5">🚐 Armada Ambulans:</span>
              <span>Siaga 24 jam bebas biaya khusus wilayah Parung Panjang dan sekitarnya.</span>
            </div>
            <div className="p-3 bg-white rounded-xl border border-emerald-200/80">
              <span className="font-bold block text-emerald-800 mb-0.5">⚰️ Paket Fardhu Kifayah:</span>
              <span>Kain kafan, tim pemandian ikhwan/akhwat, imam salat, dan gali liang lahat.</span>
            </div>
          </div>
        </div>

      </div>

      {/* Cemetery Modal Form */}
      {showAddCemetery && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-xs flex items-center justify-center z-50 p-4 animate-fade-in">
          <div className="bg-white rounded-3xl p-6 max-w-lg w-full border border-slate-200 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <MapPin className="w-4 h-4 text-emerald-600" />
                <h3 className="font-extrabold text-sm text-slate-900">
                  {editingCemeteryId ? 'Edit Data TPU' : 'Tambah Lokasi TPU Rujukan Baru'}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setShowAddCemetery(false)}
                className="p-1.5 hover:bg-slate-100 text-slate-400 hover:text-slate-600 rounded-lg"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-700 block mb-1">Nama TPU Rujukan:</label>
                <input
                  type="text"
                  value={cemeteryForm.name || ''}
                  onChange={(e) => setCemeteryForm({ ...cemeteryForm, name: e.target.value })}
                  placeholder="Contoh: TPU Desa Gerowong / TPU Giri Mulya"
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-bold text-slate-900 focus:bg-white focus:ring-2 focus:ring-emerald-500"
                  required
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Alamat Lengkap / Lokasi:</label>
                <input
                  type="text"
                  value={cemeteryForm.location || ''}
                  onChange={(e) => setCemeteryForm({ ...cemeteryForm, location: e.target.value })}
                  placeholder="Jl. Raya Salimah, Gerowong, Parungpanjang, Bogor"
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl text-slate-900 focus:bg-white focus:ring-2 focus:ring-emerald-500"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Nama Kontak / Kuncen:</label>
                  <input
                    type="text"
                    value={cemeteryForm.contactPerson || ''}
                    onChange={(e) => setCemeteryForm({ ...cemeteryForm, contactPerson: e.target.value })}
                    placeholder="Bpk. Endang"
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl text-slate-900"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">No. HP / WA Kontak:</label>
                  <input
                    type="text"
                    value={cemeteryForm.phone || ''}
                    onChange={(e) => setCemeteryForm({ ...cemeteryForm, phone: e.target.value })}
                    placeholder="0812-3456-7890"
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-mono text-slate-900"
                  />
                </div>
              </div>

              <div className="flex items-center gap-2 pt-1">
                <input
                  type="checkbox"
                  id="cemeteryPrimaryCheck"
                  checked={Boolean(cemeteryForm.isPrimary)}
                  onChange={(e) => setCemeteryForm({ ...cemeteryForm, isPrimary: e.target.checked })}
                  className="rounded text-emerald-600 focus:ring-emerald-500"
                />
                <label htmlFor="cemeteryPrimaryCheck" className="text-xs font-bold text-slate-800 cursor-pointer">
                  Jadikan sebagai TPU Rujukan Utama
                </label>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setShowAddCemetery(false)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleSaveCemetery}
                className="flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white text-xs font-bold rounded-xl shadow-xs"
              >
                <Check className="w-3.5 h-3.5" />
                <span>Simpan TPU</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Fleet Modal Form */}
      {showAddFleet && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-xs flex items-center justify-center z-50 p-4 animate-fade-in">
          <div className="bg-white rounded-3xl p-6 max-w-lg w-full border border-slate-200 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Car className="w-4 h-4 text-emerald-600" />
                <h3 className="font-extrabold text-sm text-slate-900">
                  {editingFleetId ? 'Edit Armada Ambulans & Driver' : 'Tambah Unit Ambulans / Driver Baru'}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setShowAddFleet(false)}
                className="p-1.5 hover:bg-slate-100 text-slate-400 hover:text-slate-600 rounded-lg"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Nomor Polisi (Plat Nomor):</label>
                  <input
                    type="text"
                    value={fleetForm.plateNumber || ''}
                    onChange={(e) => setFleetForm({ ...fleetForm, plateNumber: e.target.value.toUpperCase() })}
                    placeholder="Contoh: F 1982 MPP"
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-mono font-bold text-slate-900 focus:bg-white focus:ring-2 focus:ring-emerald-500"
                    required
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Status Kesiapan:</label>
                  <select
                    value={fleetForm.status || 'Siaga 24 Jam'}
                    onChange={(e) => setFleetForm({ ...fleetForm, status: e.target.value as any })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-bold text-slate-800"
                  >
                    <option value="Siaga 24 Jam">Siaga 24 Jam</option>
                    <option value="Dalam Tugas">Dalam Tugas</option>
                    <option value="Perawatan / Servis">Perawatan / Servis</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Tipe / Model Kendaraan:</label>
                <input
                  type="text"
                  value={fleetForm.vehicleModel || ''}
                  onChange={(e) => setFleetForm({ ...fleetForm, vehicleModel: e.target.value })}
                  placeholder="Suzuki APV GX Ambulans Jenazah"
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl text-slate-900 focus:bg-white focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Nama Driver Penanggung Jawab:</label>
                  <input
                    type="text"
                    value={fleetForm.driverName || ''}
                    onChange={(e) => setFleetForm({ ...fleetForm, driverName: e.target.value })}
                    placeholder="Bpk. Herman Suherman"
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-bold text-slate-900"
                    required
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">No. HP / WA Driver Siaga:</label>
                  <input
                    type="text"
                    value={fleetForm.driverPhone || ''}
                    onChange={(e) => setFleetForm({ ...fleetForm, driverPhone: e.target.value })}
                    placeholder="0812-8822-1100"
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-mono text-slate-900"
                  />
                </div>
              </div>

              <div className="flex items-center gap-2 pt-1">
                <input
                  type="checkbox"
                  id="fleetPrimaryCheck"
                  checked={Boolean(fleetForm.isPrimary)}
                  onChange={(e) => setFleetForm({ ...fleetForm, isPrimary: e.target.checked })}
                  className="rounded text-emerald-600 focus:ring-emerald-500"
                />
                <label htmlFor="fleetPrimaryCheck" className="text-xs font-bold text-slate-800 cursor-pointer">
                  Jadikan sebagai Armada / Driver Utama
                </label>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setShowAddFleet(false)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleSaveFleet}
                className="flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white text-xs font-bold rounded-xl shadow-xs"
              >
                <Check className="w-3.5 h-3.5" />
                <span>Simpan Armada</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </form>
  );
};
