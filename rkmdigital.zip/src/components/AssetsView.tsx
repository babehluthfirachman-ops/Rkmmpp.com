import React, { useState } from 'react';
import { 
  Box, 
  Plus, 
  Search, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  ShieldCheck, 
  Printer, 
  Archive, 
  ArrowRight,
  Truck,
  Layers,
  Sparkles
} from 'lucide-react';
import { useRkm } from '../context/RkmContext';
import { Asset, AssetLoan } from '../types';

export const AssetsView: React.FC = () => {
  const { 
    assets, 
    assetLoans, 
    addAsset, 
    borrowAsset, 
    returnAsset, 
    citizens, 
    currentRole 
  } = useRkm();

  const [activeTab, setActiveTab] = useState<'inventory' | 'loans'>('inventory');
  const [searchQuery, setSearchQuery] = useState('');
  const [showAddAssetModal, setShowAddAssetModal] = useState(false);
  const [showBorrowModal, setShowBorrowModal] = useState(false);

  // Add Asset Form
  const [assetName, setAssetName] = useState('');
  const [assetCategory, setAssetCategory] = useState<any>('Logistik');
  const [assetQty, setAssetQty] = useState<number | ''>(1);
  const [assetUnit, setAssetUnit] = useState('Unit');
  const [assetCondition, setAssetCondition] = useState<any>('Baik');
  const [assetLocation, setAssetLocation] = useState('Gudang Masjid Metro Parung Panjang');

  // Borrow Form
  const [borrowAssetId, setBorrowAssetId] = useState<string>(assets[0]?.id || '');
  const [borrowQty, setBorrowQty] = useState<number>(1);
  const [borrowCitizenName, setBorrowCitizenName] = useState(citizens[0]?.headOfFamily || '');
  const [borrowPhone, setBorrowPhone] = useState(citizens[0]?.phone || '');
  const [borrowPurpose, setBorrowPurpose] = useState('Keperluan Takziah & Pemakaman');
  const [borrowExpectedReturn, setBorrowExpectedReturn] = useState(new Date(Date.now() + 86400000 * 2).toISOString().split('T')[0]);

  // Filter assets
  const filteredAssets = assets.filter(a => 
    a.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    a.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
    a.location.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleAddAssetSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!assetName.trim()) return;

    addAsset({
      name: assetName,
      category: assetCategory,
      totalQuantity: Number(assetQty) || 1,
      availableQuantity: Number(assetQty) || 1,
      unit: assetUnit,
      condition: assetCondition,
      location: assetLocation
    });

    setAssetName('');
    setShowAddAssetModal(false);
  };

  const handleBorrowSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const asset = assets.find(a => a.id === borrowAssetId);
    if (!asset || borrowQty > asset.availableQuantity) {
      alert('Stok barang tidak mencukupi untuk dipinjam.');
      return;
    }

    borrowAsset({
      assetId: asset.id,
      assetName: asset.name,
      borrowerName: borrowCitizenName,
      borrowerPhone: borrowPhone,
      borrowerNoKK: citizens.find(c => c.headOfFamily === borrowCitizenName)?.noKK || '3273010000000000',
      quantity: borrowQty,
      borrowDate: new Date().toISOString().split('T')[0],
      expectedReturnDate: borrowExpectedReturn,
      status: 'Dipinjam',
      purpose: borrowPurpose
    });

    setShowBorrowModal(false);
  };

  return (
    <div className="space-y-6 pb-12 animate-fade-in">
      
      {/* Header & Tabs */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 bg-indigo-100 text-indigo-700 rounded-xl">
              <Box className="w-5 h-5" />
            </span>
            <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900">Inventaris Aset & Peminjaman Alat</h1>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Pengelolaan stok kain kafan, keranda jenazah, tenda, kursi, dan monitoring peminjaman warga.
          </p>
        </div>

        {/* Tab Buttons & Action */}
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center bg-slate-100 p-1.5 rounded-2xl border border-slate-200">
            <button
              onClick={() => setActiveTab('inventory')}
              className={`px-4 py-2 text-xs font-bold rounded-xl transition-all ${
                activeTab === 'inventory' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Daftar Barang & Stok ({assets.length})
            </button>
            <button
              onClick={() => setActiveTab('loans')}
              className={`px-4 py-2 text-xs font-bold rounded-xl transition-all ${
                activeTab === 'loans' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Riwayat Peminjaman ({assetLoans.filter(l => l.status === 'Dipinjam').length} Aktif)
            </button>
          </div>

          {currentRole !== 'warga' && (
            <div className="flex gap-2">
              <button
                onClick={() => setShowBorrowModal(true)}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow transition-all"
              >
                + Pinjamkan Alat
              </button>
              <button
                onClick={() => setShowAddAssetModal(true)}
                className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-xl shadow transition-all"
              >
                + Barang Baru
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Main Tab Content */}
      {activeTab === 'inventory' ? (
        <div className="space-y-4">
          
          {/* Search bar */}
          <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-sm flex items-center justify-between gap-3">
            <div className="relative flex-1 max-w-md">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Cari barang / kain kafan / keranda / tenda..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-none"
              />
            </div>
            
            <button
              onClick={() => window.print()}
              className="flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold"
            >
              <Printer className="w-4 h-4" />
              <span>Cetak Stok</span>
            </button>
          </div>

          {/* Asset Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredAssets.map((asset) => {
              const isAvailable = asset.availableQuantity > 0;
              return (
                <div
                  key={asset.id}
                  className="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-sm hover:shadow-md transition-all flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-start justify-between gap-2">
                      <span className="text-[10px] font-bold px-2 py-0.5 bg-indigo-50 text-indigo-700 rounded-md">
                        {asset.category}
                      </span>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        asset.condition === 'Baik' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                      }`}>
                        Kondisi: {asset.condition}
                      </span>
                    </div>

                    <h3 className="font-extrabold text-base text-slate-900 mt-2">
                      {asset.name}
                    </h3>
                    <p className="text-xs text-slate-500 mt-0.5">
                      📍 {asset.location}
                    </p>
                  </div>

                  <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
                    <div>
                      <span className="text-[10px] text-slate-400 font-bold block uppercase">Ketersediaan Stok</span>
                      <div className="text-sm font-black text-slate-900 font-mono">
                        <span className={isAvailable ? 'text-emerald-700 font-bold' : 'text-rose-600'}>
                          {asset.availableQuantity}
                        </span> / {asset.totalQuantity} {asset.unit}
                      </div>
                    </div>

                    {isAvailable ? (
                      <button
                        onClick={() => {
                          setBorrowAssetId(asset.id);
                          setShowBorrowModal(true);
                        }}
                        className="px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold text-xs rounded-xl transition-colors"
                      >
                        Pinjamkan
                      </button>
                    ) : (
                      <span className="text-xs font-bold text-rose-600 bg-rose-50 px-2.5 py-1 rounded-lg">
                        Sedang Dipinjam Semua
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

        </div>
      ) : (
        /* Loans Table */
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="bg-slate-900 text-white font-bold">
                  <th className="p-3.5">Nama Peminjam / KK</th>
                  <th className="p-3.5">Barang & Jumlah</th>
                  <th className="p-3.5">Tanggal Pinjam</th>
                  <th className="p-3.5">Tenggat Kembali</th>
                  <th className="p-3.5">Keperluan</th>
                  <th className="p-3.5">Status</th>
                  <th className="p-3.5 text-center">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {assetLoans.map((loan) => {
                  const isBorrowed = loan.status === 'Dipinjam';
                  return (
                    <tr key={loan.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="p-3.5 font-bold text-slate-900">
                        {loan.borrowerName}
                        <div className="text-[10px] text-slate-500 font-normal">📞 {loan.borrowerPhone}</div>
                      </td>
                      <td className="p-3.5 font-semibold text-indigo-950">
                        {loan.assetName} ({loan.quantity} Unit)
                      </td>
                      <td className="p-3.5 text-slate-600">{loan.borrowDate}</td>
                      <td className="p-3.5 text-slate-600">{loan.expectedReturnDate}</td>
                      <td className="p-3.5 text-slate-600 max-w-xs truncate">{loan.purpose}</td>
                      <td className="p-3.5">
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                          isBorrowed ? 'bg-amber-100 text-amber-800' : 'bg-emerald-100 text-emerald-800'
                        }`}>
                          {loan.status}
                        </span>
                      </td>
                      <td className="p-3.5 text-center">
                        {isBorrowed && currentRole !== 'warga' && (
                          <button
                            onClick={() => returnAsset(loan.id)}
                            className="px-3 py-1 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-lg shadow-sm transition-all"
                          >
                            Tandai Kembali
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Add Asset Modal */}
      {showAddAssetModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-sm animate-fade-in">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full shadow-2xl border border-slate-100">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="font-extrabold text-base text-slate-900">
                Tambah Barang / Aset Paguyuban
              </h3>
              <button
                onClick={() => setShowAddAssetModal(false)}
                className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleAddAssetSubmit} className="mt-4 space-y-3 text-xs">
              <div>
                <label className="text-slate-700 font-bold block mb-1">Nama Barang / Fasilitas:</label>
                <input
                  type="text"
                  placeholder="Contoh: Lampu Sorot Emergency"
                  value={assetName}
                  onChange={(e) => setAssetName(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-bold"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-700 font-bold block mb-1">Kategori:</label>
                  <select
                    value={assetCategory}
                    onChange={(e) => setAssetCategory(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-semibold"
                  >
                    <option value="Pemulasaraan">Pemulasaraan</option>
                    <option value="Tenda & Kursi">Tenda & Kursi</option>
                    <option value="Kendaraan">Kendaraan</option>
                    <option value="Sound System">Sound System</option>
                    <option value="Logistik">Logistik</option>
                  </select>
                </div>

                <div>
                  <label className="text-slate-700 font-bold block mb-1">Kondisi:</label>
                  <select
                    value={assetCondition}
                    onChange={(e) => setAssetCondition(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-semibold"
                  >
                    <option value="Baik">Baik</option>
                    <option value="Perlu Perbaikan">Perlu Perbaikan</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-700 font-bold block mb-1">Jumlah Unit:</label>
                  <input
                    type="number"
                    value={assetQty}
                    onChange={(e) => setAssetQty(Number(e.target.value) || '')}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-mono font-bold"
                    required
                  />
                </div>

                <div>
                  <label className="text-slate-700 font-bold block mb-1">Satuan:</label>
                  <input
                    type="text"
                    placeholder="Unit / Buah / Set"
                    value={assetUnit}
                    onChange={(e) => setAssetUnit(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl"
                  />
                </div>
              </div>

              <div>
                <label className="text-slate-700 font-bold block mb-1">Lokasi Penyimpanan:</label>
                <input
                  type="text"
                  placeholder="Gudang RT 02 / Pos Kamling"
                  value={assetLocation}
                  onChange={(e) => setAssetLocation(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl"
                  required
                />
              </div>

              <div className="pt-3 border-t border-slate-100 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddAssetModal(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl shadow"
                >
                  Simpan Barang
                </button>
              </div>
            </form>

          </div>
        </div>
      )}

      {/* Borrow Asset Modal */}
      {showBorrowModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-sm animate-fade-in">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full shadow-2xl border border-slate-100">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="font-extrabold text-base text-slate-900">
                Formulir Peminjaman Alat Paguyuban
              </h3>
              <button
                onClick={() => setShowBorrowModal(false)}
                className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleBorrowSubmit} className="mt-4 space-y-3 text-xs">
              <div>
                <label className="text-slate-700 font-bold block mb-1">Pilih Barang:</label>
                <select
                  value={borrowAssetId}
                  onChange={(e) => setBorrowAssetId(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-bold"
                >
                  {assets.filter(a => a.availableQuantity > 0).map(a => (
                    <option key={a.id} value={a.id}>
                      {a.name} (Tersedia: {a.availableQuantity} {a.unit})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-slate-700 font-bold block mb-1">Jumlah yang Dipinjam:</label>
                <input
                  type="number"
                  min="1"
                  value={borrowQty}
                  onChange={(e) => setBorrowQty(Number(e.target.value) || 1)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-mono font-bold"
                  required
                />
              </div>

              <div>
                <label className="text-slate-700 font-bold block mb-1">Nama Peminjam / Kepala Keluarga:</label>
                <input
                  type="text"
                  placeholder="Nama warga peminjam"
                  value={borrowCitizenName}
                  onChange={(e) => setBorrowCitizenName(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-semibold"
                  required
                />
              </div>

              <div>
                <label className="text-slate-700 font-bold block mb-1">No. Handphone Peminjam:</label>
                <input
                  type="text"
                  placeholder="08123456789"
                  value={borrowPhone}
                  onChange={(e) => setBorrowPhone(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl"
                  required
                />
              </div>

              <div>
                <label className="text-slate-700 font-bold block mb-1">Perkiraan Tanggal Pengembalian:</label>
                <input
                  type="date"
                  value={borrowExpectedReturn}
                  onChange={(e) => setBorrowExpectedReturn(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl font-semibold"
                  required
                />
              </div>

              <div>
                <label className="text-slate-700 font-bold block mb-1">Keperluan Peminjaman:</label>
                <input
                  type="text"
                  placeholder="Contoh: Takziah keluarga di RT 03"
                  value={borrowPurpose}
                  onChange={(e) => setBorrowPurpose(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl"
                  required
                />
              </div>

              <div className="pt-3 border-t border-slate-100 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowBorrowModal(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl shadow"
                >
                  Konfirmasi Pinjam
                </button>
              </div>
            </form>

          </div>
        </div>
      )}

    </div>
  );
};
