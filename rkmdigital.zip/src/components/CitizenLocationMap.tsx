import React, { useState, useMemo, useEffect } from 'react';
import { 
  MapPin, 
  Navigation, 
  ExternalLink, 
  Copy, 
  Check, 
  Compass, 
  Edit3, 
  Save, 
  X, 
  Home, 
  Info,
  Car
} from 'lucide-react';
import { Citizen } from '../types';
import { useRkm } from '../context/RkmContext';

interface CitizenLocationMapProps {
  citizen: Citizen;
  onNotify?: (msg: string) => void;
  compact?: boolean;
}

// Center of Perumahan Metro Parung Panjang, Bogor
const BASE_LAT = -6.345812;
const BASE_LNG = 106.576523;

// Map block offsets for Metro Parung Panjang layout
const getBlockOffset = (block?: string): { latOffset: number; lngOffset: number } => {
  if (!block) return { latOffset: 0, lngOffset: 0 };
  const clean = block.toUpperCase().replace('BLOK', '').trim();
  const code = clean.charCodeAt(0) - 65; // A = 0, B = 1, etc.
  if (isNaN(code) || code < 0) return { latOffset: 0, lngOffset: 0 };
  
  // Distribute blocks across grid
  const row = Math.floor(code / 4);
  const col = code % 4;
  return {
    latOffset: (row * 0.00045) - 0.0009,
    lngOffset: (col * 0.00055) - 0.0008
  };
};

export const CitizenLocationMap: React.FC<CitizenLocationMapProps> = ({ 
  citizen, 
  onNotify,
  compact = false 
}) => {
  const { updateCitizen, currentRole } = useRkm();
  const canEdit = ['superadmin', 'ketua', 'bendahara', 'petugas'].includes(currentRole);

  // Compute active coordinates
  const defaultCoords = useMemo(() => {
    if (citizen.coordinates && typeof citizen.coordinates.lat === 'number') {
      return citizen.coordinates;
    }
    const offset = getBlockOffset(citizen.block);
    const houseNum = parseInt(citizen.houseNumber?.replace(/\D/g, '') || '1', 10);
    const numOffset = (houseNum % 20) * 0.00002;
    return {
      lat: BASE_LAT + offset.latOffset + numOffset,
      lng: BASE_LNG + offset.lngOffset + numOffset
    };
  }, [citizen]);

  const [copied, setCopied] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [editLat, setEditLat] = useState(defaultCoords.lat.toString());
  const [editLng, setEditLng] = useState(defaultCoords.lng.toString());

  useEffect(() => {
    setEditLat(defaultCoords.lat.toString());
    setEditLng(defaultCoords.lng.toString());
  }, [defaultCoords.lat, defaultCoords.lng]);

  const handleCopyCoords = () => {
    const coordStr = `${defaultCoords.lat.toFixed(6)}, ${defaultCoords.lng.toFixed(6)}`;
    navigator.clipboard.writeText(coordStr);
    setCopied(true);
    if (onNotify) onNotify(`Titik koordinat GPS [${coordStr}] berhasil disalin!`);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSaveCoords = (e: React.FormEvent) => {
    e.preventDefault();
    const lat = parseFloat(editLat);
    const lng = parseFloat(editLng);
    if (isNaN(lat) || isNaN(lng)) return;

    updateCitizen(citizen.id, {
      coordinates: { lat, lng }
    });
    setIsEditing(false);
    if (onNotify) onNotify('Titik koordinat rumah warga berhasil diperbarui!');
  };

  const openGoogleMaps = () => {
    const url = `https://www.google.com/maps/search/?api=1&query=${defaultCoords.lat},${defaultCoords.lng}`;
    window.open(url, '_blank');
  };

  const openWaze = () => {
    const url = `https://waze.com/ul?ll=${defaultCoords.lat},${defaultCoords.lng}&navigate=yes`;
    window.open(url, '_blank');
  };

  // OpenStreetMap embed URL with bbox around coords
  const bboxDelta = 0.0025;
  const osmUrl = `https://www.openstreetmap.org/export/embed.html?bbox=${defaultCoords.lng - bboxDelta}%2C${defaultCoords.lat - bboxDelta}%2C${defaultCoords.lng + bboxDelta}%2C${defaultCoords.lat + bboxDelta}&layer=mapnik&marker=${defaultCoords.lat}%2C${defaultCoords.lng}`;

  return (
    <div className="bg-slate-50 border border-slate-200/90 rounded-3xl p-4 sm:p-5 shadow-sm space-y-4">
      {/* Header Info */}
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <span className="p-2 bg-emerald-100 text-emerald-800 rounded-xl">
            <MapPin className="w-5 h-5 text-emerald-700" />
          </span>
          <div>
            <h4 className="text-sm font-black text-slate-900 flex items-center gap-1.5">
              <span>Koordinasi Lokasi Rumah Warga</span>
              <span className="text-[10px] font-bold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full">
                {citizen.block || 'Metro Parung Panjang'}
              </span>
            </h4>
            <p className="text-xs text-slate-500">
              {citizen.address} • RT {citizen.rt} / RW {citizen.rw}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          {canEdit && !isEditing && (
            <button
              onClick={() => {
                setEditLat(defaultCoords.lat.toString());
                setEditLng(defaultCoords.lng.toString());
                setIsEditing(true);
              }}
              className="p-1.5 text-slate-500 hover:text-emerald-700 hover:bg-white rounded-lg transition-colors cursor-pointer"
              title="Kalibrasi Koordinat GPS"
            >
              <Edit3 className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Editing Form */}
      {isEditing && (
        <form onSubmit={handleSaveCoords} className="bg-white p-3.5 rounded-2xl border border-emerald-300 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-emerald-900">Atur Titik Koordinat Presisi (Lat, Lng)</span>
            <button
              type="button"
              onClick={() => setIsEditing(false)}
              className="p-1 text-slate-400 hover:text-slate-600 rounded-md"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-[10px] font-bold text-slate-500 block">Latitude</label>
              <input
                type="text"
                value={editLat}
                onChange={(e) => setEditLat(e.target.value)}
                className="w-full text-xs p-2 bg-slate-50 border border-slate-300 rounded-lg font-mono"
              />
            </div>
            <div>
              <label className="text-[10px] font-bold text-slate-500 block">Longitude</label>
              <input
                type="text"
                value={editLng}
                onChange={(e) => setEditLng(e.target.value)}
                className="w-full text-xs p-2 bg-slate-50 border border-slate-300 rounded-lg font-mono"
              />
            </div>
          </div>
          <div className="flex justify-end gap-2 pt-1">
            <button
              type="button"
              onClick={() => setIsEditing(false)}
              className="px-3 py-1.5 bg-slate-100 text-slate-700 text-xs font-bold rounded-lg"
            >
              Batal
            </button>
            <button
              type="submit"
              className="px-3.5 py-1.5 bg-emerald-600 text-white text-xs font-bold rounded-lg shadow-sm flex items-center gap-1"
            >
              <Save className="w-3.5 h-3.5" />
              Simpan Titik
            </button>
          </div>
        </form>
      )}

      {/* Embedded Map Container */}
      <div className="relative rounded-2xl overflow-hidden border border-slate-200 shadow-inner bg-slate-200">
        <iframe
          title={`Peta Lokasi ${citizen.headOfFamily}`}
          width="100%"
          height={compact ? "180" : "240"}
          frameBorder="0"
          scrolling="no"
          marginHeight={0}
          marginWidth={0}
          src={osmUrl}
          className="w-full"
        />

        {/* Floating Pin Label */}
        <div className="absolute top-2 left-2 bg-white/95 backdrop-blur-xs px-2.5 py-1 rounded-xl shadow-md border border-slate-200/80 flex items-center gap-1.5 pointer-events-none">
          <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />
          <span className="text-[11px] font-black text-slate-800">
            Rumah Bpk/Ibu {citizen.headOfFamily}
          </span>
        </div>
      </div>

      {/* Quick Navigation & Access Bar */}
      <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
        <div className="flex items-center gap-1.5 text-[11px] font-mono text-slate-600 bg-white px-3 py-1.5 rounded-xl border border-slate-200">
          <Compass className="w-3.5 h-3.5 text-emerald-600" />
          <span>{defaultCoords.lat.toFixed(6)}, {defaultCoords.lng.toFixed(6)}</span>
          <button
            onClick={handleCopyCoords}
            className="ml-1 p-1 hover:bg-slate-100 rounded-md text-slate-500 hover:text-emerald-700 transition-colors"
            title="Salin Koordinat GPS"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
          </button>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={openGoogleMaps}
            className="flex items-center gap-1 px-3 py-1.5 bg-blue-600 hover:bg-blue-700 active:scale-95 text-white text-xs font-bold rounded-xl shadow-xs transition-all cursor-pointer"
            title="Buka Navigasi Rute di Google Maps"
          >
            <Navigation className="w-3.5 h-3.5" />
            <span>Google Maps</span>
            <ExternalLink className="w-3 h-3 ml-0.5 opacity-80" />
          </button>

          <button
            onClick={openWaze}
            className="flex items-center gap-1 px-3 py-1.5 bg-cyan-600 hover:bg-cyan-700 active:scale-95 text-white text-xs font-bold rounded-xl shadow-xs transition-all cursor-pointer"
            title="Buka di Waze"
          >
            <Car className="w-3.5 h-3.5" />
            <span>Waze</span>
          </button>
        </div>
      </div>

      {/* Takziah / Death Service Access Guidance */}
      <div className="p-3 bg-emerald-50/70 border border-emerald-200/80 rounded-2xl text-xs text-emerald-950 flex items-start gap-2.5">
        <Info className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
        <div>
          <span className="font-bold block">Petunjuk Akses Tim Takziah & Ambulans:</span>
          <p className="text-[11px] text-emerald-900 mt-0.5">
            Masuk melalui Gerbang Utama Perumahan Metro Parung Panjang, akses menuju {citizen.block ? `wilayah ${citizen.block}` : 'blok warga'}, RT {citizen.rt} / RW {citizen.rw}. Hubungi penanggung jawab di {citizen.phone || 'kontak warga'} sebelum meluncur.
          </p>
        </div>
      </div>
    </div>
  );
};
