import React from 'react';
import { 
  Users, 
  CreditCard, 
  HeartHandshake, 
  BookOpen, 
  FileSpreadsheet, 
  Package, 
  ScrollText, 
  Settings, 
  History,
  ChevronLeft, 
  ChevronRight, 
  ShieldCheck, 
  LogOut,
  LogIn,
  Home,
  Sun,
  Moon
} from 'lucide-react';
import { useRkm } from '../context/RkmContext';
import { isSuperAdmin, getAvatarUrl, getDirectImageUrl } from '../utils/formatters';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  isCollapsed: boolean;
  setIsCollapsed: (collapsed: boolean) => void;
  mobileOpen: boolean;
  setMobileOpen: (open: boolean) => void;
  onOpenFourMonthReport?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  setActiveTab,
  isCollapsed,
  setIsCollapsed,
  mobileOpen,
  setMobileOpen,
  onOpenFourMonthReport
}) => {
  const { currentUser, currentRole, deathNotices, logout, settings, theme, toggleTheme } = useRkm();
  const userIsSuperAdmin = isSuperAdmin(currentUser);

  const activeDeathsCount = deathNotices.filter(d => d.status === 'Aktif').length;

  const navigationItems = [
    { id: 'beranda', label: 'Beranda & Info Publik', icon: Home, badge: 'Portal', badgeColor: 'bg-emerald-500/20 text-emerald-300', roles: ['superadmin', 'bendahara', 'koordinator', 'tim_jenazah', 'warga', 'ketua', 'petugas'] },
    { id: 'warga', label: 'Data Master Warga (KK)', icon: Users, badge: null, roles: ['superadmin', 'bendahara', 'koordinator', 'ketua', 'petugas', 'warga'] },
    { id: 'iuran', label: 'Kasir & Setoran Iuran', icon: CreditCard, badge: null, roles: ['superadmin', 'bendahara', 'koordinator', 'ketua', 'petugas', 'warga'] },
    { id: 'layanan-duka', label: 'Pelayanan Duka Cita', icon: HeartHandshake, badge: activeDeathsCount > 0 ? `${activeDeathsCount} Siaga` : null, badgeColor: 'bg-rose-500 text-white', roles: ['superadmin', 'bendahara', 'koordinator', 'tim_jenazah', 'ketua', 'petugas', 'warga'] },
    { id: 'buku-kas', label: 'Buku Kas & Keuangan', icon: BookOpen, badge: null, roles: ['superadmin', 'bendahara', 'ketua'] },
    { id: 'laporan-4-bulan', label: 'Laporan 4-Bulanan ART', icon: FileSpreadsheet, badge: 'ART', badgeColor: 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30', roles: ['superadmin', 'bendahara', 'ketua', 'koordinator', 'petugas'] },
    { id: 'inventaris', label: 'Logistik & Aset RKM', icon: Package, badge: null, roles: ['superadmin', 'bendahara', 'tim_jenazah', 'koordinator', 'ketua', 'petugas'] },
    { id: 'ad-art', label: 'Dokumen AD/ART 2024–2027', icon: ScrollText, badge: null, roles: ['superadmin', 'bendahara', 'koordinator', 'tim_jenazah', 'warga', 'ketua', 'petugas'] },
    { id: 'activity-log', label: 'Activity Log (Audit)', icon: History, badge: 'Audit', badgeColor: 'bg-indigo-500/20 text-indigo-300', roles: ['superadmin'] },
    { id: 'pengaturan', label: 'Pengaturan Sistem', icon: Settings, badge: 'Super Admin', badgeColor: 'bg-amber-500/20 text-amber-300', roles: ['superadmin'] },
  ];

  const allowedNavs = navigationItems.filter(item => {
    if (userIsSuperAdmin) return true;
    return item.roles.includes(currentRole);
  });

  const handleNavClick = (id: string) => {
    if (id === 'laporan-4-bulan') {
      if (onOpenFourMonthReport) {
        onOpenFourMonthReport();
      } else {
        setActiveTab('buku-kas');
      }
    } else {
      setActiveTab(id);
    }
    setMobileOpen(false);
  };

  return (
    <>
      {/* Mobile Backdrop */}
      {mobileOpen && (
        <div 
          onClick={() => setMobileOpen(false)}
          className="fixed inset-0 z-40 bg-slate-950/70 backdrop-blur-xs lg:hidden"
        />
      )}

      {/* Sidebar Container */}
      <aside
        className={`fixed top-0 bottom-0 left-0 z-50 bg-[#0f172a] text-slate-300 border-r border-slate-800/90 flex flex-col transition-all duration-300 ease-in-out ${
          isCollapsed ? 'w-20' : 'w-72'
        } ${
          mobileOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        
        {/* Brand & Logo Header */}
        <div className="p-4 border-b border-slate-800/90 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3 overflow-hidden">
            {settings?.logoUrl ? (
              <img 
                src={getDirectImageUrl(settings.logoUrl)} 
                alt="RKM Logo" 
                referrerPolicy="no-referrer"
                className="w-10 h-10 rounded-2xl object-cover shadow-lg shadow-emerald-950/50 shrink-0 ring-2 ring-emerald-400/20 bg-slate-800"
              />
            ) : (
              <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-700 to-emerald-500 flex items-center justify-center text-white shadow-lg shadow-emerald-950/50 shrink-0 ring-2 ring-emerald-400/20">
                <HeartHandshake className="w-5 h-5" />
              </div>
            )}
            {!isCollapsed && (
              <div className="truncate">
                <h1 className="text-sm font-black text-white tracking-tight flex items-center gap-1.5">
                  <span>RKM MPP DIGITAL</span>
                  <span className="text-[9px] bg-emerald-500/20 text-emerald-300 font-extrabold px-1.5 py-0.5 rounded border border-emerald-500/30">
                    2024–27
                  </span>
                </h1>
                <p className="text-[10px] text-slate-400 truncate">Rukun Kematian Metro Parung Panjang</p>
              </div>
            )}
          </div>

          {/* Desktop Collapse Toggle */}
          <button
            onClick={() => setIsCollapsed(!isCollapsed)}
            className="hidden lg:flex p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            title={isCollapsed ? 'Perluas Menu' : 'Perkecil Menu'}
          >
            {isCollapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
          </button>
        </div>

        {/* User Mini Profile Card with Avatar */}
        {currentUser && (
          <div className="p-3 border-b border-slate-800/70 shrink-0">
            <div className={`p-2.5 rounded-2xl bg-slate-800/60 border border-slate-700/60 flex items-center ${isCollapsed ? 'justify-center' : 'gap-3'}`}>
              <img
                src={getAvatarUrl(currentUser.name, currentUser.role, currentUser.avatar)}
                alt={currentUser.name}
                referrerPolicy="no-referrer"
                className="w-9 h-9 rounded-xl object-cover shadow-sm ring-2 ring-emerald-500/30 shrink-0 bg-slate-700"
              />
              {!isCollapsed && (
                <div className="overflow-hidden flex-1 min-w-0">
                  <div className="text-xs font-bold text-white truncate">{currentUser.name}</div>
                  <div className="text-[10px] font-semibold text-emerald-400 truncate flex items-center gap-1">
                    {userIsSuperAdmin ? (
                      <span className="text-amber-300 font-extrabold flex items-center gap-0.5">
                        <ShieldCheck className="w-3 h-3" />
                        Super Admin
                      </span>
                    ) : (
                      <span className="capitalize">{currentUser.title || currentRole}</span>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Navigation Menu Links */}
        <div className="flex-1 overflow-y-auto p-3 space-y-1.5 scrollbar-thin scrollbar-thumb-slate-800">
          {!isCollapsed && (
            <div className="px-3 pt-1 pb-2 text-[10px] font-black uppercase tracking-wider text-slate-400">
              Navigasi Utama
            </div>
          )}

          {allowedNavs.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;

            return (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                title={isCollapsed ? item.label : undefined}
                className={`w-full flex items-center ${
                  isCollapsed ? 'justify-center p-3' : 'justify-between px-3.5 py-2.5'
                } rounded-2xl text-xs font-bold transition-all group cursor-pointer ${
                  isActive
                    ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-950/60 font-extrabold'
                    : 'text-slate-400 hover:text-slate-100 hover:bg-slate-800/80'
                }`}
              >
                <div className="flex items-center gap-3 truncate">
                  <Icon className={`w-4 h-4 shrink-0 transition-transform group-hover:scale-110 ${isActive ? 'text-white' : 'text-slate-400 group-hover:text-emerald-400'}`} />
                  {!isCollapsed && <span className="truncate">{item.label}</span>}
                </div>

                {!isCollapsed && item.badge && (
                  <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full ${item.badgeColor || 'bg-emerald-500/20 text-emerald-300'}`}>
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Dark Mode Permanent Toggle Switch */}
        <div className="p-3 border-t border-slate-800/80 bg-slate-900/60 shrink-0">
          {isCollapsed ? (
            <button
              onClick={toggleTheme}
              title={theme === 'dark' ? 'Mode Gelap Aktif (Klik untuk Mode Terang)' : 'Mode Terang Aktif (Klik untuk Mode Gelap)'}
              className="w-full flex items-center justify-center p-2.5 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 transition-colors cursor-pointer"
            >
              {theme === 'dark' ? (
                <Moon className="w-4 h-4 text-amber-300" />
              ) : (
                <Sun className="w-4 h-4 text-amber-400" />
              )}
            </button>
          ) : (
            <div className="flex items-center justify-between px-2.5 py-1.5 rounded-xl bg-slate-800/50 border border-slate-700/50">
              <div className="flex items-center gap-2 text-xs font-semibold text-slate-300">
                {theme === 'dark' ? (
                  <Moon className="w-4 h-4 text-amber-300 shrink-0" />
                ) : (
                  <Sun className="w-4 h-4 text-amber-400 shrink-0" />
                )}
                <span className="text-[11px] font-bold">
                  {theme === 'dark' ? 'Mode Gelap' : 'Mode Terang'}
                </span>
              </div>

              {/* Toggle Switch Component */}
              <button
                type="button"
                role="switch"
                aria-checked={theme === 'dark'}
                onClick={toggleTheme}
                className={`relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                  theme === 'dark' ? 'bg-emerald-600' : 'bg-slate-600'
                }`}
                title="Ganti Tema Tampilan"
              >
                <span
                  aria-hidden="true"
                  className={`pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow-sm ring-0 transition duration-200 ease-in-out ${
                    theme === 'dark' ? 'translate-x-4' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>
          )}
        </div>

        {/* Database & Server Status Indicator */}
        <div className="p-3 border-t border-slate-800/80 bg-slate-950/40 shrink-0">
          <div className={`flex items-center ${isCollapsed ? 'justify-center' : 'justify-between'} text-[11px]`}>
            <div className="flex items-center gap-2">
              <span className="relative flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
              </span>
              {!isCollapsed && (
                <div>
                  <span className="font-bold text-slate-300 block text-[11px]">Database Online</span>
                  <span className="text-[9px] text-slate-500">AD/ART 2024–2027 Active</span>
                </div>
              )}
            </div>

            {!isCollapsed && (
              currentUser ? (
                <button
                  onClick={() => {
                    logout();
                    setActiveTab('beranda');
                  }}
                  className="p-1.5 text-slate-400 hover:text-rose-400 hover:bg-slate-800 rounded-xl transition-colors cursor-pointer"
                  title="Keluar Akun"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              ) : (
                <button
                  onClick={() => {
                    setActiveTab('login');
                    setMobileOpen(false);
                  }}
                  className="flex items-center gap-1 text-[10px] font-bold text-emerald-400 hover:text-emerald-300 bg-emerald-950/60 hover:bg-emerald-900/60 px-2 py-1 rounded-lg border border-emerald-800/60 transition-colors cursor-pointer"
                  title="Masuk Akun"
                >
                  <LogIn className="w-3.5 h-3.5" />
                  <span>Masuk</span>
                </button>
              )
            )}
          </div>
        </div>

      </aside>
    </>
  );
};
