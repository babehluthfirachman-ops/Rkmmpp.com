import React, { useState } from 'react';
import { 
  MessageSquare, 
  FileText, 
  Save, 
  CheckCircle2, 
  Copy, 
  Hash, 
  Sparkles, 
  Info,
  HelpCircle,
  Eye,
  RotateCcw,
  Check,
  X
} from 'lucide-react';
import { OrganizationSettings } from '../types';

interface NotificationTemplateSettingsProps {
  formState: OrganizationSettings;
  setFormState: React.Dispatch<React.SetStateAction<OrganizationSettings>>;
  onSave: () => void;
}

const DEFAULT_TEMPLATES = {
  receipt: `*KUITANSI PEMBAYARAN IURAN RKM MPP*
No: {no_kuitansi}
----------------------------------------
Telah terima dari: *{nama}*
No. KK: {no_kk} | RT/RW: {rt}/08
Bulan Iuran: *{bulan}*
Nominal: *{nominal}*
Status: *LUNAS (TERVERIFIKASI)*
----------------------------------------
_Terima kasih atas partisipasi aktif dalam Paguyuban RKM Masjid Metro Parung Panjang._
Call Center: {hotline}`,

  lelayu: `*INNA LILLAHI WA INNA ILAIHI RAJI'UN*
Telah berpulang ke Rahmatullah, saudara/i kita:

*Almarhum/Almarhumah: {nama}*
Usia: {usia} Tahun
Alamat Duka: {alamat} (RT {rt}/RW 08)
Waktu Pemakaman: {waktu_pemakaman}
Lokasi Pemakaman: {tpu}

_Semoga almarhum/ah husnul khotimah, diampuni segala dosanya, dan keluarga yang ditinggalkan diberikan ketabahan. Aamiin YRA._
Pengurus RKM MPP 2024-2027`,

  reminder: `*PEMBERITAHUAN IURAN BULANAN RKM MPP*
Kepada Yth. Bpk/Ibu *{nama}* (No. KK: {no_kk})

Mengingatkan bahwa iuran fardhu kifayah RKM MPP periode *{bulan}* sebesar *{nominal}* telah jatuh tempo.
Pembayaran dapat dilakukan melalui koordinator RT setempat, transfer Bank, atau QRIS kasir.

_Semoga Allah SWT senantiasa melapangkan rezeki dan keberkahan untuk keluarga._
Hotline: {hotline}`,

  welcome: `*SELAMAT BERGABUNG DI RKM METRO PARUNG PANJANG*
Ahlan wa Sahlan Bpk/Ibu *{nama}*!

Data keluarga Anda telah terdaftar resmi dalam database RKM MPP:
• No. KTA: *{kta_no}*
• No. KK: *{no_kk}*
• Alamat: *{alamat}*

KTA Digital dan rincian keanggotaan dapat diakses di portal resmi: https://portal.rkm-mpp.id
_Salam Guyub Rukun,_
Pengurus RKM MPP`
};

export const NotificationTemplateSettings: React.FC<NotificationTemplateSettingsProps> = ({
  formState,
  setFormState,
  onSave
}) => {
  const [saved, setSaved] = useState(false);
  const [activeTab, setActiveTab] = useState<'wa' | 'prefix'>('wa');
  const [copiedTag, setCopiedTag] = useState<string | null>(null);
  const [previewTemplate, setPreviewTemplate] = useState<{ title: string; text: string } | null>(null);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    onSave();
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  const copyVariable = (tag: string) => {
    navigator.clipboard.writeText(tag);
    setCopiedTag(tag);
    setTimeout(() => setCopiedTag(null), 2000);
  };

  const resetTemplate = (key: 'receipt' | 'lelayu' | 'reminder' | 'welcome') => {
    if (confirm('Kembalikan template ini ke format standar baku AD/ART?')) {
      if (key === 'receipt') setFormState({ ...formState, waTemplateReceipt: DEFAULT_TEMPLATES.receipt });
      if (key === 'lelayu') setFormState({ ...formState, waTemplateLelayu: DEFAULT_TEMPLATES.lelayu });
      if (key === 'reminder') setFormState({ ...formState, waTemplateReminder: DEFAULT_TEMPLATES.reminder });
      if (key === 'welcome') setFormState({ ...formState, waTemplateWelcome: DEFAULT_TEMPLATES.welcome });
    }
  };

  const handleOpenPreview = (title: string, rawText: string) => {
    // Replace dummy variables
    let rendered = rawText
      .replace(/{nama}/g, 'H. Ahmad Dahlan')
      .replace(/{no_kk}/g, '3201123456780001')
      .replace(/{bulan}/g, 'September 2026')
      .replace(/{nominal}/g, 'Rp 30.000 (6 Bulan)')
      .replace(/{no_kuitansi}/g, 'KW-RKM-2026-09-0042')
      .replace(/{kta_no}/g, 'KTA-MPP-08-0142')
      .replace(/{rt}/g, '03')
      .replace(/{alamat}/g, 'Blok C2 No. 15, RT 03 / RW 08')
      .replace(/{usia}/g, '68')
      .replace(/{waktu_pemakaman}/g, 'Ba\'da Ashar (Pukul 15:30 WIB)')
      .replace(/{tpu}/g, 'TPU Desa Gerowong Parungpanjang')
      .replace(/{hotline}/g, formState.contactCenter || '0812-3456-7890');

    setPreviewTemplate({ title, text: rendered });
  };

  return (
    <form onSubmit={handleSave} className="space-y-6">
      <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200 shadow-sm space-y-6">
        
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-emerald-100 text-emerald-800 rounded-2xl">
              <MessageSquare className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-extrabold text-base text-slate-900">
                Template Pesan Otomatis WhatsApp & Format Penomoran
              </h2>
              <p className="text-xs text-slate-500">
                Sesuaikan format pesan siaran, kuitansi digital, berita lelayu, dan kode penomoran resmi.
              </p>
            </div>
          </div>

          <button
            type="submit"
            className="flex items-center justify-center gap-2 px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white font-bold text-xs rounded-xl shadow-md transition-all self-start sm:self-auto cursor-pointer"
          >
            {saved ? (
              <>
                <CheckCircle2 className="w-4 h-4 text-emerald-200" />
                <span>Tersimpan!</span>
              </>
            ) : (
              <>
                <Save className="w-4 h-4" />
                <span>Simpan Template & Prefix</span>
              </>
            )}
          </button>
        </div>

        {/* Sub-tab navigation */}
        <div className="flex items-center gap-2 border-b border-slate-100 pb-2">
          <button
            type="button"
            onClick={() => setActiveTab('wa')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'wa'
                ? 'bg-emerald-50 text-emerald-800 border border-emerald-200 shadow-2xs'
                : 'text-slate-600 hover:bg-slate-50'
            }`}
          >
            Template Pesan WhatsApp
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('prefix')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'prefix'
                ? 'bg-emerald-50 text-emerald-800 border border-emerald-200 shadow-2xs'
                : 'text-slate-600 hover:bg-slate-50'
            }`}
          >
            Prefix & Format Penomoran
          </button>
        </div>

        {activeTab === 'wa' && (
          <div className="space-y-6">
            
            {/* Variable Cheat-sheet */}
            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200">
              <div className="flex items-center justify-between gap-2 text-xs font-bold text-slate-800 mb-2">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-amber-500" />
                  <span>Variabel Dinamis Otomatis (Klik tag untuk menyalin):</span>
                </div>
                {copiedTag && (
                  <span className="text-[11px] text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-md font-bold">
                    ✓ Tag {copiedTag} tersalin!
                  </span>
                )}
              </div>
              <div className="flex flex-wrap gap-1.5 text-[11px]">
                {[
                  '{nama}', '{no_kk}', '{bulan}', '{nominal}', '{no_kuitansi}', 
                  '{kta_no}', '{rt}', '{alamat}', '{usia}', '{waktu_pemakaman}', 
                  '{tpu}', '{hotline}'
                ].map(tag => (
                  <button
                    key={tag}
                    type="button"
                    onClick={() => copyVariable(tag)}
                    className="px-2.5 py-1 bg-white hover:bg-emerald-50 text-slate-700 hover:text-emerald-800 border border-slate-300 hover:border-emerald-300 rounded-lg font-mono font-bold transition-colors cursor-pointer"
                    title="Klik untuk salin tag"
                  >
                    {tag}
                  </button>
                ))}
              </div>
            </div>

            {/* Template 1: Kuitansi Pembayaran */}
            <div className="space-y-2 p-4 bg-slate-50/60 rounded-2xl border border-slate-200">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-slate-800 block">
                  1. Template Pesan Kuitansi Pembayaran Iuran (WA Bukti Bayar):
                </label>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => handleOpenPreview('Preview Kuitansi WA', formState.waTemplateReceipt || DEFAULT_TEMPLATES.receipt)}
                    className="text-[11px] text-blue-600 hover:text-blue-700 font-bold flex items-center gap-1 cursor-pointer"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>Pratinjau</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => resetTemplate('receipt')}
                    className="text-[11px] text-slate-500 hover:text-slate-700 font-semibold flex items-center gap-1 cursor-pointer"
                    title="Kembalikan ke standar"
                  >
                    <RotateCcw className="w-3 h-3" />
                    <span>Reset</span>
                  </button>
                </div>
              </div>
              <textarea
                rows={5}
                value={formState.waTemplateReceipt ?? DEFAULT_TEMPLATES.receipt}
                onChange={(e) => setFormState({ ...formState, waTemplateReceipt: e.target.value })}
                className="w-full p-3 bg-white border border-slate-300 rounded-xl text-xs font-mono text-slate-900 focus:ring-2 focus:ring-emerald-500"
                placeholder="Tulis format pesan kuitansi di sini..."
              />
            </div>

            {/* Template 2: Berita Duka (Lelayu) */}
            <div className="space-y-2 p-4 bg-slate-50/60 rounded-2xl border border-slate-200">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-slate-800 block">
                  2. Template Berita Duka / Maklumat Lelayu (Broadcast Warga):
                </label>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => handleOpenPreview('Preview Berita Duka (Lelayu)', formState.waTemplateLelayu || DEFAULT_TEMPLATES.lelayu)}
                    className="text-[11px] text-blue-600 hover:text-blue-700 font-bold flex items-center gap-1 cursor-pointer"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>Pratinjau</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => resetTemplate('lelayu')}
                    className="text-[11px] text-slate-500 hover:text-slate-700 font-semibold flex items-center gap-1 cursor-pointer"
                    title="Kembalikan ke standar"
                  >
                    <RotateCcw className="w-3 h-3" />
                    <span>Reset</span>
                  </button>
                </div>
              </div>
              <textarea
                rows={6}
                value={formState.waTemplateLelayu ?? DEFAULT_TEMPLATES.lelayu}
                onChange={(e) => setFormState({ ...formState, waTemplateLelayu: e.target.value })}
                className="w-full p-3 bg-white border border-slate-300 rounded-xl text-xs font-mono text-slate-900 focus:ring-2 focus:ring-emerald-500"
                placeholder="Tulis format berita lelayu..."
              />
            </div>

            {/* Template 3: Pengingat Iuran */}
            <div className="space-y-2 p-4 bg-slate-50/60 rounded-2xl border border-slate-200">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-slate-800 block">
                  3. Template Pengingat Iuran Bulanan (Reminder Tagihan):
                </label>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => handleOpenPreview('Preview Pengingat Iuran', formState.waTemplateReminder || DEFAULT_TEMPLATES.reminder)}
                    className="text-[11px] text-blue-600 hover:text-blue-700 font-bold flex items-center gap-1 cursor-pointer"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>Pratinjau</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => resetTemplate('reminder')}
                    className="text-[11px] text-slate-500 hover:text-slate-700 font-semibold flex items-center gap-1 cursor-pointer"
                    title="Kembalikan ke standar"
                  >
                    <RotateCcw className="w-3 h-3" />
                    <span>Reset</span>
                  </button>
                </div>
              </div>
              <textarea
                rows={5}
                value={formState.waTemplateReminder ?? DEFAULT_TEMPLATES.reminder}
                onChange={(e) => setFormState({ ...formState, waTemplateReminder: e.target.value })}
                className="w-full p-3 bg-white border border-slate-300 rounded-xl text-xs font-mono text-slate-900 focus:ring-2 focus:ring-emerald-500"
                placeholder="Tulis pesan pengingat tagihan iuran..."
              />
            </div>

            {/* Template 4: Sambutan Anggota Baru & KTA */}
            <div className="space-y-2 p-4 bg-slate-50/60 rounded-2xl border border-slate-200">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-slate-800 block">
                  4. Template Sambutan Anggota Baru & Informasi KTA Digital:
                </label>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => handleOpenPreview('Preview Sambutan Anggota Baru', formState.waTemplateWelcome || DEFAULT_TEMPLATES.welcome)}
                    className="text-[11px] text-blue-600 hover:text-blue-700 font-bold flex items-center gap-1 cursor-pointer"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>Pratinjau</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => resetTemplate('welcome')}
                    className="text-[11px] text-slate-500 hover:text-slate-700 font-semibold flex items-center gap-1 cursor-pointer"
                    title="Kembalikan ke standar"
                  >
                    <RotateCcw className="w-3 h-3" />
                    <span>Reset</span>
                  </button>
                </div>
              </div>
              <textarea
                rows={5}
                value={formState.waTemplateWelcome ?? DEFAULT_TEMPLATES.welcome}
                onChange={(e) => setFormState({ ...formState, waTemplateWelcome: e.target.value })}
                className="w-full p-3 bg-white border border-slate-300 rounded-xl text-xs font-mono text-slate-900 focus:ring-2 focus:ring-emerald-500"
                placeholder="Tulis pesan selamat datang anggota baru..."
              />
            </div>

          </div>
        )}

        {activeTab === 'prefix' && (
          <div className="space-y-5">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
              
              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
                <div className="flex items-center gap-1.5 font-bold text-slate-800">
                  <Hash className="w-4 h-4 text-emerald-600" />
                  <span>Prefix Kuitansi Kasir</span>
                </div>
                <input
                  type="text"
                  value={formState.receiptPrefix || 'KW-RKM'}
                  onChange={(e) => setFormState({ ...formState, receiptPrefix: e.target.value.toUpperCase() })}
                  placeholder="KW-RKM"
                  className="w-full p-2.5 bg-white border border-slate-300 rounded-xl font-mono font-bold text-slate-900"
                />
                <p className="text-[11px] text-slate-500">
                  Contoh hasil: <strong className="font-mono">{formState.receiptPrefix || 'KW-RKM'}-2026-09-0012</strong>
                </p>
              </div>

              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
                <div className="flex items-center gap-1.5 font-bold text-slate-800">
                  <Hash className="w-4 h-4 text-blue-600" />
                  <span>Prefix Kartu Anggota (KTA)</span>
                </div>
                <input
                  type="text"
                  value={formState.ktaPrefix || 'KTA-MPP'}
                  onChange={(e) => setFormState({ ...formState, ktaPrefix: e.target.value.toUpperCase() })}
                  placeholder="KTA-MPP"
                  className="w-full p-2.5 bg-white border border-slate-300 rounded-xl font-mono font-bold text-slate-900"
                />
                <p className="text-[11px] text-slate-500">
                  Contoh hasil: <strong className="font-mono">{formState.ktaPrefix || 'KTA-MPP'}-08-0042</strong>
                </p>
              </div>

              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
                <div className="flex items-center gap-1.5 font-bold text-slate-800">
                  <Hash className="w-4 h-4 text-purple-600" />
                  <span>Prefix Berita Duka / Lelayu</span>
                </div>
                <input
                  type="text"
                  value={formState.lelayuPrefix || 'BD-MPP'}
                  onChange={(e) => setFormState({ ...formState, lelayuPrefix: e.target.value.toUpperCase() })}
                  placeholder="BD-MPP"
                  className="w-full p-2.5 bg-white border border-slate-300 rounded-xl font-mono font-bold text-slate-900"
                />
                <p className="text-[11px] text-slate-500">
                  Contoh hasil: <strong className="font-mono">{formState.lelayuPrefix || 'BD-MPP'}-2026-003</strong>
                </p>
              </div>

            </div>
          </div>
        )}

      </div>

      {/* Preview Modal */}
      {previewTemplate && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-xs flex items-center justify-center z-50 p-4 animate-fade-in">
          <div className="bg-white rounded-3xl p-6 max-w-lg w-full border border-slate-200 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <MessageSquare className="w-4 h-4 text-emerald-600" />
                <h3 className="font-extrabold text-sm text-slate-900">{previewTemplate.title}</h3>
              </div>
              <button
                type="button"
                onClick={() => setPreviewTemplate(null)}
                className="p-1.5 hover:bg-slate-100 text-slate-400 hover:text-slate-600 rounded-lg"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="bg-emerald-950 text-emerald-100 p-4 rounded-2xl font-mono text-xs whitespace-pre-wrap leading-relaxed border border-emerald-800/60 max-h-80 overflow-y-auto">
              {previewTemplate.text}
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => {
                  navigator.clipboard.writeText(previewTemplate.text);
                  alert('✓ Contoh teks pesan tersalin!');
                }}
                className="flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-xs"
              >
                <Copy className="w-3.5 h-3.5" />
                <span>Salin Contoh Pesan</span>
              </button>
              <button
                type="button"
                onClick={() => setPreviewTemplate(null)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl"
              >
                Tutup
              </button>
            </div>
          </div>
        </div>
      )}
    </form>
  );
};
