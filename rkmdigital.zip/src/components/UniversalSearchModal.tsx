import React, { useState, useEffect, useRef } from 'react';
import { 
  Search, 
  X, 
  User, 
  Users, 
  CreditCard, 
  Phone, 
  Printer, 
  ShieldCheck, 
  AlertCircle, 
  MapPin, 
  ArrowRight,
  MessageSquare
} from 'lucide-react';
import { useRkm } from '../context/RkmContext';
import { formatRupiah, getAdArtCitizenStatus, createWhatsAppUrl, calculateCitizenMonthlyDues } from '../utils/formatters';
import { Citizen } from '../types';

interface UniversalSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectCitizen: (citizen: Citizen) => void;
  onQuickPay: (citizen: Citizen) => void;
}

export const UniversalSearchModal: React.FC<UniversalSearchModalProps> = ({
  isOpen,
  onClose,
  onSelectCitizen,
  onQuickPay
}) => {
  const { citizens, openKtaModal, currentUser, currentRole } = useRkm();
  const [query, setQuery] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 50);
    } else {
      setQuery('');
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const cleanQuery = query.toLowerCase().trim();

  // Role data isolation
  const visibleCitizens = citizens.filter(c => {
    if (currentRole === 'warga') {
      if (currentUser?.noKK && c.noKK === currentUser.noKK) return true;
      if (currentUser?.name && (c.headOfFamily.toLowerCase().includes(currentUser.name.toLowerCase()) || currentUser.name.toLowerCase().includes(c.headOfFamily.toLowerCase()))) return true;
      return false;
    }
    if (currentRole === 'koordinator') {
      const isAssignedDirectly = c.assignedCollectorId === currentUser?.id;
      const isAssignedBlock = Boolean(currentUser?.assignedBlocks && currentUser.assignedBlocks.length > 0 && currentUser.assignedBlocks.includes(c.block || ''));
      const isAssignedRt = (!currentUser?.assignedBlocks || currentUser.assignedBlocks.length === 0) && (!c.assignedCollectorId) && c.rt === currentUser?.rt;
      return isAssignedDirectly || isAssignedBlock || isAssignedRt;
    }
    return true;
  });

  const results = cleanQuery
    ? visibleCitizens.filter(c => {
        const matchHead = c.headOfFamily.toLowerCase().includes(cleanQuery);
        const matchKk = c.noKK.includes(cleanQuery);
        const matchNik = c.nik.includes(cleanQuery);
        const matchAddress = c.address.toLowerCase().includes(cleanQuery);
        const matchBlock = c.block && c.block.toLowerCase().includes(cleanQuery);
        const matchRt = c.rt.includes(cleanQuery);
        const matchPhone = c.phone.includes(cleanQuery);
        const matchMembers = c.members?.some(m => m.name.toLowerCase().includes(cleanQuery));

        return matchHead || matchKk || matchNik || matchAddress || matchBlock || matchRt || matchPhone || matchMembers;
      })
    : [];

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/75 backdrop-blur-sm flex items-start justify-center p-4 pt-16 sm:pt-24 overflow-y-auto">
      <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-3xl overflow-hidden animate-fade-in">
        
        {/* Search Header Input */}
        <div className="p-4 bg-slate-900 text-white flex items-center gap-3 border-b border-slate-800">
          <Search className="w-5 h-5 text-emerald-400 shrink-0" />
          <input
            ref={inputRef}
            type="text"
            placeholder="Cari No. KK, NIK, Nama Warga, Blok A-Z, RT 001-011, No. WhatsApp..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="flex-1 bg-transparent text-white placeholder:text-slate-400 text-sm font-semibold outline-none"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="p-1 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white text-xs"
            >
              Hapus
            </button>
          )}
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search Result List */}
        <div className="max-h-[60vh] overflow-y-auto p-4 space-y-3 divide-y divide-slate-100">
          {query === '' ? (
            <div className="py-12 text-center text-slate-400 text-xs">
              <Search className="w-8 h-8 mx-auto mb-2 text-slate-300 stroke-[1.5]" />
              <p className="font-semibold text-slate-600">Pencarian Universal Data Warga RKM MPP</p>
              <p className="mt-1 text-slate-400 text-[11px]">
                Ketik nama kepala keluarga, anggota jiwa, nomor KK (16 digit), atau blok perumahan.
              </p>
            </div>
          ) : results.length === 0 ? (
            <div className="py-12 text-center text-slate-500 text-xs">
              <AlertCircle className="w-8 h-8 mx-auto mb-2 text-amber-500 stroke-[1.5]" />
              <p className="font-bold text-slate-700">Tidak ada data warga yang cocok dengan "{query}"</p>
              <p className="mt-1 text-slate-400 text-[11px]">
                Pastikan ejaan nama, nomor KK, atau blok perumahan sudah sesuai.
              </p>
            </div>
          ) : (
            results.map((c) => {
              const adArtStatus = getAdArtCitizenStatus(c);
              const duesInfo = calculateCitizenMonthlyDues(c);

              return (
                <div key={c.id} className="pt-3 first:pt-0">
                  <div className="p-3.5 rounded-2xl bg-slate-50 hover:bg-emerald-50/50 border border-slate-200/80 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    
                    <div className="space-y-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-bold text-slate-900 text-sm">{c.headOfFamily}</span>
                        <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full border ${adArtStatus.statusBadgeColor}`}>
                          {adArtStatus.statusBadgeText}
                        </span>
                        <span className="text-[10px] bg-slate-200 text-slate-700 font-bold px-2 py-0.5 rounded-full">
                          {c.block ? `Blok ${c.block}` : `RT ${c.rt}/RW ${c.rw}`}
                        </span>
                      </div>

                      <div className="text-xs text-slate-600 flex flex-wrap items-center gap-x-3 gap-y-1">
                        <span>No. KK: <strong className="font-mono text-slate-800">{c.noKK}</strong></span>
                        <span>•</span>
                        <span>Alamat: {c.address}</span>
                        <span>•</span>
                        <span>Total: <strong>{c.members.length} Jiwa</strong></span>
                      </div>

                      <p className="text-[11px] text-emerald-700 font-medium">
                        Iuran: {formatRupiah(duesInfo.totalMonthlyDues)}/bln ({duesInfo.coreMembersCount} Inti + {duesInfo.extraMembersCount} Tambahan)
                      </p>
                    </div>

                    {/* Action buttons */}
                    <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
                      <button
                        onClick={() => {
                          onQuickPay(c);
                          onClose();
                        }}
                        className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs flex items-center gap-1 shadow-sm transition-all active:scale-95"
                      >
                        <CreditCard className="w-3.5 h-3.5" />
                        <span>Bayar</span>
                      </button>

                      <button
                        onClick={() => {
                          openKtaModal(c);
                          onClose();
                        }}
                        className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-white font-bold rounded-xl text-xs flex items-center gap-1 transition-all"
                      >
                        <Printer className="w-3.5 h-3.5" />
                        <span>KTA</span>
                      </button>

                      <button
                        onClick={() => {
                          const message = `Assalamu'alaikum Bapak/Ibu ${c.headOfFamily}, kami dari Pengurus Rukun Kematian (RKM) Perumahan Metro Parung Panjang...`;
                          window.open(createWhatsAppUrl(c.phone, message), '_blank');
                        }}
                        className="p-1.5 bg-emerald-100 hover:bg-emerald-200 text-emerald-800 rounded-xl transition-all"
                        title="Chat WhatsApp"
                      >
                        <MessageSquare className="w-4 h-4" />
                      </button>
                    </div>

                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer info */}
        <div className="p-3 bg-slate-100 border-t border-slate-200 text-[11px] text-slate-500 flex items-center justify-between">
          <span>Ditemukan: <strong>{results.length} data warga</strong></span>
          <span className="font-mono text-[10px] text-slate-400">Tekan ESC untuk menutup</span>
        </div>

      </div>
    </div>
  );
};
