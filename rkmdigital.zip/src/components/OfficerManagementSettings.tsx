import React, { useState, useRef } from 'react';
import { 
  Users, 
  User,
  UserPlus, 
  ShieldCheck, 
  Phone, 
  Mail, 
  MapPin, 
  Trash2, 
  Edit3, 
  Printer, 
  CheckCircle2, 
  AlertCircle, 
  Search, 
  Filter, 
  Clock, 
  Award,
  Sparkles,
  KeyRound,
  Eye,
  Check,
  X,
  FileSpreadsheet,
  Camera,
  Upload,
  Image,
  Link,
  RotateCcw
} from 'lucide-react';
import { useRkm } from '../context/RkmContext';
import { Officer, UserProfile } from '../types';
import { formatDateIndo, getDirectImageUrl } from '../utils/formatters';

const PRESET_AVATARS = [
  'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150&auto=format&fit=crop&q=80'
];

const DIVISIONS = [
  'Semua Divisi',
  'Dewan Pembina / Penasehat',
  'Pengurus Harian',
  'Koordinator RT',
  'Pemulasaraan Jenazah',
  'Ambulans & Driver 24 Jam',
  'Logistik & Perlengkapan',
  'Petugas Lapangan & Penagihan'
];

export const OfficerManagementSettings: React.FC = () => {
  const { 
    officers, 
    addOfficer, 
    updateOfficer, 
    deleteOfficer, 
    settings,
    users,
    registerUser
  } = useRkm();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDivision, setSelectedDivision] = useState('Semua Divisi');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  
  // Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingOfficer, setEditingOfficer] = useState<Officer | null>(null);
  const [showSkModal, setShowSkModal] = useState(false);
  const [successToast, setSuccessToast] = useState<string | null>(null);

  // Form State
  const [name, setName] = useState('');
  const [role, setRole] = useState('Petugas Lapangan');
  const [division, setDivision] = useState('Petugas Lapangan & Penagihan');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [photo, setPhoto] = useState(PRESET_AVATARS[0]);
  const [dutyStatus, setDutyStatus] = useState<'Siaga 24 Jam' | 'Aktif' | 'Tugas Khusus'>('Aktif');
  const [selectedRts, setSelectedRts] = useState<string[]>(['RT 01']);
  const [notes, setNotes] = useState('');
  const [createSystemAccount, setCreateSystemAccount] = useState(true);
  const [accountRole, setAccountRole] = useState<'petugas' | 'bendahara' | 'ketua'>('petugas');

  // Dedicated Photo Modal State
  const [photoModalOfficer, setPhotoModalOfficer] = useState<Officer | null>(null);
  const [quickPhotoValue, setQuickPhotoValue] = useState('');
  const [customUrlInput, setCustomUrlInput] = useState('');
  
  const modalFileInputRef = useRef<HTMLInputElement>(null);
  const quickPhotoFileInputRef = useRef<HTMLInputElement>(null);

  const handleOpenQuickPhoto = (ofc: Officer) => {
    setPhotoModalOfficer(ofc);
    setQuickPhotoValue(ofc.photo || '');
    setCustomUrlInput('');
  };

  const handleSaveQuickPhoto = () => {
    if (!photoModalOfficer) return;
    updateOfficer(photoModalOfficer.id, { photo: quickPhotoValue });
    showToast(`Foto pengurus ${photoModalOfficer.name} berhasil diperbarui.`);
    setPhotoModalOfficer(null);
  };

  const handleProcessImageFile = (file: File, onDone: (dataUrl: string) => void) => {
    if (!file.type.startsWith('image/')) {
      alert('Mohon pilih file gambar (JPG, PNG, atau WebP).');
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      alert('Ukuran file foto maksimal 5MB.');
      return;
    }
    const reader = new FileReader();
    reader.onload = (e) => {
      const result = e.target?.result as string;
      if (result) {
        onDone(result);
      }
    };
    reader.readAsDataURL(file);
  };

  const showToast = (msg: string) => {
    setSuccessToast(msg);
    setTimeout(() => setSuccessToast(null), 3500);
  };

  const handleOpenAdd = () => {
    setEditingOfficer(null);
    setName('');
    setRole('Petugas Lapangan RT');
    setDivision('Petugas Lapangan & Penagihan');
    setPhone('08');
    setEmail('');
    setPhoto(PRESET_AVATARS[Math.floor(Math.random() * PRESET_AVATARS.length)]);
    setDutyStatus('Aktif');
    setSelectedRts(['RT 01']);
    setNotes('');
    setCreateSystemAccount(true);
    setAccountRole('petugas');
    setIsModalOpen(true);
  };

  const handleOpenEdit = (ofc: Officer) => {
    setEditingOfficer(ofc);
    setName(ofc.name);
    setRole(ofc.role);
    setDivision((ofc as any).division || 'Petugas Lapangan & Penagihan');
    setPhone(ofc.phone);
    setEmail((ofc as any).email || '');
    setPhoto(ofc.photo || PRESET_AVATARS[0]);
    setDutyStatus(ofc.dutyStatus);
    setSelectedRts(ofc.rtAssigned.length ? ofc.rtAssigned : ['Semua RT']);
    setNotes((ofc as any).notes || '');
    setCreateSystemAccount(false);
    setIsModalOpen(true);
  };

  const toggleRtSelection = (rt: string) => {
    if (rt === 'Semua RT') {
      setSelectedRts(['Semua RT']);
      return;
    }
    
    let updated = selectedRts.filter(r => r !== 'Semua RT');
    if (updated.includes(rt)) {
      updated = updated.filter(r => r !== rt);
      if (updated.length === 0) updated = ['Semua RT'];
    } else {
      updated.push(rt);
    }
    setSelectedRts(updated);
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !phone.trim() || !role.trim()) {
      alert('Mohon lengkapi nama pengurus, jabatan, dan nomor telepon.');
      return;
    }

    if (editingOfficer) {
      // Update existing officer
      updateOfficer(editingOfficer.id, {
        name,
        role,
        division: division as any,
        phone,
        email: email || undefined,
        photo,
        dutyStatus,
        rtAssigned: selectedRts,
        notes: notes || undefined
      } as any);
      showToast(`Data pengurus ${name} berhasil diperbarui.`);
    } else {
      // Add new officer
      const newOfcData: Omit<Officer, 'id'> = {
        name,
        role,
        phone,
        photo,
        dutyStatus,
        rtAssigned: selectedRts
      };
      (newOfcData as any).division = division;
      (newOfcData as any).email = email;
      (newOfcData as any).notes = notes;

      addOfficer(newOfcData);

      // Create linked user account if requested
      if (createSystemAccount) {
        const cleanName = name.toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 10);
        const username = `petugas_${cleanName || Date.now().toString().slice(-4)}`;
        
        // check if username exists
        const exists = users.some(u => u.username === username);
        const finalUsername = exists ? `${username}_${Math.floor(Math.random() * 90 + 10)}` : username;

        registerUser({
          username: finalUsername,
          name,
          role: accountRole,
          phone,
          email: email || `${finalUsername}@rkmmpp.id`,
          password: '123456',
          status: 'Aktif',
          title: role,
          rt: selectedRts.join(', '),
          rw: '08',
          avatar: photo
        });
      }

      showToast(`Pengurus ${name} berhasil ditambahkan ke susunan organisasi.`);
    }

    setIsModalOpen(false);
  };

  const handleDelete = (ofc: Officer) => {
    if (confirm(`Apakah Anda yakin ingin menghapus petugas/pengurus "${ofc.name}" (${ofc.role}) dari sistem?`)) {
      deleteOfficer(ofc.id);
      showToast(`Petugas ${ofc.name} telah dihapus.`);
    }
  };

  // Filter officers
  const filteredOfficers = officers.filter(ofc => {
    const matchQuery = 
      ofc.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      ofc.role.toLowerCase().includes(searchQuery.toLowerCase()) ||
      ofc.phone.includes(searchQuery) ||
      ofc.rtAssigned.some(r => r.toLowerCase().includes(searchQuery.toLowerCase()));

    const ofcDiv = (ofc as any).division || 'Petugas Lapangan & Penagihan';
    const matchDivision = selectedDivision === 'Semua Divisi' || ofcDiv === selectedDivision;
    const matchStatus = selectedStatus === 'all' || ofc.dutyStatus === selectedStatus;

    return matchQuery && matchDivision && matchStatus;
  });

  return (
    <div className="space-y-6 animate-fade-in">
      
      {/* Toast Notification */}
      {successToast && (
        <div className="fixed bottom-6 right-6 z-50 bg-emerald-900 text-emerald-100 px-5 py-3.5 rounded-2xl shadow-xl border border-emerald-700/80 flex items-center gap-3 animate-bounce">
          <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
          <span className="text-xs sm:text-sm font-semibold">{successToast}</span>
        </div>
      )}

      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 rounded-3xl p-6 sm:p-8 text-white border border-slate-800 shadow-lg relative overflow-hidden">
        <div className="absolute right-0 top-0 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/20 border border-indigo-400/30 text-indigo-300 text-xs font-semibold">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>SK Pengurus Periode 2024–2027</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black tracking-tight">
              Struktur Organisasi & Satgas Siaga 24 Jam
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 max-w-2xl leading-relaxed">
              Kelola susunan Dewan Penasehat, Pengurus Harian, Koordinator RT 01–08, Tim Pemulasaraan Jenazah Ikhwan & Akhwat, serta Tim Mobilisasi Ambulans {settings.orgName}.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <button
              type="button"
              onClick={() => setShowSkModal(true)}
              className="px-4 py-2.5 bg-slate-800/80 hover:bg-slate-700 text-slate-200 hover:text-white font-bold rounded-xl text-xs flex items-center gap-2 border border-slate-700 transition-all shadow-sm"
            >
              <Printer className="w-4 h-4 text-indigo-400" />
              <span>Cetak SK Pengurus</span>
            </button>

            <button
              type="button"
              onClick={handleOpenAdd}
              className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs flex items-center gap-2 shadow-md shadow-emerald-900/30 transition-all hover:scale-[1.02]"
            >
              <UserPlus className="w-4 h-4" />
              <span>Tambah Pengurus Baru</span>
            </button>
          </div>
        </div>

        {/* Quick Stats Banner */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6 pt-6 border-t border-slate-800/80 text-xs">
          <div className="bg-slate-800/40 p-3 rounded-xl border border-slate-800">
            <p className="text-slate-400 text-[11px]">Total Pengurus & Satgas</p>
            <p className="text-lg font-black text-white mt-0.5">{officers.length} Orang</p>
          </div>
          <div className="bg-slate-800/40 p-3 rounded-xl border border-slate-800">
            <p className="text-slate-400 text-[11px]">Siaga Tanggap 24 Jam</p>
            <p className="text-lg font-black text-rose-400 mt-0.5">
              {officers.filter(o => o.dutyStatus === 'Siaga 24 Jam').length} Personil
            </p>
          </div>
          <div className="bg-slate-800/40 p-3 rounded-xl border border-slate-800">
            <p className="text-slate-400 text-[11px]">Cakupan Wilayah</p>
            <p className="text-lg font-black text-emerald-400 mt-0.5">RT 01 s/d RT 08</p>
          </div>
          <div className="bg-slate-800/40 p-3 rounded-xl border border-slate-800">
            <p className="text-slate-400 text-[11px]">Terhubung Akun Login</p>
            <p className="text-lg font-black text-indigo-300 mt-0.5">
              {users.filter(u => u.role !== 'warga').length} Akun
            </p>
          </div>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-sm flex flex-col md:flex-row items-center justify-between gap-3">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Cari nama, jabatan, nomor telepon..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500 transition-all font-medium"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
          {/* Division Selector */}
          <select
            value={selectedDivision}
            onChange={(e) => setSelectedDivision(e.target.value)}
            className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-700 focus:outline-none focus:ring-2 focus:ring-emerald-500"
          >
            {DIVISIONS.map(d => (
              <option key={d} value={d}>{d}</option>
            ))}
          </select>

          {/* Duty Status Selector */}
          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-700 focus:outline-none focus:ring-2 focus:ring-emerald-500"
          >
            <option value="all">Semua Status Dinas</option>
            <option value="Siaga 24 Jam">🔴 Siaga 24 Jam</option>
            <option value="Aktif">🟢 Aktif</option>
            <option value="Tugas Khusus">🔵 Tugas Khusus</option>
          </select>
        </div>
      </div>

      {/* Officers Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredOfficers.map((ofc) => {
          const hasLinkedAccount = users.some(u => u.phone === ofc.phone || u.name.toLowerCase() === ofc.name.toLowerCase());
          
          return (
            <div 
              key={ofc.id} 
              className="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-sm hover:shadow-md transition-all flex flex-col justify-between group relative overflow-hidden"
            >
              {/* Top Accent Strip */}
              <div className={`absolute top-0 left-0 right-0 h-1.5 ${
                ofc.dutyStatus === 'Siaga 24 Jam' ? 'bg-rose-500' : 'bg-emerald-600'
              }`} />

              <div>
                <div className="flex items-start gap-3.5 pt-1">
                  <div className="relative group/avatar w-14 h-14 rounded-2xl overflow-hidden border-2 border-slate-200 shadow-sm shrink-0 bg-slate-100">
                    {ofc.photo ? (
                      <img
                        src={getDirectImageUrl(ofc.photo)}
                        alt={ofc.name}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover"
                        onError={(e) => {
                          (e.currentTarget as HTMLElement).style.display = 'none';
                          const fallback = e.currentTarget.nextElementSibling as HTMLElement;
                          if (fallback) fallback.style.display = 'flex';
                        }}
                      />
                    ) : null}
                    <div className={`w-full h-full bg-emerald-700 text-white flex items-center justify-center font-black text-lg ${ofc.photo ? 'hidden' : 'flex'}`}>
                      {ofc.name.charAt(0)}
                    </div>

                    {/* Quick Camera Hover Button */}
                    <button
                      type="button"
                      onClick={() => handleOpenQuickPhoto(ofc)}
                      className="absolute inset-0 bg-slate-900/60 text-white opacity-0 group-hover/avatar:opacity-100 transition-opacity flex flex-col items-center justify-center gap-0.5 cursor-pointer"
                      title="Ganti Foto Pengurus"
                    >
                      <Camera className="w-4 h-4 text-emerald-300" />
                      <span className="text-[8px] font-extrabold uppercase tracking-wider">Ganti</span>
                    </button>
                  </div>

                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between gap-1">
                      <h4 className="font-extrabold text-slate-900 text-sm truncate">{ofc.name}</h4>
                    </div>
                    <p className="text-emerald-700 font-bold text-xs mt-0.5">{ofc.role}</p>
                    
                    <div className="flex flex-wrap items-center gap-1.5 mt-2">
                      <span className={`px-2 py-0.5 rounded-md text-[10px] font-extrabold ${
                        ofc.dutyStatus === 'Siaga 24 Jam' 
                          ? 'bg-rose-100 text-rose-800' 
                          : ofc.dutyStatus === 'Tugas Khusus'
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-emerald-100 text-emerald-800'
                      }`}>
                        {ofc.dutyStatus}
                      </span>

                      {hasLinkedAccount && (
                        <span className="px-1.5 py-0.5 rounded-md text-[9px] font-bold bg-indigo-50 text-indigo-700 border border-indigo-100 flex items-center gap-0.5">
                          <KeyRound className="w-2.5 h-2.5" />
                          Akun Aktif
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                {/* RT & Contact Info */}
                <div className="mt-4 pt-3 border-t border-slate-100 space-y-2 text-xs text-slate-600">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400 text-[11px]">Wilayah Tugas:</span>
                    <span className="font-bold text-slate-800 bg-slate-100 px-2 py-0.5 rounded text-[11px]">
                      {ofc.rtAssigned.join(', ')}
                    </span>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-slate-400 text-[11px]">Kontak WA:</span>
                    <a
                      href={`https://wa.me/${ofc.phone.replace(/\D/g, '')}`}
                      target="_blank"
                      rel="noreferrer"
                      className="font-mono font-bold text-emerald-600 hover:text-emerald-700 flex items-center gap-1 hover:underline"
                    >
                      <Phone className="w-3 h-3" />
                      {ofc.phone}
                    </a>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between gap-1.5">
                <button
                  type="button"
                  onClick={() => handleOpenQuickPhoto(ofc)}
                  className="py-1.5 px-2.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 font-bold rounded-xl text-xs flex items-center justify-center gap-1 transition-colors cursor-pointer"
                  title="Ganti foto pengurus (Upload Berkas / URL / Avatar)"
                >
                  <Camera className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Foto</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleOpenEdit(ofc)}
                  className="flex-1 py-1.5 px-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Edit3 className="w-3.5 h-3.5 text-slate-500" />
                  <span>Edit Data</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleDelete(ofc)}
                  className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition-colors cursor-pointer"
                  title="Hapus Pengurus"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {filteredOfficers.length === 0 && (
        <div className="bg-white rounded-3xl p-12 text-center border border-slate-200/80 shadow-sm">
          <Users className="w-12 h-12 text-slate-300 mx-auto mb-3" />
          <h3 className="font-extrabold text-slate-800 text-base">Tidak ada pengurus ditemukan</h3>
          <p className="text-xs text-slate-500 mt-1">Coba sesuaikan kata kunci pencarian atau filter divisi.</p>
        </div>
      )}

      {/* ================= MODAL TAMBAH / EDIT PENGURUS ================= */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-xl w-full p-6 sm:p-7 shadow-2xl border border-slate-100 my-8">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <span className="p-2 bg-emerald-100 text-emerald-700 rounded-xl">
                  <UserPlus className="w-5 h-5" />
                </span>
                <div>
                  <h3 className="font-extrabold text-slate-900 text-base">
                    {editingOfficer ? 'Edit Data Pengurus / Satgas' : 'Tambah Pengurus / Petugas Baru'}
                  </h3>
                  <p className="text-xs text-slate-500">Struktur Organisasi & Pelayanan RKM MPP</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleFormSubmit} className="space-y-4 mt-5">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Nama Lengkap & Gelar <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: Drs. H. Bambang Sutrisno / Ust. Syihabuddin"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500 font-semibold"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Jabatan / Posisi <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Contoh: Koordinator RT 04 / Driver Ambulans"
                    value={role}
                    onChange={(e) => setRole(e.target.value)}
                    className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Divisi Kepengurusan
                  </label>
                  <select
                    value={division}
                    onChange={(e) => setDivision(e.target.value)}
                    className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500 font-semibold text-slate-700"
                  >
                    {DIVISIONS.filter(d => d !== 'Semua Divisi').map(d => (
                      <option key={d} value={d}>{d}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Nomor WhatsApp / HP <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="081234567890"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500 font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Status Dinas / Tugas
                  </label>
                  <select
                    value={dutyStatus}
                    onChange={(e) => setDutyStatus(e.target.value as any)}
                    className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500 font-bold text-slate-700"
                  >
                    <option value="Siaga 24 Jam">🔴 Siaga 24 Jam (Darurat Kematian & Ambulans)</option>
                    <option value="Aktif">🟢 Aktif Reguler</option>
                    <option value="Tugas Khusus">🔵 Tugas Khusus / Insidental</option>
                  </select>
                </div>
              </div>

              {/* RT Assignment */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  Wilayah Binaan RT
                </label>
                <div className="flex flex-wrap gap-1.5">
                  {['Semua RT', 'RT 01', 'RT 02', 'RT 03', 'RT 04', 'RT 05', 'RT 06', 'RT 07', 'RT 08'].map((rt) => {
                    const isSelected = selectedRts.includes(rt);
                    return (
                      <button
                        key={rt}
                        type="button"
                        onClick={() => toggleRtSelection(rt)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                          isSelected
                            ? 'bg-emerald-600 text-white shadow-xs'
                            : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                        }`}
                      >
                        {rt}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Foto Profil Pengurus */}
              <div className="space-y-3 p-3.5 bg-slate-50 rounded-2xl border border-slate-200/80">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                    <Camera className="w-4 h-4 text-emerald-600" />
                    <span>Foto Profil Pengurus</span>
                  </label>
                  {photo && (
                    <button
                      type="button"
                      onClick={() => setPhoto('')}
                      className="text-[11px] font-bold text-rose-600 hover:text-rose-700 flex items-center gap-1 cursor-pointer"
                    >
                      <RotateCcw className="w-3 h-3" />
                      <span>Hapus Foto (Gunakan Inisial)</span>
                    </button>
                  )}
                </div>

                <div className="flex items-center gap-3.5">
                  {/* Preview Avatar */}
                  <div className="relative w-16 h-16 rounded-2xl overflow-hidden border-2 border-emerald-500/50 shadow-sm shrink-0 bg-white">
                    {photo ? (
                      <img
                        src={getDirectImageUrl(photo)}
                        alt="Preview"
                        className="w-full h-full object-cover"
                        onError={(e) => {
                          (e.currentTarget as HTMLElement).style.display = 'none';
                        }}
                      />
                    ) : (
                      <div className="w-full h-full bg-emerald-700 text-white flex items-center justify-center font-black text-xl">
                        {name.trim() ? name.charAt(0) : <User className="w-8 h-8" />}
                      </div>
                    )}
                  </div>

                  <div className="flex-1 space-y-2">
                    <input
                      type="file"
                      ref={modalFileInputRef}
                      accept="image/*"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) handleProcessImageFile(file, (dataUrl) => setPhoto(dataUrl));
                      }}
                      className="hidden"
                    />
                    <button
                      type="button"
                      onClick={() => modalFileInputRef.current?.click()}
                      className="w-full py-2 px-3 bg-white hover:bg-emerald-50 border border-emerald-300 text-emerald-700 font-bold text-xs rounded-xl flex items-center justify-center gap-2 shadow-xs transition-colors cursor-pointer"
                    >
                      <Upload className="w-4 h-4" />
                      <span>Unggah Berkas Foto (Galeri / Kamera)</span>
                    </button>

                    <div className="flex items-center gap-1.5">
                      <Link className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <input
                        type="text"
                        placeholder="Atau tempel URL foto online (Google Drive / Imgur)..."
                        value={photo.startsWith('data:') ? '(Foto Berkas Lokal Dipilih)' : photo}
                        onChange={(e) => setPhoto(e.target.value)}
                        disabled={photo.startsWith('data:')}
                        className="w-full px-2.5 py-1 text-[11px] bg-white border border-slate-200 rounded-lg outline-none focus:border-emerald-500 font-sans"
                      />
                    </div>
                  </div>
                </div>

                <div>
                  <span className="block text-[11px] font-bold text-slate-500 mb-1">
                    Atau Pilih Avatar Default:
                  </span>
                  <div className="flex items-center gap-2 overflow-x-auto py-1">
                    {PRESET_AVATARS.map((url, idx) => (
                      <img
                        key={idx}
                        src={url}
                        alt={`avatar-${idx}`}
                        onClick={() => setPhoto(url)}
                        className={`w-9 h-9 rounded-xl object-cover cursor-pointer border-2 transition-all shrink-0 ${
                          photo === url ? 'border-emerald-600 scale-105 shadow-md ring-2 ring-emerald-500/20' : 'border-transparent opacity-60 hover:opacity-100'
                        }`}
                      />
                    ))}
                  </div>
                </div>
              </div>

              {/* Create System User Checkbox (Only for new) */}
              {!editingOfficer && (
                <div className="p-3.5 bg-indigo-50/80 rounded-2xl border border-indigo-100 space-y-2">
                  <label className="flex items-center gap-2.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={createSystemAccount}
                      onChange={(e) => setCreateSystemAccount(e.target.checked)}
                      className="w-4 h-4 text-indigo-600 rounded border-slate-300 focus:ring-indigo-500"
                    />
                    <span className="text-xs font-extrabold text-indigo-900">
                      Buatkan Akun Login Pengurus Sekaligus di Sistem
                    </span>
                  </label>
                  
                  {createSystemAccount && (
                    <div className="pt-2 flex items-center justify-between text-xs text-indigo-800">
                      <span>Peran Hak Akses:</span>
                      <select
                        value={accountRole}
                        onChange={(e) => setAccountRole(e.target.value as any)}
                        className="px-2.5 py-1 bg-white border border-indigo-200 rounded-lg text-xs font-bold text-indigo-900"
                      >
                        <option value="petugas">Petugas Lapangan / Satgas</option>
                        <option value="bendahara">Bendahara / Admin Utama</option>
                        <option value="ketua">Ketua Paguyuban</option>
                      </select>
                    </div>
                  )}
                </div>
              )}

              <div className="flex items-center justify-end gap-2.5 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs transition-colors"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs shadow-md shadow-emerald-900/20 transition-all"
                >
                  {editingOfficer ? 'Simpan Perubahan' : 'Tambahkan Pengurus'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ================= MODAL CETAK SK PENGURUS ================= */}
      {showSkModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-3xl w-full p-8 shadow-2xl border border-slate-200 my-8 text-slate-900">
            {/* Header Actions */}
            <div className="flex items-center justify-between pb-4 border-b border-slate-200 print:hidden">
              <div className="flex items-center gap-2">
                <Printer className="w-5 h-5 text-indigo-600" />
                <span className="font-extrabold text-sm text-slate-800">Preview Surat Keputusan (SK) Pengurus</span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl shadow flex items-center gap-1.5"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Cetak / Simpan PDF</span>
                </button>
                <button
                  type="button"
                  onClick={() => setShowSkModal(false)}
                  className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Printable Content */}
            <div className="mt-6 space-y-6 text-xs sm:text-sm font-serif">
              {/* Kop Surat */}
              <div className="text-center border-b-2 border-slate-900 pb-4 space-y-1">
                <h2 className="text-lg sm:text-xl font-bold uppercase tracking-wider text-slate-900">
                  PAGUYUBAN RUKUN KEMATIAN MUSLIM (RKM)
                </h2>
                <h3 className="text-base sm:text-lg font-bold text-emerald-800 uppercase">
                  {settings.orgName}
                </h3>
                <p className="text-xs font-sans text-slate-600">
                  Sekretariat: {settings.rtRw}, {settings.village}, {settings.district}, {settings.regency}
                </p>
                <p className="text-xs font-sans text-slate-600 font-mono">
                  Layanan Darurat: {settings.contactCenter} | Email: {settings.email}
                </p>
              </div>

              {/* Title of SK */}
              <div className="text-center space-y-1 font-sans">
                <h4 className="font-black text-sm uppercase tracking-wider underline">
                  SURAT KEPUTUSAN KETUA PAGUYUBAN RKM MPP
                </h4>
                <p className="text-xs text-slate-600 font-mono">
                  Nomor: 014/SK-RKM-MPP/VIII/2024
                </p>
                <p className="text-xs font-semibold text-slate-800">
                  Tentang: Susunan Pengurus & Satgas Pemulasaraan Jenazah Periode 2024–2027
                </p>
              </div>

              {/* Table of Officers */}
              <div className="font-sans">
                <table className="w-full border-collapse border border-slate-300 text-xs">
                  <thead>
                    <tr className="bg-slate-100 text-slate-800">
                      <th className="border border-slate-300 px-3 py-2 text-center w-10">No</th>
                      <th className="border border-slate-300 px-3 py-2 text-left">Nama Lengkap</th>
                      <th className="border border-slate-300 px-3 py-2 text-left">Jabatan</th>
                      <th className="border border-slate-300 px-3 py-2 text-left">Wilayah Tugas</th>
                      <th className="border border-slate-300 px-3 py-2 text-left">No. Telepon / WA</th>
                    </tr>
                  </thead>
                  <tbody>
                    {officers.map((ofc, idx) => (
                      <tr key={ofc.id} className="hover:bg-slate-50">
                        <td className="border border-slate-300 px-3 py-2 text-center font-bold">{idx + 1}</td>
                        <td className="border border-slate-300 px-3 py-2 font-bold text-slate-900">{ofc.name}</td>
                        <td className="border border-slate-300 px-3 py-2 text-emerald-800 font-semibold">{ofc.role}</td>
                        <td className="border border-slate-300 px-3 py-2">{ofc.rtAssigned.join(', ')}</td>
                        <td className="border border-slate-300 px-3 py-2 font-mono">{ofc.phone}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Signatures */}
              <div className="grid grid-cols-2 gap-8 pt-8 font-sans text-center text-xs">
                <div>
                  <p className="text-slate-600">Mengetahui,</p>
                  <p className="font-bold text-slate-900 mt-1">Ketua DKM Masjid Metro Parung Panjang</p>
                  <div className="h-16 flex items-center justify-center">
                    <span className="text-[10px] text-slate-400 italic">( Tanda Tangan & Stempel )</span>
                  </div>
                  <p className="font-bold text-slate-900 underline">K.H. Ahmad Syahid, Lc.</p>
                </div>

                <div>
                  <p className="text-slate-600">Ditetapkan di Parung Panjang, {formatDateIndo('2024-01-10')}</p>
                  <p className="font-bold text-slate-900 mt-1">Ketua Paguyuban RKM MPP</p>
                  <div className="h-16 flex items-center justify-center">
                    <span className="text-[10px] text-slate-400 italic">( Tanda Tangan Digital Resmi )</span>
                  </div>
                  <p className="font-bold text-slate-900 underline">{settings.chairmanName}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ================= MODAL CEPAT GANTI FOTO PENGURUS ================= */}
      {photoModalOfficer && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto animate-fade-in">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-100 space-y-4 my-8">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <span className="p-2 bg-emerald-100 text-emerald-700 rounded-xl">
                  <Camera className="w-5 h-5" />
                </span>
                <div>
                  <h3 className="font-extrabold text-slate-900 text-sm sm:text-base">
                    Ganti Foto Pengurus
                  </h3>
                  <p className="text-xs text-slate-500 truncate max-w-[220px]">
                    {photoModalOfficer.name} ({photoModalOfficer.role})
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setPhotoModalOfficer(null)}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-xl"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Big Preview */}
            <div className="flex flex-col items-center justify-center p-4 bg-slate-50 rounded-2xl border border-slate-200/80">
              <div className="w-24 h-24 rounded-3xl overflow-hidden border-4 border-white shadow-md bg-emerald-700 text-white flex items-center justify-center font-black text-3xl shrink-0 mb-2 relative">
                {quickPhotoValue ? (
                  <img
                    src={getDirectImageUrl(quickPhotoValue)}
                    alt={photoModalOfficer.name}
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      (e.currentTarget as HTMLElement).style.display = 'none';
                    }}
                  />
                ) : (
                  <span>{photoModalOfficer.name.charAt(0)}</span>
                )}
              </div>
              <span className="text-xs font-bold text-slate-700">
                {quickPhotoValue ? 'Pratinjau Foto Terpasang' : 'Menggunakan Icon Inisial'}
              </span>
              {quickPhotoValue && (
                <button
                  type="button"
                  onClick={() => {
                    setQuickPhotoValue('');
                    setCustomUrlInput('');
                  }}
                  className="mt-1 text-[11px] font-bold text-rose-600 hover:text-rose-700 flex items-center gap-1 cursor-pointer"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span>Hapus Foto (Gunakan Inisial)</span>
                </button>
              )}
            </div>

            {/* Upload Button */}
            <input
              type="file"
              ref={quickPhotoFileInputRef}
              accept="image/*"
              onChange={(e) => {
                const file = e.target.files?.[0];
                if (file) {
                  handleProcessImageFile(file, (dataUrl) => {
                    setQuickPhotoValue(dataUrl);
                  });
                }
              }}
              className="hidden"
            />

            <div className="space-y-2.5">
              <button
                type="button"
                onClick={() => quickPhotoFileInputRef.current?.click()}
                className="w-full py-2.5 px-4 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs sm:text-sm rounded-xl flex items-center justify-center gap-2 shadow-sm transition-all cursor-pointer"
              >
                <Upload className="w-4 h-4" />
                <span>Pilih Foto dari Galeri / Kamera</span>
              </button>

              <div className="relative">
                <input
                  type="text"
                  placeholder="Atau tempel tautan URL foto gambar..."
                  value={customUrlInput}
                  onChange={(e) => {
                    setCustomUrlInput(e.target.value);
                    setQuickPhotoValue(e.target.value);
                  }}
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs outline-none focus:border-emerald-500 font-sans"
                />
              </div>

              <div>
                <span className="block text-[11px] font-bold text-slate-500 mb-1.5">
                  Pilihan Avatar Default:
                </span>
                <div className="flex items-center gap-2 overflow-x-auto py-1">
                  {PRESET_AVATARS.map((url, idx) => (
                    <img
                      key={idx}
                      src={url}
                      alt={`Avatar ${idx}`}
                      onClick={() => {
                        setQuickPhotoValue(url);
                        setCustomUrlInput('');
                      }}
                      className={`w-10 h-10 rounded-xl object-cover cursor-pointer border-2 transition-all shrink-0 ${
                        quickPhotoValue === url ? 'border-emerald-600 scale-105 shadow-md ring-2 ring-emerald-500/20' : 'border-transparent opacity-60 hover:opacity-100'
                      }`}
                    />
                  ))}
                </div>
              </div>
            </div>

            {/* Action buttons */}
            <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setPhotoModalOfficer(null)}
                className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100 transition-colors"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleSaveQuickPhoto}
                className="px-5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-black rounded-xl shadow-sm flex items-center gap-1.5 transition-all cursor-pointer"
              >
                <Check className="w-4 h-4" />
                <span>Terapkan & Simpan Foto</span>
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
