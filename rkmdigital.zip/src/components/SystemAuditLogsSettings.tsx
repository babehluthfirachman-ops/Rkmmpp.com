import React, { useState, useMemo } from 'react';
import { 
  Activity, 
  Search, 
  Filter, 
  Trash2, 
  Download, 
  RefreshCw, 
  ShieldCheck, 
  AlertTriangle, 
  CheckCircle2, 
  XCircle, 
  User, 
  Clock, 
  FileSpreadsheet, 
  Sliders, 
  Eye,
  Info
} from 'lucide-react';
import { useRkm } from '../context/RkmContext';
import { AccessAuditLog } from '../types';

export const SystemAuditLogsSettings: React.FC = () => {
  const { auditLogs, clearAuditLogs, securityPolicy, updateSecurityPolicy } = useRkm();

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [selectedLogDetail, setSelectedLogDetail] = useState<AccessAuditLog | null>(null);

  // Filtered logs
  const filteredLogs = useMemo(() => {
    return auditLogs.filter(log => {
      const matchSearch = 
        log.userName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        log.action.toLowerCase().includes(searchTerm.toLowerCase()) ||
        log.details.toLowerCase().includes(searchTerm.toLowerCase()) ||
        log.ipAddress.toLowerCase().includes(searchTerm.toLowerCase()) ||
        log.userRole.toLowerCase().includes(searchTerm.toLowerCase());

      const matchCategory = selectedCategory === 'all' || 
        (selectedCategory === 'auth' && (log.action.toLowerCase().includes('login') || log.action.toLowerCase().includes('logout') || log.action.toLowerCase().includes('auth'))) ||
        (selectedCategory === 'finance' && (log.action.toLowerCase().includes('kas') || log.action.toLowerCase().includes('iuran') || log.action.toLowerCase().includes('transaksi') || log.action.toLowerCase().includes('uang'))) ||
        (selectedCategory === 'citizen' && (log.action.toLowerCase().includes('warga') || log.action.toLowerCase().includes('kk') || log.action.toLowerCase().includes('anggota'))) ||
        (selectedCategory === 'duka' && (log.action.toLowerCase().includes('duka') || log.action.toLowerCase().includes('jenazah') || log.action.toLowerCase().includes('santunan') || log.action.toLowerCase().includes('lelayu'))) ||
        (selectedCategory === 'security' && (log.action.toLowerCase().includes('akses') || log.action.toLowerCase().includes('user') || log.action.toLowerCase().includes('role') || log.action.toLowerCase().includes('password') || log.action.toLowerCase().includes('kebijakan') || log.action.toLowerCase().includes('pin')));

      const matchStatus = selectedStatus === 'all' || log.status === selectedStatus;

      return matchSearch && matchCategory && matchStatus;
    });
  }, [auditLogs, searchTerm, selectedCategory, selectedStatus]);

  // Summary Metrics
  const totalCount = auditLogs.length;
  const successCount = auditLogs.filter(l => l.status === 'Success').length;
  const warningCount = auditLogs.filter(l => l.status === 'Warning').length;
  const failedCount = auditLogs.filter(l => l.status === 'Failed').length;

  // Export CSV
  const handleExportCSV = () => {
    if (auditLogs.length === 0) {
      alert('Tidak ada log untuk diekspor.');
      return;
    }

    const headers = ['ID', 'Waktu (WIB)', 'Pengguna', 'Role', 'Aksi', 'Rincian', 'IP/Perangkat', 'Status'];
    const rows = auditLogs.map(l => [
      l.id,
      `"${l.timestamp}"`,
      `"${l.userName}"`,
      `"${l.userRole}"`,
      `"${l.action}"`,
      `"${l.details.replace(/"/g, '""')}"`,
      `"${l.ipAddress}"`,
      `"${l.status}"`
    ]);

    const csvContent = "data:text/csv;charset=utf-8," + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `AUDIT_LOG_RKM_MPP_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    link.remove();
  };

  return (
    <div className="space-y-6">
      
      {/* Header & Quick Action Bar */}
      <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/80 shadow-sm space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-indigo-50 text-indigo-700 flex items-center justify-center font-bold">
              <Activity className="w-6 h-6" />
            </div>
            <div>
              <h2 className="font-extrabold text-base sm:text-lg text-slate-900">
                Log Audit & Riwayat Keamanan Sistem
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Pemantauan kronologis aktivitas otentikasi, mutasi kas, perubahan data warga, dan event otorisasi Super Admin.
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={handleExportCSV}
              className="flex items-center gap-1.5 px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition-all border border-slate-200"
            >
              <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
              <span>Ekspor CSV</span>
            </button>
            <button
              onClick={() => {
                if (confirm('PERINGATAN: Apakah Anda yakin ingin mengosongkan seluruh riwayat log aktivitas audit sistem?')) {
                  clearAuditLogs();
                }
              }}
              className="flex items-center gap-1.5 px-3.5 py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 text-xs font-bold rounded-xl transition-all border border-rose-200"
            >
              <Trash2 className="w-4 h-4 text-rose-600" />
              <span>Bersihkan Log</span>
            </button>
          </div>
        </div>

        {/* 4 Summary Stat Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5">
          <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200/80 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-slate-200 text-slate-700 flex items-center justify-center shrink-0">
              <Clock className="w-5 h-5" />
            </div>
            <div>
              <div className="text-[11px] text-slate-500 font-bold uppercase">Total Rekaman Log</div>
              <div className="text-lg font-black text-slate-900">{totalCount} Event</div>
            </div>
          </div>

          <div className="p-4 bg-emerald-50/60 rounded-2xl border border-emerald-200 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0">
              <CheckCircle2 className="w-5 h-5" />
            </div>
            <div>
              <div className="text-[11px] text-emerald-800 font-bold uppercase">Aktivitas Berhasil</div>
              <div className="text-lg font-black text-emerald-950">{successCount} Event</div>
            </div>
          </div>

          <div className="p-4 bg-amber-50/60 rounded-2xl border border-amber-200 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500 text-white flex items-center justify-center shrink-0">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <div className="text-[11px] text-amber-800 font-bold uppercase">Peringatan / Warning</div>
              <div className="text-lg font-black text-amber-950">{warningCount} Event</div>
            </div>
          </div>

          <div className="p-4 bg-purple-50/60 rounded-2xl border border-purple-200 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-purple-600 text-white flex items-center justify-center shrink-0">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="text-[11px] text-purple-800 font-bold uppercase">Pencatatan Audit Trail</div>
              <div className="text-sm font-black text-purple-950">
                {securityPolicy?.enableAuditLogging ? 'Aktif (Real-Time)' : 'Nonaktif'}
              </div>
            </div>
          </div>
        </div>

        {/* Filter Bar */}
        <div className="p-4 bg-slate-50/80 rounded-2xl border border-slate-200 space-y-3">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            
            {/* Search Input */}
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
              <input
                type="text"
                placeholder="Cari user, aksi, rincian, IP..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-9 pr-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-semibold text-slate-900 focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            {/* Category Filter */}
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="p-2 bg-white border border-slate-300 rounded-xl text-xs font-bold text-slate-800 focus:ring-2 focus:ring-emerald-500"
            >
              <option value="all">Semua Kategori Aktivitas</option>
              <option value="auth">🔐 Otentikasi & Login Pengguna</option>
              <option value="finance">💰 Keuangan, Mutasi Kas & Iuran</option>
              <option value="citizen">👥 Data Warga & Anggota</option>
              <option value="duka">🖤 Layanan Duka & Pemakaman</option>
              <option value="security">🛡️ Hak Akses, Akun & Keamanan</option>
            </select>

            {/* Status Filter */}
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="p-2 bg-white border border-slate-300 rounded-xl text-xs font-bold text-slate-800 focus:ring-2 focus:ring-emerald-500"
            >
              <option value="all">Semua Status (Sukses/Warning/Gagal)</option>
              <option value="Success">✓ Sukses (Success)</option>
              <option value="Warning">⚠ Peringatan (Warning)</option>
              <option value="Failed">✕ Gagal (Failed)</option>
            </select>

          </div>

          <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1">
            <span>Menampilkan <strong>{filteredLogs.length}</strong> dari total {auditLogs.length} catatan audit log</span>
            {(searchTerm || selectedCategory !== 'all' || selectedStatus !== 'all') && (
              <button
                onClick={() => {
                  setSearchTerm('');
                  setSelectedCategory('all');
                  setSelectedStatus('all');
                }}
                className="text-emerald-700 font-bold hover:underline"
              >
                Reset Filter
              </button>
            )}
          </div>
        </div>

        {/* Audit Log Table */}
        <div className="overflow-x-auto rounded-2xl border border-slate-200">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-100/90 text-slate-700 font-extrabold border-b border-slate-200">
                <th className="p-3.5 pl-4 whitespace-nowrap">Waktu (WIB)</th>
                <th className="p-3.5 whitespace-nowrap">Pengguna & Peran</th>
                <th className="p-3.5 whitespace-nowrap">Aksi Sistem</th>
                <th className="p-3.5 min-w-[280px]">Rincian Aktivitas</th>
                <th className="p-3.5 whitespace-nowrap">Perangkat / IP</th>
                <th className="p-3.5 text-center whitespace-nowrap">Status</th>
                <th className="p-3.5 text-center whitespace-nowrap">Detail</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium">
              {filteredLogs.map((log) => {
                const isSuperAdmin = log.userRole?.toLowerCase().includes('super') || log.userName?.toLowerCase().includes('admin');
                const isTreasurer = log.userRole?.toLowerCase().includes('bendahara');
                
                return (
                  <tr key={log.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="p-3.5 pl-4 whitespace-nowrap text-slate-500 font-mono text-[11px]">
                      {log.timestamp}
                    </td>
                    <td className="p-3.5 whitespace-nowrap">
                      <div className="flex items-center gap-2">
                        <div className={`w-7 h-7 rounded-lg flex items-center justify-center font-bold text-xs shrink-0 ${
                          isSuperAdmin ? 'bg-purple-100 text-purple-800' :
                          isTreasurer ? 'bg-amber-100 text-amber-800' :
                          'bg-emerald-100 text-emerald-800'
                        }`}>
                          <User className="w-3.5 h-3.5" />
                        </div>
                        <div>
                          <span className="font-bold text-slate-900 block text-xs">{log.userName}</span>
                          <span className="text-[10px] text-slate-400 capitalize font-medium">{log.userRole}</span>
                        </div>
                      </div>
                    </td>
                    <td className="p-3.5 whitespace-nowrap">
                      <span className="px-2.5 py-1 rounded-lg bg-slate-100 text-slate-800 font-mono font-bold text-[10px] border border-slate-200">
                        {log.action}
                      </span>
                    </td>
                    <td className="p-3.5 text-slate-700 text-xs leading-relaxed">
                      {log.details}
                    </td>
                    <td className="p-3.5 whitespace-nowrap text-slate-500 text-[11px] font-mono">
                      {log.ipAddress || 'Internal Web'}
                    </td>
                    <td className="p-3.5 text-center whitespace-nowrap">
                      <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-black ${
                        log.status === 'Success' 
                          ? 'bg-emerald-100 text-emerald-800 border border-emerald-200' 
                          : log.status === 'Warning' 
                            ? 'bg-amber-100 text-amber-800 border border-amber-200' 
                            : 'bg-rose-100 text-rose-800 border border-rose-200'
                      }`}>
                        {log.status === 'Success' && <CheckCircle2 className="w-3 h-3" />}
                        {log.status === 'Warning' && <AlertTriangle className="w-3 h-3" />}
                        {log.status === 'Failed' && <XCircle className="w-3 h-3" />}
                        <span>{log.status}</span>
                      </span>
                    </td>
                    <td className="p-3.5 text-center whitespace-nowrap">
                      <button
                        onClick={() => setSelectedLogDetail(log)}
                        className="p-1.5 hover:bg-slate-200 text-slate-600 rounded-lg transition-colors"
                        title="Lihat Detail Log"
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {filteredLogs.length === 0 && (
          <div className="p-12 text-center bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
            <Activity className="w-8 h-8 text-slate-400 mx-auto" />
            <p className="text-slate-600 font-bold text-xs">Tidak ada catatan audit log yang cocok dengan filter.</p>
            <p className="text-[11px] text-slate-400">Silakan ubah kata kunci pencarian atau reset filter kategori.</p>
          </div>
        )}

      </div>

      {/* MODAL: DETAIL AUDIT LOG */}
      {selectedLogDetail && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 animate-scale-up space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Info className="w-5 h-5 text-indigo-600" />
                <h3 className="font-black text-base text-slate-900">Rincian Catatan Audit Log</h3>
              </div>
              <button 
                onClick={() => setSelectedLogDetail(null)}
                className="w-8 h-8 rounded-full bg-slate-100 text-slate-500 hover:bg-slate-200 flex items-center justify-center font-bold"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="p-3 bg-slate-50 rounded-xl space-y-1">
                <span className="text-[10px] text-slate-400 font-bold uppercase">Log ID:</span>
                <p className="font-mono text-slate-800 font-bold">{selectedLogDetail.id}</p>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="p-3 bg-slate-50 rounded-xl space-y-1">
                  <span className="text-[10px] text-slate-400 font-bold uppercase">Waktu Kejadian:</span>
                  <p className="font-semibold text-slate-900">{selectedLogDetail.timestamp}</p>
                </div>
                <div className="p-3 bg-slate-50 rounded-xl space-y-1">
                  <span className="text-[10px] text-slate-400 font-bold uppercase">Status:</span>
                  <p className={`font-black ${
                    selectedLogDetail.status === 'Success' ? 'text-emerald-700' :
                    selectedLogDetail.status === 'Warning' ? 'text-amber-700' : 'text-rose-700'
                  }`}>
                    {selectedLogDetail.status}
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="p-3 bg-slate-50 rounded-xl space-y-1">
                  <span className="text-[10px] text-slate-400 font-bold uppercase">Pengguna:</span>
                  <p className="font-bold text-slate-900">{selectedLogDetail.userName}</p>
                  <p className="text-[10px] text-slate-500 capitalize">{selectedLogDetail.userRole}</p>
                </div>
                <div className="p-3 bg-slate-50 rounded-xl space-y-1">
                  <span className="text-[10px] text-slate-400 font-bold uppercase">IP / Sesi:</span>
                  <p className="font-mono text-slate-800">{selectedLogDetail.ipAddress || 'Internal Web'}</p>
                </div>
              </div>

              <div className="p-3 bg-slate-50 rounded-xl space-y-1">
                <span className="text-[10px] text-slate-400 font-bold uppercase">Aksi Sistem:</span>
                <p className="font-mono font-bold text-emerald-800">{selectedLogDetail.action}</p>
              </div>

              <div className="p-3.5 bg-emerald-50/50 border border-emerald-100 rounded-xl space-y-1">
                <span className="text-[10px] text-emerald-900 font-bold uppercase">Deskripsi & Payload:</span>
                <p className="text-slate-800 leading-relaxed font-medium">{selectedLogDetail.details}</p>
              </div>
            </div>

            <div className="flex justify-end pt-2">
              <button
                type="button"
                onClick={() => setSelectedLogDetail(null)}
                className="px-5 py-2 bg-slate-800 text-white font-bold text-xs rounded-xl"
              >
                Tutup
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
