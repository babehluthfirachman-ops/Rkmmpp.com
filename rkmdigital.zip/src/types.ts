export type UserRole = 'superadmin' | 'ketua' | 'bendahara' | 'koordinator' | 'petugas' | 'tim_jenazah' | 'warga';

export interface UserProfile {
  id: string;
  username: string;
  name: string;
  role: UserRole;
  phone: string;
  email?: string;
  password?: string;
  status?: 'Aktif' | 'Nonaktif' | 'Terkunci';
  noKK?: string;
  rt?: string;
  rw?: string;
  avatar?: string;
  title?: string;
  lastLogin?: string;
  createdAt?: string;
  assignedBlocks?: string[]; // Wilayah / Blok binaan khusus koordinator
  customPermissions?: string[];
}

export interface SystemPermission {
  id: string;
  category: 'Kas & Keuangan' | 'Data Warga' | 'Layanan Duka & Santunan' | 'Logistik & Aset' | 'Pengaturan & Keamanan';
  label: string;
  description: string;
  defaultRoles: UserRole[];
}

export interface SecurityPolicy {
  sessionTimeoutHours: number;
  allowCitizenNoKkLogin: boolean;
  requireTwoFactorForAdmin: boolean;
  pinLength: number;
  autoLockFailedAttempts: number;
  enforceStrongPassword: boolean;
  enableAuditLogging: boolean;
}

export interface SmtpConfig {
  host: string;
  port: number;
  secure: boolean;
  username: string;
  password?: string;
  senderEmail: string;
  senderName: string;
}

export interface SuperadminSystemSettings {
  // 1. Manajamen Identitas & Brand Aplikasi
  appName: string;
  logoUrl: string;
  faviconUrl: string;
  footerText: string;
  smtp: SmtpConfig;

  // 2. Konfigurasi Sistem OCR & Integrasi
  ocrApiKey: string;
  ocrEndpoint: string;
  googleWorkspaceApiKey: string;
  googleWorkspaceEndpoint: string;
  autoScanCameraOcr: boolean;
  maxUploadFileSizeMb: number;

  // 3. Keamanan & Akses (Security & Access Control)
  maintenanceMode: boolean;
  sessionTimeoutMinutes: number;
  maxLoginAttempts: number;
  passwordMinLength: number;
  passwordRequireSpecialChar: boolean;
  passwordRequireNumber: boolean;

  // 4. Fitur Backup & Metadata
  lastBackupDate?: string;
  updatedAt?: string;
  updatedBy?: string;
}

export interface AccessAuditLog {
  id: string;
  timestamp: string;
  userName: string;
  userRole: string;
  action: string;
  details: string;
  ipAddress: string;
  status: 'Success' | 'Warning' | 'Failed';
}

export type RelationType = 
  | 'Kepala Keluarga' 
  | 'Istri' 
  | 'Suami'
  | 'Anak' 
  | 'Orang Tua' 
  | 'Mertua'
  | 'Adik' 
  | 'Kakak' 
  | 'Saudara'
  | 'Famili Lain';

export type MemberCategory = 'Inti' | 'Tambahan';
export type CommunityType = 'RT' | 'Paguyuban';
export type MemberStatus = 'Hidup' | 'Meninggal' | 'Pindah';
export type GenderType = 'Laki-laki' | 'Perempuan';

export type SocialCategoryType = 
  | 'Umum'
  | 'Yatim' 
  | 'Piatu' 
  | 'Yatim Piatu' 
  | 'Janda' 
  | 'Duda' 
  | 'Lansia' 
  | 'Disabilitas' 
  | 'Dhuafa';

export interface FamilyMember {
  id: string;
  name: string;
  nik: string;
  relation: RelationType;
  category?: MemberCategory; // 'Inti' (Orang tua, anak, istri/suami, mertua) vs 'Tambahan' (Adik, kakak, saudara)
  gender: GenderType;
  birthDate?: string;
  status: MemberStatus;
  socialCategory?: SocialCategoryType;
  notes?: string;
}

export interface MonthPayment {
  paid: boolean;
  paidAt?: string;
  receiptNo?: string;
  amount: number;
  paymentMethod?: 'Tunai' | 'Transfer Bank' | 'QRIS' | 'Kolektif';
  collector?: string;
  infaqAmount?: number;
}

export type CitizenStatusType = 'Aktif' | 'Masa Tenggang' | 'Menunggak' | 'Gugur / Non-Aktif' | 'Non-Aktif' | 'Pindah';

export interface Citizen {
  id: string;
  noKK: string;
  headOfFamily: string;
  nik: string;
  phone: string;
  address: string;
  block?: string; // Blok A s/d Blok Z
  houseNumber?: string;
  communityType?: 'RT' | 'Paguyuban'; // RT atau Paguyuban
  paguyubanName?: string;
  rt: string;
  rw: string;
  joinDate: string;
  status: CitizenStatusType;
  members: FamilyMember[];
  monthlyDues: Record<string, MonthPayment>; // Key: "2026-01", "2026-02", etc.
  assignedCollectorId?: string; // ID atau Username Koordinator Pembayaran (Downline)
  assignedCollectorName?: string; // Nama Koordinator Pembayaran Penanggung Jawab
  avatar?: string; // Foto Profil / KTA Kepala Keluarga
  coordinates?: { lat: number; lng: number }; // Titik Koordinat Rumah untuk Kunjungan Duka / Takziah
  notes?: string;
  // Sinkronisasi Pengurus Terpilih & KTA
  isOfficer?: boolean;
  officerRole?: string;
  officerDutyStatus?: 'Siaga 24 Jam' | 'Aktif' | 'Tugas Khusus';
  officerDivision?: string;
  ktaNumber?: string;
  socialCategories?: SocialCategoryType[];
}

export type TransactionType = 'in' | 'out';

export interface Transaction {
  id: string;
  type: TransactionType;
  category: 
    | 'Iuran Wajib' 
    | 'Infaq / Sedekah' 
    | 'Donasi / Hibah' 
    | 'Santunan Kematian' 
    | 'Perlengkapan Kain Kafan' 
    | 'Gali Kubur / TPU' 
    | 'Operasional Ambulance' 
    | 'Perawatan Aset & Tenda' 
    | 'Konsumsi Takziah' 
    | 'Biaya Operasional Organisasi'
    | 'Dana Talangan Pengurus'
    | 'Pengembalian Talangan'
    | 'Lainnya';
  amount: number;
  date: string;
  description: string;
  recipientOrPayer: string;
  noKK?: string;
  receiptNo?: string;
  paymentMethod: string;
  verifiedBy: string;
  proofUrl?: string;
}

export interface DeathPackageItem {
  id: string;
  name: string;
  amount: number;
}

export interface DeathBudgetBreakdown {
  shroud: number; // 150.000
  bathing: number; // 100.000
  prayer: number; // 450.000
  transport: number; // 200.000
  gravedigger: number; // 800.000
  adminDistrict: number; // 150.000
  tactical: number; // 50.000
}

export interface FamilyAddOnItem {
  id: string;
  name: string;
  cost: number;
  paidByFamily: boolean;
  notes?: string;
}

export interface BridgeFundLoan {
  hasLoan: boolean;
  amount: number;
  lenderName: string;
  lenderRole: string;
  date: string;
  isReimbursed: boolean;
  reimbursementDate?: string;
}

export interface DeathNotice {
  id: string;
  deceasedName: string;
  binBinti: string;
  gender: GenderType;
  age: number;
  noKK: string;
  address: string;
  rt: string;
  rw: string;
  passAwayTime: string;
  passAwayLocation: string;
  funeralTime: string;
  mosqueName: string;
  cemeteryName: string;
  cemeteryType?: 'makam_rkm_gerowong' | 'luar_rkm_nonmuslim';
  contactPerson: string;
  contactPhone: string;
  rkmAssistanceAmount: number;
  shroudsProvided: boolean;
  ambulanceProvided: boolean;
  graveDiggerAssigned: boolean;
  budgetBreakdown?: DeathBudgetBreakdown;
  familyAddOns?: FamilyAddOnItem[];
  bridgeFundLoan?: BridgeFundLoan;
  taskChecklist?: {
    bathingDone: boolean;
    shroudingDone: boolean;
    prayerDone: boolean;
    transportDone: boolean;
    burialDone: boolean;
    adminDone: boolean;
  };
  benefitEligibility?: 'Santunan Penuh' | 'Layanan Tanpa Santunan' | 'Non-Anggota';
  status: 'Aktif' | 'Selesai';
  notes?: string;
  createdAt: string;
}

export interface Asset {
  id: string;
  code: string;
  name: string;
  category: 'Perlengkapan Jenazah' | 'Tenda & Terpal' | 'Kursi & Meja' | 'Sound & Kelistrikan' | 'Kendaraan' | 'Peralatan Makam';
  quantity: number;
  availableQty: number;
  unit: string;
  condition: 'Baik' | 'Perlu Perbaikan' | 'Rusak';
  location: string;
  notes?: string;
}

export interface AssetLoan {
  id: string;
  assetId: string;
  assetName: string;
  borrowerName: string;
  borrowerKK: string;
  borrowerPhone: string;
  borrowDate: string;
  returnDatePlanned: string;
  returnDateActual?: string;
  quantity: number;
  purpose: 'Kematian / Takziah' | 'Hajatan / Pernikahan' | 'Pengajian' | 'Kerja Bakti' | 'Lainnya';
  status: 'Dipinjam' | 'Dikembalikan';
  officerInCharge: string;
}

export interface CemeteryItem {
  id: string;
  name: string;
  location: string;
  isPrimary?: boolean;
  contactPerson?: string;
  phone?: string;
  notes?: string;
}

export interface AmbulanceFleetItem {
  id: string;
  plateNumber: string;
  vehicleModel: string;
  driverName: string;
  driverPhone: string;
  status: 'Siaga 24 Jam' | 'Dalam Tugas' | 'Perawatan / Servis';
  isPrimary?: boolean;
}

export interface BankAccount {
  bank: string;
  accountNumber: string;
  accountHolder: string;
  isPrimary?: boolean;
}

export interface OrganizationSettings {
  orgName: string;
  shortName: string;
  slogan: string;
  legalNumber?: string;
  foundedYear?: string;
  adArtPeriod?: string;
  rtRw: string;
  village: string;
  district: string;
  regency: string;
  province: string;
  postalCode?: string;
  contactCenter: string;
  waAdmin: string;
  email: string;
  websiteUrl?: string;
  qrisCodeUrl?: string;
  qrisMerchantId?: string;
  bankAccounts: BankAccount[];
  duesAmount: number; // e.g. 5000 / month (base fee for 1 KK including core members)
  baseDuesAmount?: number; // e.g. 5000 / month
  extraMemberDuesAmount?: number; // e.g. 3000 / extra member / month
  deathBenefitAmount: number; // e.g. 3000000
  registrationFee: number; // e.g. 50000
  gracePeriodMonths?: number; // e.g. 3
  maxArrearsMonths?: number; // e.g. 3
  
  // Auto-Aging Status Iuran Otomatis
  autoAgingEnabled?: boolean; // Aktifkan Auto-Aging Status Iuran
  autoAgingDueDay?: number; // Tanggal batas waktu pembayaran bulanan (e.g. tanggal 10 atau 20)
  autoAgingGraceMonths?: number; // Jumlah bulan toleransi sebelum status otomatis menjadi Menunggak (default 3)
  lastAutoAgingRun?: string; // Timestamp terakhir auto-aging dijalankan
  
  // Rincian Alokasi Paket Fardhu Kifayah
  deathPackageItems?: DeathPackageItem[];
  deathPackageShroud?: number;
  deathPackageBathing?: number;
  deathPackagePrayer?: number;
  deathPackageTransport?: number;
  deathPackageGravedigger?: number;
  deathPackageAdminDistrict?: number;
  deathPackageTactical?: number;

  // Penandatangan Dokumen Resmi
  treasurerName: string;
  treasurerPhone?: string;
  chairmanName: string;
  chairmanPhone?: string;
  secretaryName: string;
  secretaryPhone?: string;
  advisorName?: string;
  mortuaryCoordinatorName?: string;
  mortuaryCoordinatorPhone?: string;

  // Format Penomoran
  receiptPrefix?: string;
  ktaPrefix?: string;
  lelayuPrefix?: string;

  // Operasional Ambulans & Pemakaman
  ambulancePlate?: string;
  ambulanceDriver1?: string;
  ambulanceDriver2?: string;
  cemeteryName?: string;
  cemeteryLocation?: string;
  cemeteryList?: CemeteryItem[];
  ambulanceFleetList?: AmbulanceFleetItem[];

  // Template Notifikasi WhatsApp
  waTemplateReceipt?: string;
  waTemplateLelayu?: string;
  waTemplateReminder?: string;
  waTemplateWelcome?: string;

  // Master Wilayah
  rwList?: string[];
  rtList?: string[];
  paguyubanList?: string[];
  blockList?: string[];

  // Media & Cloud
  logoUrl?: string;
  stampUrl?: string;
  lastSheetSync?: string;
  lastSheetSyncStatus?: 'Success' | 'Failed' | 'Syncing';
  googleSheetConnected: boolean;
  autoSheetSyncEnabled?: boolean;
  autoSheetSyncIntervalMinutes?: number;
  sheetUrl?: string;
  webhookUrl?: string;

  // Konfigurasi Lengkap Superuser / Sistem
  systemSettings?: AdvancedSystemSettings;
}

export interface AdvancedSystemSettings {
  maintenanceMode?: boolean;
  publicPortalEnabled?: boolean;
  citizenSelfRegistration?: boolean;
  strictNikValidation?: boolean;
  sessionTimeoutMinutes?: number;
  maxLoginAttempts?: number;
  masterPin?: string;
  criticalCashThreshold?: number;
  annualPaymentDiscount?: number;
  monthlyLateFee?: number;
  waGatewayProvider?: 'fonnte' | 'wablas' | 'whacenter' | 'custom';
  waGatewayApiKey?: string;
  waGatewayEndpoint?: string;
  autoSendReceiptWa?: boolean;
  autoBroadcastDeathNotice?: boolean;
  autoSendMonthlyReminder?: boolean;
  auditLogRetentionDays?: number;
  requireTwoFactorAuth?: boolean;
  autoBackupDaily?: boolean;
}

export interface FeedbackMessage {
  id: string;
  citizenName: string;
  noKK: string;
  phone: string;
  category: 'Saran' | 'Pertanyaan' | 'Keluhan' | 'Ucapan Terima Kasih';
  message: string;
  createdAt: string;
  status: 'Baru' | 'Dibaca' | 'Dibalas';
  reply?: string;
}

export interface Officer {
  id: string;
  name: string;
  role: string;
  phone: string;
  rtAssigned: string[];
  photo?: string;
  dutyStatus: 'Siaga 24 Jam' | 'Aktif' | 'Tugas Khusus';
  // Link to Citizen (Pengurus adalah seorang anggota yg terpilih)
  citizenId?: string;
  noKK?: string;
  nik?: string;
  ktaNumber?: string;
  address?: string;
  block?: string;
  houseNumber?: string;
  rt?: string;
  rw?: string;
  division?: string;
  termPeriod?: string; // e.g. 2024–2027
}

export type NotificationCategory = 'iuran' | 'warga' | 'layanan' | 'sistem';
export type NotificationType = 'info' | 'success' | 'warning' | 'urgent';

export interface AppNotification {
  id: string;
  title: string;
  message: string;
  category: NotificationCategory;
  type: NotificationType;
  createdAt: string;
  read: boolean;
  targetRole?: UserRole | 'all';
  targetNoKK?: string;
  linkTab?: string;
  meta?: Record<string, any>;
}

export type ThemeMode = 'light' | 'dark';

export interface DutySchedule {
  id: string;
  date: string; // Format YYYY-MM-DD
  dayName: string; // Senin, Selasa, Rabu, Kamis, Jumat, Sabtu, Minggu
  shiftType: 'Pagi (08:00 - 16:00)' | 'Malam (16:00 - 08:00)' | 'Siaga 24 Jam' | 'Khusus Pemakaman';
  assignedOfficerIds: string[];
  assignedOfficerNames: string[];
  coordinatorName: string;
  coordinatorPhone: string;
  ambulanceDriverName?: string;
  ambulanceDriverPhone?: string;
  graveDiggerName?: string;
  graveDiggerPhone?: string;
  status: 'Siaga' | 'Bertugas' | 'Selesai';
  notes?: string;
}

