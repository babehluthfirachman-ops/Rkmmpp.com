import React, { useState, useEffect } from 'react';
import { RkmProvider, useRkm } from './context/RkmContext';
import { Sidebar } from './components/Sidebar';
import { TopHeader } from './components/TopHeader';
import { DuesManagementView } from './components/DuesManagementView';
import { CashbookView } from './components/CashbookView';
import { CitizensDirectoryView } from './components/CitizensDirectoryView';
import { DeathServicesView } from './components/DeathServicesView';
import { AssetsView } from './components/AssetsView';
import { SettingsView } from './components/SettingsView';
import { ActivityLog } from './components/ActivityLog';
import { AdArtView } from './components/AdArtView';
import { HomeView } from './components/HomeView';
import { LoginPage } from './components/LoginPage';
import { LoadingScreen } from './components/LoadingScreen';
import { ReceiptModal } from './components/ReceiptModal';
import { KtaCardModal } from './components/KtaCardModal';
import { LelayuModal } from './components/LelayuModal';
import { CitizenProfileModal } from './components/CitizenProfileModal';
import { QuickDuesModal } from './components/QuickDuesModal';
import { ReportDeathModal } from './components/ReportDeathModal';
import { FourMonthReportModal } from './components/FourMonthReportModal';
import { UniversalSearchModal } from './components/UniversalSearchModal';
import { isSuperAdmin } from './utils/formatters';
import { 
  HeartHandshake, 
  Phone, 
  Lock, 
  AlertTriangle, 
  ArrowRight
} from 'lucide-react';
import { Citizen } from './types';

const MainAppContent: React.FC = () => {
  const [activeTab, setActiveTab] = useState<string>('beranda');
  const [showSplash, setShowSplash] = useState<boolean>(true);
  
  // Layout states
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Quick Action Modal States
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isQuickDuesOpen, setIsQuickDuesOpen] = useState(false);
  const [isReportDeathOpen, setIsReportDeathOpen] = useState(false);
  const [isFourMonthReportOpen, setIsFourMonthReportOpen] = useState(false);
  const [quickDuesCitizen, setQuickDuesCitizen] = useState<Citizen | null>(null);

  const { settings, currentUser, deathNotices, openLelayuModal } = useRkm();
  const userIsSuperAdmin = isSuperAdmin(currentUser);

  // Keyboard shortcut (Ctrl+K or Cmd+K) for Universal Search
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setIsSearchOpen(prev => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const activeDeaths = deathNotices.filter(d => d.status === 'Aktif');

  // When logged in as specific role on initial success
  const handleLoginSuccess = () => {
    if (currentUser?.role === 'warga') {
      setActiveTab('warga');
    } else {
      setActiveTab('warga');
    }
  };

  const isPublicStandalone = activeTab === 'beranda' || activeTab === 'login';

  return (
    <div className="min-h-screen bg-slate-100/70 dark:bg-slate-950 text-slate-800 dark:text-slate-100 flex flex-col font-sans selection:bg-emerald-500 selection:text-white transition-colors duration-200">
      
      {/* Initial Loading Splash */}
      {showSplash && (
        <LoadingScreen onFinish={() => setShowSplash(false)} minDuration={1000} />
      )}

      {/* BERANDA / HOME VIEW (Stand-alone public news and information portal) */}
      {activeTab === 'beranda' && (
        <HomeView
          onNavigateToLogin={() => setActiveTab('login')}
          onNavigateToTab={(tab) => setActiveTab(tab)}
          onOpenReportDeath={() => setIsReportDeathOpen(true)}
          onOpenQuickDues={() => {
            setQuickDuesCitizen(null);
            setIsQuickDuesOpen(true);
          }}
        />
      )}

      {/* LOGIN VIEW (Stand-alone focused auth page) */}
      {activeTab === 'login' && (
        <div className="min-h-screen flex flex-col justify-center bg-slate-100 dark:bg-slate-950 py-8 px-4">
          <LoginPage 
            onSuccess={handleLoginSuccess} 
            onBackToHome={() => setActiveTab('beranda')} 
          />
        </div>
      )}

      {/* DASHBOARD / AUTHENTICATED INTERNAL APPLICATION LAYOUT */}
      {!isPublicStandalone && (
        <div className="flex-1 flex min-w-0">
          {/* Modern Collapsible Left Sidebar */}
          <Sidebar
            activeTab={activeTab}
            setActiveTab={setActiveTab}
            isCollapsed={sidebarCollapsed}
            setIsCollapsed={setSidebarCollapsed}
            mobileOpen={mobileMenuOpen}
            setMobileOpen={setMobileMenuOpen}
            onOpenFourMonthReport={() => setIsFourMonthReportOpen(true)}
          />

          {/* Main Content Wrapper */}
          <div className={`flex-1 flex flex-col min-w-0 transition-all duration-300 ${
            sidebarCollapsed ? 'lg:pl-20' : 'lg:pl-72'
          }`}>
            
            {/* Top Header Bar */}
            <TopHeader
              onToggleMobileMenu={() => setMobileMenuOpen(!mobileMenuOpen)}
              onOpenSearch={() => setIsSearchOpen(true)}
              onOpenReportDeath={() => setIsReportDeathOpen(true)}
              onOpenQuickDues={() => {
                setQuickDuesCitizen(null);
                setIsQuickDuesOpen(true);
              }}
              setActiveTab={setActiveTab}
            />

            {/* Emergency Running Alert Banner (If Active Death Notice) */}
            {activeDeaths.length > 0 && (
              <div className="bg-gradient-to-r from-rose-900 via-rose-800 to-slate-900 text-white p-3.5 shadow-md border-b border-rose-700/60 no-print animate-fade-in">
                <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
                  <div className="flex items-center gap-2.5">
                    <span className="p-1.5 bg-rose-600 rounded-xl text-white animate-pulse">
                      <AlertTriangle className="w-4 h-4" />
                    </span>
                    <div>
                      <span className="font-extrabold text-rose-200 uppercase tracking-wider text-[11px] block">
                        SIAGA 1 MUSIBAH DUKA CITA (LELAYU AKTIF):
                      </span>
                      <span className="font-bold text-white text-sm">
                        Inna lillahi wa inna ilaihi raji'un — Telah wafat Alm/Almh. <strong>{activeDeaths[0].deceasedName}</strong> ({activeDeaths[0].binBinti})
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 self-end sm:self-center">
                    <button
                      onClick={() => openLelayuModal(activeDeaths[0])}
                      className="px-3 py-1.5 bg-white/10 hover:bg-white/20 text-white rounded-xl text-xs font-bold border border-white/20 flex items-center gap-1.5 transition-all cursor-pointer"
                    >
                      <span>Lihat Maklumat & Broadcast WA</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => setActiveTab('layanan-duka')}
                      className="px-3 py-1.5 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-bold shadow transition-all cursor-pointer"
                    >
                      Task Satgas
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Dynamic Main View */}
            <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
              {activeTab === 'warga' && <CitizensDirectoryView />}
              {activeTab === 'iuran' && <DuesManagementView />}
              {activeTab === 'layanan-duka' && <DeathServicesView />}
              {activeTab === 'buku-kas' && <CashbookView />}
              {activeTab === 'inventaris' && <AssetsView />}
              {activeTab === 'ad-art' && <AdArtView />}
              {activeTab === 'activity-log' && <ActivityLog />}
              {activeTab === 'pengaturan' && (
                userIsSuperAdmin ? (
                  <SettingsView />
                ) : (
                  <div className="bg-white rounded-3xl p-8 text-center max-w-md mx-auto my-12 border border-slate-200/90 shadow-lg animate-fade-in">
                    <div className="w-14 h-14 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center mx-auto mb-3 shadow-inner">
                      <Lock className="w-7 h-7" />
                    </div>
                    <h2 className="text-lg font-black text-slate-900">Akses Terbatas</h2>
                    <p className="text-xs text-slate-600 mt-2 mb-6 leading-relaxed">
                      Halaman <strong>Pengaturan Sistem</strong> hanya dapat diakses oleh akun <strong>Super Admin</strong>.
                    </p>
                    <button
                      onClick={() => setActiveTab('beranda')}
                      className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow-md transition-all active:scale-[0.98] cursor-pointer"
                    >
                      Kembali ke Beranda
                    </button>
                  </div>
                )
              )}
            </main>

            {/* Global Dashboard Footer */}
            <footer className="bg-slate-900 text-slate-400 border-t border-slate-800 py-8 px-4 text-xs no-print mt-auto">
              <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6 text-center md:text-left">
                <div>
                  <div className="flex items-center justify-center md:justify-start gap-2 text-white font-extrabold text-sm">
                    <div className="w-6 h-6 rounded-lg bg-emerald-600 flex items-center justify-center text-white">
                      <HeartHandshake className="w-3.5 h-3.5" />
                    </div>
                    <span>{settings.orgName}</span>
                    <span className="ml-2 text-[10px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded-full border border-emerald-500/30 font-bold">
                      Sistem Digital
                    </span>
                  </div>
                  <p className="text-slate-400 text-[11px] mt-1 max-w-md">
                    Sistem Digitalisasi Kas Rukun Kematian, Transparansi Dana Duka, Kuitansi WhatsApp & Layanan Pemulasaraan Jenazah Terpadu. Berlandaskan <strong>AD/ART RKM MPP 2024–2027</strong>.
                  </p>
                </div>

                <div className="flex flex-col md:items-end text-[11px] space-y-1.5">
                  <div className="flex items-center gap-2 text-slate-300">
                    <Phone className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Satgas Siaga 24 Jam: <strong>{settings.contactCenter}</strong></span>
                  </div>
                  <div className="flex items-center gap-3 text-slate-400">
                    <button 
                      onClick={() => setActiveTab('beranda')} 
                      className="hover:text-emerald-400 hover:underline font-bold text-emerald-400 cursor-pointer"
                    >
                      Beranda Publik
                    </button>
                    <span>•</span>
                    <button 
                      onClick={() => setActiveTab('ad-art')} 
                      className="hover:text-emerald-400 hover:underline font-medium text-slate-300 cursor-pointer"
                    >
                      AD/ART 2024-2027
                    </button>
                    <span>•</span>
                    <button 
                      onClick={() => setIsFourMonthReportOpen(true)} 
                      className="hover:text-emerald-400 hover:underline text-slate-300 cursor-pointer"
                    >
                      Laporan 4-Bulanan
                    </button>
                  </div>
                  <p className="text-slate-500">
                    © 2024–2027 {settings.orgName} • Sistem Kas & Layanan Duka Terpadu
                  </p>
                </div>
              </div>
            </footer>
          </div>
        </div>
      )}

      {/* Global Interactive Modals */}
      <ReceiptModal />
      <KtaCardModal />
      <LelayuModal />
      <CitizenProfileModal />

      {/* Quick Action Modals */}
      <UniversalSearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        onSelectCitizen={(c) => {
          setActiveTab('warga');
        }}
        onQuickPay={(c) => {
          setQuickDuesCitizen(c);
          setIsQuickDuesOpen(true);
        }}
      />

      <QuickDuesModal
        isOpen={isQuickDuesOpen}
        onClose={() => {
          setIsQuickDuesOpen(false);
          setQuickDuesCitizen(null);
        }}
        preselectedCitizen={quickDuesCitizen}
      />

      <ReportDeathModal
        isOpen={isReportDeathOpen}
        onClose={() => setIsReportDeathOpen(false)}
        onNavigateToLogin={() => {
          setIsReportDeathOpen(false);
          setActiveTab('login');
        }}
      />

      <FourMonthReportModal
        isOpen={isFourMonthReportOpen}
        onClose={() => setIsFourMonthReportOpen(false)}
      />

    </div>
  );
};

export default function App() {
  return (
    <RkmProvider>
      <MainAppContent />
    </RkmProvider>
  );
}
